﻿
$Menu_Run_QuickSettingsDefault = @{

    Info =  @{

      # 0 = ''
        1 = ' #DarkGray#======================================================================================================================#'
        2 = "       #Magenta#Quick Settings#DarkGray#: #Magenta#$($L.s1) #White#$($L.s1_1) #DarkGray#| $($L.s1_2)#" # Восстановление всех параметров из всех меню | Кроме некоторых
        3 = "       #DarkGray#$($L.s1_3): #",'& Show-Selected-Users' # Для текущего аккаунта
        4 = "       #DarkGray#$($L.s2): #", '#White#& Run-QuickSettings | -CheckState CurrentPreset -Act Set#'      # Список групп параметров можно изменить в файле пресетов, текущий файл
        5 = ' #DarkGray#======================================================================================================================#'
        6 = ''
    }

    Status = @{

        0 = "       #DarkGray#$($L.s3):#`n"    # Все группы параметров для восстановления

        1 = '& Run-QuickSettings | -CheckState Configs -Act Default'
        2 = ''
        3 = "       #DarkGray#$($L.s3_1):#`n"  # Варианты для выбора
    }

    Options = @{


       1 = "#Magenta# [999]# = #Magenta#$($L.s4)# $($L.s4_1) #DarkGray#| $($L.s4_2)#`n" # Восстановить все параметры | Применить параметры 'По умолчанию' из всех отображённых групп параметров

          2 = "#Cyan# [$($L.s5)]# = #DarkGray#$($L.s5_1)#`n"  # Без ввода = Возврат в Главное Меню
    }

    Selection = @{


      999 = '& Run-QuickSettings | -Options SetConfigs -Act Default'

   'Exit' = "  ◄◄◄ $($L.s5_1)", '$MainMenu'   # Возврат в Главное Меню

    }
}
