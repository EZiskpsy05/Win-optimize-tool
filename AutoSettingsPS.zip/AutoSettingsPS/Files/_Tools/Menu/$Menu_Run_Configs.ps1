﻿
# Перевод из $Lang.$Menu_Run_Configs.s[]

$Menu_Run_Configs = @{

    Info =  @{

      # 0 = ''
        1 = ' #DarkGray#======================================================================================================================#'
        2 = "       #Yellow#Configs-Checks#DarkGray#: #Green#$($L.s1)#DarkGray#, #Cyan#$($L.s1_1) #DarkGray#$($L.s1_2) #Magenta#$($L.s1_3)# $($L.s1_4)#"   # Применение, Проверка или Восстановление настроек
        3 = "       #DarkGray#$($L.s1_5): #",'& Show-Selected-Users' # Для текущего аккаунта
        4 = "       #DarkGray#$($L.s2): #", '#White#& Run-Configs | -CheckState CurrentPreset#' # Список групп параметров можно изменить в файле пресетов, текущий файл:
        5 = ' #DarkGray#======================================================================================================================#'
        6 = ''
    }

    Status = @{

        0 = "       #DarkGray#$($L.s3):#`n"   # Все группы Параметров

        1 = '& Run-Configs | -CheckState ShowScripts'
        2 = ''
        3 = "       #DarkGray#$($L.s4):#`n"   # Варианты для выбора:
    }

    Options = @{

         1 = "#Green#   [1]# = #Green#$($L.s5)# $($L.s5_1)  #DarkGray#| $($L.s5_2)#"    # Применить все параметры | Применить все отображённые группы параметров
         2 = "#Green#   [2]# = #Green#$($L.s6)# $($L.s6_1)  #DarkGray#| $($L.s6_2)#`n"  # Применить выборочно     | С запросом номеров групп параметров

          3 = "#Cyan#   [3]# = #Cyan#$($L.s7)# $($L.s5_1)  #DarkGray#| $($L.s7_1)#"     # Проверить все параметры  | Проверить все отображённые группы параметров
          4 = "#Cyan#   [4]# = #Cyan#$($L.s8)# $($L.s6_1)  #DarkGray#| $($L.s6_2)#`n"   # Проверить выборочно      | С запросом номеров групп параметров

       5 = "#Magenta# [777]# = #Magenta#$($L.s9 )# $($L.s6_1)  #DarkGray#| $($L.s6_2)#"    # Восстановить выборочно      | С запросом номеров групп параметров
       6 = "#Magenta# [999]# = #Magenta#$($L.s10)# $($L.s5_1)  #DarkGray#| $($L.s10_1)#`n" # Восстановить все параметры  | Восстановить 'По умолчанию' из всех отображённых групп параметров

          7 = "#Cyan# [$($L.s11)]# = #DarkGray#$($L.s11_1)#`n"   # Без ввода = Возврат в Главное Меню
    }

    Selection = @{

        1 = '& Run-Configs | -Action Set'
        2 = '& Run-Configs | -Action Set -Select'

        3 = '& Run-Configs | -Action Check'
        4 = '& Run-Configs | -Action Check -Select'


      777 = '& Run-Configs | -Action Default -Select'
      999 = '& Run-Configs | -Action Default'

   'Exit' = "  ◄◄◄ $($L.s11_1)", '$MainMenu'  # Возврат в Главное Меню

    }
}
