﻿
$Menu_Move_Temp_System = @{

    Info =  @{

      # 0 = ''
        1 = ' #DarkGray#======================================================================================================================#'
        2 = "      #Yellow#$($L.s1) #White#$($L.s1_1)#"                       # Изменение расположения системной папки Temp
        3 = "      #DarkGray#$($L.s2) #Blue#$($L.s2_1)#DarkGray#$($L.s2_2)#"  # Возможность создания символической ссылки, вместо папки по умолчанию, для совместимости.
        4 = "      #Magenta#$($L.s3) #DarkGray#$($L.s3_1)#"                   # Закройте все программы перед выполнением! Можно указать одно расположение с папкой Temp пользователя
        5 = "      #DarkGray#$($L.s4): #", '#White#& Run-Configs | -CheckState CurrentPreset#' # Свое расположение можно задать в файле пресетов, текущий файл
        6 = ' #DarkGray#======================================================================================================================#'
        7 = ''
    }

    Status = @{

        1 = "      #DarkGray#$($L.s5):#"     # В данный момент
        2 = "      $($L.s6): ", '& Move-Temp-Folders | -CheckState System'   # Папка Temp
        3 = "      $($L.s7): ", '& Move-Temp-Folders | -CheckSymLink System' # Символ. ссылка

      4 = "`n      #DarkGray#$($L.s8):#`n"   # Варианты для выбора
    }

    Options = @{

        1 = "#Cyan#  [1]# = $($L.s9) #DarkGray#$($L.s9_1): ", '& Move-Temp-Folders | -CheckPreset System'   # Изменить на
        2 = "#Cyan#  [2]# = $($L.s9) #DarkGray#$($L.s9_1): ", '& Move-Temp-Folders | -CheckPreset System',  # Изменить на
                            " #DarkGray#| $($L.s9_2) #Blue#$($L.s9_3) #DarkGray#$($L.s9_4): #Yellow#%SystemRoot%\#Blue#Temp#" # И сделать ссылку вместо

   3 = "`n#Magenta#  [3]# = #Magenta#$($L.s10) #DarkGray#| $($L.s10_1) #White#%SystemRoot%\Temp #DarkGray#| $($L.s10_2)#"  # Восстановить | в ... | По умолчанию

      4 = "`n#Cyan#  [$($L.s11)]# = #DarkGray#$($L.s11_1)#`n" # Без ввода, Возврат в меню Личных Настроек
    }

    Selection = @{

        1 = '& Move-Temp-Folders | -Target System'
        2 = '& Move-Temp-Folders | -Target System -SymLink'
        3 = '& Move-Temp-Folders | -Target System -Default'

   'Exit' = '  ◄◄◄ SelfMenu', '$Menu_SelfMenu'

    }
}
