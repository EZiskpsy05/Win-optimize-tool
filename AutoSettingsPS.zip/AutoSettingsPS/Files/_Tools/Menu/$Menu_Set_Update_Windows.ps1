﻿
$Menu_Set_Update_Windows = @{

    Info =  @{

      # 0 = ''
        1 = ' #DarkGray#======================================================================================================================#'
        2 = "      $($L.s1) #Yellow#$($L.s1_1) #DarkGray#| $($L.s1_2)#"  # Управление Центром Обновлений Windows | Сокращение: ЦО
        3 = "      #DarkGray#$($L.s2)#"                                  # Иногда требуется повторная настройка ЦО после перезагрузки, так как не сразу принимаются параметры
        4 = "      #Blue#$($L.s3)#"                                      # Служба wuauserv нужна для некоторых типов активаций Windows!
        5 = ' #DarkGray#======================================================================================================================#'
        6 = ''
    }

    Status = @{

        1 = "   #White#$($L.s4  ): ", '& Set-Update-Windows | -CheckState Update',    # Режим Обновлений
            "   #White#$($L.s4_1): ", '& Set-Update-Windows | -CheckState Delivery'   # Режим Доставки
        2 = "   #White#$($L.s4_2): ", '& Set-Update-Windows | -CheckState OtherMS',   # Обновлять продукты MS
             "   #Gray#$($L.s4_3): ", '& Set-Update-Windows | -CheckState StubFile'   # Файл-заглушка

      3 = "`n   $($L.s5  ): ", '& Set-Update-Windows | -CheckState HideUpdate',       # Отображение ЦО
            "   $($L.s5_1): ", '& Set-Update-Windows | -CheckState HideDelivery'      # Отображение Доставки

        4 = "   $($L.s6  ): ", '& Check-State-Service | -ServiceName wuauserv -Default Manual -Need Disabled',      # Служба wuauserv ЦО
            "   $($L.s6_1): ", '& Check-State-Service | -ServiceName WaaSMedicSvc -Default Manual -Need Disabled',  # Служба WaaSMedicSvc
            "   $($L.s6_2): ", '& Check-State-Service | -ServiceName DoSvc -Default Manual -Need Disabled'          # Служба DoSvc Доставки

        5 = "   $($L.s7  ): ", '& Check-State-Service | -ServiceName UsoSvc -Default DelayedAuto -Need Disabled',   # Служба UsoSvc
            "   $($L.s7_1): ", '& Check-State-Service | -ServiceName BITS -Default Manual -Need Disabled'           # Служба BITS

      6 = "`n   #DarkGray#$($L.s8):            #",  # Задачи ЦО
             "        Report policies: ",'& Check-State-Task | -TaskName "\Microsoft\Windows\UpdateOrchestrator\Report policies" -Default Enabled -Need Disabled'

        7 = "         Scheduled Start: ",'& Check-State-Task | -TaskName "\Microsoft\Windows\WindowsUpdate\Scheduled Start" -Default Enabled -Need Disabled',
             "        UpdateModelTask: ",'& Check-State-Task | -TaskName "\Microsoft\Windows\UpdateOrchestrator\UpdateModelTask" -Default Enabled -Need Disabled',
            "            USO_UxBroker: ",'& Check-State-Task | -TaskName "\Microsoft\Windows\UpdateOrchestrator\USO_UxBroker" -Default Enabled -Need Disabled'

        8 = "           Schedule Scan: ",'& Check-State-Task | -TaskName "\Microsoft\Windows\UpdateOrchestrator\Schedule Scan" -Default Enabled -Need Disabled',
             "    Schedule Retry Scan: ",'& Check-State-Task | -TaskName "\Microsoft\Windows\UpdateOrchestrator\Schedule Retry Scan" -Default Enabled -Need Disabled',
            "             Backup Scan: ",'& Check-State-Task | -TaskName "\Microsoft\Windows\UpdateOrchestrator\Backup Scan" -Default Enabled -Need Disabled'


        9 = "    Schedule Scan Static: ",'& Check-State-Task | -TaskName "\Microsoft\Windows\UpdateOrchestrator\Schedule Scan Static Task" -Default Enabled -Need Disabled',
             "     PerformRemediation: ",'& Check-State-Task | -TaskName "\Microsoft\Windows\WaaSMedic\PerformRemediation" -Default Disabled -Need Disabled',
            "     Maintenance Install: ",'& Check-State-Task | -TaskName "\Microsoft\Windows\UpdateOrchestrator\Maintenance Install" -Default Disabled -Need Disabled'

       10 = "       AC Power Download: ",'& Check-State-Task | -TaskName "\Microsoft\Windows\UpdateOrchestrator\AC Power Download" -Default Enabled -Need Disabled',
             "       AC Power Install: ",'& Check-State-Task | -TaskName "\Microsoft\Windows\UpdateOrchestrator\AC Power Install" -Default Enabled -Need Disabled',
            "                  Reboot: ",'& Check-State-Task | -TaskName "\Microsoft\Windows\UpdateOrchestrator\Reboot" -Default Disabled -Need Disabled'

     11 = "`n   #DarkGray#$($L.s9):              #DarkGray#$($L.s11):#"  # Обновление языков:      Яз. Задачи:
       12 = "   $($L.s10): ", '& Check-State-Service | -ServiceName LxpSvc -Default Manual -Need Disabled',  # Служба LxpSvc
             "           Installation: ",'& Check-State-Task | -TaskName "\Microsoft\Windows\LanguageComponentsInstaller\Installation" -Default Enabled -Need Disabled',
            "   ReconcileLanguageRes~: ",'& Check-State-Task | -TaskName "\Microsoft\Windows\LanguageComponentsInstaller\ReconcileLanguageResources" -Default Enabled -Need Disabled'
       13 = "                                              Uninstallation: ",'& Check-State-Task | -TaskName "\Microsoft\Windows\LanguageComponentsInstaller\Uninstallation" -Default Enabled -Need Disabled'
      #20 = ""
    }

    Options = @{

        1 = "#Cyan#  [1]# = $($L.s12)"                                    #  [1] = Отключить Обновления Полностью
        2 = "#Cyan#  [2]# = $($L.s13)"                                    #  [2] = Ручная Установка Обновлений
        3 = "#Cyan#  [3]# = $($L.s14)"                                    #  [3] = Проверять и только сообщать о наличии обновлений

    4 = "`n#Yellow#  [4]# = #Yellow#$($L.s15) #DarkGray#| $($L.s15_1)#"   #  [4] = Меню Управления Обновлением Драйверов | Отключить или принудительно запретить обновлять драйвера

      5 = "`n#Cyan#  [9]# = $($L.s15_2) #DarkMagenta#  ◄#Magenta#  [90]# = #Magenta#$($L.s15_3) #DarkGray#| $($L.s15_4)#" #   [9] = Включить обновления для других продуктов MS   ◄ [100] = Отключить | По умолчанию
        6 = "#Cyan# [10]# = $($L.s15_5) #DarkMagenta#  ◄#Magenta# [100]# = #Magenta#$($L.s15_6) #DarkGray#| $($L.s15_7)#" #  [10] = Включить обновления для других продуктов MS   ◄ [100] = Отключить | По умолчанию
  
  7 = "`n#DarkCyan# [11]# = #DarkCyan#$($L.s16) #$($L.s16_1) #DarkGray#| $($L.s16_2)#"  # [11] = Очистить Кэш Обновлений без Журнала | При проблемах обновления (Журнал обновлений останется)
    8 = "#DarkCyan# [12]# = #DarkCyan#$($L.s17) #$($L.s17_1) #DarkGray#| $($L.s17_2)#"  # [12] = Очистить Кэш Обновлений с Журналом  | Полная очистка

      9 = "`n#Cyan# [$($L.s19)]# = #DarkGray#$($L.s19_1)   #Magenta# [999]# = #Magenta#$($L.s18) #DarkGray#| $($L.s18_1)#`n"    # [Без ввода] = Возврат в Главное Меню       [99] = Восстановить все | По умолчанию
    }

    Selection = @{

        1 = '& Set-Update-Windows | -Act Set -Option Disable -ApplyGP'  # -ApplyGP везде в том числе для паузы при запуске из этого меню
        2 = '& Set-Update-Windows | -Act Set -Option Manual  -ApplyGP'
        3 = '& Set-Update-Windows | -Act Set -Option Notify  -ApplyGP'

        4 = "    ► $($L.s15)", '$Menu_Set_Update_Drivers'  # Меню Управления Обновлением Драйверов

        9 = '& Set-Update-Windows | -Act Set     -Option DisableLangUpdate -ApplyGP'
       90 = '& Set-Update-Windows | -Act Default -Option DisableLangUpdate -ApplyGP'

       10 = '& Set-Update-Windows | -Act Set     -Option EnableOtherMS -ApplyGP'
      100 = '& Set-Update-Windows | -Act Default -Option EnableOtherMS -ApplyGP'

       11 = '& Set-Update-Windows | -Act Set -Option ClearCache'
       12 = '& Set-Update-Windows | -Act Set -Option ClearCacheAll'

      999 = '& Set-Update-Windows | -Act Default -ApplyGP'

   'Exit' = "  ◄◄◄ $($L.s19_1)", '$MainMenu'               # Возврат в Главное Меню

    }
}
