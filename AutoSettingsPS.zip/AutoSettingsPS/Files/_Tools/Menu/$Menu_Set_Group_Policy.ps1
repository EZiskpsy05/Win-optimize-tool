﻿
$Menu_Set_Group_Policy = @{

    Info =  @{

      # 0 = ''
        1 = ' #DarkGray#======================================================================================================================#'
        2 = "       $($L.s1) #Yellow#$($L.s1_1)# $($L.s1_2) #Yellow#LGPO.exe #DarkGray#v3.0 $($L.s1_3)#"   # Настройка Групповых Политик с помощью утилиты LGPO.exe v3.0 от MS
        3 = "       #DarkGray#$($L.s2)#"   # Достаточно одного .txt файла формата LGPO для настройки ГП. Параметры будут отображены в оснастке ГП
        4 = "       #DarkGray#$($L.s3)#"   # Параметры будут добавлены/заменены если уже настроены. Файлы комментариев ГП копируются при создании/настройке
        5 = "       #Blue#$($L.s4)#"       # Сброс ГП приведет и к сбросу параметров из других меню, настроенных через LGPO или оснастку ГП
        6 = ' #DarkGray#======================================================================================================================#'
        7 = ''
    }

    Status = @{

        1 = "       #DarkGray#$($L.s5):#"  # В данный момент Групповые Политики
        2 = "       #DarkGray#$($L.s6) #White#$($L.s6_1)#DarkGray#:# ", '& Set-Group-Policy | -CheckState Machine' # Конфигурация для Компьютера
        3 = "       #DarkGray#$($L.s7) #White#$($L.s7_1)#DarkGray#:# ", '& Set-Group-Policy | -CheckState User'    # Конфигурация для Пользователя

      4 = "`n       #DarkGray#$($L.s8):#`n"  # Варианты для выбора
    }

    Options = @{

          1 = "#Cyan#   [1]# = $($L.s9) #",                     '& Set-Group-Policy | -CheckFile FileLGPO'   # Настроить ГП из файла
          2 = "#Cyan#   [2]# = $($L.s10) #White#$($L.s10_1) #", '& Set-Group-Policy | -CheckFile MyFileLGPO' # Настроить ГП Своим файлом

      3 = "`n#DarkCyan# [333]# = #DarkCyan#$($L.s11)# $($L.s11_1) #DarkGray#Files\GP\#LGPO-Machine-User-My.txt #DarkGray#| $($L.s11_2)" # Создать Бэкап настроенных ГП в файл: ... | Существующий файл переименуется

     4 = "`n#Magenta# [999]# = #Magenta#$($L.s12) #DarkGray#| $($L.s12_1)#" # Сброс всех настроек ГП | По умолчанию, кроме настроенных через реестр. Удаляются только файлы .pol

        5 = "`n#Cyan# [$($L.s13)]# = #DarkGray#$($L.s13_1)#`n"  # [Без ввода] = Возврат в Главное Меню
    }

    Selection = @{

        1 = '& Set-Group-Policy | -ApplyGP FileLGPO'
        2 = '& Set-Group-Policy | -ApplyGP MyFileLGPO'
      333 = '& Set-Group-Policy | -CreateFile'
      999 = '& Set-Group-Policy | -Reset'

   'Exit' = "  ◄◄◄ $($L.s13_1)", '$MainMenu'  # Возврат в Главное Меню

    }
}
