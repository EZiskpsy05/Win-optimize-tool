﻿
$Menu_Set_UAC = @{

    Info =  @{

      # 0 = ''
        1 = ' #DarkGray#======================================================================================================================#'
        2 = "      #Yellow#$($L.s1) #DarkGray#| UAC#"  # Контроль учётных записей | UAC
        3 = "      #DarkGray#$($L.s2)#"                # Отключение или автосоглашение UAC ведет к серьезной бреши в безопасности!
        4 = "      #DarkGray#$($L.s3)#"                # Если UAC не отключён, и отключить службу Appinfo, то будет ошибка вместо запроса прав админа!
        5 = "      #Blue#$($L.s4)#"                    # Категорически не рекомендуется отключать или ослаблять UAC!
        6 = ' #DarkGray#======================================================================================================================#'
        7 = ''
    }

    Status = @{

        0 = "  #DarkGray#$($L.s5):#"                                  # В данный момент

        1 = "  $($L.s6 ): ", '& Set-UAC | -CheckState UAC'            # Режим UAC

      2 = "`n  $($L.s7 ): ", '& Check-State-Driver | -DriverName luafv -Default Automatic -Need Automatic',  # Драйвер UAC luafv
                          "$($L.s7_1): ", '& Check-State-Service | -ServiceName Appinfo -Need Manual -Default Manual'  # Служба (UAC) Appinfo

        3 = "  $($L.s8 ): ", '& Set-UAC | -CheckState EnableLUA'      # Запросы
        4 = "  $($L.s9 ): ", '& Set-UAC | -CheckState SecureDesktop'  # Обработка запросов
        5 = "  $($L.s10): ", '& Set-UAC | -CheckState Virtualization' # Виртуализация доступа
        6 = "  $($L.s11): ", '& Set-UAC | -CheckState BehaviorAdmin'  # Поведение запросов

        7 = "`n      #DarkGray#$($L.s12):#`n"                         # Варианты для выбора
    }

    Options = @{

        1 = "#Cyan#  [1]# = $($L.s13) #DarkGray#| $($L.s13_1)#"  # [1] = Усиленный режим | Запросы UAC для всех программ, при доступе к системным данным (Безопаснее)
        2 = "#Cyan#  [2]# = $($L.s14) #DarkGray#| $($L.s14_1)#"  # [2] = Слабый режим    | Запросы UAC Без затемнения
        3 = "#Cyan#  [3]# = $($L.s15) #DarkGray#| $($L.s15_1)#"  # [3] = Автосоглашение  | Нет запросов UAC только для пользователей из группы Администраторы
        4 = "#Cyan#  [4]# = $($L.s16) #DarkGray#| $($L.s16_1)#"  # [4] = Отключить       | Нет запросов UAC. Полное отключение для всех пользователей

   5 = "`n#Magenta#  [5]# = #Magenta#$($L.s17)# $($L.s17_1) #DarkGray#| $($L.s17_2) | #White#$($L.s17_3)#"  # [5] = Восстановить режим UAC | По умолчанию | Рекомендуется, если UAC отключен!

     12 = "`n#Cyan#  [$($L.s18)]# = #DarkGray#$($L.s18_1)#`n"    # [Без ввода] = Возврат в меню Личных Настроек

    }

    Selection = @{

        1 = '& Set-UAC | -Option ForcedUAC     -Act Set'
        2 = '& Set-UAC | -Option LowUAC        -Act Set'
        3 = '& Set-UAC | -Option AutoAcceptUAC -Act Set'
        4 = '& Set-UAC | -Option DisableUAC    -Act Set'

        5 = '& Set-UAC | -Act Default'

   'Exit' = '  ◄◄◄ SelfMenu', '$Menu_SelfMenu'

    }
}
