﻿
$Menu_Set_Registry_BackUp = @{

    Info =  @{

      # 0 = ''
        1 = ' #DarkGray#======================================================================================================================#'
        2 = "      #Yellow#$($L.s1) #DarkGray#| $($L.s1_1)#"  # Резервирование Кустов Реестра | Создание Задачи по автоматическому резервированию кустов реестра
        3 = "      #DarkGray#$($L.s2)#"                       # Оригинальная задача резервирования RegIdleBackup больше не работает, и будет отключена
        4 = "      #DarkGray#$($L.s3)#"                       # Восстановить кусты реестра можно через MSDaRT, если интегрирован в Windows (войти в меню: Shift + Перезагрузка)
        5 = "      #DarkGray#$($L.s4): ", '& Set-Registry-BackUp | -CheckState HivePath'  # Папка для резервирования:
        6 = ' #DarkGray#======================================================================================================================#'
        7 = ''
    }

    Status = @{

        0 = "      #DarkGray#$($L.s5):#"    # В данный момент задача

        1 = "             MyRegIdleBackup: ", '& Check-State-Task | -TaskName "\Microsoft\Windows\Registry\MyRegIdleBackup" -Default Enabled -Need Enabled'

      2 = "`n      #DarkGray#$($L.s6):#"    # Резервные Кусты реестра
        3 = '& Set-Registry-BackUp | -CheckState BackUpHives'

      4 = "`n      #DarkGray#$($L.s7):#`n"  # Варианты для выбора
    }

    Options = @{

        1 = "#Cyan#  [1]# = $($L.s8) #DarkGray#| $($L.s8_1)#"             # [1] = Создать задачу   | Создание резервных копий раз в неделю по понедельникам
        2 = "#Cyan#  [2]# = $($L.s9) #DarkGray#| $($L.s9_1)#"             # [2] = Выполнить задачу | Создать резервные копии сейчас

   3 = "`n#Magenta# [99]# = #Magenta#$($L.s10) #DarkGray#| $($L.s10_1)#"  # [99] = Восстановить | По умолчанию. Удалить задачу

     4  = "`n#Cyan# [$($L.s11)]# = #DarkGray#$($L.s11_1)#`n"              # [Без ввода] = Возврат в меню Личных Настроек

    }

    Selection = @{

        1 = '& Set-Registry-BackUp | -Options CreateTask -Act Set'
        2 = '& Set-Registry-BackUp | -Options RunTask    -Act Set'

       99 = '& Set-Registry-BackUp | -Act Default'

   'Exit' = '  ◄◄◄ SelfMenu', '$Menu_SelfMenu'

    }
}
