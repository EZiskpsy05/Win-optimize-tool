﻿
$Menu_Set_Boot_Optimization = @{

    Info =  @{

      # 0 = ''
        1 = ' #DarkGray#======================================================================================================================#'
        2 = "      $($L.s1) #Yellow#$($L.s1_1)#" # Настройка Оптимизации Загрузки Windows и Запуска Программ, Гибернации и Быстрой загрузки
        3 = "      #DarkGray#$($L.s2)#"          # Оптимизацию Загрузки можно отключить, если системный диск SSD
        4 = "      #DarkGray#$($L.s3)#"          # Быстрая загрузка часто приводит к проблемам, рекомендуется отключить
        5 = ' #DarkGray#======================================================================================================================#'
        6 = ''
    }

    Status = @{

        1 = "$($L.s4): ", '& Check-State-Service | -ServiceName SysMain -Default Automatic -Need Disabled',  # Служба SysMain
                "$($L.s4_1): ", '& Set-Boot-Optimization | -CheckState Superfetch' # Параметр Superfetch

        2 = "$($L.s5): ", '& Set-Boot-Optimization | -CheckState ReadyBoot', # Анализ ReadyBoot
              "  $($L.s5_1): ", '& Set-Boot-Optimization | -CheckState Prefetcher' # Параметр Prefetcher

      3 = "`n$($L.s6): " #  Задачи
        4 = '      ResPriStaticDbSync: ', '& Check-State-Task | -TaskName "\Microsoft\Windows\Sysmain\ResPriStaticDbSync" -Default Enabled -Need Disabled',
                '    HybridDriveCachePrepopulate: ', '& Check-State-Task | -TaskName "\Microsoft\Windows\Sysmain\HybridDriveCachePrepopulate" -Default Disabled -Need Disabled'


        5 = '    WsSwapAssessmentTask: ', '& Check-State-Task | -TaskName "\Microsoft\Windows\Sysmain\WsSwapAssessmentTask" -Default Enabled -Need Disabled',
                '      HybridDriveCacheRebalance: ', '& Check-State-Task | -TaskName "\Microsoft\Windows\Sysmain\HybridDriveCacheRebalance" -Default Disabled -Need Disabled'

      6 = "`n$($L.s7): ", '& Set-Boot-Optimization | -CheckState Hibernate' # Гибернация
        7 = "$($L.s8): ", '& Set-Boot-Optimization | -CheckState FastBoot'  # Быстрая загрузка

       10 = "`n#DarkGray#$($L.s9):#`n"  # Варианты для выбора

    }

    Options = @{

        1 = "#Cyan#  [1]# = $($L.s10) #DarkGray#| $($L.s10_1)#"   # Отключить Оптимизацию загрузки | Все параметры, службу SysMain и задачи
        2 = "#Cyan#  [2]# = $($L.s11) #DarkGray#| $($L.s11_1)#"   # Отключить Гибернацию           | Быстрая загрузка перестанет работать
        3 = "#Cyan#  [3]# = $($L.s12) #DarkGray#| $($L.s12_1)#"   # Отключить Быструю загрузку     | Для полноценного завершения работы Windows

   4 = "`n#Magenta#  [4]# = #Magenta#$($L.s13)# $($L.s13_1) #DarkGray#| $($L.s13_2) #" # Включить Оптимизацию загрузки | По умолчанию
     5 = "#Magenta#  [5]# = #Magenta#$($L.s14)# $($L.s14_1) #DarkGray#| $($L.s14_2) #" # Включить Гибернацию           | По умолчанию
     6 = "#Magenta#  [6]# = #Magenta#$($L.s15)# $($L.s15_1) #DarkGray#| $($L.s15_2) #" # Включить Быструю загрузку     | По умолчанию. Использует гибернацию вместо выключения Windows

      7 = "`n#Cyan#  [$($L.s16)]# = #DarkGray#$($L.s16_1)#`n"     # Без ввода = Возврат в меню Личных Настроек

    }

    Selection = @{

        1 = '& Set-Boot-Optimization | -Options OptimizationDisable -Act Set'
        2 = '& Set-Boot-Optimization | -Options HibernateDisable    -Act Set'
        3 = '& Set-Boot-Optimization | -Options FastBootDisable     -Act Set'

        4 = '& Set-Boot-Optimization | -Options OptimizationDisable -Act Default'
        5 = '& Set-Boot-Optimization | -Options HibernateDisable    -Act Default'
        6 = '& Set-Boot-Optimization | -Options FastBootDisable     -Act Default'

   'Exit' = '  ◄◄◄ SelfMenu', '$Menu_SelfMenu'

    }
}
