﻿
$Menu_Set_Network_Local = @{

    Info =  @{

      # 0 = ''
        1 = ' #DarkGray#======================================================================================================================#'
        2 = "      #Yellow#$($L.s1) #DarkGray#|# $($L.s1_1)#" # Локальная Сеть | Настройка минимально необходимых сетевых параметров общего доступа и других условий
        3 = "      #DarkGray#$($L.s2)#"                       # Автоматизация действий, выполняющихся при ручной настройке в параметрах общего доступа, + доп. настройки
        4 = "      #DarkGray#$($L.s3)#"                       # Настройку IP, расшаривание своих папок, настройку доступов для них нужно делать самостоятельно
        5 = ' #DarkGray#======================================================================================================================#'
        6 = ''
    }

    Status = @{

        1 = "   $($L.s4): ", '& Check-State-Service | -ServiceName FDResPub -Default Manual -Need Automatic',             # Служба FDResPub
               "   $($L.s4_1): ", '& Check-State-Service | -ServiceName mpssvc -Default Automatic -Need Automatic',       # Служба mpssvc
                        "   $($L.s4_2): ", '& Check-State-Service | -ServiceName BFE -Default Automatic -Need Automatic'  # Служба BFE
       
        2 = "   $($L.s5): ", '& Check-State-Service | -ServiceName fdPHost -Default Manual -Need Automatic',              # Служба fdPHost
               "   $($L.s5_1): ", '& Check-State-Driver | -DriverName mpsdrv -Default Manual -Need Manual'                # Драйвер mpsdrv

       
      3 = "`n   $($L.s6): ", '& Set-Network-Local | -CheckState SMB1',                     # Протокол SMB1
            "   $($L.s6_1): ", '& Set-Network-Local | -CheckState PrNetworkDiscovery'      # Обнаружение (Частная)

        4 = "   $($L.s7): ", '& Set-Network-Local | -CheckState UnsafeGuest',              # Небезоп. гостевые входы
            "     $($L.s7_1): ", '& Set-Network-Local | -CheckState PrivateSharing'        # Общий доступ (Частная)

        5 = "   $($L.s8): ", '& Set-Network-Local | -CheckState PrivateAutoConfig',        # Автоматическая настройка
            "    $($L.s8_1): ", '& Set-Network-Local | -CheckState PubNetworkDiscovery'    # Обнаружение (Публичная)

        6 = "   $($L.s9): ", '& Set-Network-Local | -CheckState PublicSharing'             # Общий доступ (Публичная)

        7 = "   $($L.s9_1): ", '& Set-Network-Local | -CheckState DomNetworkDiscovery'     # Обнаружение (Домен)
        8 = "   $($L.s9_2): ", '& Set-Network-Local | -CheckState DomainSharing'           # Общий доступ (Домен)

        9 = "   $($L.s10): ", '& Set-Network-Local | -CheckState AllPublicFolders'         # Общие папки (Все)
       10 = "   $($L.s11): ", '& Set-Network-Local | -CheckState AllPasswordProtect'       # Парольная защита (Все)

     30 = "`n      #DarkGray#$($L.s12):#`n"  # Варианты для выбора

    }

    Options = @{

        1 = "#Cyan#  [1]# = $($L.s13) #White#$($L.s13_1) #DarkGray#| $($L.s13_2)  #DarkMagenta#◄ #Magenta#[11]# = #Magenta#$($L.s13_3)#"  #   [1] = Включить:  Протокол SMB1 + Небезопасные входы  | Нужно для сединения к прошлым Windows   ◄ [11] = Отключить
        2 = "#Cyan#  [2]# = $($L.s14) #White#$($L.s14_1) #DarkGray#| $($L.s14_2)  #DarkMagenta#◄ #Magenta#[12]# = #Magenta#$($L.s14_3)#"  #   [2] = Включить:  Сетевое Обнаружение + 2 службы      | Для Частной Сети                        ◄ [12] = Восстановить
        3 = "#Cyan#  [3]# = $($L.s15) #White#$($L.s15_1) #DarkGray#| $($L.s15_2)  #DarkMagenta#◄ #Magenta#[13]# = #Magenta#$($L.s15_3)#"  #   [3] = Включить:  Общий доступ к файлам и принтерам   | Для Частной Сети                        ◄ [13] = Отключить
        4 = "#Cyan#  [4]# = $($L.s16) #White#$($L.s16_1) #DarkGray#| $($L.s16_2)  #DarkMagenta#◄ #Magenta#[14]# = #Magenta#$($L.s16_3)#"  #   [4] = Включить:  Общий доступ к общедоступным папкам | Все Сети                                ◄ [14] = Отключить
        5 = "#Cyan#  [5]# = $($L.s17) #White#$($L.s17_1) #DarkGray#| $($L.s17_2)  #DarkMagenta#◄ #Magenta#[15]# = #Magenta#$($L.s17_3)#"  #   [5] = Отключить: Общий доступ с парольной защитой    | Все Сети                                ◄ [15] = Включить

      6 = "`n#Cyan#  [6]# = $($L.s18) #White#$($L.s18_1) #DarkGray#| $($L.s18_2)  #DarkMagenta#◄ #Magenta#[16]# = #Magenta#$($L.s18_3)#"  #   [6] = Включить:  Сетевое Обнаружение                 | Для Публичной Сети                      ◄ [16] = Отключить
        7 = "#Cyan#  [7]# = $($L.s19) #White#$($L.s19_1) #DarkGray#| $($L.s19_2)  #DarkMagenta#◄ #Magenta#[17]# = #Magenta#$($L.s19_3)#"  #   [7] = Включить:  Общий доступ к файлам и принтерам   | Для Публичной Сети                      ◄ [17] = Отключить

     8 = "`n#Green# [22]# = #Green#$($L.s20) #White#$($L.s20_1) #DarkGray#| $($L.s20_2)#"  #  [22] = Выполнить 1-5 настройки сразу | Первые 5 вариантов

   9 = "`n#Magenta# [30]# = #Magenta#$($L.s21) #DarkGray#| $($L.s21_1)#"                   #  [30] = Сбросить все правила Брандмауэра Windows | По умолчанию (Дополнительная возможность)

    10 = "#Magenta# [99]# = #Magenta#$($L.s22) #DarkGray#| $($L.s22_1)#"                   #  [99] = Восстановить Все параметры | По умолчанию (И отключить SMB1)

       11 = "#Cyan# [$($L.s23)]# = #DarkGray#$($L.s23_1)#`n"                               #  [Без ввода] = Возврат в меню Личных Настроек

    }

    Selection = @{

        1 = '& Set-Network-Local | -Act Set -Options SetSMB1                -ApplyGP'  # Всем ApplyGP, чтобы пауза срабатывала только через меню.
        2 = '& Set-Network-Local | -Act Set -Options SetPrNetworkDiscovery  -ApplyGP'
        3 = '& Set-Network-Local | -Act Set -Options SetPrivateSharing      -ApplyGP'
        4 = '& Set-Network-Local | -Act Set -Options SetAllPublicFolders    -ApplyGP'
        5 = '& Set-Network-Local | -Act Set -Options SetAllPasswordProtect  -ApplyGP'

        6 = '& Set-Network-Local | -Act Set -Options SetPubNetworkDiscovery -ApplyGP'
        7 = '& Set-Network-Local | -Act Set -Options SetPublicSharing       -ApplyGP'

       22 = '& Set-Network-Local | -Act Set -Options SetSMB1,SetPrNetworkDiscovery,SetPrivateSharing,SetAllPublicFolders,SetAllPasswordProtect -ApplyGP'

       11 = '& Set-Network-Local | -Act Default -Options SetSMB1                -ApplyGP'
       12 = '& Set-Network-Local | -Act Default -Options SetPrNetworkDiscovery  -ApplyGP'
       13 = '& Set-Network-Local | -Act Default -Options SetPrivateSharing      -ApplyGP'
       14 = '& Set-Network-Local | -Act Default -Options SetAllPublicFolders    -ApplyGP'
       15 = '& Set-Network-Local | -Act Default -Options SetAllPasswordProtect  -ApplyGP'

       16 = '& Set-Network-Local | -Act Default -Options SetPubNetworkDiscovery -ApplyGP'
       17 = '& Set-Network-Local | -Act Default -Options SetPublicSharing       -ApplyGP'

       30 = '& Set-Network-Local | -Act Default -Options ResetAllFirewallRules  -ApplyGP'

       99 = '& Set-Network-Local | -Act Default -Options SetSMB1,SetPrNetworkDiscovery,SetPrivateSharing,SetAllPublicFolders,SetAllPasswordProtect,SetPubNetworkDiscovery,SetPublicSharing -ApplyGP'

   'Exit' = '  ◄◄◄ SelfMenu', '$Menu_SelfMenu'

    }
}
