﻿
$Menu_Move_User_Folders = @{

    Info =  @{

      # 0 = ''
        1 = ' #DarkGray#======================================================================================================================#'
        2 = "      $($L.s1) #Yellow#$($L.s1_1) #White#$($L.s1_2): #",'& Show-Selected-Users | -OnlyUsers' # Изменение Расположения папок текущего пользователя:
        3 = "      #DarkGray#$($L.s2)#" # Пропуск копирования/удаления исходной папки, если не хватает или мало остаётся места на диске назначения
        4 = "      #DarkGray#$($L.s3)#" # Удаление исходной папки, только после копирования без ошибок. Настроятся права доступа и атрибутов
        5 = "      $($L.s4) #Magenta#$($L.s4_1)#" # Восстанавливает и при отсутствии папок или параметров в реестре. Завершите всё перед выполнением!
        6 = "      #Blue#$($L.s5)#DarkGray# $($L.s5_1)#" # Символические ссылки создаются в расположении По умолчанию, ведущие в новое расположение
        7 = "      #DarkGray#$($L.s6): #", '#White#& Run-Configs | -CheckState CurrentPreset#' # Свое расположение можно задать в файле пресетов, текущий файл
        8 = ' #DarkGray#======================================================================================================================#'
        9 = ''
    }

    Status = @{

        0 = "      #DarkGray#$($L.s7):#"  # Расположение папок в данный момент
        1 = "        $($L.s9   )#DarkGray#:# ", '& Move-User-Folders | -CheckState Videos'
        2 = "        $($L.s10  )#DarkGray#:# ", '& Move-User-Folders | -CheckState Documents'
        3 = "        $($L.s11  )#DarkGray#:# ", '& Move-User-Folders | -CheckState Downloads'
        4 = "        $($L.s12  )#DarkGray#:# ", '& Move-User-Folders | -CheckState Pictures'
        5 = "        $($L.s13  )#DarkGray#:# ", '& Move-User-Folders | -CheckState Music'
        6 = "        $($L.s14  )#DarkGray#:# ", '& Move-User-Folders | -CheckState Desktop'
        7 = "        $($L.s15_1)#DarkGray#:# ", '& Move-User-Folders | -CheckState SavedGames'
        8 = ''
        9 = "      #DarkGray#$($L.s8):#"  # Варианты для выбора
       10 = ''
    }

    Options = @{

        1 = "#Cyan#  [1]# = #Yellow#$($L.s15) #DarkGray#| $($L.s16)", " #DarkMagenta#◄#Magenta# [100]# = #Yellow#$($L.s15) #DarkGray#| $($L.s17)" # Перенести все папки по своим путям
        2 = "#Cyan#  [2]# = $($L.s9   ) #DarkGray#| $($L.s18) ", '& Move-User-Folders | -CheckPreset Videos',     " #DarkMagenta#◄#Magenta# [200]# = $($L.s9   ) #DarkGray#| $($L.s17)"
        3 = "#Cyan#  [3]# = $($L.s10  ) #DarkGray#| $($L.s18) ", '& Move-User-Folders | -CheckPreset Documents',  " #DarkMagenta#◄#Magenta# [300]# = $($L.s10  ) #DarkGray#| $($L.s17)"
        4 = "#Cyan#  [4]# = $($L.s11  ) #DarkGray#| $($L.s18) ", '& Move-User-Folders | -CheckPreset Downloads',  " #DarkMagenta#◄#Magenta# [400]# = $($L.s11  ) #DarkGray#| $($L.s17)"
        5 = "#Cyan#  [5]# = $($L.s12  ) #DarkGray#| $($L.s18) ", '& Move-User-Folders | -CheckPreset Pictures',   " #DarkMagenta#◄#Magenta# [500]# = $($L.s12  ) #DarkGray#| $($L.s17)"
        6 = "#Cyan#  [6]# = $($L.s13  ) #DarkGray#| $($L.s18) ", '& Move-User-Folders | -CheckPreset Music',      " #DarkMagenta#◄#Magenta# [600]# = $($L.s13  ) #DarkGray#| $($L.s17)"
        7 = "#Cyan#  [7]# = $($L.s14  ) #DarkGray#| $($L.s18) ", '& Move-User-Folders | -CheckPreset Desktop',    " #DarkMagenta#◄#Magenta# [700]# = $($L.s14  ) #DarkGray#| $($L.s17)"
        8 = "#Cyan#  [8]# = $($L.s15_1) #DarkGray#| $($L.s18) ", '& Move-User-Folders | -CheckPreset SavedGames', " #DarkMagenta#◄#Magenta# [800]# = $($L.s15_1) #DarkGray#| $($L.s17)"
        
        9 = ''
       10 = "#DarkCyan#  [222]# = #Magenta#$($L.s19) #DarkCyan#$($L.s19_1)# $($L.s19_2) #DarkGray#| $($L.s19_3)#" # Очистить панель Быстрый доступ от ваших закрепленных элементов | Если не получается удалить
       11 = ''
       12 = "#Cyan#  [$($L.s20)]# = #DarkGray#$($L.s20_1)#" # Без ввода = Возврат в меню Личных Настроек
       13 = ''
    }

    Selection = @{

        1 = '& Move-User-Folders | -Folders Videos,Documents,Downloads,Pictures,Music,Desktop,SavedGames'
        2 = '& Move-User-Folders | -Folders Videos'
        3 = '& Move-User-Folders | -Folders Documents'
        4 = '& Move-User-Folders | -Folders Downloads'
        5 = '& Move-User-Folders | -Folders Pictures'
        6 = '& Move-User-Folders | -Folders Music'
        7 = '& Move-User-Folders | -Folders Desktop'
        8 = '& Move-User-Folders | -Folders SavedGames'

      100 = '& Move-User-Folders | -Folders Videos,Documents,Downloads,Pictures,Music,Desktop,SavedGames -Default'
      200 = '& Move-User-Folders | -Folders Videos -Default'
      300 = '& Move-User-Folders | -Folders Documents -Default'
      400 = '& Move-User-Folders | -Folders Downloads -Default'
      500 = '& Move-User-Folders | -Folders Pictures -Default'
      600 = '& Move-User-Folders | -Folders Music -Default'
      700 = '& Move-User-Folders | -Folders Desktop -Default'
      800 = '& Move-User-Folders | -Folders SavedGames -Default'

      222 = '& Move-User-Folders | -ClearFastAccess'

   'Exit' = '  ◄◄◄ SelfMenu', '$Menu_SelfMenu'

    }
}
