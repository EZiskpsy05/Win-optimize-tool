﻿
$Menu_Set_Drives_Icons = @{

    Info =  @{

      # 0 = ''
        1 = ' #DarkGray#======================================================================================================================#'
        2 = "      $($L.s1) #Yellow#$($L.s1_1) #DarkGray#| $($L.s1_2)#" # Настройка Иконок дисков | Установка своих иконок для RAM и USB дисков/Флешек
        3 = "      #DarkGray#$($L.s2)#"                                 # Нельзя заранее знать какие буквы дисков будут у подключённых USB устройств, но есть решение:
        4 = "      #DarkGray#$($L.s3)#"                                 # Для постоянных букв задать принудительные иконки Локальных/RAM дисков. А глобально для всех иконку флешки
        5 = "      #DarkGray#$($L.s4):# ", '#White#& Run-Configs | -CheckState CurrentPreset#' # Можно изменить на свои иконки в текущем файле пресетов:
        6 = ' #DarkGray#======================================================================================================================#'
        7 = ''
    }

    Status = @{

        1 = "      $($L.s5 ): ", '& Set-Drives-Icons | -CheckState PresetIconForLocalDrives' #  Пресет Иконки для Local дисков
        2 = "      $($L.s6 ): ", '& Set-Drives-Icons | -CheckState PresetIconForRamDrives'   #    Пресет Иконки для RAM дисков
        3 = "      $($L.s7 ): ", '& Set-Drives-Icons | -CheckState PresetIconForUsbDrives'   #    Пресет Иконки для USB дисков
        4 = ''
        5 = "      $($L.s8 ): ", '& Set-Drives-Icons | -CheckState GlobalIconForAllDrives'   # Глобальная Иконка у Всех дисков
        6 = "      $($L.s9 ): ", '& Set-Drives-Icons | -CheckState GlobalIconForFlashDrives' #  Глобальная Иконка у USB дисков
        7 = "      $($L.s10): ", '& Set-Drives-Icons | -CheckState DrivesWithIcons'          #          Личные иконки у дисков
        8 = ''

        9 = '& Set-Drives-Icons | -CheckState ShowAllDrives'

   # 10 = "`n      #DarkGray#$($L.s11):#`n"   # Варианты для выбора
       10 = ''

    }

    Options = @{

        1 = "#Cyan#  [1]# = $($L.s12) #DarkGray#$($L.s12_1) | #", '& Set-Drives-Icons | -CheckState ShowDrivesTypes' # Установить иконки исходя из |

     2 = "#Magenta# [99]# = #Magenta#$($L.s13)# $($L.s13_1) #DarkGray#| $($L.s13_2)#"  # Восстановить иконки | По умолчанию

      3 = "`n#Cyan# [$($L.s15)]# = #DarkGray#$($L.s15_1) #DarkCyan# [333]# = #DarkCyan#$($L.s14) #$($L.s14_1) #DarkGray#| $($L.s14_2)#`n" # [Без ввода] = Возврат в меню Настройка Проводника       [333] = Перезапустить Проводник | Корректно
    }

    Selection = @{

        1 = '& Set-Drives-Icons | -Act Set'

       99 = '& Set-Drives-Icons | -Act Default'

      333 = "   $($L.s14_1) ...", '& ReStart-Explorer' # Перезапуск Проводника

   'Exit' = "  ◄◄◄ $($L.s16)", '$Menu_Set_Explorer_Settings' # Проводник

    }
}
