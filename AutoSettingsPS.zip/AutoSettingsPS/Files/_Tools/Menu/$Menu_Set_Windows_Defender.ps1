﻿
$Menu_Set_Windows_Defender = @{

    Info =  @{

      # 0 = ''
        1 = ' #DarkGray#======================================================================================================================#'
        2 = "      #Yellow#$($L.s1) #DarkGray#| $($L.s1_1)#"  # Защитник Windows | Добавить Исключения или Настроить
        3 = "      #DarkGray#$($L.s2)#"                       # Папка со скриптом будет добавлена в исключения, если не добавлена через ГП или Защитника
        4 = "      #DarkGray#$($L.s3)#"                       # Если что-то не настроится, повторить выполнение еще раз после перезагрузки
        5 = "      #Blue#$($L.s3_1)#"                         # Для отключения Защитника может потребоваться вручную отключить 'Защиту от Подделки' в его настройках
        6 = "      $($L.s4): ", '#White#& Run-Configs | -CheckState CurrentPreset#', ' #DarkGray#| & Set-Windows-Defender | -CheckState PresetExclusions'  # В файле Пресетов
        7 = ' #DarkGray#======================================================================================================================#'
        8 = ''
    }

    Status = @{

        1 = "      $($L.s5 ): ", '& Set-Windows-Defender | -CheckState Exclusion'   # Исключение папки

      2 = "`n      $($L.s6 ): ", '& Set-Windows-Defender | -CheckState Defender'    # Защитник

        3 = "      $($L.s7 ): ", '& Set-Windows-Defender | -CheckState Run',                         # Автозагрузка
                            "   $($L.s7_1 ): ", '& Set-Windows-Defender | -CheckState HideDefender'  # Отображение в Настройках

        4 = "      #White#$($L.s7_2): ", '& Set-Windows-Defender | -CheckState TamperProtection',           # Защита от подделки
                            "   $($L.s7_3 ): ", '& Set-Windows-Defender | -CheckState ContextMenu'   # Контекстное меню

      5 = "`n      $($L.s8 ): ", '& Check-State-Service | -ServiceName WinDefend -Default Automatic -Need Disabled',                         # Служба WinDefend
                                 '& Check-State-Service | -ServiceName WinDefend -CheckStatus -Return Result',
                          "     $($L.s8_1 ): ", '& Check-State-Service | -ServiceName SecurityHealthService -Default Manual -Need Disabled', # Служба SecurityHealthService
                                                '& Check-State-Service | -ServiceName SecurityHealthService -CheckStatus -Return Result'


        6 = "      $($L.s9 ): ", '& Check-State-Service | -ServiceName WdNisSvc -Default Manual -Need Disabled',             # Служба WdNisSvc
                                 '& Check-State-Service | -ServiceName WdNisSvc -CheckStatus -Return Result',
                          "     $($L.s9_1 ): ", '& Check-State-Service | -ServiceName Sense -Default Manual -Need Disabled', # Служба Sense
                                                '& Check-State-Service | -ServiceName Sense -CheckStatus -Return Result'

      7 = "`n      $($L.s10): ", '& Check-State-Driver | -DriverName WdFilter -Default Boot -Need Disabled',                 # Драйвер WdFilter
                                 '& Check-State-Driver | -DriverName WdFilter -CheckStatus -Return Result',
                          "     $($L.s10_1): ",'& Check-State-Driver | -DriverName WdBoot -Default Boot -Need Disabled',     # Драйвер WdBoot
                                               '& Check-State-Driver | -DriverName WdBoot -CheckStatus -Return Result'


        8 = "      $($L.s11): ", '& Check-State-Driver | -DriverName WdNisDrv -Default Manual -Need Disabled',               # Драйвер WdNisDrv
                                 '& Check-State-Driver | -DriverName WdNisDrv -CheckStatus -Return Result',
                          "     $($L.s11_1): ",'& Check-State-Driver | -DriverName MsSecFlt -Default Boot -Need Disabled',   # Драйвер MsSecFlt
                                               '& Check-State-Driver | -DriverName MsSecFlt -CheckStatus -Return Result'

      9 = "`n      $($L.s12):"  # Задачи
        10 = "        Cache Maintenance: ", '& Check-State-Task | -TaskName "\Microsoft\Windows\Windows Defender\Windows Defender Cache Maintenance" -Default Enabled -Need Disabled',
                "                      Defender Scheduled Scan: ", '& Check-State-Task | -TaskName "\Microsoft\Windows\Windows Defender\Windows Defender Scheduled Scan" -Default Enabled -Need Disabled'


       11 = "         Defender Cleanup: ", '& Check-State-Task | -TaskName "\Microsoft\Windows\Windows Defender\Windows Defender Cleanup" -Default Enabled -Need Disabled',
                "                        Defender Verification: ", '& Check-State-Task | -TaskName "\Microsoft\Windows\Windows Defender\Windows Defender Verification" -Default Enabled -Need Disabled'

     30 = "`n      #DarkGray#$($L.s13):#`n"  # Варианты для выбора

    }

    Options = @{

        1 = "#Cyan#  [1]# = $($L.s14) #DarkGray#| $($L.s14_1)#"          #  [1] = Добавить в список Исключений Защитника | Только Исключения, и только если ещё не добавлены
        2 = "#Cyan#  [2]# = $($L.s16) #DarkGray#| $($L.s16_1)#"          #  [2] = Отключить всё | Автозапуск, Задачи, Службы/Драйвера, Скрыть контекстное меню и Настройки + Исключения

   4 = "`n#Magenta# [99]# = #Magenta#$($L.s17) #DarkGray#| $($L.s17_1)#" # [99] = Восстановить всё | По умолчанию. После перезагрузки Защитник восстанавливается с задержкой

      7 = "`n#Cyan# [$($L.s18)]# = #DarkGray#$($L.s18_1)#`n"             # [Без ввода] = Возврат в меню Личных Настроек
    }

    Selection = @{                                                  # ApplyGP для вызова паузы при запуске из меню, чтобы через быстрые настройки не было паузы

        1 = '& Set-Windows-Defender | -Act Set -Option AddExclusions -ApplyGP'

        2 = '& Set-Windows-Defender | -Act Set -Option AllDisable    -ApplyGP'

       99 = '& Set-Windows-Defender | -Act Default                   -ApplyGP'

   'Exit' = '  ◄◄◄ SelfMenu', '$Menu_SelfMenu'

    }
}
