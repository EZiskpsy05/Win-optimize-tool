﻿
$Menu_Set_Explorer_Settings = @{

    Info =  @{

      # 0 = ''
        1 = ' #DarkGray#======================================================================================================================#'
        2 = "       #Yellow#$($L.s1)#DarkGray#: #White#$($L.s1_1)#"  # Настройка Проводника: Папки пользователя, Дубликаты съемных устройств, Значок Сеть, Быстрый доступ и др.
        3 = "       #DarkGray#$($L.s2): #",'& Show-Selected-Users | -OnlyUsers'   # Настраивается без смены разрешений для текущего аккаунта
        4 = "       #DarkGray#$($L.s3)#"                             # Перед установкой Обоев, файл будет скопирован в папку 'Изображения' пользователя
        5 = ' #DarkGray#======================================================================================================================#'
        6 = ''
    }

    Status = @{

        1 = "    $($L.s4 ): ", '& Set-Explorer-Settings | -CheckState VideoHide',     "   $($L.s4_1 ): ", '& Set-Explorer-Settings | -CheckState DuplicateDevicesHide' # Видео          Дубликаты
        2 = "    $($L.s5 ): ", '& Set-Explorer-Settings | -CheckState DocumentsHide', "   $($L.s5_1 ): ", '& Set-Explorer-Settings | -CheckState NetIconHide'          # Документы      Значок Сеть
        3 = "    $($L.s6 ): ", '& Set-Explorer-Settings | -CheckState DownloadsHide', "   $($L.s6_1 ): ", '& Set-Explorer-Settings | -CheckState FastAccessHide'       # Загрузки       Быстрый доступ
        4 = "    $($L.s7 ): ", '& Set-Explorer-Settings | -CheckState PicturesHide'     # Изображения
        5 = "    $($L.s8 ): ", '& Set-Explorer-Settings | -CheckState MusicHide'        # Музыка
        6 = "    $($L.s9 ): ", '& Set-Explorer-Settings | -CheckState DesktopHide',   "   $($L.s9_1 ): ", '& Set-Drives-Icons | -CheckState GlobalIconForFlashDrives'  # Рабочий стол   Иконки глобально
        7 = "    $($L.s10): ", '& Set-Explorer-Settings | -CheckState 3dHide',        "   $($L.s10_1): ", '& Set-Drives-Icons | -CheckState DrivesWithIcons'           # 3d объекты     Иконки у дисков

        8 = ''
        9 = "    $($L.s11): ", '& Set-Explorer-Settings | -CheckState WallPaper'        # Обои

     10 = "`n       #DarkGray#$($L.s12):#`n"  # Варианты для выбора

    }

    Options = @{

        1 = "#Cyan#   [1]# = #White#$($L.s14) #DarkGray#| $($L.s13)  #DarkMagenta#◄#Magenta# [101]# = #DarkGray#$($L.s13_2 )   #Cyan#    [9]# = $($L.s14_1) #DarkGray#| $($L.s13)  #DarkMagenta#◄#Magenta# [109]# = #DarkGray#$($L.s13_1)#" # [1] = Все 7 папок  | Скрыть  ◄ [101] = Вернуть Все 7       [9] = Дубликаты      | Скрыть  ◄ [109] = Вернуть
        2 = "#Cyan#   [2]# = $($L.s15) #DarkGray#| $($L.s13       )  #DarkMagenta#◄#Magenta# [102]# = #DarkGray#$($L.s13_1 )   #Cyan#   [10]# = $($L.s15_1) #DarkGray#| $($L.s13)  #DarkMagenta#◄#Magenta# [110]# = #DarkGray#$($L.s13_1)#" # [2] = Видео        | Скрыть  ◄ [102] = Вернуть            [10] = Значок Сеть    | Скрыть  ◄ [110] = Вернуть
        3 = "#Cyan#   [3]# = $($L.s16) #DarkGray#| $($L.s13       )  #DarkMagenta#◄#Magenta# [103]# = #DarkGray#$($L.s13_1 )   #Cyan#   [11]# = $($L.s16_1) #DarkGray#| $($L.s13)  #DarkMagenta#◄#Magenta# [111]# = #DarkGray#$($L.s13_1)#" # [3] = Документы    | Скрыть  ◄ [103] = Вернуть            [11] = Быстрый доступ | Скрыть  ◄ [111] = Вернуть
        4 = "#Cyan#   [4]# = $($L.s17) #DarkGray#| $($L.s13       )  #DarkMagenta#◄#Magenta# [104]# = #DarkGray#$($L.s13_1)#"                                                                                                              # [4] = Загрузки     | Скрыть  ◄ [104] = Вернуть
        5 = "#Cyan#   [5]# = $($L.s18) #DarkGray#| $($L.s13       )  #DarkMagenta#◄#Magenta# [105]# = #DarkGray#$($L.s13_1)    #Yello#  [22]# = #Yellow#$($L.s22) #DarkGray#| $($L.s22_1)#"                                                 # [5] = Изображения  | Скрыть  ◄ [105] = Вернуть            [22] = Иконки дисков | Меню для управления иконками дисков
        6 = "#Cyan#   [6]# = $($L.s19) #DarkGray#| $($L.s13       )  #DarkMagenta#◄#Magenta# [106]# = #DarkGray#$($L.s13_1)    #Magen# [301]# = #Magent#$($L.s23)# $($L.s23_1) #DarkGray#| IconCache#"                                      # [6] = Музыка       | Скрыть  ◄ [106] = Вернуть           [301] = Очистить кэш иконок проводника  | IconCache
        7 = "#Cyan#   [7]# = $($L.s20) #DarkGray#| $($L.s13       )  #DarkMagenta#◄#Magenta# [107]# = #DarkGray#$($L.s13_1)    #Magen# [302]# = #Magent#$($L.s24)# $($L.s24_1) #DarkGray#| ThumbCache#"                                     # [7] = Рабочий стол | Скрыть  ◄ [107] = Вернуть           [302] = Очистить кэш эскизов проводника | ThumbCache
        8 = "#Cyan#   [8]# = $($L.s21) #DarkGray#| $($L.s13       )  #DarkMagenta#◄#Magenta# [108]# = #DarkGray#$($L.s13_1)    #DarkC# [333]# = #DarkCy#$($L.s25)# $($L.s25_1) #DarkGray#$($L.s25_2)#"                                      # [8] = 3d объекты   | Скрыть  ◄ [108] = Вернуть           [333] = Перезапустить проводник (Корректно)

      9 = "`n#Cyan#  [20]# = $($L.s26) $($L.s26_1) #DarkGray#| $($L.s26_2): #", '& Set-Explorer-Settings | -CheckState ImageForWallPaper' #  [20] = Установить обои Рабочего стола   | Файл:
    10 = "#Magenta# [200]# = #Magenta#$($L.s27)# $($L.s27_1) #DarkGray#| $($L.s27_2)#"                                                    # [200] = Восстановить обои Рабочего стола | По умолчанию

  11 = "`n#Magenta# [999]# = #Magenta#$($L.s28) #DarkGray#| $($L.s28_1)#" # [999] = Восстановить все | По умолчанию (кроме иконок дисков)

     12 = "`n#Cyan# [$($L.s29)]# = #DarkGray#$($L.s29_1)#`n" # [Без ввода] = Возврат в меню Личных Настроек

    }

    Selection = @{

        1 = '& Set-Explorer-Settings | -Options VideoHide,DocumentsHide,DownloadsHide,PicturesHide,MusicHide,DesktopHide,3dHide -Act Set'

        2 = '& Set-Explorer-Settings | -Options VideoHide     -Act Set'
        3 = '& Set-Explorer-Settings | -Options DocumentsHide -Act Set'
        4 = '& Set-Explorer-Settings | -Options DownloadsHide -Act Set'
        5 = '& Set-Explorer-Settings | -Options PicturesHide  -Act Set'
        6 = '& Set-Explorer-Settings | -Options MusicHide     -Act Set'
        7 = '& Set-Explorer-Settings | -Options DesktopHide   -Act Set'
        8 = '& Set-Explorer-Settings | -Options 3dHide        -Act Set'

        9 = '& Set-Explorer-Settings | -Options DuplicateDevicesHide -Act Set'
       10 = '& Set-Explorer-Settings | -Options NetIconHide          -Act Set'
       11 = '& Set-Explorer-Settings | -Options FastAccessHide       -Act Set'

      101 = '& Set-Explorer-Settings | -Options VideoHide,DocumentsHide,DownloadsHide,PicturesHide,MusicHide,DesktopHide,3dHide -Act Default'

      102 = '& Set-Explorer-Settings | -Options VideoHide     -Act Default'
      103 = '& Set-Explorer-Settings | -Options DocumentsHide -Act Default'
      104 = '& Set-Explorer-Settings | -Options DownloadsHide -Act Default'
      105 = '& Set-Explorer-Settings | -Options PicturesHide  -Act Default'
      106 = '& Set-Explorer-Settings | -Options MusicHide     -Act Default'
      107 = '& Set-Explorer-Settings | -Options DesktopHide   -Act Default'
      108 = '& Set-Explorer-Settings | -Options 3dHide        -Act Default'

      109 = '& Set-Explorer-Settings | -Options DuplicateDevicesHide  -Act Default'
      110 = '& Set-Explorer-Settings | -Options NetIconHide           -Act Default'
      111 = '& Set-Explorer-Settings | -Options FastAccessHide        -Act Default'

      301 = '& Set-Explorer-Settings | -Options ClearIconCache  -Act Set'
      302 = '& Set-Explorer-Settings | -Options ClearThumbCache -Act Set'

      333 = "   $($L.s30)", '& ReStart-Explorer'  # Перезапуск проводника (корректный) ...

       20 = '& Set-Explorer-Settings | -Options SetWallPaper -Act Set'
      200 = '& Set-Explorer-Settings | -Options SetWallPaper -Act Default'

      999 = '& Set-Explorer-Settings | -Options VideoHide,DocumentsHide,DownloadsHide,PicturesHide,MusicHide,DesktopHide,3dHide,
                                                DuplicateDevicesHide,NetIconHide,FastAccessHide,SetWallPaper -Act Default'

       22 = "    ► $($L.s22)", '$Menu_Set_Drives_Icons'  # Иконки дисков

   'Exit' = '  ◄◄◄ SelfMenu', '$Menu_SelfMenu'

    }
}
