﻿
$Menu_Set_Sound_VolumeDown = @{

    Info =  @{

      # 0 = ''
        1 = ' #DarkGray#======================================================================================================================#'
        2 = "      $($L.s1) #Yellow#$($L.s1_1) #DarkGray#| $($L.s1_2): #",'& Show-Selected-Users' # Управление Звуковыми профилями | Для текущего аккаунта
        3 = "      #DarkGray#$($L.s1_3)#" # С понижением громкости аудио файлов wav утилитой ffmpeg.exe
        4 = "      #DarkGray#$($L.s2)#"   # Уровень громкости приблизительно разделён по шкале с 99% по 1% (Минимальная громкость)
        5 = "      #DarkGray#$($L.s3)#"   # Нижний порог громкости необходим для ограничения снижения изначально тихих звуковых файлов
        6 = "      #DarkGray#$($L.s4): #", '#White#& Run-Configs | -CheckState CurrentPreset#' # Параметры громкости можно изменить в файле пресетов, текущий файл:
        7 = ' #DarkGray#======================================================================================================================#'
        8 = ''
    }

    Status = @{

        0 = "      $($L.s8): ", '& Set-Sound-VolumeDown | -CheckState AudioProfile'     # Звуковой профиль

      1 = "`n      #DarkGray#$($L.s9):#`n"  # Варианты для выбора
    }

    Options = @{

        1 = "#Cyan#  [1]# = $($L.s10) #DarkGray#| #", '& Set-Sound-VolumeDown | -CheckState VolumePresets'  #  [1] = Установить Звуковой профиль | Громкость: 30% | Нижний порог: -60 dB
        2 = "#Cyan#  [2]# = $($L.s11)#"                                                                     #  [2] = Установить Профиль без звука

  3 = "`n#DarkCyan# [10]# = #DarkCyan#$($L.s12)#"                                                           # [10] = Открыть панель управления звуком

   4 = "`n#Magenta# [99]# = #Magenta#$($L.s13)# $($L.s13_1) #DarkGray#| $($L.s13_2)#"                       # [99] = Восстановить Звуковой профиль | По умолчанию

      5 = "`n#Cyan# [$($L.s14)]# = #DarkGray#$($L.s14_1)#`n"                                                # [Без ввода] = Возврат в меню Личных Настроек

    }

    Selection = @{

        1 = '& Set-Sound-VolumeDown | -Option SetVolumeDown -Act Set'
        2 = '& Set-Sound-VolumeDown | -Option NoSound       -Act Set'

       10 = "& Start-Process | 'rundll32.exe' -ArgumentList  'Shell32.dll, Control_RunDLL mmsys.cpl,,2'", '& Start-Sleep | -Milliseconds 1000', '& Set-NoConsole-Scroll'

       99 = '& Set-Sound-VolumeDown | -Option SetVolumeDown -Act Default'

   'Exit' = '  ◄◄◄ SelfMenu', '$Menu_SelfMenu'

    }
}
