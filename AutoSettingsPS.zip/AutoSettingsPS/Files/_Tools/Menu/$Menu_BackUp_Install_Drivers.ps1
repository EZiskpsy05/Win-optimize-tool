﻿
$Menu_BackUp_Install_Drivers = @{

    Info =  @{

      # 0 = ''
        1 = ' #DarkGray#======================================================================================================================#'
        2 = "       #Yellow#$($L.s1) #DarkGray#| $($L.s1_1): \Files\Update\Drivers#" # Сохранение Драйверов | Бэкап или Установка Драйверов из папки: \Files\Update\Drivers
        3 = "       #DarkGray#$($L.s2)#"                                             # Позволяет восстановить все драйвера после чистой установки Windows
        4 = ' #DarkGray#======================================================================================================================#'
        5 = ''
    }

    Status = @{

        0 = "       #DarkGray#$($L.s3):#`n"  # Сохранённые драйвера
        1 = '& BackUp-Install-Drivers | -ShowDrivers'

      2 = "`n       #DarkGray#$($L.s4):`n"   # Варианты для выбора
    }

    Options = @{

        1 = "#Cyan# [111]# = #Magenta#$($L.s5)# $($L.s5_1) #DarkGray#| $($L.s5_2)#" # [111] = Сохранить Драйвера  | В папку:  \Files\Update\Drivers
        2 = "#Cyan# [222]# = #Magenta#$($L.s6)# $($L.s6_1) #DarkGray#| $($L.s6_2)#" # [222] = Установить Драйвера | Из папки: \Files\Update\Drivers

      3 = "`n#Cyan# [$($L.s7)]# = #DarkGray#$($L.s7_1)#`n"   # [Без ввода] = Возврат в Меню Обслуживания
    }

    Selection = @{

      111 = '& BackUp-Install-Drivers | -BackUp'
      222 = '& BackUp-Install-Drivers | -Install'

   'Exit' = "  ◄◄◄ $($L.s7_1)", '$Menu_Set_Windows_Maintenance' # Возврат в Меню Обслуживания

    }
}