﻿
$Menu_Features_Capabilities = @{

    Info =  @{

      # 0 = ''
        1 = ' #DarkGray#======================================================================================================================#'
        2 = "     #Yellow#$($L.s1)#DarkGray#$($L.s1_1)$($L.s1_2)#" # Настройка Дополнительных Компонентов и Возможностей | Windows Optional Features | Windows Capabilities
        4 = "     #DarkGray#$($L.s2)#"    # Необходим Интернет и ЦО для Установки всех Capabilities и Включения некоторых Optional Features
        5 = "     #DarkGray#$($L.s3)#"    # ○ = Не настроен;  ● = Настроен (Пропуск настройки);  х = Ошибка (Пропуск настройки)
        6 = "     #DarkGray#$($L.s4): #", "#White#& Run-Configs | -CheckState CurrentPreset#"  # Изменить список параметров можно в файле пресетов, текущий файл:
        7 = ' #DarkGray#======================================================================================================================#'
        8 = ''
    }

    Status = @{

        0 = "     #Blue#$($L.s5) #DarkGray#$($L.s5_1):#",    # Optional Features в пресете:
                    "#DarkGray#$($L.s5_2): #", '& Test-Internet | -Access'    # Интернет: OffLine
        1 = '& Manage-Optional-Features | Check -NoTitle'
        2 = ''
        3 = "     #White#$($L.s6) #DarkGray#$($L.s6_1):#"    # Capabilities в пресете:
        4 = '& Manage-Capabilities | Check -NoTitle'
        5 = ''
       20 = "     #DarkGray#$($L.s7):#"                      # Варианты для выбора
       21 = ''
    }

    Options = @{
        
        1 = "#Cyan#  [1]# = #Cyan#$($L.s8 )# $($L.s8_1) #DarkGray#| ► $(Get-SaveListPath Features-Capab SaveFileFeaturesGlobal | Split-Path -leaf)#" #  [1] = Сохранить список всех возможных Features/Capabilities для файла пресетов | ► Features-Capab_.....txt

      2 = "`n#Blue# [10]# = $($L.s9 ) #Blue#$($L.s9_1 ) #DarkGray#| $($L.s9_2 )   #DarkBlue#◄#Blue# [100]# = $($L.s9_3 ) #DarkGray#| $($L.s9_4 )#"   # [10] = Настроить Все Features     | Отключить/Включить   ◄ [100] = Настроить выборочно | Ввод номеров (1 3 5 ...)
        3 = "#Whit# [20]# = $($L.s10) #Whit#$($L.s10_1) #DarkGray#| $($L.s10_2)   #DarkGray#◄#Whit# [200]# = $($L.s10_3) #DarkGray#| $($L.s10_4)#"   # [20] = Настроить Все Capabilities | Удалить/Установить   ◄ [200] = Настроить выборочно | Ввод номеров (1 3 5 ...)

      4 = "`n#Cyan# [30]# = $($L.s11) #Blue#$($L.s11_1)#DarkGray#/#White#$($L.s11_2)#"   # [30] = Настроить Все Features/Capabilities

      5 = "`n#Cyan# [$($L.s20)]# = #DarkGray#$($L.s20_1)#`n"       # [Без ввода] = Возврат в меню Личных Настроек
    }

    Selection = @{
        
         1 = '& Manage-Optional-Features | -SaveList -NoPause', '& Manage-Capabilities | -SaveList'

        10 = '& Manage-Optional-Features | Set'
       100 = '& Manage-Optional-Features | Set -Select'

        20 = '& Manage-Capabilities | Set'
       200 = '& Manage-Capabilities | Set -Select'

        30 = '& Manage-Optional-Features | Set -NoPause', '& Manage-Capabilities | Set'

   'Exit' = '  ◄◄◄ SelfMenu', '$Menu_SelfMenu'

    }
}
