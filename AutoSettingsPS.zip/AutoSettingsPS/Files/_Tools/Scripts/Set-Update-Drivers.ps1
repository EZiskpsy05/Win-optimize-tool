﻿
<#
.SYNOPSIS
 Настройка обновления драйверов через Центр Обновления Системы
 заготовленными несколькими вариантами: Отключение Автоустановки и принудительная блокировка.


.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.
 Сделано для меню $Menu_Set_Update_Drivers.
 Используется функция Get-Pause для установки паузы.
 Используется функция Set-Reg для установки параметров реестра, с проверкой и выводом результата.
 Используется функция Set-LGP для установки параметров реестра, с проверкой и выводом результата.
 Set-LGP настраивает параметры через утилиту LGPO.exe, поэтому все параметры будут отображены в оснастке ГП.
 Используется функция Set-OwnerAndAccess для установки прав на разделы реестра.

.EXAMPLE
    Set-Update-Drivers -Act Set -Option Lock -ApplyGP

    Описание
    --------
    Отключение поиска + блокировка обновления драйверов.


.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  09-04-2019
 ===============================================

#>
Function Set-Update-Drivers {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $true,  ParameterSetName = 'Set', Position = 0 )]
        [ValidateSet( 'Set', 'Check', 'Default' )]
        [string] $Act
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set', Position = 1 )]
        [ValidateSet( 'Disable', 'Lock' )]
        [string] $Option = 'Disable'
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set' )]
        [switch] $ApplyGP
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Check' )]
        [ValidateSet( 'DriversLoad', 'DriversSearch', 'DriversPriority', # 'MasterUpdate',
                      'MetaDataLoad', 'SearchOrder', 'DriversReports', 'DriversIdentifyLock', 'DriversSearchLock' )]
        [string] $CheckState
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    if ( $CheckState )
    {
        if ( $CheckState -eq 'DriversLoad' )
        {
            try { [int] $DriversLoad = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate','ExcludeWUDriversInQualityUpdate',$null)
            } catch { $DriversLoad = $null }

            if ( 1 -eq $DriversLoad ) {  "#Green#{0}#" -f $(if ( $L.s1 ) { $L.s1 } else { "Отключена загрузка         " }) }
            else                      { "#Yellow#{0}#" -f $(if ( $L.s2 ) { $L.s2 } else { "По умолчанию               " }) }
        }
        elseif ( $CheckState -eq 'DriversSearch' )
        {
            try { [int] $DriversSearch = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\DriverSearching','DontSearchWindowsUpdate',$null)
            } catch { $DriversSearch = $null }

            if ( 1 -eq $DriversSearch ) {  "#Green#{0}#" -f $(if ( $L.s3 ) { $L.s3 } else { "Отключен                   " }) }
            else                        { "#Yellow#{0}#" -f $(if ( $L.s4 ) { $L.s4 } else { "По умолчанию               " }) }
        }
        elseif ( $CheckState -eq 'DriversPriority' )
        {
            try { [int] $Priority = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Settings','AllSigningEqual',$null)
            } catch { $Priority = $null }

            if ( 1 -eq $Priority ) {  "#Green#{0}#" -f $(if ( $L.s5 ) { $L.s5 } else { "Равный                     " }) }
            else                   { "#Yellow#{0}#" -f $(if ( $L.s6 ) { $L.s6 } else { "По умолчанию               " }) }
        }
       <#elseif ( $CheckState -eq 'MasterUpdate' )
        {
            try { $MasterUpdate = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\DriverSearching','DriverUpdateWizardWuSearchEnabled',$null)
            } catch { $MasterUpdate = $null }

            if ( 0 -eq $MasterUpdate ) {  "#Green#{0}#" -f $(if ( $L.s7 ) { $L.s7 } else { "Отключен                   " }) }
            else                       { "#Yellow#{0}#" -f $(if ( $L.s8 ) { $L.s8 } else { "По умолчанию               " }) }
        }#>
        elseif ( $CheckState -eq 'MetaDataLoad' )
        {
            try { [int] $MetaDataLoad = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\Device Metadata','PreventDeviceMetadataFromNetwork',$null)
            } catch { $MetaDataLoad = $null }

            if ( 1 -eq $MetaDataLoad ) {  "#Green#{0}#" -f $(if ( $L.s9  ) { $L.s9  } else { "Запрещено                  " }) }
            else                       { "#Yellow#{0}#" -f $(if ( $L.s10 ) { $L.s10 } else { "По умолчанию               " }) }
        }
        elseif ( $CheckState -eq 'SearchOrder' )
        {
            try { $SearchOrder = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\DriverSearching','SearchOrderConfig',$null)
            } catch { $SearchOrder = $null }

            if ( 0 -eq $SearchOrder ) {  "#Green#{0}#" -f $(if ( $L.s11 ) { $L.s11 } else { "Отключен                   " }) }
            else                      { "#Yellow#{0}#" -f $(if ( $L.s12 ) { $L.s12 } else { "По умолчанию               " }) }
        }
        elseif ( $CheckState -eq 'DriversReports' )
        {
            $Reports = $Reports1 = $Reports2 = $null

            try { [int] $Reports1 = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Settings','DisableSendRequestAdditionalSoftwareToWER',$null) } catch {}
            try { [int] $Reports2 = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Settings','DisableSendGenericDriverNotFoundToWER',$null) } catch {}

            try { [int] $Reports = $Reports1 + $Reports2 } catch { [int] $Reports = 0 }

            if     ( 2 -eq $Reports ) {  "#Green#{0}#" -f $(if ( $L.s13 ) { $L.s13 } else { "Отключена отправка         " }) }
            elseif ( 1 -eq $Reports ) { "#Yellow#{0}#" -f $(if ( $L.s14 ) { $L.s14 } else { "Отключено частично         " }) }
            else                      { "#Yellow#{0}#" -f $(if ( $L.s15 ) { $L.s15 } else { "По умолчанию               " }) }
        }
        elseif ( $CheckState -eq 'DriversIdentifyLock' )
        {
            $DriversIdentifyLock = $null

            try { [string] $DriversIdentifyLock = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\WindowsUpdate\ExpressionEvaluators\Driver','DLL',$null) } catch {}

            if ( 'wuuhext.dll' -eq $DriversIdentifyLock ) { "#Yellow#{0}#" -f $(if ( $L.s16 ) { $L.s16 } else { "По умолчанию               " }) }
            else                                          {  "#Green#{0}#" -f $(if ( $L.s17 ) { $L.s17 } else { "Заблокирована              " }) }
        }
        elseif ( $CheckState -eq 'DriversSearchLock' )
        {
            $DriversSearchLock = $null

            try { [string] $DriversSearchLock = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\WindowsUpdate\UpdateHandlers\Driver','DLL',$null) } catch {}

            if ( 'wuuhext.dll' -eq $DriversSearchLock ) { "#Yellow#{0}#" -f $(if ( $L.s18 ) { $L.s18 } else { "По умолчанию               " }) }
            else                                         { "#Green#{0}#" -f $(if ( $L.s19 ) { $L.s19 } else { "Заблокирована              " }) }
        }

        Return
    }

    if ( $Act -ne 'Default' )
    {
        $text = if ( $L.s20 ) { $L.s20 } else { "Настройка Обновлений Драйверов" }
        Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline

        $text = if ( $L.s20_1 ) { $L.s20_1 } else { "Функция" }
        Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray

        if (( $Option -eq 'Disable' ) -or ( $Option -eq 'Lock' ))
        {
            $text = if ( $L.s21 ) { $L.s21 } else { "Отключение Автоустановки драйверов" }
            Write-Host "`n   $text`:`n" -ForegroundColor DarkCyan

            # Комп\Адм. Шабл\Компоненты Windows\Центр обновления Windows\ "Не включать драйвера в обновления Windows" (Включено)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'ExcludeWUDriversInQualityUpdate' -Type DWord 1

            # Комп\Адм. Шабл\Система\Управление связью через Интернет\Параметры связи через Интернет\ "Отключить поиск драйверов устройств в Центре обновления Windows" (Включено)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DriverSearching' -Name 'DontSearchWindowsUpdate' -Type DWord 1

            # Комп\Адм. Шабл\Система\Установка устройства\ "Задать порядок поиска ... драйверов" (Включена, не искать)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DriverSearching' -Name 'SearchOrderConfig' -Type DWord 0

            # Параметра нет в оснастке ГП.  устаревший
            # Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DriverSearching' -Name 'DriverUpdateWizardWuSearchEnabled' -Type DWord 0

            # Комп\Адм. Шабл\Система\Установка устройства\ "Устанавливать одинаковый приоритет для драйверов с цифровой подписью" (Включена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Settings' -Name 'AllSigningEqual' -Type DWord 1

            # Комп\Адм. Шабл\Система\Установка устройства\ "Не отправлять отчет об ошибках при запросе доп. програмного обеспечения ..." (Включена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Settings' -Name 'DisableSendRequestAdditionalSoftwareToWER' -Type DWord 1

            # Комп\Адм. Шабл\Система\Установка устройства\ "Не отправлять отчет об ошибках если установлен универсальный драйвер ..." (Включена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Settings' -Name 'DisableSendGenericDriverNotFoundToWER' -Type DWord 1

            # Комп\Адм. Шабл\Система\Установка устройства\ "Запретить получение метаданных устройств из Интернета" (Включена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Device Metadata' -Name 'PreventDeviceMetadataFromNetwork' -Type DWord 1

            # Отключение поиска и скачивания приложений и значков для ваших устройства
            # Эти настройки в: Свойства системы -> Оборудование -> параметры установки устройств
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Device Metadata' -Name 'PreventDeviceMetadataFromNetwork' -Type DWord 1
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\DriverSearching' -Name 'SearchOrderConfig' -Type DWord 0


            if ( $Option -eq 'Lock' )
            {
                $text = if ( $L.s22 ) { $L.s22 } else { "Принудительная блокировка обновления драйверов" }
                Write-Host "`n   $text`:`n" -ForegroundColor DarkCyan

                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WindowsUpdate\ExpressionEvaluators\Driver' -Name 'DLL' -Type String '1wuuhext.dll1'
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WindowsUpdate\ExpressionEvaluators\Driver' -Name 'Prefixes' -Type MultiString '1d1.'
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UpdateHandlers\Driver' -Name 'DLL' -Type String '1wuuhext.dll1'
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UpdateHandlers\Driver' -Name 'LocalOnly' -Type DWord 1
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UpdateHandlers\Driver' -Name 'URI' -Type String 'http://ssschemas.mmmmicrosoft.ccccom/msus/2002/12/UpdateHandlers/Windows'

                if ( $Act -eq 'Set' )
                {
                    [string] $LockSDDL = 'O:BAG:BAD:PAI(D;CI;DCLCWPSDRCWDWO;;;WD)(A;CI;KR;;;SY)(A;CI;KR;;;BA)(A;CI;KR;;;BU)(A;CI;KR;;;AC)
                                         (A;CI;KR;;;S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464)
                                         (A;CI;KR;;;S-1-15-3-1024-1065365936-1281604716-3511738428-1654721687-432734479-3232135806-4053264122-3456934681)'

                    [string] $RegKey = 'SOFTWARE\Microsoft\WindowsUpdate\ExpressionEvaluators\Driver'

                    $text = if ( $L.s23 ) { $L.s23 } else { "Блокировка" }
                    Write-Host "`n   $text`: " -ForegroundColor White -NoNewline
                    Write-Host "HKLM:\$RegKey" -ForegroundColor DarkGray

                    Set-OwnerAndAccess -Path "HKLM:\$RegKey" -RecoverySDDL $LockSDDL

                    [string] $RegKey = 'SOFTWARE\Microsoft\WindowsUpdate\UpdateHandlers\Driver'

                    $text = if ( $L.s23 ) { $L.s23 } else { "Блокировка" }
                    Write-Host "`n   $text`: " -ForegroundColor White -NoNewline
                    Write-Host "HKLM:\$RegKey" -ForegroundColor DarkGray

                    Set-OwnerAndAccess -Path "HKLM:\$RegKey" -RecoverySDDL $LockSDDL
                }
            }
            else
            {
                $text = if ( $L.s24 ) { $L.s24 } else { "Удаление блокировки обновления драйверов" }
                Write-Host "`n   $text`:`n" -ForegroundColor Magenta

                # Восстановление блокировки
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WindowsUpdate\ExpressionEvaluators\Driver' -Name 'DLL' -Type String 'wuuhext.dll'
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WindowsUpdate\ExpressionEvaluators\Driver' -Name 'Prefixes' -Type MultiString 'd.'
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UpdateHandlers\Driver' -Name 'DLL' -Type String 'wuuhext.dll'
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UpdateHandlers\Driver' -Name 'LocalOnly' -Type DWord 0
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UpdateHandlers\Driver' -Name 'URI' -Type String 'http://schemas.microsoft.com/msus/2002/12/UpdateHandlers/WindowsDriver'

                if ( $Act -eq 'Set' )
                {
                    [string] $OrigSDDL = 'O:S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464
                                          G:S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464
                                          D:PAI(A;CIIO;GR;;;SY)(A;;KR;;;SY)(A;;KR;;;BA)(A;CIIO;GR;;;BA)(A;CIIO;GR;;;BU)(A;;KR;;;BU)(A;CIIO;GR;;;AC)(A;;KR;;;AC)
                                          (A;CIIO;GA;;;S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464)
                                          (A;;KA;;;S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464)
                                          (A;;KR;;;S-1-15-3-1024-1065365936-1281604716-3511738428-1654721687-432734479-3232135806-4053264122-3456934681)
                                          (A;CIIO;GR;;;S-1-15-3-1024-1065365936-1281604716-3511738428-1654721687-432734479-3232135806-4053264122-3456934681)'

                    [string] $RegKey = 'SOFTWARE\Microsoft\WindowsUpdate\ExpressionEvaluators\Driver'

                    $text = if ( $L.s25 ) { $L.s25 } else { "Удаление Блокировки с" }
                    Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline
                    Write-Host "HKLM:\$RegKey" -ForegroundColor DarkGray

                    Set-OwnerAndAccess -Path "HKLM:\$RegKey" -RecoverySDDL $OrigSDDL

                    [string] $RegKey = 'SOFTWARE\Microsoft\WindowsUpdate\UpdateHandlers\Driver'

                    $text = if ( $L.s25 ) { $L.s25 } else { "Удаление Блокировки с" }
                    Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline
                    Write-Host "HKLM:\$RegKey" -ForegroundColor DarkGray

                    Set-OwnerAndAccess -Path "HKLM:\$RegKey" -RecoverySDDL $OrigSDDL
                }
            }
        }
    }
    else
    {
        # Раздел восстановления По умолчанию.

        $text = if ( $L.s26 ) { $L.s26 } else { "Восстановление обновлений драйверов (По умолчанию)" }
        Write-Host "`n   $text`:`n" -ForegroundColor Magenta

        # Комп\Адм. Шабл\Компоненты Windows\Центр обновления Windows\ "Не включать драйвера в обновления Windows" (Не задана)
        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'ExcludeWUDriversInQualityUpdate'

        # Комп\Адм. Шабл\Система\Управление связью через Интернет\Параметры связи через Интернет\ "Отключить поиск драйверов устройств в Центре обновления Windows" (Не задана)
        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DriverSearching' -Name 'DontSearchWindowsUpdate'

        # Комп\Адм. Шабл\Система\Установка устройства\ "Задать порядок поиска ... драйверов" (Не задана)
        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DriverSearching' -Name 'SearchOrderConfig'

        # Параметра нет в оснастке ГП.
        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DriverSearching' -Name 'DriverUpdateWizardWuSearchEnabled'

        # Комп\Адм. Шабл\Система\Установка устройства\ "Устанавливать одинаковый приоритет для драйверов с цифровой подписью" (Не задана)
        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Settings' -Name 'AllSigningEqual'

        # Комп\Адм. Шабл\Система\Установка устройства\ "Не отправлять отчет об ошибках при запросе доп. програмного обеспечения ..." (Не задана)
        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Settings' -Name 'DisableSendRequestAdditionalSoftwareToWER'

        # Комп\Адм. Шабл\Система\Установка устройства\ "Не отправлять отчет об ошибках если установлен универсальный драйвер ..." (Не задана)
        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Settings' -Name 'DisableSendGenericDriverNotFoundToWER'

        # Комп\Адм. Шабл\Система\Установка устройства\ "Запретить получение метаданных устройств из Интернета" (Не задана)
        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Device Metadata' -Name 'PreventDeviceMetadataFromNetwork'

        # Отключение поиска и скачивания приложений и значков для ваших устройства
        # Эти настройки в: Свойства системы -> Оборудование -> параметры установки устройств
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Device Metadata' -Name 'PreventDeviceMetadataFromNetwork' -Type DWord 0
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\DriverSearching' -Name 'SearchOrderConfig' -Type DWord 1



        # Восстановление блокировки
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WindowsUpdate\ExpressionEvaluators\Driver' -Name 'DLL' -Type String 'wuuhext.dll'
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WindowsUpdate\ExpressionEvaluators\Driver' -Name 'Prefixes' -Type MultiString 'd.'
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UpdateHandlers\Driver' -Name 'DLL' -Type String 'wuuhext.dll'
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UpdateHandlers\Driver' -Name 'LocalOnly' -Type DWord 0
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UpdateHandlers\Driver' -Name 'URI' -Type String 'http://schemas.microsoft.com/msus/2002/12/UpdateHandlers/WindowsDriver'

        [string] $OrigSDDL = 'O:S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464
                             G:S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464
                             D:PAI(A;CIIO;GR;;;SY)(A;;KR;;;SY)(A;;KR;;;BA)(A;CIIO;GR;;;BA)(A;CIIO;GR;;;BU)(A;;KR;;;BU)(A;CIIO;GR;;;AC)(A;;KR;;;AC)
                             (A;CIIO;GA;;;S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464)
                             (A;;KA;;;S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464)
                             (A;;KR;;;S-1-15-3-1024-1065365936-1281604716-3511738428-1654721687-432734479-3232135806-4053264122-3456934681)
                             (A;CIIO;GR;;;S-1-15-3-1024-1065365936-1281604716-3511738428-1654721687-432734479-3232135806-4053264122-3456934681)'

        [string] $RegKey = 'SOFTWARE\Microsoft\WindowsUpdate\ExpressionEvaluators\Driver'

        $text = if ( $L.s25 ) { $L.s25 } else { "Удаление Блокировки с" }
        Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline
        Write-Host "HKLM:\$RegKey" -ForegroundColor DarkGray

        Set-OwnerAndAccess -Path "HKLM:\$RegKey" -RecoverySDDL $OrigSDDL

        [string] $RegKey = 'SOFTWARE\Microsoft\WindowsUpdate\UpdateHandlers\Driver'

        $text = if ( $L.s25 ) { $L.s25 } else { "Удаление Блокировки с" }
        Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline
        Write-Host "HKLM:\$RegKey" -ForegroundColor DarkGray

        Set-OwnerAndAccess -Path "HKLM:\$RegKey" -RecoverySDDL $OrigSDDL
    }

    if ( $ApplyGP )
    {
        # Если есть подготовленные параметры Групповых политик для LGPO.exe в глобальной переменной $Global:SettingsGP, то выполнится применение ГП.
        Set-LGP -ApplyGP

        $text = if ( $L.s27 ) { $L.s27 } else { "Необходимо перезагрузиться!" }
        Write-Host "`n   ••••• $text •••••" -ForegroundColor Yellow

        Get-Pause
    }
}
