﻿
<#
.SYNOPSIS
 Установка запрета запуска EXE файлов, указанных в пресете.

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.
 Сделано для меню $Menu_Set_Lock_FilesExe.

 Используется функция Get-Pause для установки паузы.
 Используется функция Set-Reg для установки параметров реестра.
 Используется функция Write-HostColor для раскраски вывода.

.EXAMPLE
    Set-Lock-FilesExe -Option 'LockFiles' -Act Set

    Описание
    --------
    Установить запреты запуска EXE файлов, указанных в файле пресетов.

.EXAMPLE
    Set-Lock-FilesExe -Act Default

    Описание
    --------
    Удалить все запреты запуска EXE файлов


.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  21-05-2019
 ===============================================

#>
Function Set-Lock-FilesExe {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $true,  ParameterSetName = 'Set', Position = 0 )]
        [ValidateSet( 'Set', 'Check', 'Default' )]
        [string] $Act
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set', Position = 1 )]
        [ValidateSet( 'LockFiles', 'LockFilesWithShow' )]
        [string] $Option = 'LockFiles'
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set'  )]
        [Parameter( Mandatory = $true,  ParameterSetName = 'Select' )]
        [switch] $Select      # Если указана необходимость выбрать нужные наборы параметров
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Check' )]
        [ValidateSet( 'ShowList', 'LockedCount' )]
        [string] $CheckState
       ,
        [Parameter( Mandatory = $false )]
        [string] $FilePresets = $FilePresetsGlobal
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    # Если будут найдены другие файлы для настроек, состоящих из имени и расширения заданного оригинала,
    # то будет использоваться как пресет для настроек первый из дополнительных найденных.
    try
    {
        [string] $PresetsPath = [System.IO.Path]::GetDirectoryName($FilePresets)
        [string] $PresetsName = [System.IO.Path]::GetFileNameWithoutExtension($FilePresets)
        [string] $PresetsExt  = [System.IO.Path]::GetExtension($FilePresets)

        [string] $FoundPresetsMy = ((Get-ChildItem -File -LiteralPath $PresetsPath -ErrorAction Stop).Where({
            $_.Name -like "$PresetsName`?*$PresetsExt"
        },'First',1)).FullName
    }
    catch { [string] $FoundPresetsMy = '' }

    if ( $FoundPresetsMy ) { $FilePresets = $FoundPresetsMy }

    # Если файл с пресетами существует.
    if ( [System.IO.File]::Exists($FilePresets) )
    {
        # Получение пресетов в переменную.
        try { [string[]] $ListPresets = Get-Content -LiteralPath \\?\$FilePresets -Encoding UTF8 -ErrorAction SilentlyContinue }
        catch { [string[]] $ListPresets = $null }
    }

    [array] $PresetExe = @()

    # Получаем список файлов exe для блокировки из файла пресетов. И заполняем таблицу $AllExeFiles.
    foreach ( $Line in ( $ListPresets -match '^\s*Set-Lock-FileExe-Name\s*=\s*1\s*=.+' ))
    {
        # Берем заданный путь в пресете для указанного файла, отсеивая все непечатные (скрытые) и запрещённые символы, включая TAB.
        if ( $Line -match "^\s*Set-Lock-FileExe-Name\s*=\s*1\s*=\s*(?<FileName>[^$([regex]::Escape([System.IO.Path]::InvalidPathChars))?``#'=*\\/:]+[.]exe\s*)=((?<Note>[^#\n\r]+)=)?" )
        {
            $Number++
            [string] $FileName = $Matches.FileName.Trim()

            try { [string] $FileNote = $Matches.Note.Trim() } catch { [string] $FileNote = '{0}' -f $(if ( $L.s1 ) { $L.s1 } else { 'Нет описания' }) }
            if ( -not $FileNote ) { [string] $FileNote = '{0}' -f $(if ( $L.s1 ) { $L.s1 } else { 'Нет описания' }) }

            $PresetExe += [PSCustomObject] @{ 
                FileName = $FileName
                FileNote = $FileNote
                Locked   = $false
                Preset   = $true
            }
        }
    }

    [array] $ExeLocked = @()

    [string] $LockSubKey = 'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options'

    try { [psobject] $OpenSubkey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($LockSubKey,'ReadSubTree','QueryValues,EnumerateSubKeys') }
    catch { [psobject] $OpenSubkey = $null }

    if ( $OpenSubkey )
    {
        foreach ( $ExeFile in ($OpenSubkey.GetSubKeyNames() -like '*.exe' ) )
        {
            try { [psobject] $Openkey = $OpenSubkey.OpenSubKey($ExeFile,'ReadSubTree','QueryValues') }
            catch { [psobject] $Openkey = $null }

            if ( $Openkey )
            {
                if ( $Openkey.GetValue('Debugger',$null) -like '?*' )
                {
                    $ExeLocked += $ExeFile
                }

                $Openkey.Close()
            }
        }

        $OpenSubkey.Close()
    }

    foreach ( $Exe in $ExeLocked )
    {
        if ( $PresetExe.FileName -like $Exe )
        {
            $PresetExe.Where({$_.FileName -eq $Exe}) | Add-Member -MemberType NoteProperty -Name Locked -Value $true -Force
        }
        else
        {
            $PresetExe += New-Object PSCustomObject -Property @{ FileName = $Exe ; FileNote = '' ; Locked = $true ; Preset = $false }
        }
    }

    [hashtable] $AllExeFiles = @{}
    
    [int] $Number = 0
    foreach ( $Item in ( $PresetExe | Sort-Object -Property FileName -Unique ))
    {
        $Number++
        $AllExeFiles[$Number] = @{}
        $AllExeFiles[$Number]['FileName'] = $Item.FileName
        $AllExeFiles[$Number]['FileNote'] = $Item.FileNote
        $AllExeFiles[$Number]['Locked']   = $Item.Locked
        $AllExeFiles[$Number]['Preset']   = $Item.Preset
    }

    if ( $CheckState -eq 'LockedCount' )
    {
        [int64] $LockedCount = @(@($AllExeFiles.Values.Locked).Where({$_ -eq $true})).Count

        if ( -not $LockedCount ) { "#DarkYellow#{0}#" -f $(if ( $L.s2 ) { $L.s2 } else { 'Нет блокировок' }) }
        else { "#Green#$LockedCount#" }

        Return
    }

    # Не выводить заголовок, если проверка параметров в пресете или предлагается выбор
    if ( -not $CheckState -and -not $Select )
    {
        $text = if ( $L.s3 ) { $L.s3 } else { 'Запрет запуска EXE файлов' }
        Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline

        $text = if ( $L.s3_1 ) { $L.s3_1 } else { 'Функция' }
        Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray

        if ( $Act -eq 'Default' )
        {
            $text = if ( $L.s4 ) { $L.s4 } else { 'Разблокировка (По умолчанию)' }
            Write-Host "   $text" -ForegroundColor Magenta
        }
        elseif ( $Act -eq 'Check' )
        {
            $text = if ( $L.s5 ) { $L.s5 } else { 'Проверка запретов' }
            Write-Host "   $text" -ForegroundColor DarkCyan
        }
        else
        {
            $text = if ( $L.s6 ) { $L.s6 } else { 'Установка запретов' }
            Write-Host "   $text" -ForegroundColor Green
        }
    }

    [int] $NameLenght = 0
    [int] $Lenght = 0
    foreach ( $F in $PresetExe.FileName )
    {
        $NameLenght = $F.Length
        if ( $Lenght -lt $NameLenght ) { $Lenght = $NameLenght }
    }

    if ( $CheckState ) { [int] $Indent = 8 } else { [int] $Indent = 4 ; $Lenght = 0 }

    # Если указана необходимость выбрать нужные параметры.
    if ( $Select -and $AllExeFiles.Count )
    {
        if ( $Act -eq 'Default' ) { $text = if ( $L.s7 ) { $L.s7 } else { 'Введите номера через пробел (убрать запрет)' } }
        else                      { $text = if ( $L.s8 ) { $L.s8 } else { 'Введите номера через пробел (заблокировать)' } }

        Write-Host "      $text" -NoNewline
        
        # Ждем ввода пользователя.
        [string] $Choice = Read-Host -Prompt " "

        [Uint16[]] $SelectedParams = $null

        # Фильтр введеных пользователем данных. Убираются все группы символов, разделенные через пробел и
        # которые не являются положительным числом, число ноль, превышают количество или повторно введенные номера наборов.
        # Если пустая строка, вернуться в меню. В результате создается массив из чисел $SelectedParams, с выбранными существующми намерами.
        if ( -not ( $Choice.Trim() -eq '' ))
        {
            $Choice.Split() | ForEach-Object {
                try
                {
                    [Uint16] $ParamNumber = $_

                    if (( $ParamNumber -gt 0 ) -and ( $ParamNumber -le $AllExeFiles.Count ) -and ( $SelectedParams -notcontains $ParamNumber ))
                    { [Uint16[]] $SelectedParams += $ParamNumber }
                }
                catch {}
            }
        }

        if ( -not $SelectedParams )
        {
            $text = if ( $L.s9 ) { $L.s9 } else { 'Неверный выбор!' }
            Write-Host "`n   $text`n" -ForegroundColor Yellow
            Start-Sleep -Milliseconds 1000
            Return
        }

        $text = if ( $L.s10 ) { $L.s10 } else { 'Выбранные номера' }
        Write-HostColor "`n      $text`: #DarkGray#[ #White#$SelectedParams #DarkGray#]#"
    }

    [string] $LockPath = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options'

    [bool] $Skip = $false

    # Выводим информацию и/или выполняем действие по всему списку
    foreach ( $Number in $AllExeFiles.Keys | Sort-Object )
    {
        if ( $Select -and ( -not ( $SelectedParams -like $Number ) )) { Continue }  # Пропуск не выбранных номеров, если был выбор

        $FileName = $AllExeFiles[$Number]['FileName']
        $FileNote = $AllExeFiles[$Number]['FileNote']

        if ( $FileNote ) { $ShowFileNote = " #DarkGray#| $FileNote" } else { $ShowFileNote = '' }

        $Status = '○' ; $Color = 'Red' ; $ColorName = 'Gray'

        if ( $AllExeFiles[$Number]['Locked'] ) { $Status = '●' ; $Color = 'Green' }
        
        if ( -not $AllExeFiles[$Number]['Preset'] )
        {
            $ColorName = 'DarkCyan'
            $ShowFileNote = " #DarkGray#| #DarkCyan#{0}" -f $(if ( $L.s11 ) { $L.s11 } else { 'Нет в пресете' })

            $Skip = $true
        }
        else { $Skip = $false }

        [string] $ResultShow = "#DarkGray#{0}. #$Color#{1} #$ColorName#{2}$ShowFileNote#" -f
            $Number.ToString().PadLeft($Indent,' '),
            $Status,
            $FileName.ToString().PadRight($Lenght,' ')

        if ( -not $CheckState ) { Write-Host }

        Write-HostColor $ResultShow

        if ( $CheckState -or $Skip ) { Continue }
        
        [string] $Path  = "$LockPath\$FileName"

        if ( $Act -ne 'Default' )
        {
            [string] $Value = 'dllhost.exe'

            if ( $Option -eq 'LockFilesWithShow' )
            {
                $Value = "cmd /c color 4F&echo.&echo.&echo.         $FileName ^| {0}&timeout /t 6 >nul&exit" -f $(if ( $L.s12 ) { $L.s12 } else { 'Программа Заблокирована' })
            }

            Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'Debugger' -Type String $Value
        }
        else
        {
            Set-Reg Remove-ItemProperty -Path $Path -Name 'Debugger'
        }
    }

    if ( -not $AllExeFiles.Count )
    {
        if ( -not $CheckState ) { Write-Host }

        $text = if ( $L.s13 ) { $L.s13 } else { 'Нет заблокированных и указаных EXE в файле пресетов' }
        Write-Host "        $text" -ForegroundColor DarkYellow
    }
    
    if ( -not $CheckState )
    {
        $text = if ( $L.s14 ) { $L.s14 } else { 'Завершено' }
        Write-Host "`n   $text" -ForegroundColor Green
    }

    # Если запуск не из главных меню быстрых настроек (0 и 1) и не вывод состояния для меню
    if ( -not $MenuConfigsQuickSettings -and -not $CheckState )
    {
        Get-Pause
    }
}
