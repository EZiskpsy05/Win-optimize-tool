﻿
<#
.SYNOPSIS
 Закрепление/Открепление/Сброс папок в Быстром доступе проводника.

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.

 Если после закрепления папки пользователя, перенести её в другое расположение, и при этом создается символическая ссылка по этому расположению,
 то закреплённую папку удалить не получиться, без сброса всего Быстрого доступа или удаления символической ссылки.
 Поэтому закреплять папку надо после её перемещения. Иначе ссылка на папку может перестать работать.
 
 Файлы automaticDestinations-ms это специальный формат Jump List File с обычными ярлыками и списком путей внутри, править по простому напрямую корректно ни как.
 https://forensicswiki.xyz/wiki/index.php?title=Jump_Lists

 Создаются в расположениях:
 %AppData%\Microsoft\Windows\Recent\AutomaticDestinations
 %AppData%\Microsoft\Windows\Recent\CustomDestinations

 Несколько примеров для указания системных папок пользователя:

 shell:::{CLSID} или специальных переменных Проводника в виде: 'shell:....' 
 https://www.winhelponline.com/blog/shell-commands-to-access-the-special-folders/
 https://www.outsidethebox.ms/11103/

 Downloads: shell:::{374DE290-123F-4565-9164-39C4925E467B} или shell:Local Downloads
 Desktop:   shell:::{B4BFCC3A-DB2C-424C-B029-7FE99A87C641} или shell:ThisPCDesktopFolder или shell:Desktop
 Documents: shell:::{D3162B92-9365-467A-956B-92703ACA08AF} или shell:Local Documents
 Pictures:  shell:::{24AD3AD4-A569-4530-98E1-AB02F9417AA8} или shell:Local Pictures
 Videos:    shell:::{F86FA3AB-70D2-4FC7-9C99-FCBF05467F3A} или shell:Local Videos
 Music:     shell:::{3DFDF296-DBEC-4FB4-81D1-6A3438BCF4DE} или shell:Local Music

.EXAMPLE
    Pin-UnPin-QuickAccess -Option 'PinToQuickAccess' -Target 'shell:ThisPCDesktopFolder'

    Описание
    --------
    Закрепить Рабочий стол текущего пользователя

.EXAMPLE
    Pin-UnPin-QuickAccess -Option 'UnPinFromQuickAccess' -Target '%SystemDrive%\1'

    Описание
    --------
    Открепить папку C:\1

.EXAMPLE
    Pin-UnPin-QuickAccess -Option 'UnPinAllQuickAccess' 

    Описание
    --------
    Сбросить по умолчанию Быстрый доступ и затем открепить все элементы

.EXAMPLE
    Pin-UnPin-QuickAccess -Option 'ResetQuickAccess' 

    Описание
    --------
    Сбросить по умолчанию Быстрый доступ

.EXAMPLE
    Pin-UnPin-QuickAccess

    Описание
    --------
    Настройка согласно пресету из переменной $FilePresetsGlobal


.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  29-05-2021
 ===============================================

#>
Function Pin-UnPin-QuickAccess {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param (
        [Parameter( Mandatory = $false, Position = 0, ParameterSetName = 'Preset' )]
        [ValidateSet( 'Set', 'Check', 'Default' )] # Не используется, добавлено для работы в скрипте AutoSettingsPS и возможности добавления использования в будущем
        [string] $Act
       ,
        [Parameter( Mandatory = $true,  ParameterSetName = 'TargetPath' )]
        [ValidateSet( 'PinToQuickAccess', 'UnPinFromQuickAccess', 'UnPinAllQuickAccess', 'ResetQuickAccess' )]
        [string] $Option
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'TargetPath' )]
        [string] $TargetPath
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Preset' )]
        [string] $FilePresets = $FilePresetsGlobal
    )
    
    # Получение имени этой функции.
    $NameThisFunction = $MyInvocation.MyCommand.Name

    Write-Host

    if ( $Act -match 'Check|Default' )
    {
        Write-Host "   $NameThisFunction`: 'Check/Default' Not supported" -ForegroundColor DarkGray
        Return
    }

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

     [bool] $ResetQuickAccess   = $false
     [bool] $UnPinAll           = $false
    [array] $UnPinPresetFolders = @()
    [array] $PinPresetFolders   = @()

    if ( -not $Option )
    {
        # Если будут найдены другие файлы для настроек, состоящих от имени и расширения заданного оригинала,
        # то будет использоваться как пресет для настроек первый от дополнительных найденных.
        try
        {
            [string] $PresetsPath = [System.IO.Path]::GetDirectoryName($FilePresets)
            [string] $PresetsName = [System.IO.Path]::GetFileNameWithoutExtension($FilePresets)
            [string] $PresetsExt  = [System.IO.Path]::GetExtension($FilePresets)

            [string] $FoundPresetsMy = ((Get-ChildItem -File -LiteralPath $PresetsPath -ErrorAction Stop).Where({
                $_.Name -like "$PresetsName`?*$PresetsExt"
            },'First',1)).FullName
        }
        catch { [string] $FoundPresetsMy = '' }

        if ( $FoundPresetsMy ) { $FilePresets = $FoundPresetsMy }

        # Если файл с пресетами существует.
        if ( [System.IO.File]::Exists($FilePresets) )
        {
            # Получение пресетов в переменную.
            try { [string[]] $ListPresets = Get-Content -LiteralPath \\?\$FilePresets -Encoding UTF8 -ErrorAction SilentlyContinue }
            catch { [string[]] $ListPresets = $null }
        }

        # Получаем список папок для Закрепления
        foreach ( $Line in ( $ListPresets -match '^\s*Pin-To-QuickAccess\s*=\s*1\s*=' ))
        {
            # Берем заданный путь в пресете, отсеивая некторые непечатные (скрытые) и запрещённые символы, включая TAB.
            if ( $Line -match "^\s*Pin-To-QuickAccess\s*=\s*1\s*=\s*(?<Folder>([a-z]:|shell:)?[^\r\n\t\x02\x1c\x1d\x1e\x1f<>|:?*""\/=]+)\s*==" )
            {
                $PinPresetFolders += $Matches.Folder.Trim()
            }
        }

        # Получаем список папок для Открепления
        foreach ( $Line in ( $ListPresets -match '^\s*UnPin-From-QuickAccess\s*=\s*1\s*=' ))
        {
            # Берем заданный путь в пресете, отсеивая некторые непечатные (скрытые) и запрещённые символы, включая TAB.
            if ( $Line -match "^\s*UnPin-From-QuickAccess\s*=\s*1\s*=\s*(?<Folder>([a-z]:|shell:)?[^\r\n\t\x02\x1c\x1d\x1e\x1f<>|:?*""\/=]+)\s*==" )
            {
                $UnPinPresetFolders += $Matches.Folder.Trim()
            }
        }

        # Получение параметра для сброса быстрого доступа
        if ( $ListPresets.Where({ $_ -match '^\s*Reset-QuickAccess\s*=\s*1\s*=' },'First',1) )
        {
            $ResetQuickAccess = $true
        }

        # Получение параметра для открепления всех элементов быстрого доступа
        if ( $ListPresets.Where({ $_ -match '^\s*UnPin-All-QuickAccess\s*=\s*1\s*=' },'First',1) )
        {
            $UnPinAll = $true
        }
    }

    if (( $Option -match 'ResetQuickAccess|UnPinAllQuickAccess' ) -or $UnPinAll -or $ResetQuickAccess )
    {
        $text = if ( $L.s1 ) { $L.s1 } else { 'Сброс Быстрого доступа' }
        Write-Host "   $text`:" -ForegroundColor DarkCyan
        [string[]] $Files = "$env:APPDATA\Microsoft\Windows\Recent\AutomaticDestinations\5f7b5f1e01b83767.automaticDestinations-ms",
                            "$env:APPDATA\Microsoft\Windows\Recent\AutomaticDestinations\f01b4d95cf55d32a.automaticDestinations-ms"
        
        $text = if ( $L.s2 ) { $L.s2 } else { '   Удаление' }
        Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline
        Write-Host "$($Files[0])" -ForegroundColor DarkGray

        Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline
        Write-Host "$($Files[1])" -ForegroundColor DarkGray

        try { Remove-Item -LiteralPath $Files -Force -ErrorAction SilentlyContinue } catch {}

        Start-Sleep -Milliseconds 200

        if ( $Option -eq 'ResetQuickAccess' ) { Return }
    }

    if (( $Option -eq 'UnPinAllQuickAccess' ) -or $UnPinAll )
    {
        $text = if ( $L.s5 ) { $L.s5 } else { 'Открепление всех элементов Быстрого доступа' }
        Write-Host "   $text`:" -ForegroundColor DarkCyan
        
        [psobject] $Shell = $null
        $Shell = (New-Object -ComObject Shell.Application).Namespace('shell:::{679F85CB-0220-4080-B29B-5540CC05AAB6}')

        if ( $Shell.Title )
        {
            $Shell.Items() | Where-Object { $_.IsFolder -eq $true } | ForEach-Object {
                
                $text = if ( $L.s3 ) { $L.s3 } else { 'Открепление' }
                Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline
                Write-Host "$($_.Name) " -ForegroundColor White -NoNewline
                Write-Host "| $($_.Path)" -ForegroundColor DarkGray

                try { $_.InvokeVerb('unpinfromhome') } catch {}
            }
        }
        
        if ( $Option -eq 'UnPinAllQuickAccess' ) { Return }
    }

    if (( -not $TargetPath ) -and ( -not $PinPresetFolders ) -and ( -not $UnPinPresetFolders ))
    {
        $text = if ( $L.s6 ) { $L.s6 } else { 'Параметры не указаны' }
        Write-Host "   $NameThisFunction`: $text" -ForegroundColor DarkGray
        Return
    }

    if (( $Option -eq 'UnPinFromQuickAccess' ) -or $UnPinPresetFolders )
    {
        if ( $Option -eq 'UnPinFromQuickAccess' ) { $UnPinPresetFolders = $TargetPath }

        foreach ( $Target in ($UnPinPresetFolders.Where({$_})) )
        {
            try { $ShellApp = (New-Object -ComObject Shell.Application).NameSpace($Target) } catch { $ShellApp = $null }

            if ( $Target -like 'shell:*' )
            {
                if ( $ShellApp.Self.Path ) { [string] $Path = $ShellApp.Self.Path } else { [string] $Path = '' }
            }
            else
            {
                [string] $Path = [System.Environment]::ExpandEnvironmentVariables($Target)
            }

            if ( -not $Path )
            {
                $text = if ( $L.s7 ) { $L.s7 } else { 'Открепление: Папка не существует' }
                Write-Host "   $text | $Target" -ForegroundColor DarkGray
                Continue
            }

            $ShellItem = (New-Object -ComObject Shell.Application).Namespace('shell:::{679F85CB-0220-4080-B29B-5540CC05AAB6}').Items() |
                Where-Object { $_.Path -eq $Path }

            if ( $ShellItem.Path )
            {
                $ShellItem | Where-Object { $_.Path -eq $Path } | ForEach-Object { try { $_.InvokeVerb('unpinfromhome') } catch {} } 

                $ShellItem = (New-Object -ComObject Shell.Application).Namespace('shell:::{679F85CB-0220-4080-B29B-5540CC05AAB6}').Items() |
                    Where-Object { $_.Path -eq $Path }

                if ( $ShellItem.Path )
                {
                    $text = if ( $L.s3 ) { $L.s3 } else { 'Открепление' }
                    Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline
                    
                    $text = if ( $L.s8 ) { $L.s8 } else { 'Папка не открепилась от Быстрого доступа' }
                    Write-Host "$text " -ForegroundColor DarkYellow -NoNewline
                    Write-Host "| $Path" -ForegroundColor DarkGray
                }
                else
                {
                    $text = if ( $L.s3 ) { $L.s3 } else { 'Открепление' }
                    Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline

                    $text = if ( $L.s9 ) { $L.s9 } else { 'Папка откреплена от Быстрого доступа' }
                    Write-Host "$text " -ForegroundColor Green -NoNewline
                    Write-Host "| $Path" -ForegroundColor DarkGray
                }
            }
            else
            {
                $text = if ( $L.s10 ) { $L.s10 } else { 'Открепление: Папка не закреплена в Быстром доступе' }
                Write-Host "   $text | $Path" -ForegroundColor DarkGray
            }
        }
    }

    if (( $Option -eq 'PinToQuickAccess' ) -or $PinPresetFolders )
    {
        if ( $Option -eq 'PinToQuickAccess' ) { $PinPresetFolders = $TargetPath }

        foreach ( $Target in ($PinPresetFolders.Where({$_})) )
        {
            if ( $Target -notlike 'shell:*' )
            {
                [string] $Path = [System.Environment]::ExpandEnvironmentVariables($Target)
            }
            else { [string] $Path = $Target }

            try { $ShellApp = (New-Object -ComObject Shell.Application).NameSpace($Path) } catch { $ShellApp = $null }

            $Path = $ShellApp.Self.Path

            if ( $Path )
            {
                try { $ShellApp.Self.InvokeVerb('pintohome') } catch {}

                $ShellItem = (New-Object -ComObject Shell.Application).Namespace('shell:::{679F85CB-0220-4080-B29B-5540CC05AAB6}').Items() |
                    Where-Object { $_.Path -eq $Path }

                if ( $ShellItem.Path )
                {
                    $text = if ( $L.s4 ) { $L.s4 } else { 'Закрепление' }
                    Write-Host "   $text`: " -ForegroundColor Cyan -NoNewline

                    $text = if ( $L.s11 ) { $L.s11 } else { 'Папка закреплена в Быстром доступе' }
                    Write-Host "$text " -ForegroundColor Green -NoNewline
                    Write-Host "| " -ForegroundColor DarkGray -NoNewline
                    Write-Host "$($ShellItem.Name) " -ForegroundColor White -NoNewline
                    Write-Host "| $($ShellItem.Path)" -ForegroundColor DarkGray
                }
            }
            else
            {
                $text = if ( $L.s12 ) { $L.s12 } else { 'Закрепление: Папка не существует' }
                Write-Host "   $text | $Target" -ForegroundColor DarkGray
            }
        }
    }
}
