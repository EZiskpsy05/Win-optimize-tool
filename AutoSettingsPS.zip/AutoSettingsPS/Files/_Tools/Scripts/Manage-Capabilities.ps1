﻿
<#
.SYNOPSIS
 Функция для Установки/Удаления Возможностей Windows (Windows Capabilities)
 Function for Install/Remove Windows Capabilities

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS
 Сделано для меню $Menu_Features_Capabilities

 Используется функция Get-Pause для установки паузы.
 Используется функция Write-HostColor, для вывода информации.
 Используется функция Test-Internet

 Получает из файла пресетов 'Presets.txt' список параметров для настройки и шаблоны исключений.
 Настройка осуществляется через командлеты Add-WindowsCapability и Remove-WindowsCapability
 Выводит текущее состояние указанных параметров


.EXAMPLE
    Manage-Capabilities -SaveList

.EXAMPLE
    Manage-Capabilities Check

.EXAMPLE
    Manage-Capabilities Set


.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  22-03-2021
 ===============================================

#>
Function Manage-Capabilities {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $true,  ParameterSetName = 'First', Position = 0 )]
        [ValidateSet( 'Set', 'Check', 'Default' )]  # Default Не используется, будет выводить сообщение о пропуске.
        [string] $Act
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'First'  )]
        [Parameter( Mandatory = $true,  ParameterSetName = 'Select' )]
        [switch] $Select      # Если указана необходимость выбрать нужные наборы параметров
       ,
        [Parameter( Mandatory = $true,  ParameterSetName = 'SaveList' )]
        [switch] $SaveList
       ,
        [Parameter( Mandatory = $false )]
        [string] $FilePresets = $FilePresetsGlobal
       ,
        [Parameter( Mandatory = $false )]
        [switch] $NoTitle
       ,
        [Parameter( Mandatory = $false )]
        [switch] $NoPause
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    if ( $Act -eq 'Default' )
    {
        $text = if ( $L.s9 ) { $L.s9 } else { "'Default' не предусмотрен" }
        Write-Host "`n   $NameThisFunction`: $text`n" -ForegroundColor DarkGray

        $noDefault = $true

        Return   # Выход из функции
    }

    # Если будут найдены другие файлы для настроек, состоящих из имени и расширения заданного оригинала,
    # то будет использоваться как пресет для настроек первый из дополнительных найденных.
    try
    {
        [string] $PresetsPath = [System.IO.Path]::GetDirectoryName($FilePresets)
        [string] $PresetsName = [System.IO.Path]::GetFileNameWithoutExtension($FilePresets)
        [string] $PresetsExt  = [System.IO.Path]::GetExtension($FilePresets)

        [string] $FoundPresetsMy = ((Get-ChildItem -File -LiteralPath $PresetsPath -ErrorAction Stop).Where({
            $_.Name -like "$PresetsName`?*$PresetsExt"
        },'First',1)).FullName
    }
    catch { [string] $FoundPresetsMy = '' }

    if ( $FoundPresetsMy ) { $FilePresets = $FoundPresetsMy }

    # Если файл с пресетами существует.
    if ( [System.IO.File]::Exists($FilePresets) )
    {
        # Получение пресетов в переменную.
        try { [string[]] $ListPresets = Get-Content -LiteralPath \\?\$FilePresets -Encoding UTF8 -ErrorAction SilentlyContinue }
        catch { [string[]] $ListPresets = $null }
    }

    # Получить шаблоны имён для исключений
    [string[]] $GetExclusions = @()

    foreach ( $Line in ( $ListPresets -match '^\s*Set-Capability-Exclusions\s*=\s*[*]\s*=.+' ))
    {
        if ( $Line -match '^\s*Set-Capability-Exclusions\s*=\s*[*]\s*=\s*(?<Excl>[^\r\n\t\x02\x1c\x1d\x1e\x1f<>|?``=#]+)==' )
        {
            $GetExclusions += @($Matches.Excl.Split(',').Trim('"''* ')).Where({$_})
        }
    }

    # Исключение компонентов, критичных для работоспособности Windows
    $GetExclusions += @('Windows.Client.ShellComponents','DirectX.Configuration.Database')

    if ( $GetExclusions )
    {
        $ExclusionsMatch = ($GetExclusions.ForEach({[regex]::Escape($_)})) -join '|'
        $GetCapabilities = Get-WindowsCapability -Online -ErrorAction SilentlyContinue | Where-Object { $_.Name -notmatch "^($ExclusionsMatch)" }
    }
    else
    {
        $ExclusionsMatch = $null
        $GetCapabilities = Get-WindowsCapability -Online -ErrorAction SilentlyContinue
    }

    if ( $SaveList )
    {
        $text = if ( $L.s1 ) { $L.s1 } else { "Сохранение" }
        Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

        $text = if ( $L.s1_1 ) { $L.s1_1 } else { "списка всех возможных Capabilities (Кроме исключений)" }
        Write-Host "$text " -ForegroundColor Gray

        if ( -not $SaveFileFeaturesGlobal ) { Write-Warning "$NameThisFunction`: The File to save not specified: `$SaveFileFeaturesGlobal" ; Return }
        
        $text = if ( $L.s1_2 ) { $L.s1_2 } else { "Файл" }
        Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline
        Write-Host "$SaveFileFeaturesGlobal" -ForegroundColor White

        $SaveExclusions = ''

        if ( $GetExclusions )
        {
            $SaveExclusions = $GetExclusions -join '; '

            $text = if ( $L.s2 ) { $L.s2 } else { "Шаблоны исключений" }
            Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline
            Write-Host "$SaveExclusions`n" -ForegroundColor DarkCyan
        }

        $N = 0
        $Count = $GetCapabilities.Count
        $Format = @(1..$Count.ToString().Length).ForEach({'0'}) -join ''

        $CapabilitiesAll = $GetCapabilities.Name | ForEach-Object -Process {
            $N++
            Write-Host " | $(($N).ToString($Format)) : $Count | $_"
            Get-WindowsCapability -Online -Name $_
        }

        $Data = @()
        [int] $NameLenght = 0
        [int] $Lenght = 0
        foreach ( $C in $CapabilitiesAll )
        {
            $NameLenght = $C.Name.Length
            if ( $Lenght -lt $NameLenght ) { $Lenght = $NameLenght }
        }

        foreach ( $C in $CapabilitiesAll )
        {
            if ( $C.State -eq 'NotPresent' ) { $StateCap = '---------' } else { $StateCap = $C.State }
            $Data += "     Set-Windows-Capability = 0 = {0} == #Info: {1} | {2} | {3}" -f
                $C.Name.ToString().PadRight($Lenght,' ').Substring(0,$Lenght),
                $StateCap,
                $C.DisplayName,
                $C.Description
        }

        if ( $Data )
        {
            # Все данные по Windows в начало экспортного списка
            try { "`n`n   Windows Capabilities" | Out-File -Width 1000 -FilePath $SaveFileFeaturesGlobal -Force -Encoding utf8 -Append }
            catch { throw }

            if ( $SaveExclusions )
            {
                $text = if ( $L.s2 ) { $L.s2 } else { "Шаблоны исключений" }
                try { "`n   $text`: $SaveExclusions`n" | Out-File -Width 1000 -FilePath $SaveFileFeaturesGlobal -Force -Encoding utf8 -Append }
                catch { throw }
            }
            else { $Append = $false }

            try { $Data | Out-File -Width 1000 -FilePath $SaveFileFeaturesGlobal -Force -Encoding utf8 -Append }
            catch { throw }
        }
        else
        {
            Write-Warning "$NameThisFunction`: No data in Get-WindowsCapability -Online"
        }

        if ( -not $NoPause ) { Get-Pause }
        
        Return    # Выход
    }

    [int] $Number = 0
    [hashtable] $Capabilities = @{}

    # Заполняем таблицу $Capabilities. Для каждой строки подходящей под шаблон
    foreach ( $Line in ( $ListPresets -match '^\s*Set-Windows-Capability\s*=\s*[12]\s*=.+' ))
    {
        # Если строка совпадает с шаблоном, и не содержит все непечатные (скрытые) и запрещённые символы, включая TAB.
        if ( $Line -match '^\s*Set-Windows-Capability\s*=\s*(?<Run>[12])\s*=\s*(?<LikeName>[^\r\n\t\x02\x1c\x1d\x1e\x1f<>|?``=#]+)==' )
        {
            [string] $LikeName = $Matches.LikeName.Trim()
            [string] $Run      = $Matches.Run.Trim()

            $CapabilitiesMatch = @( $GetCapabilities | Where-Object { $_.Name -like $LikeName } )
            
            if ( $CapabilitiesMatch )
            {
                foreach ( $Capability in $CapabilitiesMatch )
                {
                    $Number++

                    $Name = $Capability.Name

                    $Capabilities[$Number] = @{}
                    $Capabilities[$Number]['Skip'] = $false
                    $Capabilities[$Number]['Err']  = ''
                    $Capabilities[$Number]['Stat'] = $Capability.State

                    if ( $Run -eq 1 ) { $Capabilities[$Number]['Run'] = 'Remove'  }
                    else              { $Capabilities[$Number]['Run'] = 'Install' }

                    # Этот блок для вывода только одной строки, с подходящим под шаблон имени (LikeName) для удаления, 
                    # если все подходящие Capabilities уже удалены
                    # Так как при указании шаблона по началу имени ААА* может совпадать с большим количеством Capabilities,
                    # а раз с ними ничего делать не надо, то и выводить их все смысла нет (не удобно прокручивать большой список)
                    #
                    # Если шаблон имени указан для удаления и текущее совпадение с Capability уже удалено
                    if (( $Capabilities[$Number]['Run'] -eq 'Remove' ) -and ( $Capability.State -eq 'NotPresent' ))
                    {
                        # Если уже добавлен шаблон имени в список (для всех уже удалённых)
                        if ( @(foreach ( $Key in $Capabilities.Keys ) { $Capabilities[$Key]['Name'] }) -eq $LikeName )
                        {
                            # удалить строку и откатить номер
                            $Capabilities.Remove($Number)
                            $Number--
                        }
                        else
                        {
                            # Если нет ни одного установленного Capability, подходящего под шаблон имени
                            if ( -not @(foreach ( $C in $CapabilitiesMatch ) { $( if ( $C.State -eq 'Installed' ) { $true } ) } ))
                            {
                                # Добавить имя в список как шаблон поиска (подходящий для всех уже удалённых)
                                $Capabilities[$Number]['Name'] = $LikeName
                            }
                            else
                            {
                                # Иначе, удалить строку и откатить номер
                                $Capabilities.Remove($Number)
                                $Number--
                            }
                        }

                        Continue  # пропустить дальнейшие действия с этим совпадением
                    }

                    if ( @(foreach ( $Key in $Capabilities.Keys ) { $Capabilities[$Key]['Name'] }) -like $Name )
                    {
                        $Capabilities[$Number]['Skip'] = $true
                        $Capabilities[$Number]['Err']  = if ( $L.s3 ) { $L.s3 } else { 'Дубликат имени' }
                        $Capabilities[$Number]['dupl'] = $true
                        $Capabilities[$Number]['Stat'] = ''
                    }

                    $Capabilities[$Number]['Name']    = $Name
                    $Capabilities[$Number]['Pattern'] = $LikeName
                }
            }
            else
            {
                $Number++
                $Capabilities[$Number] = @{}
                $Capabilities[$Number]['Skip'] = $true
                $Capabilities[$Number]['Stat'] = ''

                if ( $Run -eq 1 ) { $Capabilities[$Number]['Run'] = 'Remove'  }
                else              { $Capabilities[$Number]['Run'] = 'Install' }

                # LikeName с * в конце не влияет по сути, в данному случае, на результат для match!
                if ( $ExclusionsMatch -and ( $LikeName -match "^($ExclusionsMatch)" ))
                {
                    $Capabilities[$Number]['Err']  = if ( $L.s5 ) { $L.s5 } else { "Подпадает под шаблон исключений" } # Matches into an Exclusions Pattern
                    $Capabilities[$Number]['Excl'] = $true
                }
                else
                {
                    $Capabilities[$Number]['Err']       = if ( $L.s6 ) { $L.s6 } else { 'Нет совпадений' }
                    $Capabilities[$Number]['WrongName'] = $true
                }

                foreach ( $Key in $Capabilities.Keys )
                {
                    if (( $LikeName -eq $Capabilities[$Key]['Name'] ) -and ( $Capabilities[$Key]['WrongName'] ))
                    {
                        $Capabilities[$Number]['Err'] = if ( $L.s4 ) { $L.s4 } else { 'Нет совпадений (дубликат)' }
                        break
                    }
                }
                
                $Capabilities[$Number]['Name'] = $LikeName
            }
        }
        elseif ( $Line -match '^\s*Set-Windows-Capability\s*=\s*(?<Run>[12])\s*=\s*(?<LikeName>.+)==' )
        {
            # Иначе если строка имеет запрещенные символы, пропускать

            [string] $LikeName = $Matches.LikeName.Trim()
            [string] $Run      = $Matches.Run.Trim()

            $Number++
                
            $Capabilities[$Number] = @{}
            $Capabilities[$Number]['Skip'] = $true
            $Capabilities[$Number]['Stat'] = ''

            if ( $Run -eq 1 ) { $Capabilities[$Number]['Run'] = 'Remove'  }
            else              { $Capabilities[$Number]['Run'] = 'Install' }

            if ( $(foreach ( $Key in $Capabilities.Keys ) { $Capabilities[$Key]['Name'] }) -like $LikeName )
            {
                $Capabilities[$Number]['Err'] = if ( $L.s7 ) { $L.s7 } else { 'Запрещённые символы в строке пресета (дубликат)' }
            }
            else
            {
                $Capabilities[$Number]['Err'] = if ( $L.s8 ) { $L.s8 } else { 'Запрещённые символы в строке пресета' }
            }
            
            $Capabilities[$Number]['Name'] = $LikeName
        }
    }

    # Не выводить заголовок, если проверка параметров в пресете или предлагается выбор
    if ( -not $NoTitle -and -not $Select )
    {
        $text = if ( $L.s10 ) { $L.s10 } else { "Настройка" }
        Write-Host "`n██ $text " -ForegroundColor White -NoNewline

        $text = if ( $L.s10_1 ) { $L.s10_1 } else { "Windows Capabilities" }
        Write-Host "$text " -ForegroundColor White -NoNewline

        $text = if ( $L.s10_2 ) { $L.s10_2 } else { "Функция" }
        Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray
    }

    if ( -not $NoTitle ) { [int] $Indent = 4 } else { [int] $Indent = 7 }

    # Если указана необходимость выбрать нужные параметры.
    if ( $Select -and $Capabilities.Count )
    {
        $text = if ( $L.s11 ) { $L.s11 } else { 'Введите номера' }
        Write-Host "      $text " -NoNewline
        Write-Host "Capabilities" -ForegroundColor White -NoNewline
        
        # Ждем ввода пользователя.
        [string] $Choice = Read-Host -Prompt " "

        [Uint16[]] $SelectedParams = $null

        # Фильтр введеных пользователем данных. Убираются все группы символов, разделенные через пробел и
        # которые не являются положительным числом, число ноль, превышают количество или повторно введенные номера наборов.
        # Если пустая строка, вернуться в меню. В результате создается массив из чисел $SelectedParams, с выбранными существующми намерами.
        if ( -not ( $Choice.Trim() -eq '' ))
        {
            $Choice.Split() | ForEach-Object {
                try
                {
                    [Uint16] $ParamNumber = $_

                    if (( $ParamNumber -gt 0 ) -and ( $ParamNumber -le $Capabilities.Count ) -and ( $SelectedParams -notcontains $ParamNumber ))
                    { [Uint16[]] $SelectedParams += $ParamNumber }
                }
                catch {}
            }
        }

        if ( -not $SelectedParams )
        {
            $text = if ( $L.s12 ) { $L.s12 } else { 'Неверный выбор!' }
            Write-Host "`n   $text`n" -ForegroundColor Yellow
            Start-Sleep -Milliseconds 1000
            Return
        }

        $text = if ( $L.s13 ) { $L.s13 } else { 'Выбранные номера' }
        Write-HostColor "`n      $text`: #DarkGray#[ #White#$SelectedParams #DarkGray#]#`n"
    }

    # Выводим информацию по всем строкам.
    foreach ( $Number in $Capabilities.Keys | Sort-Object )
    {
        if ( $Select -and ( -not ( $SelectedParams -like $Number ) )) { Continue }  # Пропуск не выбранных номеров, если был выбор

        $Run     = $Capabilities[$Number]['Run']
        $Name    = $Capabilities[$Number]['Name']
        $State   = $Capabilities[$Number]['Stat']
        $Pattern = $Capabilities[$Number]['Pattern']

        if ( $Capabilities[$Number]['Skip'] )
        {
            $Status = 'х' ; $ColorName = 'Red' ; $Color = 'Red'

            if ( $Capabilities[$Number]['Excl'] )
            {
                $ColorName = 'DarkGray' ; $Color = 'DarkCyan'
            }
            elseif ( $Capabilities[$Number]['WrongName'] -or $Capabilities[$Number]['dupl'] )
            {
                $ColorName = 'DarkGray' ; $Color = 'DarkGray'
            }

            [string] $ResultShow = "#DarkGray#{0}. #Red#{1} #DarkGray#{2} | #$ColorName#{3} #DarkGray#| #$Color#{4}#" -f
                $Number.ToString().PadLeft($Indent,' '),
                $Status,
                $Run.ToString().PadRight(7,' ').Substring(0,7),
                $Name,
                $Capabilities[$Number]['Err']
        }
        else
        {
            $Status = '○' ; $ColorName = 'White' ; $Color = 'Yellow'

            if ( $State -eq 'Installed' )
            {
                if ( $Run -eq 'Install' ) { $Status = '●' ; $Color = 'Green' ; $ColorName = 'Green' ; $Capabilities[$Number]['Skip'] = $true }
            }
            else
            {
                if ( $Run -eq 'Remove'  ) { $Status = '●' ; $Color = 'Green' ; $ColorName = 'Green' ; $Capabilities[$Number]['Skip'] = $true }
            }

            if ( $Pattern ) { $ShowPattern = " | $Pattern" } else { $ShowPattern = '' }

            [string] $ResultShow = "#DarkGray#{0}. #$Color#{1} #DarkGray#{2} | #$ColorName#{3}#DarkGray#{4}#" -f
                $Number.ToString().PadLeft($Indent,' '),
                $Status,
                $Run.ToString().PadRight(7,' ').Substring(0,7),
                $Name,
                $ShowPattern
        }

        if ( -not $NoTitle ) { Write-Host }

        Write-HostColor $ResultShow

        if ( $Act -eq 'Check' )
        {
            if (( -not $Capabilities[$Number]['Skip'] ) -and ( -not $NoTitle )) { $NeedFix = $true }

            Continue
        }


        # Далее, если выполнение ...

        if ( $Capabilities[$Number]['Skip'] )
        {
            if ( $Capabilities[$Number]['Err'] )
            {
                $text = if ( $L.s14 ) { $L.s14 } else { 'Пропущено' }
                Write-Host "        $text" -ForegroundColor DarkYellow
            }
            else
            {
                if ( $State -eq 'Installed' )
                {
                    $text = if ( $L.s15 ) { $L.s15 } else { 'Уже Установлено' }
                    Write-Host "        $text" -ForegroundColor DarkGreen
                }
                else
                {
                    $text = if ( $L.s16 ) { $L.s16 } else { 'Уже удалено' }
                    Write-Host "        $text" -ForegroundColor DarkGreen
                }
            }

            Continue
        }

        # Выполняем ..............
        
        # $ProgressPreference = 'SilentlyContinue'
        
        if ( $Run -eq 'Install' )
        {
            $text = if ( $L.s17 ) { $L.s17 } else { 'Установка' }
            Write-Host "        >>>" -ForegroundColor DarkGray -NoNewline
            Write-Host " $text" -ForegroundColor Green
            Write-Host "        Add-WindowsCapability -Online -Name $Name" -ForegroundColor DarkGray

            if ( Test-Internet -Bool -Access )
            {
                try { Add-WindowsCapability -Online -Name $Name -ErrorAction Continue > $null }
                catch
                {
                    Write-Host "        Error: $($_.CategoryInfo.Category): $($_.Exception.Message)" -ForegroundColor Red
                    $NeedFix = $true
                }
            }
            else
            {
                $text = if ( $L.s20 ) { $L.s20 } else { "Нет доступа в Интернет для PS" }
                Write-Host "        $text" -ForegroundColor Red
            }
        }
        else
        {
            $text = if ( $L.s18 ) { $L.s18 } else { 'Удаление' }
            Write-Host "        >>>" -ForegroundColor DarkGray -NoNewline
            Write-Host " $text" -ForegroundColor Magenta
            Write-Host "        Remove-WindowsCapability -Online -Name $Name" -ForegroundColor DarkGray

            try { Remove-WindowsCapability -Online -Name $Name -ErrorAction Continue > $null }
            catch
            {
                Write-Host "        Error: $($_.CategoryInfo.Category): $($_.Exception.Message)" -ForegroundColor Red
                $NeedFix = $true
            }
        }

        $ProgressPreference = 'Continue'
    }

    if ( -not $Capabilities.Count )
    {
        $text = if ( $L.s19 ) { $L.s19 } else { 'Не указаны Параметры в файле пресетов' }

        if ( $NoTitle )
        {
            Write-Host "         $text" -ForegroundColor DarkYellow
        }
        else
        {
            Write-Host "`n   $text`n" -ForegroundColor DarkYellow
        }
    }

    if ( $Act -eq 'Check' )
    {
        Return
    }

    # Если запуск не из главных меню быстрых настроек (0 и 1) и не запрещена пауза тут
    if ( -not $MenuConfigsQuickSettings -and -not $NoPauses -and -not $NoPause )
    {
        Get-Pause
    }

    Return
}
