﻿
Function Set-Sound-VolumeDown {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param (
        [Parameter( Mandatory = $true,  ParameterSetName = 'Set', Position = 0 )]
        [ValidateSet( 'Set', 'Check', 'Default' )]
        [string] $Act
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set', Position = 1 )]
        [ValidateSet( 'SetVolumeDown', 'SetNoSound' )]
        [string] $Option = 'SetVolumeDown'
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set', Position = 2 )]
        [string] $ToLevel  # Default = 50 %
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set', Position = 3 )]
        [int] $ThresholdDb = -70
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set' )]
        [string] $ffmpeg = $ffmpegExe
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Check' )]
        [ValidateSet( 'AudioProfile', 'VolumePresets' )]
        [string] $CheckState
       ,
        [Parameter( Mandatory = $false )]
        [string] $FilePresets = $FilePresetsGlobal
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    # Если будут найдены другие файлы для настроек, состоящих из имени и расширения заданного оригинала,
    # то будет использоваться как пресет для настроек первый из дополнительных найденных.
    try
    {
        [string] $PresetsPath = [System.IO.Path]::GetDirectoryName($FilePresets)
        [string] $PresetsName = [System.IO.Path]::GetFileNameWithoutExtension($FilePresets)
        [string] $PresetsExt  = [System.IO.Path]::GetExtension($FilePresets)

        [string] $FoundPresetsMy = ((Get-ChildItem -File -LiteralPath $PresetsPath -ErrorAction Stop).Where({
            $_.Name -like "$PresetsName`?*$PresetsExt"
        },'First',1)).FullName
    }
    catch { [string] $FoundPresetsMy = '' }

    if ( $FoundPresetsMy ) { $FilePresets = $FoundPresetsMy }

    # Если файл с пресетами существует.
    if ( [System.IO.File]::Exists($FilePresets) )
    {
        # Получение пресетов в переменную.
        try { [string[]] $ListPresets = Get-Content -LiteralPath \\?\$FilePresets -Encoding UTF8 -ErrorAction SilentlyContinue }
        catch {}
    }

    if (( -not $ToLevel ) -and -not ( $Option -eq 'SetNoSound' ))
    {
        # Получаем список файлов exe для блокировки из файла пресетов. И заполняем таблицу $ExeFilesForLock.
        foreach ( $Line in ( $ListPresets -match '^\s*Set-Sound-VolumeDown\s*=.+' ))
        {
            # Берем заданный путь в пресете для указанного файла, отсеивая все непечатные (скрытые) и запрещённые символы, включая TAB.
            if ( $Line -match '^\s*Set-Sound-VolumeDown\s*=\s*(?<ToLevel>[\d]+)\s*=\s*(?<Threshold>[\d-]+)\s*=' )
            {
                [int] $ToLevel     = $Matches.ToLevel.Trim()
                [int] $ThresholdDb = $Matches.Threshold.Trim()

                break
            }
        }
    }

    [string] $SoundProfileName    = 'VolumeDownWav'
    [string] $MediaSystemPath     = "$env:SystemDrive\Windows\media"
    [string] $MediaVolumeDownPath = "$MediaSystemPath\$SoundProfileName`_All_Users"  # "$MediaSystemPath\$SoundProfileName`_$env:USERNAME"

    if ( $CheckState )
    {
        if ( 'AudioProfile' -eq $CheckState )
        {
            try { [string] $CurrentProfile = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey('AppEvents\Schemes','ReadSubTree','QueryValues,EnumerateSubKeys').GetValue('',$null) }
            catch { [string] $CurrentProfile = '' }

            try { [string] $CurrentName = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey("AppEvents\Schemes\Names\$SoundProfileName",'ReadSubTree','QueryValues,EnumerateSubKeys').GetValue('',$null) }
            catch { [string] $CurrentName = '' }

            if ( $CurrentProfile -and $CurrentProfile -eq '.Default' )
            {
                "#Yellow#{0}#" -f $(if ( $L.s1 ) { $L.s1 } else { "По умолчанию" })
            }
            elseif ( $CurrentProfile -and $CurrentProfile -eq '.None' )
            {
                "#Green#{0}#" -f $(if ( $L.s2 ) { $L.s2 } else { "Без звука" })
            }
            elseif ( $CurrentName -and $CurrentProfile -and $CurrentProfile -eq $SoundProfileName )
            {
                "#Green#$CurrentName#"
            }
            else
            {
                "#Red#{0}#" -f $(if ( $L.s3 ) { $L.s3 } else { "Не известно" })
            }
        }
        elseif ( 'VolumePresets' -eq $CheckState )
        {
            # Получаем список файлов exe для блокировки из файла пресетов. И заполняем таблицу $ExeFilesForLock.
            foreach ( $Line in ( $ListPresets -match '^\s*Set-Sound-VolumeDown\s*=.+' ))
            {
                # Берем заданный путь в пресете для указанного файла, отсеивая все непечатные (скрытые) и запрещённые символы, включая TAB.
                if ( $Line -match '^\s*Set-Sound-VolumeDown\s*=\s*(?<ToLevel>[\d]+)\s*=\s*(?<Threshold>[\d-]+)\s*=' )
                {
                    [int] $ToLevel     = $Matches.ToLevel.Trim()
                    [int] $ThresholdDb = $Matches.Threshold.Trim()

                    break
                }
            }

            if ( $ToLevel -eq 0 )
            {
                [int] $ToLevel = 0
            }
            elseif ( $ToLevel -notmatch '^([1-9]?[1-9]|[1-9][0])$' )
            {
                # $ToLevel от 1 по 99  (Диапазон Громкости %)
                [int] $ToLevel = 50
            }
            else
            {
                [int] $ToLevel = $ToLevel
            }

            #  $ThresholdDb  от -50 по -80 (Диапазон Нижнего Порога dB)
            if ( $ThresholdDb -notmatch '^(-[5-7][1-9]|-[5-8][0])$' )
            {
                if     ( $ThresholdDb -gt -50 ) { $ThresholdDb = -50 }
                elseif ( $ThresholdDb -lt -80 ) { $ThresholdDb = -80 }
                else                            { $ThresholdDb = -70 }
            }

            if ( $ToLevel -eq 0 )
            {
                "#Cyan#{0}#" -f $(if ( $L.s2 ) { $L.s2 } else { "Без звука" })
            }
            elseif ( $ToLevel -and $ThresholdDb )
            {
                "#DarkGray#{0}: #Cyan#$ToLevel% #DarkGray#| {1}: #Magenta#$ThresholdDb dB#" -f $(if ( $L.s4 ) { $L.s4, $L.s5 } else { "Громкость", "Нижний порог" })
            }
            else
            {
                "#Yellow#{0}#" -f $(if ( $L.s6 ) { $L.s6 } else { "Пресет не задан" })
            }
        }

        Return
    }

    if ( $Act -eq 'Set' )
    {
        if ( $ToLevel -eq '0' -or $Option -eq 'SetNoSound' )
        {
            $SoundProfileName = '.None'
            $Option = 'SetNoSound'
        }
    }

    if ( $Option -eq 'SetVolumeDown' -and $Act -eq 'Set' )
    {
        # Проверка существования утилиты ffmpeg.exe
        if ( -not [System.IO.File]::Exists($ffmpeg) )
        {
            $text = if ( $L.s7 ) { $L.s7 } else { "Не найден или не указан файл ffmpeg.exe" }
            Write-Warning "`n  $NameThisFunction`: $text`: '$ffmpeg'!"

            # Если запуск не из главных меню быстрых настроек (0 и 1)
            if ( -not $MenuConfigsQuickSettings )
            {
                Get-Pause
            }

            Return    # Выход из функции
        }
    }

    $text = if ( $L.s8 ) { $L.s8 } else { "Настройка звукового профиля" }
    Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline

    $text = if ( $L.s8_1 ) { $L.s8_1 } else { "Функция" }
    Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray


    if ( $Option -like 'SetVolumeDown' )
    {
        if ( $Act -eq 'Set' )
        {
            # $ToLevel от 1 по 99  (Диапазон Громкости %)
            if ( $ToLevel -notmatch '^([1-9]?[1-9]|[1-9][0])$' )
            {
                [int] $ToLevel = 50
            }
            else
            {
                [int] $ToLevel = $ToLevel
            }

            #  $ThresholdDb  от -50 по -80 (Диапазон Нижнего Порога dB)
            if ( $ThresholdDb -notmatch '^(-[5-7][1-9]|-[5-8][0])$' )
            {
                if     ( $ThresholdDb -gt -50 ) { $ThresholdDb = -50 }
                elseif ( $ThresholdDb -lt -80 ) { $ThresholdDb = -80 }
                else                            { $ThresholdDb = -70 }
            }

            $text = if ( $L.s9 ) { $L.s9 } else { "Установка" }
            Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

            $text = if ( $L.s9_1 ) { $L.s9_1 } else { "Звукового профиля" }
            Write-Host "$text " -ForegroundColor Gray -NoNewline
            Write-Host "| " -ForegroundColor DarkGray -NoNewline

            $text = if ( $L.s4 ) { $L.s4 } else { "Громкость" }
            Write-Host "$text`: $ToLevel %" -ForegroundColor Blue

            $text = if ( $L.s10 ) { $L.s10 } else { "Понижение" }
            Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

            $text = if ( $L.s10_1 ) { $L.s10_1 } else { "Громкости звуковых файлов до" }
            Write-Host "$text`: " -ForegroundColor Gray -NoNewline
            Write-Host "$ToLevel % " -ForegroundColor Cyan -NoNewline

            $text = if ( $L.s11 ) { $L.s11 } else { "Ограничение нижнего порога" }
            Write-Host "| $text`: " -ForegroundColor DarkGray -NoNewline
            Write-Host "$ThresholdDb dB" -ForegroundColor Magenta

            $text = if ( $L.s12 ) { $L.s12 } else { "Папка для изменённых файлов" }
            Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline
            Write-Host "$MediaVolumeDownPath`n" -ForegroundColor White

            [bool] $Successffmpeg = $false

            # Создаем новую папку для профиля обработанных wav файлов
            New-Item -ItemType Directory -Path $MediaVolumeDownPath -Force -ErrorAction SilentlyContinue > $null

            if ( -not (Test-Path -LiteralPath \\?\$MediaVolumeDownPath -PathType Container -ErrorAction SilentlyContinue) )
            {
                $text = if ( $L.s12_1 ) { $L.s12_1 } else { "Папка не создана" }
                Write-Host "   $text`: $MediaVolumeDownPath" -ForegroundColor Red

                # Если запуск не из главных меню быстрых настроек (0 и 1)
                if ( -not $MenuConfigsQuickSettings )
                {
                    Get-Pause
                }

                Return
            }

            (Get-Item -LiteralPath "$MediaSystemPath" -Force -ErrorAction SilentlyContinue).Attributes = 'ReadOnly', 'System'
            (Get-Item -LiteralPath "$MediaSystemPath\Desktop.ini" -Force -ErrorAction SilentlyContinue).Attributes = 'Hidden', 'System', 'Archive'
            (Get-Item -LiteralPath "$MediaVolumeDownPath" -Force -ErrorAction SilentlyContinue).Attributes = 'ReadOnly', 'System'

            Copy-Item -LiteralPath "$MediaSystemPath\Desktop.ini" -Destination $MediaVolumeDownPath -Force -ErrorAction SilentlyContinue

            [int] $N = 0

            (Get-ChildItem -File -LiteralPath $MediaSystemPath -ErrorAction SilentlyContinue).Where({ $_.Name -like '*.wav' }) | ForEach-Object {

                $N++

                [string] $FileIn  = "$($_.FullName)"
                [string] $FileOut = "$MediaVolumeDownPath\$($_.Name)"

                [double] $x = ( 1 / 99 ) * $ThresholdDb
                [double] $y = ($x / 99 )

                [double] $dB = ( $x - ( $y * $ToLevel )) * ( 99 - $ToLevel )

                [string] $Detect = & $ffmpeg -hide_banner -guess_layout_max 0 -i "$FileIn" -filter:a 'volumedetect' -vn -sn -dn -f null NUL 2>&1
                [string] $GetDb = [regex]::Match($Detect,'(?=max_volume:\s*([0-9.-]+)\s*dB)','IgnorePatternWhitespace').Groups.Value.Where({$_},'First')[0]

                [double] $CurrentDb = 0

                [double]::TryParse($GetDb,[System.Globalization.NumberStyles]::Float,[System.Globalization.NumberFormatInfo]::InvariantInfo,[ref]$CurrentDb) > $null

                if ( $CurrentDb -and (($CurrentDb + $dB) -lt $ThresholdDb ))
                {
                    [double] $PercentVolume = [math]::Pow(10.0,( 0.05 * ($ThresholdDb - $CurrentDb)))

                    [double] $ExpectedResultDb = $CurrentDb + ($ThresholdDb - $CurrentDb)
                }
                else
                {
                    [double] $PercentVolume = [math]::Pow(10.0,( 0.05 * ($Db)))

                    [double] $ExpectedResultDb = ($CurrentDb + $dB)
                }

                [string] $volume = [math]::Round($PercentVolume, 5).ToString([System.Globalization.NumberFormatInfo]::InvariantInfo)

                Write-Host "   $($N.ToString().PadLeft(3,' ')). " -ForegroundColor DarkGray -NoNewline

                Write-Host "$(($CurrentDb).ToString('N1',[System.Globalization.NumberFormatInfo]::InvariantInfo).Padleft(5,' ').Substring(0,5)) dB " -ForegroundColor White -NoNewline

                $text = if ( $L.s4 ) { $L.s4 } else { "Громкость" }
                Write-Host "▼ $text`: " -ForegroundColor DarkGray -NoNewline

                Write-Host "$ToLevel % " -ForegroundColor Cyan -NoNewline
                Write-Host "(" -ForegroundColor DarkGray -NoNewline
                Write-Host "$(($dB).ToString('N1',[System.Globalization.NumberFormatInfo]::InvariantInfo)) " -ForegroundColor Cyan -NoNewline
                Write-Host "dB) = " -ForegroundColor DarkGray -NoNewline
                Write-Host "$(($ExpectedResultDb).ToString('N1',[System.Globalization.NumberFormatInfo]::InvariantInfo)) " -ForegroundColor Cyan -NoNewline

                $text = if ( $L.s13 ) { $L.s13 } else { "Порог" }
                Write-Host "| $text`: " -ForegroundColor DarkGray -NoNewline
                Write-Host "$ThresholdDb " -ForegroundColor Magenta -NoNewline
                Write-Host "| ffmpeg: " -ForegroundColor DarkGray -NoNewline
                Write-Host "$($volume.PadRight(7,' ').Substring(0,7)) " -ForegroundColor Blue -NoNewline

                $text = if ( $L.s14 ) { $L.s14 } else { "Результат" }
                Write-Host "| $text`: " -ForegroundColor DarkGray -NoNewline

                & $ffmpeg -hide_banner -guess_layout_max 0 -i "$FileIn" -filter:a "volume=$volume" "$FileOut" -y 2>$null

                $Detect = & $ffmpeg -hide_banner -guess_layout_max 0 -i "$FileOut" -filter:a 'volumedetect' -vn -sn -dn -f null NUL 2>&1
                [string] $ResultDb = [regex]::Match($Detect,'(?=max_volume:\s*([0-9.-]+)\s*dB)','IgnorePatternWhitespace').Groups.Value.Where({$_},'First')[0]

                [double] $CurrentResultDb = 0

                [double]::TryParse($ResultDb,[System.Globalization.NumberStyles]::Float,[System.Globalization.NumberFormatInfo]::InvariantInfo,[ref]$CurrentResultDb) > $null

                if ( $CurrentResultDb ) { $Successffmpeg = $true }

                Write-Host "$(($CurrentResultDb).ToString('N1',[System.Globalization.NumberFormatInfo]::InvariantInfo).Padleft(5,' ').Substring(0,5)) dB " -ForegroundColor Green -NoNewline

                Write-Host "| " -ForegroundColor DarkGray -NoNewline

                Write-Host "$($_.Name)" -ForegroundColor White
            }

            if ( $Successffmpeg )
            {
                try { [psobject] $OpenSubkey = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey('AppEvents\Schemes\Apps','ReadSubTree','QueryValues,EnumerateSubKeys') }
                catch { [psobject] $OpenSubkey = $null }

                [int] $CountKeys = 0

                if ( $OpenSubkey )
                {
                    Write-Host

                    foreach ( $Subkey in $OpenSubkey.GetSubKeyNames() )
                    {
                       try { [psobject] $OpenSubkey2 = $OpenSubkey.OpenSubKey($Subkey,'ReadSubTree','QueryValues,EnumerateSubKeys') }
                       catch { [psobject] $OpenSubkey2 = $null }

                       if ( $OpenSubkey2 )
                       {
                            foreach ( $SubKey2 in $OpenSubkey2.GetSubKeyNames() )
                            {
                                try { [psobject] $OpenSubkey3 = $OpenSubkey2.OpenSubKey("$Subkey2\.default",'ReadSubTree','QueryValues,EnumerateSubKeys') }
                                catch { [psobject] $OpenSubkey3 = $null }

                                if ( $OpenSubkey3 )
                                {
                                    $CountKeys++

                                    # Дефолт не брать файл а целую строку
                                    [string] $File = $OpenSubkey3.GetValue('',$null) -Replace('.+\\','')

                                    $OpenSubkey3.Close()

                                    if ( $File )
                                    {
                                        [string] $Value = "$MediaVolumeDownPath\$File"
                                    }
                                    else { [string] $Value = '' }

                                    [string] $Path = "HKCU:\AppEvents\Schemes\Apps\$Subkey\$Subkey2\.Current"

                                    Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name '' -Type String $Value

                                    # дефолт все так же только удалять VolumeDown
                                    [string] $Path = "HKCU:\AppEvents\Schemes\Apps\$Subkey\$Subkey2\$SoundProfileName"

                                    Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name '' -Type String $Value
                                }
                                else
                                {
                                     [string] $Path = "HKCU:\AppEvents\Schemes\Apps\$Subkey\$Subkey2\.Current"
                                     Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name '' -Type String ''

                                     [string] $Path = "HKCU:\AppEvents\Schemes\Apps\$Subkey\$Subkey2\$SoundProfileName"
                                     Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name '' -Type String ''
                                }
                            }

                            $OpenSubkey2.Close()
                        }
                    }

                    $OpenSubkey.Close()
                }


                if ( $CountKeys )
                {
                    Write-Host

                    # Установка Названия профиля

                    $Path = "HKCU:\AppEvents\Schemes\Names\$SoundProfileName"

                    $text = if ( $L.s4 ) { $L.s4 } else { "Громкость" }
                    $Value = "$text`: $ToLevel%"   # Volume: 50%

                    Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name '' -Type String $Value

                    # Применение звукового профиля

                    $Path = "HKCU:\AppEvents\Schemes"
                    $Value = $SoundProfileName
                    Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name '' -Type String $Value
                }
                else
                {
                    $text = if ( $L.s15 ) { $L.s15 } else { "Нет параметров" }
                    Write-Host "   $text" -ForegroundColor Yellow
                }
            }
            else
            {
                $text = if ( $L.s16 ) { $L.s16 } else { "Обработки файлов не было" }
                Write-Host "   $text" -ForegroundColor Yellow
            }
        }
        elseif ( $Act -eq 'Default' )
        {
            $text = if ( $L.s17 ) { $L.s17 } else { "Восстановление" }
            Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

            $text = if ( $L.s17_1 ) { $L.s17_1 } else { "Звукового профиля 'По умолчанию'" }
            Write-Host "$text `n" -ForegroundColor White

            try { [psobject] $OpenSubkey = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey('AppEvents\Schemes\Apps','ReadSubTree','QueryValues,EnumerateSubKeys') }
            catch { [psobject] $OpenSubkey = $null }

            [int] $CountKeys = 0

            if ( $OpenSubkey )
            {
                foreach ( $Subkey in $OpenSubkey.GetSubKeyNames() )
                {
                    try { [psobject] $OpenSubkey2 = $OpenSubkey.OpenSubKey($Subkey,'ReadSubTree','QueryValues,EnumerateSubKeys') }
                    catch { [psobject] $OpenSubkey2 = $null }

                    if ( $OpenSubkey2 )
                    {
                        foreach ( $SubKey2 in $OpenSubkey2.GetSubKeyNames() )
                        {
                            try { [psobject] $OpenSubkey3 = $OpenSubkey2.OpenSubKey("$Subkey2\.default",'ReadSubTree','QueryValues,EnumerateSubKeys') }
                            catch { [psobject] $OpenSubkey3 = $null }

                            if ( $OpenSubkey3 )
                            {
                                $CountKeys++

                                # Дефолт не брать файл а целую строку
                                [string] $File = $OpenSubkey3.GetValue('',$null)

                                $OpenSubkey3.Close()

                                if ( $File )
                                {
                                    [string] $Value = $File
                                }
                                else { [string] $Value = '' }

                                [string] $Path = "HKCU:\AppEvents\Schemes\Apps\$Subkey\$Subkey2\.Current"

                                Set-Reg New-ItemProperty -Path $Path -Name '' -Type String $Value

                                # удаление $SoundProfileName
                                [string] $Path = "HKCU:\AppEvents\Schemes\Apps\$Subkey\$Subkey2\$SoundProfileName"

                                Set-Reg Remove-Item -Path $Path
                            }
                            else
                            {
                                [string] $Path = "HKCU:\AppEvents\Schemes\Apps\$Subkey\$Subkey2\.Current"
                                Set-Reg New-ItemProperty -Path $Path -Name '' -Type String ''

                                # удаление $SoundProfileName
                                [string] $Path = "HKCU:\AppEvents\Schemes\Apps\$Subkey\$Subkey2\$SoundProfileName"
                                Set-Reg Remove-Item -Path $Path
                            }
                        }

                        $OpenSubkey2.Close()
                    }
                }

                $OpenSubkey.Close()
            }

            Write-Host

            # Удаление Названия профиля

            $Path = "HKCU:\AppEvents\Schemes\Names\$SoundProfileName"
            Set-Reg Remove-Item -Path $Path

            # Применение звукового профиля, по умолчанию .Default

            $Path = "HKCU:\AppEvents\Schemes"
            Set-Reg New-ItemProperty -Path $Path -Name '' -Type String '.Default'

            $Path = "HKCU:\AppEvents\Schemes\Names\.Default"
            Set-Reg New-ItemProperty -Path $Path -Name '' -Type String '@mmres.dll,-800'

            $Path = "HKCU:\AppEvents\Schemes\Names\.None"
            Set-Reg New-ItemProperty -Path $Path -Name '' -Type String '@mmres.dll,-801'

            Remove-Item -LiteralPath \\?\$MediaVolumeDownPath -Recurse -Force -ErrorAction SilentlyContinue
        }
        else
        {
            $text = if ( $L.s18 ) { $L.s18 } else { "'Check' не предусмотрен для 'SetVolumeDown'" }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }
    elseif ( $Option -like 'SetNoSound' )
    {
        if ( $Act -eq 'Set' )
        {
            $text = if ( $L.s19 ) { $L.s19 } else { "Установка" }
            Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

            $text = if ( $L.s19_1 ) { $L.s19_1 } else { "Звукового профилия 'Без Звука'" }
            Write-Host "$text " -ForegroundColor White

            try { [psobject] $OpenSubkey = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey('AppEvents\Schemes\Apps','ReadSubTree','QueryValues,EnumerateSubKeys') }
            catch { [psobject] $OpenSubkey = $null }

            [int] $CountKeys = 0

            if ( $OpenSubkey )
            {
                Write-Host

                foreach ( $Subkey in $OpenSubkey.GetSubKeyNames() )
                {
                    try { [psobject] $OpenSubkey2 = $OpenSubkey.OpenSubKey($Subkey,'ReadSubTree','QueryValues,EnumerateSubKeys') }
                    catch { [psobject] $OpenSubkey2 = $null }

                    if ( $OpenSubkey2 )
                    {
                        foreach ( $SubKey2 in $OpenSubkey2.GetSubKeyNames() )
                        {
                            $CountKeys++

                            [string] $Path = "HKCU:\AppEvents\Schemes\Apps\$Subkey\$Subkey2\.Current"
                            Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name '' -Type String ''

                            [string] $Path = "HKCU:\AppEvents\Schemes\Apps\$Subkey\$Subkey2\$SoundProfileName"
                            Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name '' -Type String ''
                        }

                        $OpenSubkey2.Close()
                    }
                }

                $OpenSubkey.Close()
            }


            if ( $CountKeys )
            {
                Write-Host

                # Установка Названия профиля

                $Path = "HKCU:\AppEvents\Schemes\Names\.Default"
                Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name '' -Type String '@mmres.dll,-800'

                $Path = "HKCU:\AppEvents\Schemes\Names\.None"
                Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name '' -Type String '@mmres.dll,-801'

                # Применение звукового профиля .None

                $Path = "HKCU:\AppEvents\Schemes"
                $Value = $SoundProfileName
                Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name '' -Type String $Value
            }
            else
            {
                $text = if ( $L.s15 ) { $L.s15 } else { "Нет параметров" }
                Write-Host "   $text" -ForegroundColor Yellow
            }
        }
        else
        {
            $text = if ( $L.s20 ) { $L.s20 } else { "'Check', 'Default' не предусмотрен для 'SetNoSound'" }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }

    # Если запуск не из главных меню быстрых настроек (0 и 1)
    if ( -not $MenuConfigsQuickSettings )
    {
        Get-Pause
    }
}
