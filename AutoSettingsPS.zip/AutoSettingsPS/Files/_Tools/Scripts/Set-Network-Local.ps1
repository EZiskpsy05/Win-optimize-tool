﻿
<#
.SYNOPSIS
 Настройка параметров общего доступа для Локальной сети.

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.
 Сделано для меню $Menu_Set_Network_Local.

 Используется функция Get-Pause для установки паузы.
 Используется функция Set-LGP для установки параметров реестра, с проверкой и выводом результата.
 Set-LGP настраивает параметры через утилиту LGPO.exe, поэтому все параметры будут отображены в оснастке ГП.
 Используется функция Set-Svc для настройки служб, с проверкой и выводом результата.
 Используется функция Token-Impersonate.
 Используется функция Set-OwnerAndAccess.
 Используется функция Set-Sharing-Profile для корректной настройки правил фаервола.

.EXAMPLE
    Set-Network-Local -Act Set -Options SetSMB1 -ApplyGP

    Описание
    --------
    Включение протокола SMB1, ApplyGP за одно для паузы

.EXAMPLE
    Set-Network-Local -Act Default -Options ResetAllFirewallRules -ApplyGP

    Описание
    --------
    Сброс всех правил фаервола Windows, ApplyGP за одно для паузы


.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  26-06-2019
 ===============================================

#>
Function Set-Network-Local {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $true,  ParameterSetName = 'Set', Position = 0 )]
        [ValidateSet( 'Set', 'Check', 'Default' )]
        [string] $Act
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set', Position = 1 )]
        [ValidateSet( 'SetSMB1', 'SetPrNetworkDiscovery', 'SetPrivateSharing', 'SetAllPublicFolders', 'SetAllPasswordProtect',
                                'SetPubNetworkDiscovery', 'SetPublicSharing', 'ResetAllFirewallRules' )]
        [string[]] $Options = 'SetSMB1'
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set', Position = 2 )]
        [switch] $ApplyGP
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Check' )]
        [ValidateSet( 'SMB1', 'UnsafeGuest', 'PrivateAutoConfig', 'PrNetworkDiscovery', 'PrivateSharing', 'AllPublicFolders', 'AllPasswordProtect',
                                                                 'PubNetworkDiscovery', 'PublicSharing',
                                                                 'DomNetworkDiscovery', 'DomainSharing' )]
        [string] $CheckState
       ,
        [Parameter( Mandatory = $false )]
        [string] $FilePresets = $FilePresetsGlobal
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    # Если будут найдены другие файлы для настроек, состоящих из имени и расширения заданного оригинала,
    # то будет использоваться как пресет для настроек первый из дополнительных найденных.
    try
    {
        [string] $PresetsPath = [System.IO.Path]::GetDirectoryName($FilePresets)
        [string] $PresetsName = [System.IO.Path]::GetFileNameWithoutExtension($FilePresets)
        [string] $PresetsExt  = [System.IO.Path]::GetExtension($FilePresets)

        [string] $FoundPresetsMy = ((Get-ChildItem -File -LiteralPath $PresetsPath -ErrorAction Stop).Where({
            $_.Name -like "$PresetsName`?*$PresetsExt"
        },'First',1)).FullName
    }
    catch { [string] $FoundPresetsMy = '' }

    if ( $FoundPresetsMy ) { $FilePresets = $FoundPresetsMy }

    # Если файл с пресетами существует.
    if ( [System.IO.File]::Exists($FilePresets) )
    {
        # Получение пресетов в переменную.
        try { [string[]] $ListPresets = Get-Content -LiteralPath \\?\$FilePresets -Encoding UTF8 -ErrorAction SilentlyContinue }
        catch { [string[]] $ListPresets = $null }
    }
    else { [string[]] $ListPresets = $null }

    if ( $CheckState )
    {
        if ( $CheckState -eq 'SMB1' )
        {
            if ( [System.IO.File]::Exists("$env:SystemRoot\System32\drivers\mrxsmb10.sys") )
            { [bool] $FileExist = $true } else { [bool] $FileExist = $false }

            [string] $Key = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\PackagesPending'

            [psobject] $SMB1Pending = $null

            try
            {
                [psobject] $OpenSubkey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($Key,'ReadSubTree','QueryValues,EnumerateSubKeys')

                if ( $OpenSubkey )
                {
                    [string] $FoundKey = ( $OpenSubkey.GetSubKeyNames() -like 'Microsoft-Windows-SMB1-Package~*' ) | Select-Object -First 1

                    if ( $FoundKey )
                    {
                        [psobject] $OpenKey = $OpenSubkey.OpenSubKey("$FoundKey\Updates",'ReadSubTree','QueryValues')

                        if ( $OpenKey )
                        {
                            [psobject] $SMB1Pending = $OpenKey.GetValue('SMB1Protocol',$null)

                            $OpenKey.Close()
                        }
                    }

                    $OpenSubkey.Close()
                }
            }
            catch {}

            try { [psobject] $SMB1State = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\Notifications\OptionalFeatures\SMB1Protocol','Selection',$null)
            } catch { [psobject] $SMB1State = $null }

            if     (( -not $FileExist ) -and ( 1 -ne $SMB1Pending ))                           { "#Yellow#{0}#" -f $(if ( $L.s1 ) { $L.s1 } else { 'Отключён   ' }) } # Дефолт
            elseif (( -not $FileExist ) -and ( 1 -eq $SMB1Pending ))                           { "#Yellow#{0}#" -f $(if ( $L.s2 ) { $L.s2 } else { 'Включится  ' }) }
            elseif ((      $FileExist ) -and ( 0 -eq $SMB1Pending ) -and ( 1 -eq $SMB1State )) { "#Yellow#{0}#" -f $(if ( $L.s3 ) { $L.s3 } else { 'Выключится ' }) }
            elseif ((      $FileExist )                             -and ( 1 -eq $SMB1State )) {  "#Green#{0}#" -f $(if ( $L.s4 ) { $L.s4 } else { 'Включён    ' }) }
            else                                                                               {    "#Red#{0}#" -f $(if ( $L.s5 ) { $L.s5 } else { 'Не известно' }) }
        }
        elseif ( $CheckState -eq 'UnsafeGuest' )
        {
            try { [psobject] $UnsafeGuest = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\Software\Policies\Microsoft\Windows\LanmanWorkstation','AllowInsecureGuestAuth',$null)
            } catch { [psobject] $UnsafeGuest = $null }

            if ( 1 -eq $UnsafeGuest ) {  "#Green#{0}#" -f $(if ( $L.s6 ) { $L.s6 } else { 'Разрешены' }) }
            else                      { "#Yellow#{0}#" -f $(if ( $L.s7 ) { $L.s7 } else { 'Запрещены' }) } # Дефолт
        }
        elseif ( $CheckState -eq 'PrNetworkDiscovery' )
        {
            # Сетевое Обнаружение в Частной Сети

            [int] $RulesOn = 0
            $SubKey = 'System\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\FirewallRules'

            try { [psobject] $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues') }
            catch { [psobject] $OpenSubKey = $null }

            if ( $OpenSubKey )
            {
                foreach ( $ValueName in $OpenSubKey.GetValueNames() )
                {
                    if ( $OpenSubKey.GetValue($ValueName,$null) -like '*|Active=TRUE|*|Profile=Private|*|EmbedCtxt=@FirewallAPI.dll,-32752|*' )
                    {
                        $RulesOn++
                    }
                }

                $OpenSubkey.Close()
            }

            if ( 20 -eq $RulesOn ) { [string] $color = 'Green' } else { [string] $color = 'Yellow' }

            if     ( -not $OpenSubKey ) { "#Red#{0}#"                                      -f $(if ( $L.s9_2 ) { $L.s9_2     } else { 'Нет доступа'        }) }
            elseif ( $RulesOn )         { "#$color#{0} #DarkGray#| {1}: #$color#$RulesOn#" -f $(if ( $L.s8 ) { $L.s8,$L.s8_1 } else { 'Включено', 'Правил' }) } # Дефолт
            else                        { "#$color#{0} #DarkGray#| {1}: #$color#$RulesOn#" -f $(if ( $L.s9 ) { $L.s9,$L.s9_1 } else { 'Отключен', 'Правил' }) }
        }
        elseif ( $CheckState -eq 'PubNetworkDiscovery' )
        {
            # Сетевое Обнаружение в Частной Сети

            [int] $RulesOn = 0
            $SubKey = 'System\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\FirewallRules'

            try { [psobject] $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues') }
            catch { [psobject] $OpenSubKey = $null }

            if ( $OpenSubKey )
            {
                foreach ( $ValueName in $OpenSubKey.GetValueNames() )
                {
                    if ( $OpenSubKey.GetValue($ValueName,$null) -like '*|Active=TRUE|*|Profile=Public|*|EmbedCtxt=@FirewallAPI.dll,-32752|*' )
                    {
                        $RulesOn++
                    }
                }

                $OpenSubkey.Close()
            }

            if ( 22 -eq $RulesOn -or 2 -eq $RulesOn ) { [string] $color = 'Green' } else { [string] $color = 'Yellow' }

            if     ( -not $OpenSubKey ) { "#Red#{0}#"                                      -f $(if ( $L.s9_2 ) { $L.s9_2     } else { 'Нет доступа'        }) }
            elseif ( $RulesOn )         { "#$color#{0} #DarkGray#| {1}: #$color#$RulesOn#" -f $(if ( $L.s8 ) { $L.s8,$L.s8_1 } else { 'Включено', 'Правил' }) }
            else                        { "#$color#{0} #DarkGray#| {1}: #$color#$RulesOn#" -f $(if ( $L.s9 ) { $L.s9,$L.s9_1 } else { 'Отключен', 'Правил' }) } # Дефолт
        }
        elseif ( $CheckState -eq 'DomNetworkDiscovery' )
        {
            # Сетевое Обнаружение в Доменной Сети

            [int] $RulesOn = 0
            $SubKey = 'System\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\FirewallRules'

            try { [psobject] $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues') }
            catch { [psobject] $OpenSubKey = $null }

            if ( $OpenSubKey )
            {
                foreach ( $ValueName in $OpenSubKey.GetValueNames() )
                {
                    if ( $OpenSubKey.GetValue($ValueName,$null) -like '*|Active=TRUE|*|Profile=Domain|*|EmbedCtxt=@FirewallAPI.dll,-32752|*' )
                    {
                        $RulesOn++
                    }
                }

                $OpenSubkey.Close()
            }

            if ( 22 -eq $RulesOn -or 2 -eq $RulesOn ) { [string] $color = 'Green' } else { [string] $color = 'Yellow' }

            if     ( -not $OpenSubKey ) { "#Red#{0}#"                                      -f $(if ( $L.s9_2 ) { $L.s9_2     } else { 'Нет доступа'        }) }
            elseif ( $RulesOn )         { "#$color#{0} #DarkGray#| {1}: #$color#$RulesOn#" -f $(if ( $L.s8 ) { $L.s8,$L.s8_1 } else { 'Включено', 'Правил' }) }
            else                        { "#$color#{0} #DarkGray#| {1}: #$color#$RulesOn#" -f $(if ( $L.s9 ) { $L.s9,$L.s9_1 } else { 'Отключен', 'Правил' }) } # Дефолт
        }
        elseif ( $CheckState -eq 'PrivateAutoConfig' )
        {
            # Автоматическая настройка на сетевых устройствах в Частной Сети

            try { [string] $AutoSetup = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\NcdAutoSetup\Private','AutoSetup',$null)
            } catch { [string] $AutoSetup = '' }

            if     (( 1 -eq $AutoSetup ) -or ( -not $AutoSetup )) {  "#Green#{0}#" -f $(if ( $L.s10 ) { $L.s10 } else { 'Включена  ' }) } # Дефолт пусто
            elseif  ( 0 -eq $AutoSetup )                          { "#Yellow#{0}#" -f $(if ( $L.s11 ) { $L.s11 } else { 'Отключена ' }) }
            else                                                  {    "#Red#{0}#" -f $(if ( $L.s12 ) { $L.s12 } else { 'Ошибка    ' }) }
        }
        elseif ( $CheckState -eq 'PrivateSharing' )
        {
            # Общий доступ к файлам и принтерам в Частной Сети

            [int] $RulesOn = 0
            $SubKey = 'System\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\FirewallRules'

            try { [psobject] $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues') }
            catch { [psobject] $OpenSubKey = $null }

            if ( $OpenSubKey )
            {
                foreach ( $ValueName in $OpenSubKey.GetValueNames() )
                {
                    if ( $OpenSubKey.GetValue($ValueName,$null) -like '*|Active=TRUE|*|Profile=Private|*|EmbedCtxt=@FirewallAPI.dll,-28502|*' )
                    {
                        $RulesOn++
                    }
                }

                $OpenSubkey.Close()
            }

            if ( 16 -eq $RulesOn ) { [string] $color = 'Green' } else { [string] $color = 'Yellow' }

            if     ( -not $OpenSubKey ) { "#Red#{0}#"                                      -f $(if ( $L.s9_2 ) { $L.s9_2        } else { 'Нет доступа'        }) }
            elseif ( $RulesOn )         { "#$color#{0} #DarkGray#| {1}: #$color#$RulesOn#" -f $(if ( $L.s13 ) { $L.s13,$L.s13_1 } else { 'Включён ', 'Правил' }) }
            else                        { "#$color#{0} #DarkGray#| {1}: #$color#$RulesOn#" -f $(if ( $L.s14 ) { $L.s14,$L.s14_1 } else { 'Отключён', 'Правил' }) } # Дефолт
        }
        elseif ( $CheckState -eq 'PublicSharing' )
        {
            # Общий доступ к файлам и принтерам в Частной Сети

            [int] $RulesOn = 0
            $SubKey = 'System\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\FirewallRules'

            try { [psobject] $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues') }
            catch { [psobject] $OpenSubKey = $null }

            if ( $OpenSubKey )
            {
                foreach ( $ValueName in $OpenSubKey.GetValueNames() )
                {
                    if ( $OpenSubKey.GetValue($ValueName,$null) -like '*|Active=TRUE|*|Profile=Public|*|EmbedCtxt=@FirewallAPI.dll,-28502|*' )
                    {
                        $RulesOn++
                    }
                }

                $OpenSubkey.Close()
            }

            if ( 16 -eq $RulesOn ) { [string] $color = 'Green' } else { [string] $color = 'Yellow' }

            if     ( -not $OpenSubKey ) { "#Red#{0}#"                                      -f $(if ( $L.s9_2 ) { $L.s9_2        } else { 'Нет доступа'        }) }
            elseif ( $RulesOn )         { "#$color#{0} #DarkGray#| {1}: #$color#$RulesOn#" -f $(if ( $L.s13 ) { $L.s13,$L.s13_1 } else { 'Включён ', 'Правил' }) }
            else                        { "#$color#{0} #DarkGray#| {1}: #$color#$RulesOn#" -f $(if ( $L.s14 ) { $L.s14,$L.s14_1 } else { 'Отключён', 'Правил' }) } # Дефолт
        }
        elseif ( $CheckState -eq 'DomainSharing' )
        {
            # Общий доступ к файлам и принтерам в Доменной Сети

            [int] $RulesOn = 0
            $SubKey = 'System\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\FirewallRules'

            try { [psobject] $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues') }
            catch { [psobject] $OpenSubKey = $null }

            if ( $OpenSubKey )
            {
                foreach ( $ValueName in $OpenSubKey.GetValueNames() )
                {
                    if ( $OpenSubKey.GetValue($ValueName,$null) -like '*|Active=TRUE|*|Profile=Domain|*|EmbedCtxt=@FirewallAPI.dll,-28502|*' )
                    {
                        $RulesOn++
                    }
                }

                $OpenSubkey.Close()
            }

            if ( 16 -eq $RulesOn ) { [string] $color = 'Green' } else { [string] $color = 'Yellow' }

            if     ( -not $OpenSubKey ) { "#Red#{0}#"                                      -f $(if ( $L.s9_2 ) { $L.s9_2        } else { 'Нет доступа'        }) }
            elseif ( $RulesOn )         { "#$color#{0} #DarkGray#| {1}: #$color#$RulesOn#" -f $(if ( $L.s13 ) { $L.s13,$L.s13_1 } else { 'Включён ', 'Правил' }) }
            else                        { "#$color#{0} #DarkGray#| {1}: #$color#$RulesOn#" -f $(if ( $L.s14 ) { $L.s14,$L.s14_1 } else { 'Отключён', 'Правил' }) } # Дефолт
        }
        elseif ( $CheckState -eq 'AllPublicFolders' )
        {
            # Проверка общего доступа к общедоступным папкам для Всех сетей. Тут несколько условий должно быть.

            try { [string] $Access = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\LanmanServer\Shares','Users',$null) -join ', '
            } catch { [string] $Access = '' }

            [string[]] $AccessPattern = "CATimeout=0", "CSCFlags=2048", "MaxUses=4294967295", "Path=$($env:PUBLIC | Split-Path -Parent)", "Permissions=0", "Remark=", "ShareName=Users", "Type=0"

            try { [string] $UsersShareName = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Sharing','UsersShareName',$null)
            } catch { [string] $UsersShareName = '' }

            try { [string] $SecAccess = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\LanmanServer\Shares\Security",'Users',$null) -join ','
            } catch { [string] $SecAccess = '' }

            [string] $SecPattern = '1,0,4,128,72,0,0,0,88,0,0,0,0,0,0,0,20,0,0,0,2,0,52,0,2,0,0,0,0,3,24,0,255,1,31,0,1,2,0,0,0,0,0,5,32,0,0,0,32,2,0,0,0,3,20,0,255,1,31,
                                    0,1,1,0,0,0,0,0,1,0,0,0,0,1,2,0,0,0,0,0,5,32,0,0,0,32,2,0,0,1,5,0,0,0,0,0,5,21,0,0,0,89,143,225,231,185,172,82,72,76,31,2,149,1,2,0,0'

            # Для проверки Полного доступа для группы "Все" у общей папки C:\Users\Public
            try { [string] $SDDL = (Get-Item -LiteralPath $env:PUBLIC -Force -ErrorAction SilentlyContinue).GetAccessControl().Sddl }
            catch { [string] $SDDL = '' }

            if (( $Access -eq ($AccessPattern -join ', ' )) -and ( $SecAccess -eq ( $SecPattern -Replace '\s','' )) `
                  -and ( $UsersShareName -eq 'Users' ) -and ( $SDDL -like '*(A;OICI;FA;;;WD)*' ))
            {       "#Green#{0}#" -f $(if ( $L.s15 ) { $L.s15 } else { 'Включён   ' }) }
            else { "#Yellow#{0}#" -f $(if ( $L.s16 ) { $L.s16 } else { 'Отключён  ' }) } # Дефолт
        }
        elseif ( $CheckState -eq 'AllPasswordProtect' )
        {
            # Проверка общего доступа с парольной защитой

            [psobject] $Guest    = (Get-LocalUser).Where({ $_.SID.Value -like 'S-1-5-21-*-501' })
              [string] $GuestSID = $Guest.SID.Value
            [psobject] $GuestOn  = $Guest.Enabled

            Token-Impersonate -Token SYS

            # try { [string] $PasswordProtect = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\SECURITY\Policy\Accounts\$GuestSID\ActSysAc",'',$null) -join ',' }
            # catch { [string] $PasswordProtect = '' }

            [string] $PasswordProtect = '0,0,0,0' ; [byte[]] $guestNetAccess = 0 ; [string] $TestAccess = ''

            try
            {
                [string] $TestAccess = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SECURITY\Policy\Accounts\S-1-5-19\Sid','',$null)
                
                if ( $TestAccess )
                {
                    [byte[]] $guestNetAccess = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\SECURITY\Policy\Accounts\$GuestSID\ActSysAc",'',$null)
                    
                    if ( $guestNetAccess.Count -eq 4 ) { $PasswordProtect = @($guestNetAccess).ForEach({$_.ToString('x2')}) -join ',' }
                }
            }
            catch {}


            Token-Impersonate -Reset

            #if     ( '193,0,0,0' -eq $PasswordProtect               ) { "#Yellow#{0}#" -f $(if ( $L.s17 ) { $L.s17 } else { 'Включён    ' }) } # Дефолт HEX: c1,0,0,0
            #elseif (  '65,0,0,0' -eq $PasswordProtect -and $GuestOn ) {  "#Green#{0}#" -f $(if ( $L.s18 ) { $L.s18 } else { 'Отключён   ' }) } #        HEX: 41,0,0,0
            #else                                                      {    "#Red#{0}#" -f $(if ( $L.s19 ) { $L.s19 } else { 'Не известно' }) }
            
            if ( $GuestOn ) { [string] $Guest =  '{0}: #Green#{1}' -f $(if ( $L.s17_1 ) { $L.s17_1, $L.s17 } else { 'Гость', 'Включён'  }) }
            else            { [string] $Guest = '{0}: #Yellow#{1}' -f $(if ( $L.s17_1 ) { $L.s17_1, $L.s18 } else { 'Гость', 'Отключён' }) }

            if ( $TestAccess )
            {
                if ( $guestNetAccess.Count -ne 4 ) { [byte[]] $guestNetAccess = @(0,0,0,0) }

                if ( $GuestOn -and -not ( $guestNetAccess[0] -band 128 ))
                {
                     "#Green#{0} #DarkGray#| $PasswordProtect | $Guest#" -f $(if ( $L.s18 ) { $L.s18 } else { 'Отключён' })
                }
                else
                {
                    "#Yellow#{0} #DarkGray#| $PasswordProtect | $Guest#" -f $(if ( $L.s17 ) { $L.s17 } else { 'Включён'  })
                }
            }
            else
            {
                "#Red#{0} #DarkGray#| $Guest#" -f $(if ( $L.s19 ) { $L.s19 } else { 'Нет доступа' })
            }
        }

        Return
    }

    $text = if ( $L.s20 ) { $L.s20 } else { 'Настройка общего доступа к Локальной Сети' }
    Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline

    $text = if ( $L.s20_1 ) { $L.s20_1 } else { 'Функция' }
    Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray

    if ( $Options -like 'ResetAllFirewallRules' )
    {
        if ( $Act -eq 'Default' )
        {
            # Восстановление По умолчанию.

            $text = if ( $L.s61 ) { $L.s61 } else { "Сброс всех правил Брандмауэра Windows" }
            Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

            $text = if ( $L.s61_1 ) { $L.s61_1 } else { "По умолчанию" }
            Write-Host "| $text`n" -ForegroundColor DarkGray

            # Ресет всех правил
            try
            {
                [psobject] $FirewallDefaults = New-Object -ComObject 'HNetCfg.FwPolicy2' -ErrorAction SilentlyContinue
                $FirewallDefaults.RestoreLocalFirewallDefaults()

                $text = if ( $L.s62 ) { $L.s62 } else { "Сброшены" }
                Write-Host "   $text`n" -ForegroundColor Green
            }
            catch
            {
                $text = if ( $L.s63 ) { $L.s63 } else { "Ошибка сброса" }

                Write-Warning "$NameThisFunction`: $text`:`n   $($_.CategoryInfo.Category): $($_.Exception.Message)`n"
            }
           
            Set-Svc Set-Service -Name 'BFE' -StartupType Automatic
            Set-Svc Set-Service -Name 'mpssvc' -StartupType Automatic
            Set-Drv Set-Driver -Name 'mpsdrv' -StartupType Manual
        }
        else
        {
            $text = if ( $L.s64 ) { $L.s64 } else { "'Check/Set' не предусмотрен для 'ResetAllFirewallRules'" }
            Write-Host "`n   $text" -ForegroundColor DarkGray
        }
    }

    if ( $Options -like 'SetSMB1' )
    {
        if ( [System.IO.File]::Exists("$env:SystemRoot\System32\drivers\mrxsmb10.sys") )
        { [bool] $FileExist = $true } else { [bool] $FileExist = $false }

        [string] $Key = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\PackagesPending'

        [psobject] $SMB1Pending = $null

        try
        {
            [psobject] $OpenSubkey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($Key,'ReadSubTree','QueryValues,EnumerateSubKeys')

            if ( $OpenSubkey )
            {
                [string] $FoundKey = ( $OpenSubkey.GetSubKeyNames() -like 'Microsoft-Windows-SMB1-Package~*' ) | Select-Object -First 1

                if ( $FoundKey )
                {
                    [psobject] $OpenKey = $OpenSubkey.OpenSubKey("$FoundKey\Updates",'ReadSubTree','QueryValues')

                    if ( $OpenKey )
                    {
                        [psobject] $SMB1Pending = $OpenKey.GetValue('SMB1Protocol',$null)

                        $OpenKey.Close()
                    }
                }

                $OpenSubkey.Close()
            }
        }
        catch {}

        try { [psobject] $SMB1State = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\Notifications\OptionalFeatures\SMB1Protocol','Selection',$null)
        } catch { [psobject] $SMB1State = $null }

        if ( $Act -eq 'Set' )
        {
            [bool] $NeedOn = $false

            if     (( -not $FileExist ) -and ( 1 -ne $SMB1Pending ))                           { $NeedOn = $true } # Отключён Дефолт
            elseif (( -not $FileExist ) -and ( 1 -eq $SMB1Pending ))                           { Write-Host "`n   $(if ( $L.s21 ) { $L.s21 } else { 'Компонент SMB1 Включится после перезагрузки' })" -ForegroundColor Green }
            elseif ((      $FileExist ) -and ( 0 -eq $SMB1Pending ) -and ( 1 -eq $SMB1State )) { $NeedOn = $true } # Выключится
            elseif ((      $FileExist )                             -and ( 1 -eq $SMB1State )) { Write-Host "`n   $(if ( $L.s22 ) { $L.s22 } else { 'Компонент SMB1 Уже Включён' })" -ForegroundColor Green }
            else                                                                               { $NeedOn = $true } # Не известно

            if ( $NeedOn )
            {
                $text = if ( $L.s23 ) { $L.s23 } else { 'Включение' }
                Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

                $text = if ( $L.s23_1 ) { $L.s23_1 } else { 'Компонента SMB1' }
                Write-Host "$text" -ForegroundColor White

                Dism.exe /Online /Enable-Feature /All /LimitAccess /FeatureName:SMB1Protocol /NoRestart
            }

            Write-Host

            # Комп\Адм. Шабл\Сеть\Рабочая станция Lanmann\ "Включить небезопасные гостевые входы" : Включено
            Set-LGP New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\LanmanWorkstation' -Name 'AllowInsecureGuestAuth' -Type DWord 1

            Set-Reg New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\services\LanmanServer\Parameters' -Name 'SMB1' -Type DWord 1
            Set-Reg Remove-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\MSV1_0' -Name 'RestrictReceivingNTLMTraffic'
            Set-Reg Remove-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\MSV1_0' -Name 'RestrictSendingNTLMTraffic'

            # Полное отключение SMB2
            Set-Reg New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\services\LanmanServer\Parameters' -Name 'SMB2' -Type DWord 0
            Set-Reg New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation' -Name 'DependOnService' -Type MultiString 'Bowser','MRxSmb10','NSI'
            Set-Drv Set-Driver -Name mrxsmb20 -StartupType Disabled -Status Stopped
        }
        elseif ( $Act -eq 'Default' )
        {
            [bool] $NeedOff = $false

            if     (( -not $FileExist ) -and ( 1 -ne $SMB1Pending ))                           { Write-Host "`n   $(if ( $L.s22_1 ) { $L.s22_1 } else { 'Компонент SMB1 Уже Отключён' })" -ForegroundColor Green } # Отключён Дефолт
            elseif (( -not $FileExist ) -and ( 1 -eq $SMB1Pending ))                           { $NeedOff = $true } # Включится
            elseif ((      $FileExist ) -and ( 0 -eq $SMB1Pending ) -and ( 1 -eq $SMB1State )) { Write-Host "`n   $(if ( $L.s21_1 ) { $L.s21_1 } else { 'Компонент SMB1 Отключится после перезагрузки' })" -ForegroundColor Green }
            elseif ((      $FileExist )                             -and ( 1 -eq $SMB1State )) { $NeedOff = $true } # Включён
            else                                                                               { $NeedOff = $true } # Не известно

            if ( $NeedOff )
            {
                $text = if ( $L.s24 ) { $L.s24 } else { 'Отключение' }
                Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

                $text = if ( $L.s24_1 ) { $L.s24_1 } else { 'Компонента SMB1' }
                Write-Host "$text" -ForegroundColor White

                Dism.exe /Online /Disable-Feature /FeatureName:SMB1Protocol /NoRestart
            }

            Write-Host

            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\LanmanWorkstation' -Name 'AllowInsecureGuestAuth'

            Set-Reg Remove-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\services\LanmanServer\Parameters' -Name 'SMB1'
            Set-Reg Remove-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\services\LanmanServer\Parameters' -Name 'SMB2'
            Set-Reg New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation' -Name 'DependOnService' -Type MultiString 'Bowser','MRxSmb20','NSI'
            Set-Drv Set-Driver -Name 'mrxsmb20' -StartupType Manual
        }
        else
        {
            $text = if ( $L.s25 ) { $L.s25 } else { "'Check' не предусмотрен для 'SetSMB1'" }
            Write-Host "`n   $text" -ForegroundColor DarkGray
        }
    }

    if ( $Options -like 'SetPrNetworkDiscovery' )
    {
        if ( $Act -eq 'Set' )
        {
            $text = if ( $L.s26 ) { $L.s26 } else { "Включение Обнаружения (для Часной сети)" }
            Write-Host "`n   $text" -ForegroundColor DarkCyan

            Set-Sharing-Profile -GroupName NETDIS -Profile Private -Enabled true -ErrorAction SilentlyContinue

            [int] $RulesOn = 0
            $SubKey = 'System\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\FirewallRules'

            try { [psobject] $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues') }
            catch { [psobject] $OpenSubKey = $null }

            if ( $OpenSubKey )
            {
                foreach ( $ValueName in $OpenSubKey.GetValueNames() )
                {
                    if ( $OpenSubKey.GetValue($ValueName,$null) -like '*|Active=TRUE|*|Profile=Private|*|EmbedCtxt=@FirewallAPI.dll,-32752|*' )
                    {
                        $RulesOn++
                    }
                }

                $OpenSubkey.Close()
            }

            $text = if ( $L.s27 ) { $L.s27 } else { "Брандмауэр Windows" }
            Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline

            $text = if ( $L.s27_1 ) { $L.s27_1 } else { "Включено правил 'Обнаружение сети'" }
            Write-Host "$text`: " -ForegroundColor Gray -NoNewline
            Write-Host "$RulesOn" -ForegroundColor Green

            $text = if ( $L.s28 ) { $L.s28 } else { "Включение автоматической настройки на сетевых устройствах" }
            Write-Host "`n   $text`:" -ForegroundColor DarkGray

            Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\NcdAutoSetup\Private' -Name 'AutoSetup'

            $text = if ( $L.s29 ) { $L.s29 } else { "Включение" }
            Write-Host "`n   $text " -ForegroundColor DarkCyan -NoNewline

            $text = if ( $L.s29_1 ) { $L.s29_1 } else { "2 служб в режим Авто" }
            Write-Host "$text`n" -ForegroundColor DarkGray

            Set-Svc Set-Service -Name 'BFE' -StartupType Automatic
            Set-Svc Set-Service -Name 'mpssvc' -StartupType Automatic
            Set-Drv Set-Driver -Name 'mpsdrv' -StartupType Manual

            Set-Svc Set-Service -Name 'FDResPub' -StartupType Automatic
            Set-Svc Set-Service -Name 'fdPHost' -StartupType Automatic
            Set-Reg New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\FDResPub\ServiceData' -Name 'FirstStart' -Type Binary 1,0,0,0,0,0,0,0
        }
        elseif ( $Act -eq 'Default' )
        {
            # Восстановления По умолчанию. Тут теже значения. Так же будет включаться обнаружение, так как оно включено по умолчанию!

            $text = if ( $L.s30 ) { $L.s30 } else { "Включение Обнаружения (для Часной сети)" }
            Write-Host "`n   $text" -ForegroundColor Magenta

            Set-Sharing-Profile -GroupName NETDIS -Profile Private -Enabled true -ErrorAction SilentlyContinue

            [int] $RulesOn = 0
            $SubKey = 'System\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\FirewallRules'

            try { [psobject] $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues') }
            catch { [psobject] $OpenSubKey = $null }

            if ( $OpenSubKey )
            {
                foreach ( $ValueName in $OpenSubKey.GetValueNames() )
                {
                    if ( $OpenSubKey.GetValue($ValueName,$null) -like '*|Active=TRUE|*|Profile=Private|*|EmbedCtxt=@FirewallAPI.dll,-32752|*' )
                    {
                        $RulesOn++
                    }
                }
            }

            $text = if ( $L.s27 ) { $L.s27 } else { "Брандмауэр Windows" }
            Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline

            $text = if ( $L.s27_1 ) { $L.s27_1 } else { "Включено правил 'Обнаружение сети'" }
            Write-Host "$text`: " -ForegroundColor Gray -NoNewline
            Write-Host "$RulesOn" -ForegroundColor Green

            $text = if ( $L.s28 ) { $L.s28 } else { "Включение автоматической настройки на сетевых устройствах" }
            Write-Host "`n   $text`:" -ForegroundColor Magenta

            Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\NcdAutoSetup\Private' -Name 'AutoSetup'

            $text = if ( $L.s31 ) { $L.s31 } else { "Включение" }
            Write-Host "`n   $text " -ForegroundColor DarkCyan -NoNewline

            $text = if ( $L.s31_1 ) { $L.s31_1 } else { "2 служб в режим Ручной" }
            Write-Host "$text`n" -ForegroundColor DarkCyan

            Set-Svc Set-Service -Name 'BFE' -StartupType Automatic
            Set-Svc Set-Service -Name 'mpssvc' -StartupType Automatic
            Set-Drv Set-Driver -Name 'mpsdrv' -StartupType Manual

            Set-Svc Set-Service -Name 'FDResPub' -StartupType Manual
            Set-Svc Set-Service -Name 'fdPHost' -StartupType Manual
        }
        else
        {
            $text = if ( $L.s32 ) { $L.s32 } else { "'Check' не предусмотрен для 'SetPrNetworkDiscovery'" }
            Write-Host "`n   $text" -ForegroundColor DarkGray
        }
    }

    if ( $Options -like 'SetPubNetworkDiscovery' )
    {
        if ( $Act -eq 'Set' )
        {
            $text = if ( $L.s55 ) { $L.s55 } else { "Включение Обнаружения (для Публичной сети)" }
            Write-Host "`n   $text" -ForegroundColor DarkCyan

            Set-Sharing-Profile -GroupName NETDIS -Profile Public -Enabled true -ErrorAction SilentlyContinue

            [int] $RulesOn = 0
            $SubKey = 'System\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\FirewallRules'

            try { [psobject] $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues') }
            catch { [psobject] $OpenSubKey = $null }

            if ( $OpenSubKey )
            {
                foreach ( $ValueName in $OpenSubKey.GetValueNames() )
                {
                    if ( $OpenSubKey.GetValue($ValueName,$null) -like '*|Active=TRUE|*|Profile=Public|*|EmbedCtxt=@FirewallAPI.dll,-32752|*' )
                    {
                        $RulesOn++
                    }
                }
            }

            $text = if ( $L.s27 ) { $L.s27 } else { "Брандмауэр Windows" }
            Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline

            $text = if ( $L.s27_1 ) { $L.s27_1 } else { "Включено правил 'Обнаружение сети'" }
            Write-Host "$text`: " -ForegroundColor Gray -NoNewline
            Write-Host "$RulesOn" -ForegroundColor Green
        }
        elseif ( $Act -eq 'Default' )
        {
            # Восстановления По умолчанию. Тут теже значения.

            $text = if ( $L.s56 ) { $L.s56 } else { "Отключение Обнаружения (для Публичной сети)" }
            Write-Host "`n   $text" -ForegroundColor Magenta

            Set-Sharing-Profile -GroupName NETDIS -Profile Public -Enabled false -ErrorAction SilentlyContinue

            [int] $RulesOn = 0
            $SubKey = 'System\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\FirewallRules'

            try { [psobject] $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues') }
            catch { [psobject] $OpenSubKey = $null }

            if ( $OpenSubKey )
            {
                foreach ( $ValueName in $OpenSubKey.GetValueNames() )
                {
                    if ( $OpenSubKey.GetValue($ValueName,$null) -like '*|Active=TRUE|*|Profile=Public|*|EmbedCtxt=@FirewallAPI.dll,-32752|*' )
                    {
                        $RulesOn++
                    }
                }
            }

            $text = if ( $L.s27 ) { $L.s27 } else { "Брандмауэр Windows" }
            Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline

            $text = if ( $L.s27_1 ) { $L.s27_1 } else { "Включено правил 'Обнаружение сети'" }
            Write-Host "$text`: " -ForegroundColor Gray -NoNewline
            Write-Host "$RulesOn" -ForegroundColor Green
        }
        else
        {
            $text = if ( $L.s57 ) { $L.s57 } else { "'Check' не предусмотрен для 'SetPubNetworkDiscovery'" }
            Write-Host "`n   $text" -ForegroundColor DarkGray
        }
    }

    if ( $Options -like 'SetPrivateSharing' )
    {
        if ( $Act -eq 'Set' )
        {
            $text = if ( $L.s33 ) { $L.s33 } else { "Включение: Общий доступ к файлам и принтерам (для Часной сети)" }
            Write-Host "`n   $text" -ForegroundColor DarkCyan

            Set-Sharing-Profile -GroupName FPS -Profile Private -Enabled true -ErrorAction SilentlyContinue

            [int] $RulesOn = 0
            $SubKey = 'System\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\FirewallRules'

            try { [psobject] $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues') }
            catch { [psobject] $OpenSubKey = $null }

            if ( $OpenSubKey )
            {
                foreach ( $ValueName in $OpenSubKey.GetValueNames() )
                {
                    if ( $OpenSubKey.GetValue($ValueName,$null) -like '*|Active=TRUE|*|Profile=Private|*|EmbedCtxt=@FirewallAPI.dll,-28502|*' )
                    {
                        $RulesOn++
                    }
                }
            }

            $text = if ( $L.s34 ) { $L.s34 } else { "Брандмауэр Windows" }
            Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline

            $text = if ( $L.s34_1 ) { $L.s34_1 } else { "Включено правил 'Общий доступ к файлам и принтерам'" }
            Write-Host "$text`: " -ForegroundColor Gray -NoNewline
            Write-Host "$RulesOn" -ForegroundColor Green
        }
        elseif ( $Act -eq 'Default' )
        {
            # Восстановления По умолчанию.

            $text = if ( $L.s35 ) { $L.s35 } else { "Отключение: Общий доступ к файлам и принтерам (для Часной сети)" }
            Write-Host "`n   $text" -ForegroundColor Magenta

            Set-Sharing-Profile -GroupName FPS -Profile Private -Enabled false -ErrorAction SilentlyContinue

            [int] $RulesOn = 0
            $SubKey = 'System\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\FirewallRules'

            try { [psobject] $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues') }
            catch { [psobject] $OpenSubKey = $null }

            if ( $OpenSubKey )
            {
                foreach ( $ValueName in $OpenSubKey.GetValueNames() )
                {
                    if ( $OpenSubKey.GetValue($ValueName,$null) -like '*|Active=TRUE|*|Profile=Private|*|EmbedCtxt=@FirewallAPI.dll,-28502|*' )
                    {
                        $RulesOn++
                    }
                }
            }

            $text = if ( $L.s34 ) { $L.s34 } else { "Брандмауэр Windows" }
            Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline

            $text = if ( $L.s34_1 ) { $L.s34_1 } else { "Включено правил 'Общий доступ к файлам и принтерам'" }
            Write-Host "$text`: " -ForegroundColor Gray -NoNewline
            Write-Host "$RulesOn" -ForegroundColor Green
        }
        else
        {
            $text = if ( $L.s36 ) { $L.s36 } else { "'Check' не предусмотрен для 'SetPrivateSharing'" }
            Write-Host "`n   $text" -ForegroundColor DarkGray
        }
    }

    if ( $Options -like 'SetPublicSharing' )
    {
        if ( $Act -eq 'Set' )
        {
            $text = if ( $L.s58 ) { $L.s58 } else { "Включение: Общий доступ к файлам и принтерам (для Публичной сети)" }
            Write-Host "`n   $text" -ForegroundColor DarkCyan

            Set-Sharing-Profile -GroupName FPS -Profile Public -Enabled true -ErrorAction SilentlyContinue

            [int] $RulesOn = 0
            $SubKey = 'System\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\FirewallRules'

            try { [psobject] $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues') }
            catch { [psobject] $OpenSubKey = $null }

            if ( $OpenSubKey )
            {
                foreach ( $ValueName in $OpenSubKey.GetValueNames() )
                {
                    if ( $OpenSubKey.GetValue($ValueName,$null) -like '*|Active=TRUE|*|Profile=Public|*|EmbedCtxt=@FirewallAPI.dll,-28502|*' )
                    {
                        $RulesOn++
                    }
                }
            }

            $text = if ( $L.s34 ) { $L.s34 } else { "Брандмауэр Windows" }
            Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline

            $text = if ( $L.s34_1 ) { $L.s34_1 } else { "Включено правил 'Общий доступ к файлам и принтерам'" }
            Write-Host "$text`: " -ForegroundColor Gray -NoNewline
            Write-Host "$RulesOn" -ForegroundColor Green
        }
        elseif ( $Act -eq 'Default' )
        {
            # Восстановления По умолчанию.

            $text = if ( $L.s59 ) { $L.s59 } else { "Отключение: Общий доступ к файлам и принтерам (для Публичной сети)" }
            Write-Host "`n   $text" -ForegroundColor Magenta

            Set-Sharing-Profile -GroupName FPS -Profile Public -Enabled false -ErrorAction SilentlyContinue

            [int] $RulesOn = 0
            $SubKey = 'System\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\FirewallRules'

            try { [psobject] $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues') }
            catch { [psobject] $OpenSubKey = $null }

            if ( $OpenSubKey )
            {
                foreach ( $ValueName in $OpenSubKey.GetValueNames() )
                {
                    if ( $OpenSubKey.GetValue($ValueName,$null) -like '*|Active=TRUE|*|Profile=Public|*|EmbedCtxt=@FirewallAPI.dll,-28502|*' )
                    {
                        $RulesOn++
                    }
                }
            }

            $text = if ( $L.s34 ) { $L.s34 } else { "Брандмауэр Windows" }
            Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline

            $text = if ( $L.s34_1 ) { $L.s34_1 } else { "Включено правил 'Общий доступ к файлам и принтерам'" }
            Write-Host "$text`: " -ForegroundColor Gray -NoNewline
            Write-Host "$RulesOn" -ForegroundColor Green
        }
        else
        {
            $text = if ( $L.s60 ) { $L.s60 } else { "'Check' не предусмотрен для 'SetPublicSharing'" }
            Write-Host "`n   $text" -ForegroundColor DarkGray
        }
    }

    if ( $Options -like 'SetAllPublicFolders' )
    {
        if ( $Act -eq 'Set' )
        {
            $text = if ( $L.s37 ) { $L.s37 } else { "Включение: Общий доступ к общедоступным папкам (для Всех сетей)" }
            Write-Host "`n   $text" -ForegroundColor DarkCyan

            $text = if ( $L.s38 ) { $L.s38 } else { "Настройка" }
            Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline

            $text = if ( $L.s38_1 ) { $L.s38_1 } else { "параметров Общего Доступа" }
            Write-Host "$text`n" -ForegroundColor White

            [string] $Path  = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Sharing'
            Set-Reg New-ItemProperty -Path $Path -Name 'UsersShareName' -Type String 'Users'

              [string] $Path  = 'HKLM:\System\CurrentControlSet\Services\LanmanServer\Shares'
            [string[]] $Value = "CATimeout=0", "CSCFlags=2048", "MaxUses=4294967295", "Path=$($env:PUBLIC | Split-Path -Parent)", "Permissions=0", "Remark=", "ShareName=Users", "Type=0"

            Set-Reg New-ItemProperty -Path $Path -Name 'Users' -Type MultiString $Value

            $text = if ( $L.s39 ) { $L.s39 } else { "Настройка прав доступа" }
            Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline

            $text = if ( $L.s39_1 ) { $L.s39_1 } else { "SecurityDescriptor для Общего доступа" }
            Write-Host "$text`n" -ForegroundColor White

            # SecurityDescriptor (С параметрами которые создаёт Windows при настройке)
            [string] $DecString = '1,0,4,128,72,0,0,0,88,0,0,0,0,0,0,0,20,0,0,0,2,0,52,0,2,0,0,0,0,3,24,0,255,1,31,0,1,2,0,0,0,0,0,5,
                                   32,0,0,0,32,2,0,0,0,3,20,0,255,1,31,0,1,1,0,0,0,0,0,1,0,0,0,0,1,2,0,0,0,0,0,5,32,0,0,0,32,2,0,0,1,
                                   5,0,0,0,0,0,5,21,0,0,0,89,143,225,231,185,172,82,72,76,31,2,149,1,2,0,0'

            [string] $Path  = 'HKLM:\System\CurrentControlSet\Services\LanmanServer\Shares\Security'
            [byte[]] $Value = ($DecString -Replace '\s','').Split(',').Where({$_})

            Set-Reg New-ItemProperty -Path $Path -Name 'Users' -Type Binary $Value

            $text = if ( $L.s40 ) { $L.s40 } else { "Добавление прав полного доступа для группы 'Все' на общую папку" }
            Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline
            Write-Host "'$env:PUBLIC'" -ForegroundColor White

            [string] $SDDL = 'O:SYG:SYD:PAI(A;OICI;FA;;;WD)(A;OICIIO;FA;;;CO)(A;;0x1200af;;;S-1-5-3)(A;OICIIO;0x1301ff;;;S-1-5-3)(A;OICIIO;0x1301ff;;;IU)
                             (A;;0x1200af;;;IU)(A;OICIIO;0x1301ff;;;SU)(A;;0x1200af;;;SU)(A;OICI;FA;;;SY)(A;OICI;FA;;;BA)'

            Set-OwnerAndAccess -Path $env:PUBLIC -RecoverySDDL $SDDL
        }
        elseif ( $Act -eq 'Default' )
        {
            # Восстановления По умолчанию.

            $text = if ( $L.s41 ) { $L.s41 } else { "Выключение: Общий доступ к общедоступным папкам (для Всех сетей)" }
            Write-Host "`n   $text" -ForegroundColor Magenta

            $text = if ( $L.s42 ) { $L.s42 } else { "Удаление" }
            Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline

            $text = if ( $L.s42_1 ) { $L.s42_1 } else { "параметров Общего Доступа" }
            Write-Host "$text`n" -ForegroundColor White

            [string] $Path  = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Sharing'

            Set-Reg Remove-ItemProperty -Path $Path -Name 'UsersShareName'

            [string] $Path = 'HKLM:\System\CurrentControlSet\Services\LanmanServer\Shares'

            Set-Reg Remove-ItemProperty -Path $Path -Name 'Users'

            $text = if ( $L.s43 ) { $L.s43 } else { "Удаление прав доступа" }
            Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline

            $text = if ( $L.s43_1 ) { $L.s43_1 } else { "SecurityDescriptor для Общего доступа" }
            Write-Host "$text`n" -ForegroundColor White

            [string] $Path = 'HKLM:\System\CurrentControlSet\Services\LanmanServer\Shares\Security'

            Set-Reg Remove-ItemProperty -Path $Path -Name 'Users'

            $text = if ( $L.s44 ) { $L.s44 } else { "Удаление группы 'Все' из доступов на общую папку" }
            Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline
            Write-Host "'$env:PUBLIC'" -ForegroundColor White

            [string] $SDDL = 'O:SYG:SYD:PAI(A;OICIIO;FA;;;CO)(A;;0x1200af;;;S-1-5-3)(A;OICIIO;0x1301ff;;;S-1-5-3)(A;OICIIO;0x1301ff;;;IU)
                             (A;;0x1200af;;;IU)(A;OICIIO;0x1301ff;;;SU)(A;;0x1200af;;;SU)(A;OICI;FA;;;SY)(A;OICI;FA;;;BA)'

            Set-OwnerAndAccess -Path $env:PUBLIC -RecoverySDDL $SDDL

        }
        else
        {
            $text = if ( $L.s45 ) { $L.s45 } else { "'Check' не предусмотрен для 'SetAllPublicFolders'" }
            Write-Host "`n   $text" -ForegroundColor DarkGray
        }
    }

    if ( $Options -like 'SetAllPasswordProtect' )
    {
        if ( $Act -eq 'Set' )
        {
            $text = if ( $L.s46 ) { $L.s46 } else { "Отключение: Общий доступ c парольной защитой" }
            Write-Host "`n   $text" -ForegroundColor DarkCyan

            $text = if ( $L.s47 ) { $L.s47 } else { "Включение аккуанта" }
            Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline

            $text = if ( $L.s47_1 ) { $L.s47_1 } else { "Гость" }
            Write-Host "$text" -ForegroundColor White

            [psobject] $GuestSID = (Get-LocalUser).Where({ $_.SID.Value -like 'S-1-5-21-*-501' }).SID.Value

            Enable-LocalUser -SID $GuestSID -ErrorAction SilentlyContinue
            Set-LocalUser -SID $GuestSID -PasswordNeverExpires $true -UserMayChangePassword $false -ErrorAction SilentlyContinue

            [psobject] $GuestOn  = (Get-LocalUser -SID $GuestSID -ErrorAction SilentlyContinue).Enabled

            $text = if ( $L.s48 ) { $L.s48 } else { "Аккаунт Гость" }
            Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline

            if ( $true -eq $GuestOn )
            {
                $text = if ( $L.s48_1 ) { $L.s48_1 } else { "Включен" }
                Write-Host "$text" -ForegroundColor Green
            }
            else
            {
                $text = if ( $L.s48_2 ) { $L.s48_2 } else { "Отключен" }
                Write-Host "$text" -ForegroundColor Yellow
            }

            $text = if ( $L.s49 ) { $L.s49 } else { "Отключение" }
            Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline

            $text = if ( $L.s49_1 ) { $L.s49_1 } else { "Парольного доступа" }
            Write-Host "$text`n" -ForegroundColor White

            [byte[]] $NetAccess = @(0,0,0,0)
               [int] $NetBit = 2
               [int] $EnableBit = 128

            Token-Impersonate -Token SYS

            try
            {
                [string] $TestAccess = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SECURITY\Policy\Accounts\S-1-5-19\Sid','',$null)
                
                if ( $TestAccess )
                {
                    [byte[]] $guestNetAccess = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\SECURITY\Policy\Accounts\$GuestSID\ActSysAc",'',$null)
                }
            }
            catch {}

            if ( $TestAccess )
            {
                # Выключить парольный доступ HEX 41,0,0,0 = DEC 65,0,0,0  -> [Convert]::ToString(0x41, 10)
                # Set-Reg New-ItemProperty -Path $Path -Name '' -Type Binary 65,0,0,0

                # Сетевой доступ: ActSysAc
                if ( $guestNetAccess.Count -ne 4 ) { [byte[]] $guestNetAccess = @(0,0,0,0) }

                if (( $guestNetAccess[0] -band $EnableBit ) -ne 0 )
                {
                    $guestNetAccess[0] = $guestNetAccess[0] -bxor $EnableBit
                }

                [string] $RootPath = "HKLM:\SECURITY\Policy\Accounts\$GuestSID"
                
                if (( $guestNetAccess -join '' ) -eq '0000' )
                {
                    [string] $Path = $RootPath
                    # Доступ нулевой, настройка не нужна
                    Set-Reg Remove-Item -Path $Path
                }
                else
                {
                    [string] $Path = $RootPath
                    # двоичное значение нулевой длины
                    Set-Reg New-ItemProperty -Path $Path -Name '' -Type Binary ''

                    # Переключение бита сетевого доступа
                    $Path = "$RootPath\ActSysAc"
                    [string] $Value = @($guestNetAccess).ForEach({ $_.ToString('x2') }) -join ','

                    Set-Reg New-ItemProperty -Path $Path -Name '' -Type None $Value

                    # Стандартный Security Descriptor для Гостя:  для S-1-5-32-544 (983055 = PrinterFullControl) и для S-1-1-0 (131072 = ReadPermissions)
                    # При создании идентичного дескриптора в PS итоговые значения некоторых байтов отличаются (Даже при получении этого и конвертирования обратно в байты), поэтому такой варинт, чтобы были оригинальные значения.
                    # Скорее всего порядок записи прав в дескриптор MS делает по другому. Результат один, но некоторые байты отличаются. Похожее с правами на разделы реестра и папки.
                    $Path = "$RootPath\SecDesc"
                    Set-Reg New-ItemProperty -Path $Path -Name '' -Type None '01,00,04,80,48,00,00,00,58,00,00,00,00,00,00,00,14,00,00,00,02,00,34,00,02,00,00,00,00,00,
                        18,00,0f,00,0f,00,01,02,00,00,00,00,00,05,20,00,00,00,20,02,00,00,00,00,14,00,00,00,02,00,01,01,00,00,00,00,00,01,00,00,00,00,01,02,00,00,00,00,
                        00,05,20,00,00,00,20,02,00,00,01,01,00,00,00,00,00,05,12,00,00,00'
                    # Конвертация SID в Hex
                    $SecId = [System.Security.Principal.SecurityIdentifier]::new($GuestSID)
                    $bSID = [byte[]]::new($SecId.BinaryLength)
                    $SecId.GetBinaryForm($bSID, 0)
                
                    [string] $Value = $bSID.ForEach({$_.ToString('x2')}) -join ',' # Пример Reg Hex: 01,05,b3,...
                    $Path = "$RootPath\Sid"
                
                    Set-Reg New-ItemProperty -Path $Path -Name '' -Type None $Value
                }
            }
            else
            {
                $text = if ( $L.s19 ) { $L.s19 } else { 'Нет доступа' }
                Write-Host "`n   $text" -ForegroundColor Yellow
            }

            Token-Impersonate -Reset
        }
        elseif ( $Act -eq 'Default' )
        {
            # Восстановления По умолчанию.

            $text = if ( $L.s50 ) { $L.s50 } else { "Включение: Общий доступ c парольной защитой" }
            Write-Host "`n   $text" -ForegroundColor Magenta

            $text = if ( $L.s51 ) { $L.s51 } else { "Отключение аккуанта" }
            Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline

            $text = if ( $L.s51_1 ) { $L.s51_1 } else { "Гость" }
            Write-Host "$text" -ForegroundColor White

            [psobject] $GuestSID = (Get-LocalUser).Where({ $_.SID.Value -like 'S-1-5-21-*-501' }).SID.Value

            Disable-LocalUser -SID $GuestSID -ErrorAction SilentlyContinue

            [psobject] $GuestOn  = (Get-LocalUser -SID $GuestSID -ErrorAction SilentlyContinue).Enabled

            $text = if ( $L.s48 ) { $L.s48 } else { "Аккаунт Гость" }
            Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline

            if  ( $true -eq $GuestOn )
            {
                $text = if ( $L.s48_1 ) { $L.s48_1 } else { "Включен" }
                Write-Host "$text" -ForegroundColor Yellow
            }
            else
            {
                $text = if ( $L.s48_2 ) { $L.s48_2 } else { "Отключен" }
                Write-Host "$text" -ForegroundColor Green
            }

            $text = if ( $L.s52 ) { $L.s52 } else { "Включение" }
            Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline

            $text = if ( $L.s52_1 ) { $L.s52_1 } else { "Парольного доступа" }
            Write-Host "$text`n" -ForegroundColor White

            [byte[]] $NetAccess = @(2,0,0,0)
               [int] $NetBit = 2
               [int] $EnableBit = 128

            Token-Impersonate -Token SYS

            try
            {
                [string] $TestAccess = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SECURITY\Policy\Accounts\S-1-5-19\Sid','',$null)
                
                if ( $TestAccess )
                {
                    [byte[]] $guestNetAccess = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\SECURITY\Policy\Accounts\$GuestSID\ActSysAc",'',$null)
                }
            }
            catch {}

            if ( $TestAccess )
            {
                # Включить парольный доступ HEX c1,0,0,0 (по умолчанию) = DEC 193,0,0,0  -> [Convert]::ToString(0xc1, 10)
                # Set-Reg New-ItemProperty -Path $Path -Name '' -Type Binary 193,0,0,0

                # Сетевой доступ: ActSysAc
                if ( $guestNetAccess.Count -ne 4 ) { [byte[]] $guestNetAccess = @(0,0,0,0) }

                if (( $guestNetAccess[0] -band $EnableBit ) -eq 0 )
                {
                    $guestNetAccess[0] = $guestNetAccess[0] -bxor $EnableBit
                }

                [string] $RootPath = "HKLM:\SECURITY\Policy\Accounts\$GuestSID"
                
                if (( $guestNetAccess -join '' ) -eq '0000' )
                {
                    [string] $Path = $RootPath
                    # Доступ нулевой, настройка не нужна
                    Set-Reg Remove-Item -Path $Path
                }
                else
                {
                    [string] $Path = $RootPath
                    # двоичное значение нулевой длины
                    Set-Reg New-ItemProperty -Path $Path -Name '' -Type Binary ''

                    # Переключение бита сетевого доступа
                    $Path = "$RootPath\ActSysAc"
                    [string] $Value = @($guestNetAccess).ForEach({ $_.ToString('x2') }) -join ','

                    Set-Reg New-ItemProperty -Path $Path -Name '' -Type None $Value

                    # Стандартный Security Descriptor для Гостя:  для S-1-5-32-544 (983055 = PrinterFullControl) и для S-1-1-0 (131072 = ReadPermissions)
                    $Path = "$RootPath\SecDesc"
                    Set-Reg New-ItemProperty -Path $Path -Name '' -Type None '01,00,04,80,48,00,00,00,58,00,00,00,00,00,00,00,14,00,00,00,02,00,34,00,02,00,00,00,00,00,
                        18,00,0f,00,0f,00,01,02,00,00,00,00,00,05,20,00,00,00,20,02,00,00,00,00,14,00,00,00,02,00,01,01,00,00,00,00,00,01,00,00,00,00,01,02,00,00,00,00,
                        00,05,20,00,00,00,20,02,00,00,01,01,00,00,00,00,00,05,12,00,00,00'
                    # Конвертация SID в Hex
                    $SecId = [System.Security.Principal.SecurityIdentifier]::new($GuestSID)
                    $bSID = [byte[]]::new($SecId.BinaryLength)
                    $SecId.GetBinaryForm($bSID, 0)
                
                    [string] $Value = $bSID.ForEach({$_.ToString('x2')}) -join ',' # Пример Reg Hex: 01,05,b3,...
                    $Path = "$RootPath\Sid"
                
                    Set-Reg New-ItemProperty -Path $Path -Name '' -Type None $Value
                }
            }
            else
            {
                $text = if ( $L.s19 ) { $L.s19 } else { 'Нет доступа' }
                Write-Host "`n   $text" -ForegroundColor Yellow
            }

            Token-Impersonate -Reset
        }
        else
        {
            $text = if ( $L.s53 ) { $L.s53 } else { "'Check' не предусмотрен для 'AllPasswordProtect'" }
            Write-Host "`n   $text" -ForegroundColor DarkGray
        }
    }

    if ( $ApplyGP )
    {
        # Если есть подготовленные параметры Групповых политик для LGPO.exe в глобальной переменной $Global:SettingsGP, то выполнится применение ГП.
        Set-LGP -ApplyGP

        $text = if ( $L.s54 ) { $L.s54 } else { "Необходимо перезагрузиться!" }
        Write-Host "`n   ••••• $text •••••" -ForegroundColor Yellow

        Get-Pause
    }
}
