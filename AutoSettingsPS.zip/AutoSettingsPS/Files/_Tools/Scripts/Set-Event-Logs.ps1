﻿
<#
.SYNOPSIS
 Настройка Журналов Событий.

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.
 Сделано для меню $Menu_Set_Event_Logs.

 Используется функция Get-Pause для установки паузы.
 Используется функция Set-Svc для настройки служб, с проверкой и выводом результата.
 Используется системная утилита wevtutil.exe для настройки Журналов Событий.

.EXAMPLE
    Set-Event-Logs -Options EventLogsDisable -Act Set

    Описание
    --------
    Отключить ведение журналов, кроме основных.

.EXAMPLE
    Set-Event-Logs -Options EventLogsDisable -Act Default

    Описание
    --------
    Включить ведение журналов, которые включены по умолчанию.


.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  28-04-2019
 ===============================================

#>
Function Set-Event-Logs {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $true,  ParameterSetName = 'Set', Position = 0 )]
        [ValidateSet( 'Set', 'Check', 'Default' )]  # Тут 'Check' не используется, оставлено, чтобы было по стандарту и не выкидывало ошибок, если будет использовано.
        [string] $Act
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set', Position = 1 )]
        [ValidateSet( 'EventLogsDisable', 'EnableExcludedLogs', 'ClearEventLogs', 'ShowRunningLogs', 'ShowExcludedLogs' )]
        [string[]] $Options = 'EventLogsDisable'
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Check' )]
        [ValidateSet( 'EventLogs', 'ExcludedLogs' )]
        [string] $CheckState
       ,
        [Parameter( Mandatory = $false )]
        [string] $FilePresets = $FilePresetsGlobal
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    # Если будут найдены другие файлы для настроек, состоящих из имени и расширения заданного оригинала,
    # то будет использоваться как пресет для настроек первый из дополнительных найденных.
    try
    {
        [string] $PresetsPath = [System.IO.Path]::GetDirectoryName($FilePresets)
        [string] $PresetsName = [System.IO.Path]::GetFileNameWithoutExtension($FilePresets)
        [string] $PresetsExt  = [System.IO.Path]::GetExtension($FilePresets)

        [string] $FoundPresetsMy = ((Get-ChildItem -File -LiteralPath $PresetsPath -ErrorAction Stop).Where({
            $_.Name -like "$PresetsName`?*$PresetsExt"
        },'First',1)).FullName
    }
    catch { [string] $FoundPresetsMy = '' }

    if ( $FoundPresetsMy ) { $FilePresets = $FoundPresetsMy }

    # Если файл с пресетами существует.
    if ( [System.IO.File]::Exists($FilePresets) )
    {
        # Получение пресетов в переменную.
        try { [string[]] $ListPresets = Get-Content -LiteralPath \\?\$FilePresets -Encoding UTF8 -ErrorAction SilentlyContinue }
        catch {}
    }

    [array] $ExcludedLogs = @()

    # Получаем список файлов exe для блокировки из файла пресетов. И заполняем таблицу $ExeFilesForLock.
    foreach ( $Line in ( $ListPresets -match '^\s*Exclude-EventLog-Name\s*=\s*1\s*=.+' ))
    {
        # Берем заданный путь в пресете для указанного файла, отсеивая все непечатные (скрытые) и запрещённые символы, включая TAB.
        if ( $Line -match '^\s*Exclude-EventLog-Name\s*=\s*1\s*=\s*(?<LogName>[^\r\n\t\x02\x1c\x1d\x1e\x1f=]+)=' )
        {
            $ExcludedLogs += $Matches.LogName.Trim()
        }
    }


    if ( $CheckState )
    {
        if ( 'EventLogs' -eq $CheckState )
        {
            $Key = 'SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels'

            [string[]] $NamesLogsOn = @()
           
            try
            {
                [string[]] $NamesLogsOn =
                    [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($Key,'ReadSubTree','QueryValues,EnumerateSubKeys'
                        ).GetSubKeyNames().ForEach({
                            try { if ( [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$Key\$_",'Enabled',$null) -eq 1 ) { $_ } } catch {}
                        }) | Sort-Object
            }
            catch {}

            if (( & wevtutil.exe Get-Log 'Windows PowerShell' ) -like 'enabled: true' ) { $NamesLogsOn += 'Windows PowerShell' }

            if ( $NamesLogsOn.Count )
            {
                "#Yellow#{0} #Magenta#$($NamesLogsOn.Count) #DarkGray#{1}#" -f $(if ( $L.s1 ) { $L.s1,$L.s1_1 } else { "Включено","шт" })
            }
            else
            {
                "#Green#{0}#" -f $(if ( $L.s1_2 ) { $L.s1_2 } else { "Отключены" })
            }
        }
        elseif ( 'ExcludedLogs' -eq $CheckState )
        {
            if ( $ExcludedLogs.Count )
            {
                "#Blue#$($ExcludedLogs.Count)#"
            }
            else
            {
                "#DarkGray#0#"
            }
        }

        Return
    }

    $text = if ( $L.s2 ) { $L.s2 } else { "Настройка Журналов Событий" }
    Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline

    $text = if ( $L.s3 ) { $L.s3 } else { "Функция" }
    Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray

    [string] $NamesLogsDefaultOn = @'
Microsoft-AppV-Client/Admin
Microsoft-AppV-Client/Operational
Microsoft-AppV-Client/Virtual Applications
Microsoft-Client-Licensing-Platform/Admin
Microsoft-User Experience Virtualization-Agent Driver/Operational
Microsoft-User Experience Virtualization-App Agent/Operational
Microsoft-User Experience Virtualization-IPC/Operational
Microsoft-User Experience Virtualization-SQM Uploader/Operational
Microsoft-Windows-AAD/Operational
Microsoft-Windows-AllJoyn/Operational
Microsoft-Windows-All-User-Install-Agent/Admin
Microsoft-Windows-AppHost/Admin
Microsoft-Windows-AppID/Operational
Microsoft-Windows-ApplicabilityEngine/Operational
Microsoft-Windows-Application Server-Applications/Admin
Microsoft-Windows-Application Server-Applications/Operational
Microsoft-Windows-Application-Experience/Program-Compatibility-Assistant
Microsoft-Windows-Application-Experience/Program-Compatibility-Troubleshooter
Microsoft-Windows-Application-Experience/Program-Inventory
Microsoft-Windows-Application-Experience/Program-Telemetry
Microsoft-Windows-Application-Experience/Steps-Recorder
Microsoft-Windows-AppLocker/EXE and DLL
Microsoft-Windows-AppLocker/MSI and Script
Microsoft-Windows-AppLocker/Packaged app-Deployment
Microsoft-Windows-AppLocker/Packaged app-Execution
Microsoft-Windows-AppModel-Runtime/Admin
Microsoft-Windows-AppReadiness/Admin
Microsoft-Windows-AppReadiness/Operational
Microsoft-Windows-AppXDeployment/Operational
Microsoft-Windows-AppXDeploymentServer/Operational
Microsoft-Windows-AppXDeploymentServer/Restricted
Microsoft-Windows-AppxPackaging/Operational
Microsoft-Windows-AssignedAccess/Admin
Microsoft-Windows-AssignedAccessBroker/Admin
Microsoft-Windows-Audio/CaptureMonitor
Microsoft-Windows-Audio/Operational
Microsoft-Windows-Audio/PlaybackManager
Microsoft-Windows-Authentication User Interface/Operational
Microsoft-Windows-BackgroundTaskInfrastructure/Operational
Microsoft-Windows-Backup
Microsoft-Windows-Biometrics/Operational
Microsoft-Windows-BitLocker/BitLocker Management
Microsoft-Windows-BitLocker-DrivePreparationTool/Admin
Microsoft-Windows-BitLocker-DrivePreparationTool/Operational
Microsoft-Windows-Bits-Client/Operational
Microsoft-Windows-Bluetooth-BthLEPrepairing/Operational
Microsoft-Windows-Bluetooth-MTPEnum/Operational
Microsoft-Windows-Bluetooth-Policy/Operational
Microsoft-Windows-BranchCache/Operational
Microsoft-Windows-BranchCacheSMB/Operational
Microsoft-Windows-CertificateServicesClient-Lifecycle-System/Operational
Microsoft-Windows-CertificateServicesClient-Lifecycle-User/Operational
Microsoft-Windows-Cleanmgr/Diagnostic
Microsoft-Windows-CloudStorageWizard/Operational
Microsoft-Windows-CloudStore/Operational
Microsoft-Windows-CodeIntegrity/Operational
Microsoft-Windows-Compat-Appraiser/Operational
Microsoft-Windows-Containers-BindFlt/Operational
Microsoft-Windows-Containers-Wcifs/Operational
Microsoft-Windows-Containers-Wcnfs/Operational
Microsoft-Windows-CoreApplication/Operational
Microsoft-Windows-CoreSystem-SmsRouter-Events/Operational
Microsoft-Windows-CorruptedFileRecovery-Client/Operational
Microsoft-Windows-CorruptedFileRecovery-Server/Operational
Microsoft-Windows-Crypto-DPAPI/BackUpKeySvc
Microsoft-Windows-Crypto-DPAPI/Operational
Microsoft-Windows-Crypto-NCrypt/Operational
Microsoft-Windows-DAL-Provider/Operational
Microsoft-Windows-DataIntegrityScan/Admin
Microsoft-Windows-DataIntegrityScan/CrashRecovery
Microsoft-Windows-DateTimeControlPanel/Operational
Microsoft-Windows-Deduplication/Diagnostic
Microsoft-Windows-Deduplication/Operational
Microsoft-Windows-Deduplication/Scrubbing
Microsoft-Windows-DeviceGuard/Operational
Microsoft-Windows-DeviceManagement-Enterprise-Diagnostics-Provider/Admin
Microsoft-Windows-DeviceManagement-Enterprise-Diagnostics-Provider/Operational
Microsoft-Windows-Devices-Background/Operational
Microsoft-Windows-DeviceSetupManager/Admin
Microsoft-Windows-DeviceSetupManager/Operational
Microsoft-Windows-DeviceSync/Operational
Microsoft-Windows-DeviceUpdateAgent/Operational
Microsoft-Windows-Dhcp-Client/Admin
Microsoft-Windows-Dhcpv6-Client/Admin
Microsoft-Windows-Diagnosis-DPS/Operational
Microsoft-Windows-Diagnosis-PCW/Operational
Microsoft-Windows-Diagnosis-PLA/Operational
Microsoft-Windows-Diagnosis-Scheduled/Operational
Microsoft-Windows-Diagnosis-Scripted/Admin
Microsoft-Windows-Diagnosis-Scripted/Operational
Microsoft-Windows-Diagnosis-ScriptedDiagnosticsProvider/Operational
Microsoft-Windows-Diagnostics-Networking/Operational
Microsoft-Windows-Diagnostics-Performance/Operational
Microsoft-Windows-DiskDiagnostic/Operational
Microsoft-Windows-DiskDiagnosticDataCollector/Operational
Microsoft-Windows-DiskDiagnosticResolver/Operational
Microsoft-Windows-DSC/Admin
Microsoft-Windows-DSC/Operational
Microsoft-Windows-DxgKrnl-Admin
Microsoft-Windows-DxgKrnl-Operational
Microsoft-Windows-EapHost/Operational
Microsoft-Windows-EapMethods-RasChap/Operational
Microsoft-Windows-EapMethods-RasTls/Operational
Microsoft-Windows-EapMethods-Sim/Operational
Microsoft-Windows-EapMethods-Ttls/Operational
Microsoft-Windows-EDP-Application-Learning/Admin
Microsoft-Windows-EDP-Audit-Regular/Admin
Microsoft-Windows-EDP-Audit-TCB/Admin
Microsoft-Windows-EventCollector/Operational
Microsoft-Windows-Fault-Tolerant-Heap/Operational
Microsoft-Windows-FeatureConfiguration/Operational
Microsoft-Windows-FileHistory-Core/WHC
Microsoft-Windows-FileHistory-Engine/BackupLog
Microsoft-Windows-FMS/Operational
Microsoft-Windows-Folder Redirection/Operational
Microsoft-Windows-Forwarding/Operational
Microsoft-Windows-GenericRoaming/Admin
Microsoft-Windows-GroupPolicy/Operational
Microsoft-Windows-HelloForBusiness/Operational
Microsoft-Windows-Help/Operational
Microsoft-Windows-HomeGroup Control Panel/Operational
Microsoft-Windows-HomeGroup Listener Service/Operational
Microsoft-Windows-HomeGroup Provider Service/Operational
Microsoft-Windows-HotspotAuth/Operational
Microsoft-Windows-Hyper-V-Guest-Drivers/Admin
Microsoft-Windows-Hyper-V-Hypervisor-Admin
Microsoft-Windows-Hyper-V-Hypervisor-Operational
Microsoft-Windows-Hyper-V-VID-Admin
Microsoft-Windows-IdCtrls/Operational
Microsoft-Windows-IKE/Operational
Microsoft-Windows-International/Operational
Microsoft-Windows-International-RegionalOptionsControlPanel/Operational
Microsoft-Windows-Iphlpsvc/Operational
Microsoft-Windows-IPxlatCfg/Operational
Microsoft-Windows-KdsSvc/Operational
Microsoft-Windows-Kernel-ApphelpCache/Operational
Microsoft-Windows-Kernel-Boot/Operational
Microsoft-Windows-Kernel-EventTracing/Admin
Microsoft-Windows-Kernel-IO/Operational
Microsoft-Windows-Kernel-LiveDump/Operational
Microsoft-Windows-Kernel-PnP/Configuration
Microsoft-Windows-Kernel-PnP/Driver Watchdog
Microsoft-Windows-Kernel-Power/Thermal-Operational
Microsoft-Windows-Kernel-ShimEngine/Operational
Microsoft-Windows-Kernel-StoreMgr/Operational
Microsoft-Windows-Kernel-WDI/Operational
Microsoft-Windows-Kernel-WHEA/Errors
Microsoft-Windows-Kernel-WHEA/Operational
Microsoft-Windows-Known Folders API Service
Microsoft-Windows-LanguagePackSetup/Operational
Microsoft-Windows-LiveId/Operational
Microsoft-Windows-MemoryDiagnostics-Results/Debug
Microsoft-Windows-Mobile-Broadband-Experience-Parser-Task/Operational
Microsoft-Windows-Mobile-Broadband-Experience-SmsRouter/Admin
Microsoft-Windows-ModernDeployment-Diagnostics-Provider/Admin
Microsoft-Windows-ModernDeployment-Diagnostics-Provider/Autopilot
Microsoft-Windows-ModernDeployment-Diagnostics-Provider/ManagementService
Microsoft-Windows-Mprddm/Operational
Microsoft-Windows-MUI/Admin
Microsoft-Windows-MUI/Operational
Microsoft-Windows-NcdAutoSetup/Operational
Microsoft-Windows-NCSI/Operational
Microsoft-Windows-NdisImPlatform/Operational
Microsoft-Windows-NetworkLocationWizard/Operational
Microsoft-Windows-NetworkProfile/Operational
Microsoft-Windows-NetworkProvider/Operational
Microsoft-Windows-NetworkProvisioning/Operational
Microsoft-Windows-NlaSvc/Operational
Microsoft-Windows-Ntfs/Operational
Microsoft-Windows-Ntfs/WHC
Microsoft-Windows-NTLM/Operational
Microsoft-Windows-OfflineFiles/Operational
Microsoft-Windows-OneBackup/Debug
Microsoft-Windows-OOBE-Machine-DUI/Operational
Microsoft-Windows-PackageStateRoaming/Operational
Microsoft-Windows-ParentalControls/Operational
Microsoft-Windows-Partition/Diagnostic
Microsoft-Windows-PerceptionRuntime/Operational
Microsoft-Windows-PerceptionSensorDataService/Operational
Microsoft-Windows-PersistentMemory-Nvdimm/Operational
Microsoft-Windows-PersistentMemory-PmemDisk/Operational
Microsoft-Windows-PersistentMemory-ScmBus/Certification
Microsoft-Windows-PersistentMemory-ScmBus/Operational
Microsoft-WindowsPhone-Connectivity-WiFiConnSvc-Channel
Microsoft-Windows-Policy/Operational
Microsoft-Windows-PowerShell/Admin
Microsoft-Windows-PowerShell/Operational
Microsoft-Windows-PowerShell-DesiredStateConfiguration-FileDownloadManager/Operational
Microsoft-Windows-PrintBRM/Admin
Microsoft-Windows-PrintService/Admin
Microsoft-Windows-PriResources-Deployment/Operational
Microsoft-Windows-Privacy-Auditing/Operational
Microsoft-Windows-Program-Compatibility-Assistant/CompatAfterUpgrade
Microsoft-Windows-Provisioning-Diagnostics-Provider/Admin
Microsoft-Windows-Provisioning-Diagnostics-Provider/AutoPilot
Microsoft-Windows-Provisioning-Diagnostics-Provider/ManagementService
Microsoft-Windows-PushNotification-Platform/Admin
Microsoft-Windows-PushNotification-Platform/Operational
Microsoft-Windows-ReadyBoost/Operational
Microsoft-Windows-ReadyBoostDriver/Operational
Microsoft-Windows-ReFS/Operational
Microsoft-Windows-Regsvr32/Operational
Microsoft-Windows-RemoteApp and Desktop Connections/Admin
Microsoft-Windows-RemoteApp and Desktop Connections/Operational
Microsoft-Windows-RemoteAssistance/Admin
Microsoft-Windows-RemoteAssistance/Operational
Microsoft-Windows-RemoteDesktopServices-RdpCoreTS/Admin
Microsoft-Windows-RemoteDesktopServices-RdpCoreTS/Operational
Microsoft-Windows-RemoteDesktopServices-RemoteFX-Synth3dvsc/Admin
Microsoft-Windows-RemoteDesktopServices-SessionServices/Operational
Microsoft-Windows-Resource-Exhaustion-Detector/Operational
Microsoft-Windows-Resource-Exhaustion-Resolver/Operational
Microsoft-Windows-RestartManager/Operational
Microsoft-Windows-RetailDemo/Admin
Microsoft-Windows-RetailDemo/Operational
Microsoft-Windows-SearchUI/Operational
Microsoft-Windows-Security-Adminless/Operational
Microsoft-Windows-Security-Audit-Configuration-Client/Operational
Microsoft-Windows-Security-EnterpriseData-FileRevocationManager/Operational
Microsoft-Windows-Security-LessPrivilegedAppContainer/Operational
Microsoft-Windows-Security-Mitigations/KernelMode
Microsoft-Windows-Security-Mitigations/UserMode
Microsoft-Windows-SecurityMitigationsBroker/Operational
Microsoft-Windows-Security-Netlogon/Operational
Microsoft-Windows-Security-SPP-UX-GenuineCenter-Logging/Operational
Microsoft-Windows-Security-SPP-UX-Notifications/ActionCenter
Microsoft-Windows-Security-UserConsentVerifier/Audit
Microsoft-Windows-SENSE/Operational
Microsoft-Windows-SenseIR/Operational
Microsoft-Windows-SettingSync/Debug
Microsoft-Windows-SettingSync/Operational
Microsoft-Windows-SettingSync-Azure/Debug
Microsoft-Windows-SettingSync-Azure/Operational
Microsoft-Windows-SettingSync-OneDrive/Debug
Microsoft-Windows-SettingSync-OneDrive/Operational
Microsoft-Windows-ShellCommon-StartLayoutPopulation/Operational
Microsoft-Windows-Shell-ConnectedAccountState/ActionCenter
Microsoft-Windows-Shell-Core/ActionCenter
Microsoft-Windows-Shell-Core/AppDefaults
Microsoft-Windows-Shell-Core/LogonTasksChannel
Microsoft-Windows-Shell-Core/Operational
Microsoft-Windows-SmartCard-Audit/Authentication
Microsoft-Windows-SmartCard-DeviceEnum/Operational
Microsoft-Windows-SmartCard-TPM-VCard-Module/Admin
Microsoft-Windows-SmartCard-TPM-VCard-Module/Operational
Microsoft-Windows-SmbClient/Audit
Microsoft-Windows-SmbClient/Connectivity
Microsoft-Windows-SMBClient/Operational
Microsoft-Windows-SmbClient/Security
Microsoft-Windows-SMBDirect/Admin
Microsoft-Windows-SMBServer/Audit
Microsoft-Windows-SMBServer/Connectivity
Microsoft-Windows-SMBServer/Operational
Microsoft-Windows-SMBServer/Security
Microsoft-Windows-SMBWitnessClient/Admin
Microsoft-Windows-SMBWitnessClient/Informational
Microsoft-Windows-StateRepository/Operational
Microsoft-Windows-StateRepository/Restricted
Microsoft-Windows-Storage-ClassPnP/Operational
Microsoft-Windows-StorageManagement/Operational
Microsoft-Windows-StorageSettings/Diagnostic
Microsoft-Windows-StorageSpaces-Driver/Diagnostic
Microsoft-Windows-StorageSpaces-Driver/Operational
Microsoft-Windows-StorageSpaces-ManagementAgent/WHC
Microsoft-Windows-StorageSpaces-SpaceManager/Diagnostic
Microsoft-Windows-StorageSpaces-SpaceManager/Operational
Microsoft-Windows-Storage-Storport/Health
Microsoft-Windows-Storage-Storport/Operational
Microsoft-Windows-Storage-Tiering/Admin
Microsoft-Windows-Store/Operational
Microsoft-Windows-Storsvc/Diagnostic
Microsoft-Windows-SystemSettingsThreshold/Operational
Microsoft-Windows-TaskScheduler/Maintenance
Microsoft-Windows-TCPIP/Operational
Microsoft-Windows-TerminalServices-ClientUSBDevices/Admin
Microsoft-Windows-TerminalServices-ClientUSBDevices/Operational
Microsoft-Windows-TerminalServices-LocalSessionManager/Admin
Microsoft-Windows-TerminalServices-LocalSessionManager/Operational
Microsoft-Windows-TerminalServices-PnPDevices/Admin
Microsoft-Windows-TerminalServices-PnPDevices/Operational
Microsoft-Windows-TerminalServices-Printers/Admin
Microsoft-Windows-TerminalServices-Printers/Operational
Microsoft-Windows-TerminalServices-RDPClient/Operational
Microsoft-Windows-TerminalServices-RemoteConnectionManager/Admin
Microsoft-Windows-TerminalServices-RemoteConnectionManager/Operational
Microsoft-Windows-TerminalServices-ServerUSBDevices/Admin
Microsoft-Windows-TerminalServices-ServerUSBDevices/Operational
Microsoft-Windows-Time-Service/Operational
Microsoft-Windows-Time-Service-PTP-Provider/PTP-Operational
Microsoft-Windows-Troubleshooting-Recommended/Admin
Microsoft-Windows-Troubleshooting-Recommended/Operational
Microsoft-Windows-TWinUI/Operational
Microsoft-Windows-TZSync/Operational
Microsoft-Windows-TZUtil/Operational
Microsoft-Windows-UAC/Operational
Microsoft-Windows-UAC-FileVirtualization/Operational
Microsoft-Windows-UniversalTelemetryClient/Operational
Microsoft-Windows-User Control Panel/Operational
Microsoft-Windows-User Device Registration/Admin
Microsoft-Windows-User Profile Service/Operational
Microsoft-Windows-User-Loader/Operational
Microsoft-Windows-UserPnp/ActionCenter
Microsoft-Windows-UserPnp/DeviceInstall
Microsoft-Windows-VDRVROOT/Operational
Microsoft-Windows-VerifyHardwareSecurity/Admin
Microsoft-Windows-VHDMP-Operational
Microsoft-Windows-Volume/Diagnostic
Microsoft-Windows-VolumeSnapshot-Driver/Operational
Microsoft-Windows-VPN/Operational
Microsoft-Windows-VPN-Client/Operational
Microsoft-Windows-Wcmsvc/Operational
Microsoft-Windows-WDAG-PolicyEvaluator-CSP/Operational
Microsoft-Windows-WDAG-PolicyEvaluator-GP/Operational
Microsoft-Windows-WebAuthN/Operational
Microsoft-Windows-WER-PayloadHealth/Operational
Microsoft-Windows-WFP/Operational
Microsoft-Windows-Win32k/Operational
Microsoft-Windows-Windows Defender/Operational
Microsoft-Windows-Windows Defender/WHC
Microsoft-Windows-Windows Firewall With Advanced Security/ConnectionSecurity
Microsoft-Windows-Windows Firewall With Advanced Security/Firewall
Microsoft-Windows-Windows Firewall With Advanced Security/FirewallDiagnostics
Microsoft-Windows-WindowsBackup/ActionCenter
Microsoft-Windows-WindowsSystemAssessmentTool/Operational
Microsoft-Windows-WindowsUpdateClient/Operational
Microsoft-Windows-WinINet-Config/ProxyConfigChanged
Microsoft-Windows-Winlogon/Operational
Microsoft-Windows-WinRM/Operational
Microsoft-Windows-Winsock-WS2HELP/Operational
Microsoft-Windows-Wired-AutoConfig/Operational
Microsoft-Windows-WLAN-AutoConfig/Operational
Microsoft-Windows-WMI-Activity/Operational
Microsoft-Windows-WMPNSS-Service/Operational
Microsoft-Windows-WorkFolders/Operational
Microsoft-Windows-WorkFolders/WHC
Microsoft-Windows-Workplace Join/Admin
Microsoft-Windows-WPD-ClassInstaller/Operational
Microsoft-Windows-WPD-CompositeClassDriver/Operational
Microsoft-Windows-WPD-MTPClassDriver/Operational
Microsoft-Windows-WWAN-SVC-Events/Operational
OpenSSH/Admin
OpenSSH/Operational
Setup
SMSApi
'@

    if ( $Options -like 'EventLogsDisable' )
    {
        if ( $Act -eq 'Set' )
        {
            $text = if ( $L.s4 ) { $L.s4 } else { "Отключение" }
            Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

            $text = if ( $L.s4_1 ) { $L.s4_1 } else { "Ведения Журналов Событий" }
            Write-Host "$text " -ForegroundColor White -NoNewline

            $text = if ( $L.s4_2 ) { $L.s4_2 } else { "Кроме системных журналов и исключённых" }
            Write-Host "| $text `n" -ForegroundColor DarkGray

            Set-Svc -Do:$Act Set-Service -Name 'EventLog' -StartupType Automatic -Status Running

            Write-Host

            [string[]] $NamesLogsOn = @()

            [string] $Key = 'SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels'
            
            try
            {
                [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($Key,'ReadSubTree','QueryValues,EnumerateSubKeys'
                ).GetSubKeyNames().ForEach({
                    try { if ( [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$Key\$_",'Enabled',$null) -eq 1 ) { $NamesLogsOn  += $_ } } catch {}
                })
            }
            catch {}

            $NamesLogsOn = foreach ( $Log in ( $NamesLogsOn | Sort-Object )) { if ( -not ( $ExcludedLogs.Where({ $Log -like $_ },'First') ) ) { $Log }}

            [int] $CountLogsOn = 0

            foreach ( $Name in $NamesLogsOn )
            {
                $CountLogsOn++

                Write-Host "   $($CountLogsOn.ToString().PadLeft(5,' ')). " -ForegroundColor DarkGray -NoNewline

                $text = if ( $L.s5 ) { $L.s5 } else { "Отключение" }
                Write-Host "$text " -ForegroundColor Cyan -NoNewline

                $text = if ( $L.s5_1 ) { $L.s5_1 } else { "Журнал" }
                Write-Host "| $text`: " -ForegroundColor DarkGray -NoNewline

                Write-Host "$Name" -ForegroundColor White

                Set-Reg -NoCheck New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\$Name" -Name 'Enabled' -Type DWord 0
            }

            $Enabled = 1
            try { $Enabled = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\EventLog\Windows PowerShell",'Enabled',1) }
            catch { $Enabled = 1 }
            
            # Если включен лог PowerShell и нет в исключениях
            if ( $Enabled -and ( -not ( $ExcludedLogs.Where({ 'Windows PowerShell' -like $_ },'First') )))
            {
                $CountLogsOn++

                Write-Host "   $($CountLogsOn.ToString().PadLeft(5,' ')). " -ForegroundColor DarkGray -NoNewline

                $text = if ( $L.s5 ) { $L.s5 } else { "Отключение" }
                Write-Host "$text " -ForegroundColor Cyan -NoNewline

                $text = if ( $L.s5_1 ) { $L.s5_1 } else { "Журнал" }
                Write-Host "| $text`: " -ForegroundColor DarkGray -NoNewline

                Write-Host 'Windows PowerShell' -ForegroundColor White

                Set-Reg -NoCheck New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\EventLog\Windows PowerShell' -Name 'Enabled' -Type DWord 0
            }

            if ( -not $CountLogsOn )
            {
                $text = if ( $L.s6 ) { $L.s6 } else { "Все журналы уже" }
                Write-Host "   $text " -ForegroundColor Green -NoNewline

                $text = if ( $L.s6_1 ) { $L.s6_1 } else { "Отключены" }
                Write-Host "$text " -ForegroundColor Magenta -NoNewline

                $text = if ( $L.s4_2 ) { $L.s4_2 } else { "Кроме системных журналов и исключённых" }
                Write-Host "| $text" -ForegroundColor DarkGray
            }
        }
        elseif ( $Act -eq 'Default' )
        {
            $Act = 'set'

            $text = if ( $L.s7 ) { $L.s7 } else { "Включение" }
            Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

            $text = if ( $L.s7_1 ) { $L.s7_1 } else { "Ведения Журналов Событий" }
            Write-Host "$text " -ForegroundColor White -NoNewline

            $text = if ( $L.s7_2 ) { $L.s7_2 } else { "Которые включены по умолчанию" }
            Write-Host "| $text`n" -ForegroundColor DarkGray

            Set-Svc -Do:$Act Set-Service -Name 'EventLog' -StartupType Automatic -Status Running

            Write-Host

            [string] $Key = 'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels'

            [int] $CountLogsOff = 0

            foreach ( $Name in ( $NamesLogsDefaultOn.Split("`n").Trim().Where{$_} ))
            {
                if ( [Microsoft.Win32.Registry]::GetValue("$Key\$Name",'Enabled',$null) -eq 0 ) {

                    $CountLogsOff++

                    Write-Host "   $($CountLogsOff.ToString().PadLeft(5,' ')). " -ForegroundColor DarkGray -NoNewline

                    $text = if ( $L.s8 ) { $L.s8 } else { "Включение" }
                    Write-Host "$text " -ForegroundColor Magenta -NoNewline

                    $text = if ( $L.s8_1 ) { $L.s8_1 } else { "Журнал" }
                    Write-Host "| $text`: " -ForegroundColor DarkGray -NoNewline

                    Write-Host "$Name" -ForegroundColor White

                    Set-Reg -NoCheck New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\$Name" -Name 'Enabled' -Type DWord 1
                }
            }

            $Enabled = 1
            try { $Enabled = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\EventLog\Windows PowerShell",'Enabled',1) }
            catch { $Enabled = 1 }
            
            # Если отключен лог PowerShell
            if ( 0 -eq $Enabled )
            {
                $CountLogsOff++

                Write-Host "   $($CountLogsOff.ToString().PadLeft(5,' ')). " -ForegroundColor DarkGray -NoNewline

                $text = if ( $L.s8 ) { $L.s8 } else { "Включение" }
                Write-Host "$text " -ForegroundColor Magenta -NoNewline

                $text = if ( $L.s8_1 ) { $L.s8_1 } else { "Журнал" }
                Write-Host "| $text`: " -ForegroundColor DarkGray -NoNewline

                Write-Host "Windows PowerShell" -ForegroundColor White

                Set-Reg -NoCheck Remove-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\EventLog\Windows PowerShell' -Name 'Enabled'
            }

            if ( -not $CountLogsOff )
            {
                $text = if ( $L.s9 ) { $L.s9 } else { "Все журналы уже" }
                Write-Host "   $text " -ForegroundColor Green -NoNewline

                $text = if ( $L.s9_1 ) { $L.s9_1 } else { "Включены" }
                Write-Host "$text " -ForegroundColor Cyan -NoNewline

                $text = if ( $L.s9_2 ) { $L.s9_2 } else { "Которые Включены По умолчанию" }
                Write-Host "| $text" -ForegroundColor DarkGray
            }

            $Act = 'Default'
        }
        else
        {
            $text = if ( $L.s10 ) { $L.s10 } else { "'Check' не предусмотрен для 'EventLogsDisable'" }
            Write-Host "   $text" -ForegroundColor DarkGray
        }

        # Если запуск из главных меню быстрых настроек (0 и 1) и отключались или включались журналы
        if ( $MenuConfigsQuickSettings -and ( $CountLogsOn -or $CountLogsOff ))
        {
            Write-Host "`n   Pause 1 sec ..." -ForegroundColor DarkGray
            Start-Sleep -Seconds 1
        }
    }

    if ( $Options -like 'EnableExcludedLogs' )
    {
        if ( $Act -eq 'Set' )
        {
            $text = if ( $L.s7 ) { $L.s7 } else { "Включение" }
            Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

            $text = if ( $L.s7_1 ) { $L.s7_1 } else { "Ведения Журналов Событий" }
            Write-Host "$text " -ForegroundColor White -NoNewline

            $text = if ( $L.s7_3 ) { $L.s7_3 } else { "По шаблонам исключений, которые отключены" }
            Write-Host "| $text`n" -ForegroundColor DarkGray

            [string[]] $NamesLogsOff    = @()
            [string[]] $EnableNamesLogs = @()

            [string] $Key = 'SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels'
            
            try
            {
                [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($Key,'ReadSubTree','QueryValues,EnumerateSubKeys'
                ).GetSubKeyNames().ForEach({
                    try { if ( [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$Key\$_",'Enabled',$null) -eq 0 ) { $NamesLogsOff += $_ } } catch {}
                })
            }
            catch {}

            $EnableNamesLogs = foreach ( $Log in ( $NamesLogsOff | Sort-Object )) { if ( $ExcludedLogs.Where({ $Log -like $_ },'First') ) { $Log }}

            $Enabled = 1
            try { $Enabled = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\EventLog\Windows PowerShell",'Enabled',1) }
            catch { $Enabled = 1 }

            # Если отключен лог PowerShell и он есть в исключениях
            if (( 0 -eq $Enabled ) -and ( $ExcludedLogs.Where({ 'Windows PowerShell' -like $_ },'First') ))
            { $EnableNamesLogs += 'Windows PowerShell' }

            [int] $N = 0

            foreach ( $Name in $EnableNamesLogs )
            {
                $N++

                Write-Host "   $($N.ToString().PadLeft(5,' ')). " -ForegroundColor DarkGray -NoNewline

                $text = if ( $L.s7 ) { $L.s7 } else { "Включение" }
                Write-Host "$text " -ForegroundColor Magenta -NoNewline

                $text = if ( $L.s5_1 ) { $L.s5_1 } else { "Журнал" }
                Write-Host "| $text`: " -ForegroundColor DarkGray -NoNewline

                Write-Host "$Name" -ForegroundColor White

                if ( $Name -eq 'Windows PowerShell' )
                {
                    Set-Reg -NoCheck Remove-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\EventLog\Windows PowerShell' -Name 'Enabled'
                }
                else
                {
                    Set-Reg -NoCheck New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\$Name" -Name 'Enabled' -Type DWord 1
                }
            }

            if ( -not $N )
            {
                $text = if ( $L.s9_3 ) { $L.s9_3 } else { "Нет отключенных" }
                Write-Host "   $text " -ForegroundColor Green -NoNewline

                $text = if ( $L.s9_4 ) { $L.s9_4 } else { "Исключённых журналов" }
                Write-Host "$text " -ForegroundColor Cyan
            }
        }
        else
        {
            $text = if ( $L.s10_1 ) { $L.s10_1 } else { "'Check/Default' не предусмотрен для 'EnableExcludedLogs'" }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }


    if ( $Options -like 'ClearEventLogs' )
    {
        if ( $Act -eq 'Set' )
        {
            $text = if ( $L.s11 ) { $L.s11 } else { "Очистка" }
            Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

            $text = if ( $L.s11_1 ) { $L.s11_1 } else { "Журналов Событий" }
            Write-Host "$text " -ForegroundColor White -NoNewline

            $text = if ( $L.s11_2 ) { $L.s11_2 } else { "Только с записями" }
            Write-Host "| $text `n" -ForegroundColor DarkGray

            [int] $ClearLogs = 0

            Get-WinEvent -ListLog * -Force -ErrorAction SilentlyContinue |
                ForEach-Object {
                    if ( $_.RecordCount -ge 1 )
                    {
                        $ClearLogs++

                        [string] $LogName = $_.LogName

                        Write-Host "   $($ClearLogs.ToString().PadLeft(5,' ')). " -ForegroundColor DarkGray -NoNewline

                        $text = if ( $L.s12 ) { $L.s12 } else { "Очистка" }
                        Write-Host "$text " -ForegroundColor Cyan -NoNewline

                        $text = if ( $L.s12_1 ) { $L.s12_1 } else { "Записей" }
                        Write-Host "| $text`: " -ForegroundColor DarkGray -NoNewline
                        Write-Host "$($_.RecordCount.ToString().PadRight(15,' ')) " -ForegroundColor Magenta -NoNewline

                        $text = if ( $L.s12_2 ) { $L.s12_2 } else { "Журнал" }
                        Write-Host "| $text`: " -ForegroundColor DarkGray -NoNewline

                        Write-Host "$LogName" -ForegroundColor White

                        & wevtutil.exe Clear-Log $LogName *>$null

                        # Если ошибка очистки, скорее всего нет доступа.
                        if ( $Global:LastExitCode )
                        {
                            [string] $Key = "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\$LogName"

                            try { [string] $ChannelAccess = [Microsoft.Win32.Registry]::GetValue($Key,'ChannelAccess',$null) }
                            catch { [string] $ChannelAccess = $null }

                            # Если значение доступа SDDL получено, значит раздел журнала в реестре существует.
                            if ( $ChannelAccess )
                            {
                                # Устанавливаем полный доступ для администратора к журналу, пробуем снова очистить, и возвращаем параметр доступа.
                                & wevtutil.exe Set-Log $LogName /ChannelAccess:'O:BAG:SYD:(A;;0x1;;;SY)(A;;0x5;;;BA)(A;;0x1;;;LA)' *>$null
                                & wevtutil.exe Clear-Log $LogName *>$null
                                & wevtutil.exe Set-Log $LogName /ChannelAccess:$ChannelAccess *>$null
                            }
                        }
                    }
                }
        }
        else
        {
            $text = if ( $L.s13 ) { $L.s13 } else { "'Check' и 'Default' не предусмотрен для 'ClearEventLogs'" }
            Write-Host "   $text" -ForegroundColor DarkGray
        }

        # Если запуск из главных меню быстрых настроек (0 и 1)
        if ( $MenuConfigsQuickSettings )
        {
            Write-Host "`n   Pause 1 sec ..." -ForegroundColor DarkGray
            Start-Sleep -Seconds 1
        }
    }


    if ( $Options -like 'ShowRunningLogs' )
    {
        $text = if ( $L.s14 ) { $L.s14 } else { "Работающие" }
        Write-Host "`n   $text " -ForegroundColor Green -NoNewline

        $text = if ( $L.s14_1 ) { $L.s14_1 } else { "Журналы Событий" }
        Write-Host "$text " -ForegroundColor White -NoNewline

        $text = if ( $L.s14_2 ) { $L.s14_2 } else { "Кроме системных журналов" }
        Write-Host "| $text`n" -ForegroundColor DarkGray

        [string] $Key = 'SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels'

        [string[]] $NamesLogsOn = @()
           
        try
        {
            [string[]] $NamesLogsOn =
                [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($Key,'ReadSubTree','QueryValues,EnumerateSubKeys'
                    ).GetSubKeyNames().ForEach({
                        try { if ( [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$Key\$_",'Enabled',$null) -eq 1 ) { $_ } } catch {}
                    }) | Sort-Object
        }
        catch {}

        [int] $CountLogsOn = 0

        foreach ( $Name in $NamesLogsOn )
        {
            $CountLogsOn++

            Write-Host "   $($CountLogsOn.ToString().PadLeft(5,' ')). " -ForegroundColor DarkGray -NoNewline

            $text = if ( $L.s15 ) { $L.s15 } else { "Журнал" }
            Write-Host "$text " -ForegroundColor Green -NoNewline
            Write-Host "| " -ForegroundColor DarkGray -NoNewline
            Write-Host "$Name" -ForegroundColor White
        }

        if (( & wevtutil.exe Get-Log 'Windows PowerShell' ) -like 'enabled: true' )
        {
            $CountLogsOn++

            Write-Host "   $($CountLogsOn.ToString().PadLeft(5,' ')). " -ForegroundColor DarkGray -NoNewline

            $text = if ( $L.s15 ) { $L.s15 } else { "Журнал" }
            Write-Host "$text " -ForegroundColor Green -NoNewline
            Write-Host "| " -ForegroundColor DarkGray -NoNewline
            Write-Host 'Windows PowerShell' -ForegroundColor White
        }

        if ( -not $CountLogsOn )
        {
            $text = if ( $L.s16 ) { $L.s16 } else { "Все журналы" }
            Write-Host "   $text " -ForegroundColor Green -NoNewline

            $text = if ( $L.s16_1 ) { $L.s16_1 } else { "Отключены" }
            Write-Host "$text " -ForegroundColor Magenta -NoNewline

            $text = if ( $L.s14_2 ) { $L.s14_2 } else { "Кроме системных журналов" }
            Write-Host "| $text" -ForegroundColor DarkGray
        }
    }

    if ( $Options -like 'ShowExcludedLogs' )
    {
        if ( $ExcludedLogs.Count )
        {
            $text = if ( $L.s17 ) { $L.s17 } else { "Шаблоны" }
            Write-Host "`n   $text " -ForegroundColor Blue -NoNewline

            $text = if ( $L.s17_1 ) { $L.s17_1 } else { "Исключений" }
            Write-Host "$text`n" -ForegroundColor White

            [int] $N = 0

            foreach ( $Log in $ExcludedLogs )
            {
                $N++
                $Space = ''
                if     (  10 -gt $N ) { $Space = '  ' }
                elseif ( 100 -gt $N ) { $Space = ' '  }

                Write-Host "   $Space$N. " -ForegroundColor DarkGray -NoNewline
                Write-Host "$Log" -ForegroundColor DarkCyan
            }
        }
        else
        {
            $text = if ( $L.s17_2 ) { $L.s17_2 } else { "Нет Шаблонов Исключений" }
            Write-Host "`n   $text " -ForegroundColor DarkGray
        }
    }

    $text = if ( $L.s18 ) { $L.s18 } else { "Выполнено" }
    Write-Host "`n   $text" -ForegroundColor Green

    Get-Pause
}
