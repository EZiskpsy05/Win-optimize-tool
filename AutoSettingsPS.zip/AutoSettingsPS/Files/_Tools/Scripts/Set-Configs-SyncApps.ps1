﻿


# Группы параметров, относящиеся к Синхронизации и AppStore.
Function Set-Configs-SyncApps {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param( [Parameter( Mandatory = $true,  Position = 0 )] [ValidateSet( 'Set', 'Check', 'Default' )] [string] $Act
          ,[Parameter( Mandatory = $false, Position = 1 )] [switch] $ApplyGP )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    [string[]] $ListPresets = Get-List-Presets

    # Получение списка подгрупп из файла пресета, с изменением имени или исключением, в зависимости от действия
    [string[]] $Groups = Get-Configs-Groups -Actions $Act -FuncName $NameThisFunction

    [string] $Group = ''   # Для названия группы
    [string] $Info  = ''   # Для описания группы
    [string] $text  = ''   # Для любого текста
    [hashtable] $L = @{}   # Для получения перевода

    [bool] $is64 = [Environment]::Is64BitOperatingSystem


    # Далее сами настройки ...



    $Info = 'Отключить Все приложения из магазина и магазин'
    $Group = 'Apps-Store' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # Проблема: Если отключить 'DisableStoreApps', то не будут работать Apps панели у современных драйверов.
        # Комп\Адм. Шабл\Компоненты Windows\Магазин "Отключить все приложения из Магазина Windows"
        # Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\WindowsStore' -Name 'DisableStoreApps' -Type DWord 1

        # Комп\Адм. Шабл\Компоненты Windows\Магазин "Отключить приложение Магазин"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\WindowsStore' -Name 'RemoveWindowsStore' -Type DWord 1
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\WindowsStore'
    }



    $Info = 'Отключить Авто Обновления приложений магазина'
    $Group = 'Apps-Store-AutoUpdate' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsStore\WindowsUpdate' -Name 'AutoDownload' -Type DWord 2

        if ($is64) {
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\WindowsStore\WindowsUpdate' -Name 'AutoDownload' -Type DWord 2
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsStore\WindowsUpdate' -Name 'AutoDownload'

        if ($is64) {
            Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\WindowsStore\WindowsUpdate' -Name 'AutoDownload'
        }
        
        # ГП: Конфигурация компьютера -> Административные шаблоны -> Компоненты Windows -> Магазин:
        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\WindowsStore' -Name 'AutoDownload'
    }



    $Info = 'Отключить Доступ к Магазину Windows'
    $Group = 'Apps-NoOpenWith' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # Комп\Адм. Шабл\Система\Управление связью через Интернет\Параметры связи через Интернет "Отключить доступ к Магазину"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer' -Name 'NoUseStoreOpenWith' -Type DWord 1

        # Пользователи\Адм. Шабл\Система\Управление связью через Интернет\Параметры связи через Интернет "Отключить доступ к Магазину"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Windows\Explorer' -Name 'NoUseStoreOpenWith' -Type DWord 1
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer' -Name 'NoUseStoreOpenWith'
        Set-LGP Remove-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Windows\Explorer' -Name 'NoUseStoreOpenWith'
    }



    $Info = 'Отключить Доступ приложениям AppStore на др. устройствах работать на этом устройстве'
    $Group = 'Apps-DeviceAccess' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\SmartGlass' -Name 'BluetoothPolicy' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\SmartGlass' -Name 'UserAuthPolicy' -Type DWord 0

        "Передача между устройствами (Настройки -> Система -> Общие возможности):" | Show-Info -Shift $L.s2

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CDP' -Name 'CdpSessionUserAuthzPolicy' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CDP' -Name 'RomeSdkChannelUserAuthzPolicy' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CDP\SettingsPage' -Name 'RomeSdkChannelUserAuthzPolicy' -Type DWord 1
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\SmartGlass' -Name 'BluetoothPolicy'
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\SmartGlass' -Name 'UserAuthPolicy'

        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CDP' -Name 'CdpSessionUserAuthzPolicy' -Type DWord 1
        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CDP' -Name 'RomeSdkChannelUserAuthzPolicy' -Type DWord 1
        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CDP\SettingsPage' -Name 'RomeSdkChannelUserAuthzPolicy' -Type DWord 1
    }



    $Info = 'Отключить службу "Служба PushToInstall Windows"'
    $Group = 'Apps-Services-PushToInstall' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        Set-Svc -Do:$Act Set-Service -Name 'PushToInstall' -StartupType Disabled
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default
        
        Set-Svc Set-Service -Name 'PushToInstall' -StartupType Manual
    }



    $Info = 'Отключить службу "Служба установки Microsoft Store"'
    $Group = 'Apps-Services-InstallService' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        Set-Svc -Do:$Act Set-Service -Name 'InstallService' -StartupType Disabled
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default
        
        Set-Svc Set-Service -Name 'InstallService' -StartupType Manual
    }



    $Info = 'Отключить службу "Служба кошелька"'
    $Group = 'Apps-Services-WalletService' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        Set-Svc -Do:$Act Set-Service -Name 'WalletService' -StartupType Disabled
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default
        
        Set-Svc Set-Service -Name 'WalletService' -StartupType Manual
    }



    $Info = 'Отключить службу "Служба географического положения"'
    $Group = 'Apps-Services-lfsvc' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        Set-Svc -Do:$Act Set-Service -Name 'lfsvc' -StartupType Disabled          # Служба географического положения
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default
        
        Set-Svc Set-Service -Name 'lfsvc' -StartupType Manual
    }



    $Info = 'Отключить службу "Служба системы push-уведомлений Windows"'
    $Group = 'Apps-Services-WpnService' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        Set-Svc -Do:$Act Set-Service -Name 'WpnService' -StartupType Disabled     # Служба системы push-уведомлений Windows
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default
        
        Set-Svc Set-Service -Name 'WpnService' -StartupType Automatic
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\WpnService' -Name 'UserServiceFlags'
    }



    $Info = 'Disable "Touch Keyboard and Handwriting Panel Service" Service'
    $Group = 'Apps-Services-TabletInputService' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        Set-Svc -Do:$Act Set-Service -Name 'TabletInputService' -StartupType Disabled     # Служба сенсорной клавиатуры и панели рукописного ввода
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default
        
        Set-Svc Set-Service -Name 'TabletInputService' -StartupType Manual
    }



    $Info = 'Отключить службу "Agent Activation Runtime"'
    $Group = 'Apps-Services-AarSvc' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        Set-Svc -Do:$Act Set-Service -Name 'AarSvc' -StartupType Disabled   # Нужна для Кортаны и подобного. 
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default
        
        Set-Svc Set-Service -Name 'AarSvc' -StartupType Manual

        try { $ImagePath = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\AarSvc','ImagePath',$null) }
        catch { $ImagePath = $null }

        if ( $ImagePath )
        {
            Set-Reg New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\AarSvc' -Name 'UserServiceFlags' -Type DWord 3
        }
    }



    $Info = 'Отключить службу "CaptureService"'
    $Group = 'Apps-Services-CaptureService' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Svc -Do:$Act Set-Service -Name 'CaptureService' -StartupType Disabled      # Служба захвата экрана # Нужна: Фрагмент и набросок и т.д.
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default
        
        Set-Svc Set-Service -Name 'CaptureService' -StartupType Manual

        try { $ImagePath = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\CaptureService','ImagePath',$null) }
        catch { $ImagePath = $null }

        if ( $ImagePath )
        {
            Set-Reg New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\CaptureService' -Name 'UserServiceFlags' -Type DWord 3
        }
    }



    $Info = 'Отключить службу "Служба развертывания AppX"'
    $Group = 'Apps-Services-AppXSVC' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        # Проблема: Если отключить службу 'AppXSVC', то некорректно работает Модерн Пуск
        Set-Svc -Do:$Act Set-Service -Name 'AppXSVC' -StartupType Disabled      # Нужна для установки Apps и модерн настройкам
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default
        
        Set-Svc Set-Service -Name 'AppXSVC' -StartupType Manual
    }



    $Info = 'Отключить службу "Служба лицензий клиента"'
    $Group = 'Apps-Services-ClipSVC' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        # Проблема: Если отключить службу 'ClipSVC', то не активировать Windows   # Служба лицензий клиента . НЕ учитывается активаторами Ratiborus
        Set-Svc -Do:$Act Set-Service -Name 'ClipSVC' -StartupType Disabled      # Нужна для установки Apps и активации Windows
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default
        
        Set-Svc Set-Service -Name 'ClipSVC' -StartupType Manual
    }



    $Info = 'Отключить службу "Служба Windows License Manager"'
    $Group = 'Apps-Services-LicenseManager' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        # Проблема: Если отключить службу 'LicenseManager', то не активировать Windows # Служба Windows License Manager. Учитывается активаторами Ratiborus
        Set-Svc -Do:$Act Set-Service -Name 'LicenseManager' -StartupType Disabled
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default
        
        Set-Svc Set-Service -Name 'LicenseManager' -StartupType Manual
    }



    $Info = 'Отключить службу "Помощник по входу в учетную запись Майкрософт"'
    $Group = 'Apps-Services-wlidsvc' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        # Проблема: Если отключить службу 'wlidsvc', невозможно будет создать даже локальную учетку через Модерн аплет настроек
        # Но через управление компьютером или "control userpasswords2" можно будет создать. Нужна также для активации Windows. Учитывается активаторами Ratiborus
        Set-Svc -Do:$Act Set-Service -Name 'wlidsvc' -StartupType Disabled        # Помощник по входу в учетную запись Майкрософт
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default
        
        Set-Svc Set-Service -Name 'wlidsvc' -StartupType Manual
    }



    $Info = 'Отключить службу "Диспетчер учетных веб-записей"'
    $Group = 'Apps-Services-TokenBroker' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        # Проблема: При отключении службы 'TokenBroker' Диспетчер учетных веб-записей, крашит некоторые настройки:
        # Учетные записи -> Параметры входа; Конфиденциальность -> журнал действий # Set-SettingsPageVisibility -Act:$Act -Names 'signinoptions', 'privacy-activityhistory'
        Set-Svc -Do:$Act Set-Service -Name 'TokenBroker' -StartupType Disabled
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default
        
        Set-Svc Set-Service -Name 'TokenBroker' -StartupType Manual
    }



    $Info = 'Отключить службу "Сведения о приложении"'
    $Group = 'Apps-Services-Appinfo' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        try { $EnableLUA = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System','EnableLUA',$null) }
        catch { $EnableLUA = $null }

        if ( 0 -eq $EnableLUA )
        {
            # Проблема: Если отключить службу 'Appinfo', то будет ошибка при выдаче запросов UAC, и в итоге не получить права админа! Теперь она в связке с UAC.
            Set-Svc -Do:$Act Set-Service -Name 'Appinfo' -StartupType Disabled      # Нужна для установки Apps и UAC
        }
        else
        {
            $text = if ( $L.s2 ) { $L.s2 } else { "Пропуск, UAC не отключен" }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default
        
        Set-Svc Set-Service -Name 'Appinfo' -StartupType Manual
    }



    $Info = 'Отключить Задачи AppStore'
    $Group = 'Apps-Tasks' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Clip\License Validation'
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\WindowsUpdate\Automatic App Update'

        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\ApplicationData\appuriverifierdaily'
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\ApplicationData\appuriverifierinstall'
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\License Manager\TempSignedLicenseExchange'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Tsk Disable-ScheduledTask -TaskName '\Microsoft\Windows\Clip\License Validation'
        Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\WindowsUpdate\Automatic App Update'

        Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\ApplicationData\appuriverifierdaily'
        Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\ApplicationData\appuriverifierinstall'
        Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\License Manager\TempSignedLicenseExchange'
    }



    $Info = 'Отключить Задачи регистрации, доступа и синхронизации с устройствами'
    $Group = 'Apps-Tasks-Sync' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\SettingSync\BackgroundUpLoadTask'
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\SettingSync\NetworkStateChangeTask'
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Device Setup\Metadata Refresh'

        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\DeviceDirectoryClient\HandleCommand'
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\DeviceDirectoryClient\HandleWnsCommand'
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\DeviceDirectoryClient\IntegrityCheck'
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\DeviceDirectoryClient\LocateCommandUserSession'
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\DeviceDirectoryClient\RegisterDeviceAccountChange'
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\DeviceDirectoryClient\RegisterDeviceLocationRightsChange'
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\DeviceDirectoryClient\RegisterDevicePeriodic24'
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\DeviceDirectoryClient\RegisterDevicePolicyChange'
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\DeviceDirectoryClient\RegisterDeviceProtectionStateChanged'
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\DeviceDirectoryClient\RegisterDeviceSettingChange'
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\DeviceDirectoryClient\RegisterUserDevice'

        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Input\LocalUserSyncDataAvailable'
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Input\MouseSyncDataAvailable'
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Input\PenSyncDataAvailable'
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Input\TouchpadSyncDataAvailable'

        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\International\Synchronize Language Settings'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\SettingSync\BackgroundUpLoadTask'
        Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\SettingSync\NetworkStateChangeTask'
        Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\Device Setup\Metadata Refresh'

        Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\DeviceDirectoryClient\HandleCommand'
        Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\DeviceDirectoryClient\HandleWnsCommand'
        Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\DeviceDirectoryClient\IntegrityCheck'
        Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\DeviceDirectoryClient\LocateCommandUserSession'
        Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\DeviceDirectoryClient\RegisterDeviceAccountChange'
        Set-Tsk Disable-ScheduledTask -TaskName '\Microsoft\Windows\DeviceDirectoryClient\RegisterDeviceLocationRightsChange'
        Set-Tsk Disable-ScheduledTask -TaskName '\Microsoft\Windows\DeviceDirectoryClient\RegisterDevicePeriodic24'
        Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\DeviceDirectoryClient\RegisterDevicePolicyChange'
        Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\DeviceDirectoryClient\RegisterDeviceProtectionStateChanged'
        Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\DeviceDirectoryClient\RegisterDeviceSettingChange'
        Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\DeviceDirectoryClient\RegisterUserDevice'

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Input\LocalUserSyncDataAvailable'
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Input\MouseSyncDataAvailable'
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Input\PenSyncDataAvailable'
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Input\TouchpadSyncDataAvailable'
        
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\International\Synchronize Language Settings'
    }



    $Info = 'Отключить Уведомления и обновления плиток в меню пуск'
    $Group = 'Apps-PushNotifications' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # Пользователи\Адм. Шабл\Система\Управление связью через Интернет\Параметры связи через Интернет "Отключить доступ к Магазину"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Windows\CurrentVersion\PushNotifications' -Name 'NoTileApplicationNotification' -Type DWord 1
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-LGP Remove-Item -Path 'HKCU:\Software\Policies\Microsoft\Windows\CurrentVersion\PushNotifications'
    }



    $Info = 'Отключить Синхронизацию'
    $Group = 'Apps-SettingSync' ; $L = $Lang.$Group

    # Если отключить (настроить) или выполнить проверку.
    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # Комп\Адм. Шабл\Компоненты Windows\Синхронизация параметров "Не синхронизировать"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\SettingSync' -Name 'DisableSettingSync' -Type DWord 2
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\SettingSync' -Name 'DisableSettingSyncUserOverride' -Type DWord 1
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\SettingSync' -Name 'EnableBackupForWin8Apps' -Type DWord 0

        # Комп\Адм. Шабл\Компоненты Windows\RSS-каналы "Выключить синхронизацию в фоновом режиме для веб-каналов и веб-фрагментов"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Feeds' -Name 'BackgroundSyncStatus' -Type DWord 0
        # Пользователи\Адм. Шабл\Компоненты Windows\RSS-каналы "Выключить синхронизацию в фоновом режиме для веб-каналов и веб-фрагментов"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Internet Explorer\Feeds' -Name 'BackgroundSyncStatus' -Type DWord 0

        # Комп\Адм. Шабл\Компоненты Windows\Конфиденциальность приложения "Разрешить синхронизацию приложений для Windows с устройствами"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy' -Name 'LetAppsSyncWithDevices' -Type DWord 2

        # Комп\Адм. Шабл\Компоненты Windows\Обмен Сообщениями\ "Разрешить синхронизацию" : Отключена
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Messaging' -Name 'AllowMessageSync' -Type DWord 0
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        # Иначе восстановить по умолчанию.

        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\SettingSync'

        Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Feeds'

        Set-LGP Remove-Item -Path 'HKCU:\Software\Policies\Microsoft\Internet Explorer\Feeds'

        Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy'

        Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Messaging'
    }




    $Info = 'Отключить Службы синхронизации'
    $Group = 'Apps-Services-Sync' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Svc -Do:$Act Set-Service -Name 'OneSyncSvc' -StartupType Disabled
        Set-Svc -Do:$Act Set-Service -Name 'MessagingService' -StartupType Disabled
        Set-Svc -Do:$Act Set-Service -Name 'PimIndexMaintenanceSvc' -StartupType Disabled
        Set-Svc -Do:$Act Set-Service -Name 'UnistoreSvc' -StartupType Disabled
        Set-Svc -Do:$Act Set-Service -Name 'UserDataSvc' -StartupType Disabled

        # Проблема: При отключении службы 'WpnUserService' Пользовательская служба push-уведомлений Windows, Не будет работать панель уведомлений.
        # Set-Svc -Do:$Act Set-Service -Name 'WpnUserService' -StartupType Disabled
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Svc Set-Service -Name 'OneSyncSvc' -StartupType Automatic
        Set-Svc Set-Service -Name 'MessagingService' -StartupType Manual
        Set-Svc Set-Service -Name 'PimIndexMaintenanceSvc' -StartupType Manual
        Set-Svc Set-Service -Name 'UnistoreSvc' -StartupType Manual
        Set-Svc Set-Service -Name 'UserDataSvc' -StartupType Manual
        Set-Svc Set-Service -Name 'WpnUserService' -StartupType Automatic

        Set-Reg Remove-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\OneSyncSvc' -Name 'UserServiceFlags'
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\MessagingService' -Name 'UserServiceFlags'

        foreach ( $Name in 'PimIndexMaintenanceSvc','UnistoreSvc','UserDataSvc','WpnUserService' )
        {
            try { $ImagePath = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\$Name",'ImagePath',$null) }
            catch { $ImagePath = $null }

            if ( $ImagePath )
            {
                $Path = "HKLM:\SYSTEM\CurrentControlSet\Services\$Name"
                Set-Reg New-ItemProperty -Path $Path -Name 'UserServiceFlags' -Type DWord 3
            }
        }
    }



    $Info = 'Отключить Конфиденциальный доступ к "Список языков"'
    $Group = 'Apps-PrivacyAccess-ListLanguages' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Control Panel\International\User Profile' -Name 'HttpAcceptLanguageOptOut' -Type DWord 1
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-ItemProperty -Path 'HKCU:\Control Panel\International\User Profile' -Name 'HttpAcceptLanguageOptOut'
    }


    $Info = 'Отключить Конфиденциальный доступ к "Распознование голоса"'
    $Group = 'Apps-PrivacyAccess-VoiceRecogn' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Speech_OneCore\Settings\OnlineSpeechPrivacy' -Name 'HasAccepted' -Type DWord 0
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Speech_OneCore\Settings\OnlineSpeechPrivacy' -Name 'HasAccepted' -Type DWord 0
    }



    $Info = 'Отключить Конфиденциальный доступ к "Персонализация Ввода"'
    $Group = 'Apps-PrivacyAccess-Input' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Personalization\Settings' -Name 'AcceptedPrivacyPolicy' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\InputPersonalization' -Name 'RestrictImplicitTextCollection' -Type DWord 1
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\InputPersonalization' -Name 'RestrictImplicitInkCollection' -Type DWord 1
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\InputPersonalization\TrainedDataStore' -Name 'HarvestContacts' -Type DWord 0

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Input\TIPC' -Name 'Enabled' -Type DWord 0

        # Комп\Адм. Шабл\Панель управления\Язык и региональные стандарты "Разрешить персонализации ввода"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\InputPersonalization' -Name 'AllowInputPersonalization' -Type DWord 0

        # Комп\Адм. Шабл\Панель управления\Язык и региональные стандарты\Персонализация рукописного текста "Отключить автоматическое обучение"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\InputPersonalization' -Name 'RestrictImplicitInkCollection' -Type DWord 1
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\InputPersonalization' -Name 'RestrictImplicitTextCollection' -Type DWord 1

        # Пользователи\Адм. Шабл\Панель управления\Язык и региональные стандарты\Персонализация рукописного текста "Отключить автоматическое обучение"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\InputPersonalization' -Name 'RestrictImplicitInkCollection' -Type DWord 1
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\InputPersonalization' -Name 'RestrictImplicitTextCollection' -Type DWord 1
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default
        
        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Personalization\Settings' -Name 'AcceptedPrivacyPolicy' -Type DWord 1
        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\InputPersonalization' -Name 'RestrictImplicitTextCollection' -Type DWord 0
        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\InputPersonalization' -Name 'RestrictImplicitInkCollection' -Type DWord 0
        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\InputPersonalization\TrainedDataStore' -Name 'HarvestContacts' -Type DWord 1

        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Input\TIPC' -Name 'Enabled' -Type DWord 0

        Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\InputPersonalization'
        Set-LGP Remove-Item -Path 'HKCU:\Software\Policies\Microsoft\InputPersonalization'
    }



    $Info = 'Отключить Конфиденциальный доступ к "Диагностические данные"'
    $Group = 'Apps-PrivacyAccess-DiagData' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Siuf\Rules' -Name 'NumberOfSIUFInPeriod' -Type DWord 0
        Set-Reg -Do:$Act Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Siuf\Rules' -Name 'PeriodInNanoSeconds'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default
        
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Siuf\Rules' -Name 'NumberOfSIUFInPeriod'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Siuf\Rules' -Name 'PeriodInNanoSeconds'
    }



    $Info = 'Отключить Конфиденциальный доступ к "Расположение"'
    $Group = 'Apps-PrivacyAccess-Location' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location' -Name 'Value' -Type String 'Deny'
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location' -Name 'Value' -Type String 'Deny'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default
        
        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location' -Name 'Value' -Type String 'Deny'
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location' -Name 'Value' -Type String 'Deny'
    }



    $Info = 'Отключить Конфиденциальный доступ к "Камера"'
    $Group = 'Apps-PrivacyAccess-Webcam' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\webcam' -Name 'Value' -Type String 'Deny'
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\webcam' -Name 'Value' -Type String 'Deny'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default
        
        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\webcam' -Name 'Value' -Type String 'Allow'
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\webcam' -Name 'Value' -Type String 'Allow'
    }



    $Info = 'Отключить Конфиденциальный доступ к "Микрофон"'
    $Group = 'Apps-PrivacyAccess-Microphone' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\microphone' -Name 'Value' -Type String 'Deny'
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\microphone' -Name 'Value' -Type String 'Deny'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default
        
        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\microphone' -Name 'Value' -Type String 'Allow'
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\microphone' -Name 'Value' -Type String 'Allow'
    }



    $Info = 'Отключить Конфиденциальный доступ к "Уведомления"'
    $Group = 'Apps-PrivacyAccess-Notifications' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\userNotificationListener' -Name 'Value' -Type String 'Deny'
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\userNotificationListener' -Name 'Value' -Type String 'Deny'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default
        
        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\userNotificationListener' -Name 'Value' -Type String 'Allow'
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\userNotificationListener' -Name 'Value' -Type String 'Allow'
    }



    $Info = 'Отключить Конфиденциальный доступ к "Учетная запись"'
    $Group = 'Apps-PrivacyAccess-UserAccount' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\userAccountInformation' -Name 'Value' -Type String 'Deny'
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\userAccountInformation' -Name 'Value' -Type String 'Deny'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default
        
        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\userAccountInformation' -Name 'Value' -Type String 'Allow'
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\userAccountInformation' -Name 'Value' -Type String 'Allow'
    }



    $Info = 'Отключить Конфиденциальный доступ к "Контакты"'
    $Group = 'Apps-PrivacyAccess-Contacts' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\contacts' -Name 'Value' -Type String 'Deny'
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\contacts' -Name 'Value' -Type String 'Deny'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default
        
        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\contacts' -Name 'Value' -Type String 'Allow'
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\contacts' -Name 'Value' -Type String 'Allow'
    }



    $Info = 'Отключить Конфиденциальный доступ к "Календарь"'
    $Group = 'Apps-PrivacyAccess-Calendar' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\appointments' -Name 'Value' -Type String 'Deny'
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\appointments' -Name 'Value' -Type String 'Deny'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default
        
        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\appointments' -Name 'Value' -Type String 'Allow'
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\appointments' -Name 'Value' -Type String 'Allow'
    }



    $Info = 'Отключить Конфиденциальный доступ к "Журнал вызовов"'
    $Group = 'Apps-PrivacyAccess-CallHistory' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\phoneCallHistory' -Name 'Value' -Type String 'Deny'
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\phoneCallHistory' -Name 'Value' -Type String 'Deny'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default
        
        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\phoneCallHistory' -Name 'Value' -Type String 'Allow'
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\phoneCallHistory' -Name 'Value' -Type String 'Allow'
    }



    $Info = 'Отключить Конфиденциальный доступ к "Электронная почта"'
    $Group = 'Apps-PrivacyAccess-Email' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\email' -Name 'Value' -Type String 'Deny'
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\email' -Name 'Value' -Type String 'Deny'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default
        
        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\email' -Name 'Value' -Type String 'Allow'
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\email' -Name 'Value' -Type String 'Allow'
    }



    $Info = 'Отключить Конфиденциальный доступ к "Задачи"'
    $Group = 'Apps-PrivacyAccess-DataTasks' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\userDataTasks' -Name 'Value' -Type String 'Deny'
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\userDataTasks' -Name 'Value' -Type String 'Deny'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default
        
        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\userDataTasks' -Name 'Value' -Type String 'Allow'
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\userDataTasks' -Name 'Value' -Type String 'Allow'
    }



    $Info = 'Отключить Конфиденциальный доступ к "Обмен сообщениями"'
    $Group = 'Apps-PrivacyAccess-Messaging' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\chat' -Name 'Value' -Type String 'Deny'
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\chat' -Name 'Value' -Type String 'Deny'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default
        
        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\chat' -Name 'Value' -Type String 'Allow'
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\chat' -Name 'Value' -Type String 'Allow'
    }



    $Info = 'Отключить Конфиденциальный доступ к "Радио"'
    $Group = 'Apps-PrivacyAccess-Radios' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\radios' -Name 'Value' -Type String 'Deny'
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\radios' -Name 'Value' -Type String 'Deny'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default
        
        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\radios' -Name 'Value' -Type String 'Allow'
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\radios' -Name 'Value' -Type String 'Allow'
    }



    $Info = 'Отключить Конфиденциальный доступ к "Другие устройства"'
    $Group = 'Apps-PrivacyAccess-BluetoothDev' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\bluetoothSync' -Name 'Value' -Type String 'Deny'
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\bluetoothSync' -Name 'Value' -Type String 'Deny'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default
        
        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\bluetoothSync' -Name 'Value' -Type String 'Allow'
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\bluetoothSync' -Name 'Value' -Type String 'Allow'
    }



    $Info = 'Отключить Конфиденциальный доступ к "Диагностика приложения"'
    $Group = 'Apps-PrivacyAccess-AppDiag' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\appDiagnostics' -Name 'Value' -Type String 'Deny'
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\appDiagnostics' -Name 'Value' -Type String 'Deny'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default
        
        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\appDiagnostics' -Name 'Value' -Type String 'Allow'
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\appDiagnostics' -Name 'Value' -Type String 'Allow'
    }



    $Info = 'Отключить Конфиденциальный доступ к "Телефонные звонки"'
    $Group = 'Apps-PrivacyAccess-PhoneCall' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\appDiagnostics' -Name 'Value' -Type String 'Deny'
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\appDiagnostics' -Name 'Value' -Type String 'Deny'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default
        
        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\appDiagnostics' -Name 'Value' -Type String 'Allow'
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\appDiagnostics' -Name 'Value' -Type String 'Allow'
    }



    $Info = 'Отключить Конфиденциальный доступ к "Сотовая связь"'
    $Group = 'Apps-PrivacyAccess-CellularData' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\cellularData' -Name 'Value' -Type String 'Deny'
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\cellularData' -Name 'Value' -Type String 'Deny'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default
        
        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\cellularData' -Name 'Value' -Type String 'Allow'
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\cellularData' -Name 'Value' -Type String 'Allow'
    }



    $Info = 'Отключить Конфиденциальный доступ к "Документы"'
    $Group = 'Apps-PrivacyAccess-Documents' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\documentsLibrary' -Name 'Value' -Type String 'Deny'
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\documentsLibrary' -Name 'Value' -Type String 'Deny'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default
        
        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\documentsLibrary' -Name 'Value' -Type String 'Allow'
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\documentsLibrary' -Name 'Value' -Type String 'Allow'
    }



    $Info = 'Отключить Конфиденциальный доступ к "Изображения"'
    $Group = 'Apps-PrivacyAccess-Pictures' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\picturesLibrary' -Name 'Value' -Type String 'Deny'
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\picturesLibrary' -Name 'Value' -Type String 'Deny'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default
        
        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\picturesLibrary' -Name 'Value' -Type String 'Allow'
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\picturesLibrary' -Name 'Value' -Type String 'Allow'
    }



    $Info = 'Отключить Конфиденциальный доступ к "Видео"'
    $Group = 'Apps-PrivacyAccess-Videos' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\videosLibrary' -Name 'Value' -Type String 'Deny'
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\videosLibrary' -Name 'Value' -Type String 'Deny'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default
        
        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\videosLibrary' -Name 'Value' -Type String 'Allow'
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\videosLibrary' -Name 'Value' -Type String 'Allow'
    }



    $Info = 'Отключить Конфиденциальный доступ к "Файловая система"'
    $Group = 'Apps-PrivacyAccess-FileSystem' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\broadFileSystemAccess' -Name 'Value' -Type String 'Deny'
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\broadFileSystemAccess' -Name 'Value' -Type String 'Deny'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default
        
        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\broadFileSystemAccess' -Name 'Value' -Type String 'Allow'
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\broadFileSystemAccess' -Name 'Value' -Type String 'Allow'
    }



    $Info = 'Отключить Конфиденциальный доступ к "Голосовая активация"'
    $Group = 'Apps-PrivacyAccess-VoiceActivat' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Speech_OneCore\Settings\VoiceActivation\UserPreferenceForAllApps' -Name 'AgentActivationEnabled' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Speech_OneCore\Settings\VoiceActivation\UserPreferenceForAllApps' -Name 'AgentActivationLastUsed' -Type DWord 0
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default
        
        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Speech_OneCore\Settings\VoiceActivation\UserPreferenceForAllApps' -Name 'AgentActivationEnabled' -Type DWord 1
        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Speech_OneCore\Settings\VoiceActivation\UserPreferenceForAllApps' -Name 'AgentActivationLastUsed' -Type DWord 1
    }



    $Info = 'Отключить Журнал буфера обмена'
    $Group = 'Apps-Clipboard' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Svc -Do:$Act Set-Service -Name 'cbdhsvc' -StartupType Disabled
        # Комп\Адм. Шабл\Система\Политики ОС
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' -Name 'AllowClipboardHistory' -Type DWord 0
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' -Name 'AllowCrossDeviceClipboard' -Type DWord 0

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Clipboard' -Name 'AllowClipboardHistory' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Clipboard' -Name 'AllowCrossDeviceClipboard' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Clipboard' -Name 'EnableClipboardHistory' -Type DWord 0
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Svc Set-Service -Name 'cbdhsvc' -StartupType Manual

        try { $ImagePath = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\cbdhsvc','ImagePath',$null) }
        catch { $ImagePath = $null }

        if ( $ImagePath )
        {
            if ( [System.Environment]::OSVersion.Version.Build -ge 22000 )
            {
                Set-Reg New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\cbdhsvc' -Name 'UserServiceFlags' -Type DWord 2
            }
            else
            {
                Set-Reg New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\cbdhsvc' -Name 'UserServiceFlags' -Type DWord 3
            }
        }

        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' -Name 'AllowClipboardHistory'
        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' -Name 'AllowCrossDeviceClipboard'

        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Clipboard' -Name 'AllowClipboardHistory'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Clipboard' -Name 'AllowCrossDeviceClipboard'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Clipboard' -Name 'EnableClipboardHistory'
    }



    $Info = 'Отключить запуск службы "Microsoft Text Input Application"'
    $Group = 'Apps-TextInput' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Input' -Name 'InputServiceEnabled' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Input' -Name 'InputServiceEnabledForCCI' -Type DWord 0
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Input' -Name 'InputServiceEnabled' -Type DWord 1
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Input' -Name 'InputServiceEnabledForCCI' -Type DWord 1
    }



    $Info = 'Отключить "Служба пользователя платформы подключенных устройств"'
    $Group = 'Apps-CDPUserSvc' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # Служба пользователя платформы подключенных устройств. Пишет Журнал действий Timeline
        # Проблема: Если отключить службу 'CDPUserSvc*' то не войти в параметры: Учетные записи -> Синхронизация параметров (Архивация Windows в W11)
        # Нужна для: Ночной свет, Журнал действий, Виртуальные рабочие столы, Ваш телефон, Синхронизация параметров
        Set-Svc -Do:$Act Set-Service -ServiceName 'CDPUserSvc' -StartupType Disabled -Status Stopped

        Get-Service -Name 'CDPUserSvc*' -ErrorAction SilentlyContinue | ForEach-Object {
            Set-Svc -Do:$Act Set-Service -ServiceName $_.Name -StartupType Disabled -Status Stopped
        }

        [array] $Paths = "$env:USERPROFILE\AppData\Local\ConnectedDevicesPlatform"

        if ( $Global:DataLocalUsers.Redirects.Value )
        {
            @($Global:DataLocalUsers.Where({ $_.Use -and $_.ProfileType -eq 'User' -and $_.Profile })).ForEach({
            
                $Paths += "$($_.Profile)\AppData\Local\ConnectedDevicesPlatform"
            })
        }

        [int] $Num = 1
        
        # Удаляем кэш действий после остановки службы CDPUserSvc*. Кэш пересоздаётся службой после ее включения. Кроме файла сертификатов .sst
        (Get-ChildItem -LiteralPath $Paths -Force -ErrorAction SilentlyContinue).FullName.Where({ $_ -notlike '*.sst' }).ForEach({
            if ( $Num -eq 1 ) { Write-Host } ; $Num++
            try
            {
                $text = if ( $L.s2 ) { $L.s2 } else { "Удаление Timeline Кэша" }
                Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline
                        
                if ( $Act -eq 'Set' )
                {
                    Write-Host "$_" -ForegroundColor DarkGray

                    Remove-Item -LiteralPath $_ -Recurse -Force -ErrorAction SilentlyContinue
                }
                else
                {
                    Write-Host "$_" -ForegroundColor DarkYellow
                    $NeedFix = $true
                }
            }
            catch {}
        })

        "Скрытие окна параметров из настроек: Параметры -> Учетные записи -> Синхронизация параметров" | Show-Info -Shift $L.s3 
        "Скрытие окна параметров из настроек: Параметры -> Конфиденциальность -> Журнал действий"      | Show-Info -Shift $L.s4 -NotIndent

        Set-SettingsPageVisibility -Act:$Act -Names 'sync','privacy-activityhistory'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Svc Set-Service -Name 'CDPUserSvc' -StartupType Automatic

        try { $ImagePath = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\CDPUserSvc','ImagePath',$null) }
        catch { $ImagePath = $null }

        if ( $ImagePath )
        {
            Set-Reg New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\CDPUserSvc' -Name 'UserServiceFlags' -Type DWord 3
        }

        Set-SettingsPageVisibility -Names 'sync','privacy-activityhistory' -Remove
    }



    $Info = 'Отключить "Служба платформы подключенных устройств"'
    $Group = 'Apps-CDPSvc' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Svc -Do:$Act Set-Service -Name 'CDPSvc' -StartupType Disabled
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Svc Set-Service -Name 'CDPSvc' -StartupType DelayedAuto
    }



    $Info = 'Отключить службу "Посредник подключений к сети"'
    $Group = 'Apps-NcbService' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # Проблема: Служба 'NcbService' нужна для возможности подключения блютуз устройств!
        # "Посредник подключений к сети", Подключения к посредникам, позволяющие приложениям Магазина Windows получать уведомления из Интернета.
        Set-Svc -Do:$Act Set-Service -Name 'NcbService' -StartupType Disabled     # Нужна для Bluetooth устройств
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Svc Set-Service -Name 'NcbService' -StartupType Manual
    }



    $Info = 'Отключить Журнал действий Timeline'
    $Group = 'Apps-Timeline' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # Комп\Адм. Шабл\Система\Политики ОС
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' -Name 'EnableActivityFeed' -Type DWord 0
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' -Name 'UploadUserActivities' -Type DWord 0
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' -Name 'PublishUserActivities' -Type DWord 0

        if ( $Act -eq 'Set' )
        {
            [array] $Paths = "$env:USERPROFILE\AppData\Local\ConnectedDevicesPlatform"

            if ( $Global:DataLocalUsers.Redirects.Value )
            {
                @($Global:DataLocalUsers.Where({ $_.Use -and $_.ProfileType -eq 'User' -and $_.Profile })).ForEach({
            
                    $Paths += "$($_.Profile)\AppData\Local\ConnectedDevicesPlatform"
                })
            }

            [int] $Num = 1
        
            [array] $CDPUserSvces = Get-Service -Name 'CDPUserSvc*','CDPUserSvc' -ErrorAction SilentlyContinue

            # Удаляем кэш действий после остановки службы CDPUserSvc*. Кэш пересоздаётся службой после ее включения. Кроме файла сертификатов .sst
            (Get-ChildItem -LiteralPath $Paths -Force -ErrorAction SilentlyContinue).FullName.Where({ $_ -notlike '*.sst' }).ForEach({
                if ( $Num -eq 1 )
                {
                    Write-Host
                    try { $CDPUserSvces | Stop-Service -Force -ErrorAction SilentlyContinue } catch {}
                } 
            
                $Num++
                
                try
                {
                    $text = if ( $L.s2 ) { $L.s2 } else { "Удаление Timeline Кэша" }
                    Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline

                    Write-Host "$_" -ForegroundColor DarkGray

                    Remove-Item -LiteralPath $_ -Recurse -Force -ErrorAction SilentlyContinue
                }
                catch {}
            })

            try { $CDPUserSvces.Where({ $_.StartType -ne 'Disabled' }) | Start-Service -ErrorAction SilentlyContinue } catch {} 
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' -Name 'EnableActivityFeed'
        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' -Name 'UploadUserActivities'
        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' -Name 'PublishUserActivities'
    }



    $Info = 'Отключить Задачи Обновления Store Apps'
    $Group = 'Apps-Tasks-Update' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # Задачи обновления UWP Apps Store  (Перенести в AppSync)  # UWP Apps Store updates 
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\InstallService\ScanForUpdates'
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\InstallService\ScanForUpdatesAsUser'
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\InstallService\SmartRetry'
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\InstallService\WakeUpAndContinueUpdates'
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\InstallService\WakeUpAndScanForUpdates'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\InstallService\ScanForUpdates'
        Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\InstallService\ScanForUpdatesAsUser'
        Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\InstallService\SmartRetry'
        Set-Tsk Disable-ScheduledTask -TaskName '\Microsoft\Windows\InstallService\WakeUpAndContinueUpdates'
        Set-Tsk Disable-ScheduledTask -TaskName '\Microsoft\Windows\InstallService\WakeUpAndScanForUpdates'
    }



    $Info = 'Отключить Задачу "CloudExperienceHost"'
    $Group = 'Apps-Task1' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # Проблема: задача "CreateObjectTask" нужна для создания локальной учетки на этапе установки ОС
        # Так же для создания учетки в рабочей ОС, но только через сам модерн аплет настроек. На другие способы не влияет.
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\CloudExperienceHost\CreateObjectTask'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\CloudExperienceHost\CreateObjectTask'
    }



    $Info = 'Отключить Задачу "Проверка и обновление Карт AppStore"'
    $Group = 'Apps-Task2' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Maps\MapsToastTask'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Maps\MapsToastTask'
    }



    $Info = 'Отключить Задачу "Проверка и обновление Карт AppStore"'
    $Group = 'Apps-Task3' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Maps\MapsUpdateTask'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Tsk Disable-ScheduledTask -TaskName '\Microsoft\Windows\Maps\MapsUpdateTask'
    }



    $Info = 'Отключить службу "Диспетчер скачанных карт"'
    $Group = 'Apps-MapsBroker' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Svc -Do:$Act Set-Service -Name 'MapsBroker' -StartupType Disabled
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Svc Set-Service -Name 'MapsBroker' -StartupType DelayedAuto
    }



    $Info = 'Отключить Автоскачивание данных карт и незапрошенный трафик'
    $Group = 'Apps-AutoUpdateMapData' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # Комп\Адм. Шабл\Компоненты Windows\Карты "Выключить автоматическое скачивание и обновление данных карт" (включить)
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Maps' -Name 'AutoDownloadAndUpdateMapData' -Type DWord 0
        # Комп\Адм. Шабл\Компоненты Windows\Карты "Отключить незапрошенный сетевой трафик на странице параметров 'Автономные карты'" (включить)
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Maps' -Name 'AllowUntriggeredNetworkTrafficOnSettingsPage' -Type DWord 0
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Maps' -Name 'AutoDownloadAndUpdateMapData'
        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Maps' -Name 'AllowUntriggeredNetworkTrafficOnSettingsPage'
    }



    $Info = 'Отключить Windows Hello и Биометрию'
    $Group = 'Apps-FingerPrint' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        "Биометрическая служба Windows:" | Show-Info -Shift $L.s2 -NotIndent
        Set-Svc -Do:$Act Set-Service -Name 'WbioSrvc' -StartupType Disabled

        # 19041 (2004); 18363 (1909); 18362 (1903)  Настройка только для версии Windows 10 от 1903
        if ( [System.Environment]::OSVersion.Version.Build -ge 18362 )
        {
            "Служба Диспетчер регистрации учетных данных:" | Show-Info -Shift $L.s3
            Set-Svc -Do:$Act Set-Service -Name 'CredentialEnrollmentManagerUserSvc' -StartupType Disabled

            # Скрытие окна параметров из настроек: Учетные записи -> Варианты входа (Параметры входа)
            Set-SettingsPageVisibility -Act $Act -Names 'signinoptions'
        }

        "Использование биометрии:" | Show-Info -Shift $L.s4
        # Комп\Адм. Шабл\Компоненты Windows\Биометрия "Разрешение использования биометрии" (отключить)
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Biometrics' -Name 'Enabled' -Type DWord 0

        "Windows Hellow для бизнеса и Использование биометрии:" | Show-Info -Shift $L.s5
        # Комп\Адм. Шабл\Компоненты Windows\Windows Hello для бизнеса "Использовать Windows Hello для бизнеса" (отключить)
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\PassportForWork' -Name 'Enabled' -Type DWord 0
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\PassportForWork' -Name 'Enabled' -Type DWord 0
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\PassportForWork' -Name 'DisablePostLogonProvisioning' -Type DWord 1
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\PassportForWork' -Name 'DisablePostLogonProvisioning' -Type DWord 1
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WinBio\Credential Provider' -Name 'Domain Accounts' -Type DWord 0
        
        # Исключение из постоянных проверок запуска Windows Hello для бизнеса и лога, если Autologger и журнал не удалены
        try { [psobject] $Enabled = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\WMI\Autologger\EventLog-Application\{23b8d46b-67dd-40a3-b636-d43e50552c6d}','Enabled',$null) } catch {}
        
        if ( $null -ne $Enabled )
        {
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\EventLog-Application\{23b8d46b-67dd-40a3-b636-d43e50552c6d}' -Name 'Enabled' -Type DWord 0
        }
        
        try { [psobject] $Enabled = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-HelloForBusiness/Operational','Enabled',$null) } catch {}
        
        if ( $null -ne $Enabled )
        {
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-HelloForBusiness/Operational' -Name 'Enabled' -Type DWord 0
        }

        # Отключить Задачу "Очистка биометрических данных Windows Hello"
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\HelloFace\FODCleanupTask'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Svc Set-Service -Name 'WbioSrvc' -StartupType Manual
        Set-Svc Set-Service -Name 'CredentialEnrollmentManagerUserSvc' -StartupType Manual

        Set-Reg Remove-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\CredentialEnrollmentManagerUserSvc' -Name 'UserServiceFlags'

        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Biometrics' -Name 'Enabled'
        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\PassportForWork' -Name 'Enabled'
        Set-LGP Remove-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\PassportForWork' -Name 'Enabled'
        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\PassportForWork' -Name 'DisablePostLogonProvisioning'
        Set-LGP Remove-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\PassportForWork' -Name 'DisablePostLogonProvisioning'
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WinBio\Credential Provider' -Name 'Domain Accounts'
        Set-Reg New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\EventLog-Application\{23b8d46b-67dd-40a3-b636-d43e50552c6d}' -Name 'Enabled' -Type DWord 1
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-HelloForBusiness/Operational' -Name 'Enabled' -Type DWord 1

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\HelloFace\FODCleanupTask'

        # Возврат окна параметров в настройки: Учетные записи -> Варианты входа (Параметры входа)
        Set-SettingsPageVisibility -Names 'signinoptions' -Remove
    }



    $Info = "Отклонить предложение Windows Defender в 'Безопасность Windows' о входе в аккаунт Microsoft"
    $Group = 'Apps-DefenderMSAccount' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows Security Health\State' -Name 'AccountProtection_MicrosoftAccount_Disconnected' -Type DWord 1
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows Security Health\State' -Name 'AccountProtection_MicrosoftAccount_Disconnected'
    }



    $Info = "Отклонить предложение Microsoft Defender в 'Безопасность Windows' включить SmartScreen для Microsoft Edge"
    $Group = 'Apps-DefenderSmartScreen' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows Security Health\State' -Name 'AppAndBrowser_EdgeSmartScreenOff' -Type DWord 0
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows Security Health\State' -Name 'AppAndBrowser_EdgeSmartScreenOff'
    }



    $Info = 'Отключить отображение недавно добавленных приложений в меню Пуск'
    $Group = 'Apps-RecentlyAddedApps' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer' -Name 'HideRecentlyAddedApps' -Type DWord 1
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer' -Name 'HideRecentlyAddedApps'
    }



    $Info = 'Отключить Синхронизацию персональных настроек программ и Windows'
    $Group = 'Apps-PersonalSync' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\SettingSync' -Name 'SyncPolicy' -Type DWord 5

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\SettingSync\Groups\Accessibility'   -Name 'Enabled' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\SettingSync\Groups\AppSync'         -Name 'Enabled' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\SettingSync\Groups\BrowserSettings' -Name 'Enabled' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\SettingSync\Groups\Credentials'     -Name 'Enabled' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\SettingSync\Groups\DesktopTheme'    -Name 'Enabled' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\SettingSync\Groups\Language'        -Name 'Enabled' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\SettingSync\Groups\PackageState'    -Name 'Enabled' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\SettingSync\Groups\Personalization' -Name 'Enabled' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\SettingSync\Groups\StartLayout'     -Name 'Enabled' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\SettingSync\Groups\Windows'         -Name 'Enabled' -Type DWord 0
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\SettingSync' -Name 'SyncPolicy'

        Set-Reg New-ItemProperty    -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\SettingSync\Groups\Accessibility'   -Name 'Enabled' -Type DWord 1
        Set-Reg New-ItemProperty    -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\SettingSync\Groups\AppSync'         -Name 'Enabled' -Type DWord 1
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\SettingSync\Groups\BrowserSettings' -Name 'Enabled'
        Set-Reg New-ItemProperty    -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\SettingSync\Groups\Credentials'     -Name 'Enabled' -Type DWord 1
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\SettingSync\Groups\DesktopTheme'    -Name 'Enabled'
        Set-Reg New-ItemProperty    -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\SettingSync\Groups\Language'        -Name 'Enabled' -Type DWord 1
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\SettingSync\Groups\PackageState'    -Name 'Enabled'
        Set-Reg New-ItemProperty    -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\SettingSync\Groups\Personalization' -Name 'Enabled' -Type DWord 1
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\SettingSync\Groups\StartLayout'     -Name 'Enabled'
        Set-Reg New-ItemProperty    -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\SettingSync\Groups\Windows'         -Name 'Enabled' -Type DWord 1
    }



    $Info = 'Отключить Content Delivery Manager | Windows spotlight on lock screen'
    $Group = 'Apps-ContentDelivery' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # Проблема: Если отключить облоко 'DisableWindowsConsumerFeatures', то не связать устройство с телефоном: Параметры -> Телефон

        # Комп\Адм. Шабл\Компоненты Windows\Содержимое облака "Выключить возможности потребителя Майкрософт"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent' -Name 'DisableWindowsConsumerFeatures' -Type DWord 1

        # Комп\Адм. Шабл\Компоненты Windows\Содержимое облака "Не показывать советы по использованию Windows"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent' -Name 'DisableSoftLanding' -Type DWord 1


        "Отключить все функции SpotLight на экране блокировки и не устанавливать Appx:" | Show-Info -Shift $L.s2
        # ГП: Компоненты Windows/Содержимое облака
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Windows\CloudContent' -Name 'DisableWindowsSpotlightFeatures' -Type DWord 1

        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Windows\CloudContent' -Name 'DisableTailoredExperiencesWithDiagnosticData' -Type DWord 1
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Windows\CloudContent' -Name 'DisableThirdPartySuggestions' -Type DWord 1
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Windows\CloudContent' -Name 'ConfigureWindowsSpotlight' -Type DWord 2
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Windows\CloudContent' -Name 'IncludeEnterpriseSpotlight' -Type DWord 0
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Windows\CloudContent' -Name 'DisableWindowsSpotlightOnSettings' -Type DWord 1
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Windows\CloudContent' -Name 'DisableWindowsSpotlightOnActionCenter' -Type DWord 1
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Windows\CloudContent' -Name 'DisableWindowsSpotlightWindowsWelcomeExperience' -Type DWord 1

        # 19041 (2004); 18363 (1909); 18362 (1903)  Настройка только для версии Windows 10 от 2004
        if ( [System.Environment]::OSVersion.Version.Build -ge 19041 )
        {
            # disable "Get even more out of Windows" Предложения по Эффективному использованию Windows: Настройки -> Система -> Уведомления и действия
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\UserProfileEngagement' -Name 'ScoobeSystemSettingEnabled' -Type DWord 0
        }

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Messaging' -Name 'CloudServiceSyncEnabled' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Messaging' -Name 'CloudServiceSyncEnabled' -Type DWord 0

        # Скрытие из-за 'DisableWindowsConsumerFeatures'
        "Скрытие окна параметров из настроек: Параметры -> Телефон" | Show-Info -Shift $L.s3

        Set-SettingsPageVisibility -Act:$Act -Names 'mobile-devices', 'mobile-devices-addphone'

        "Остальные параметры для Content Delivery Manager:" | Show-Info -Shift $L.s4

        # откл показ рекомендуемых приложений в Пуск
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'SystemPaneSuggestionsEnabled' -Type DWord 0

        # MS shoehorning apps quietly into your profile
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'ContentDeliveryAllowed' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'FeatureManagementEnabled' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'NoTileApplicationNotification' -Type DWord 1

        # Automatically Installing Suggested Apps in Windows 10 Store Apps
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'SilentInstalledAppsEnabled' -Type DWord 0
        # Preinstalled Apps in Windows 10
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'PreInstalledAppsEnabled' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'PreInstalledAppsEverEnabled' -Type DWord 0
        # OEM Preinstalled Apps
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'OemPreInstalledAppsEnabled' -Type DWord 0
        # Subsribed Content status Suggested Apps
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'SubscribedContentEnabled' -Type DWord 0

        # Lockscreen suggestions, rotating pictures, Tips, tricks and suggestions while using Windows
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'SoftLandingEnabled' -Type DWord 0
        # Windows Spotlight
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'RotatingLockScreenEnabled' -Type DWord 0
        # Get fun facts, tips, tricks, and moe on your lock screen
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'RotatingLockScreenOverlayEnabled' -Type DWord 0

        # Windows Spotlight
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'SubscribedContent-202914Enabled' -Type DWord 0

        # SyncProviders - OneDrive
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'SubscribedContent-280810Enabled' -Type DWord 0
        # OneDrive
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'SubscribedContent-280811Enabled' -Type DWord 0
        # Windows Ink - StokedOnIt
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'SubscribedContent-280813Enabled' -Type DWord 0
        # Share - Facebook, Instagram and etc.
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'SubscribedContent-280815Enabled' -Type DWord 0


        # Show me the Windows welcome experience after updates and occasionally when I sign in to highlight what's new and suggested
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'SubscribedContent-310093Enabled' -Type DWord 0

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'SubscribedContent-310091Enabled' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'SubscribedContent-310092Enabled' -Type DWord 0

        # BingWeather, Candy Crush and etc.
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'SubscribedContent-314559Enabled' -Type DWord 0
        # My People Suggested Apps
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'SubscribedContent-314563Enabled' -Type DWord 0

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'SubscribedContent-338380Enabled' -Type DWord 0
        # Windows Maps
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'SubscribedContent-338381Enabled' -Type DWord 0
        # Lock screen Spotlight - New backgrounds, tips, advertisements etc.
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'SubscribedContent-338387Enabled' -Type DWord 0

        # Не показывать рекомендации в меню Пуск
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'SubscribedContent-338388Enabled' -Type DWord 0

        # Get tips, tricks and suggestion as you use Windows and Cortana
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'SubscribedContent-338389Enabled' -Type DWord 0

        # Show me suggested content in the Settings app
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'SubscribedContent-338393Enabled' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'SubscribedContent-353694Enabled' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'SubscribedContent-353696Enabled' -Type DWord 0

        # Multitasking - Show suggestions in timeline
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'SubscribedContent-353698Enabled' -Type DWord 0

        # Отключить все зарегистрированные подписки из CreativeEvents, которые еще не отключены
        try
        {
            $SubKey = 'Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager\CreativeEvents'
            $OpenKey = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($SubKey,'ReadSubTree','QueryValues,EnumerateSubKeys')
            [string[]] $KeyNames = $null
            if ( $OpenKey )
            {
                $KeyNames = ( $OpenKey.GetSubKeyNames() -like 'SubscribedContent-*' )
                $KeyNames = $KeyNames.ForEach({"$_`Enabled"})
                $OpenKey.Close()
            }

            $Path = "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"
            $OpenKey = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey(($Path.Replace('HKCU:\','')),'ReadSubTree','QueryValues')
            if ( $OpenKey )
            {
                foreach ( $Name in $KeyNames )
                {
                    if ( -not ( $OpenKey.GetValueNames() -like $Name ))
                    {
                        Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name $Name -Type DWord 0
                    }
                }

                $OpenKey.Close()
            }
        }
        catch {}
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent' -Name 'DisableWindowsConsumerFeatures'
        Set-LGP Remove-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Windows\CloudContent' -Name 'DisableWindowsConsumerFeatures'

        Set-LGP Remove-Item -Path 'HKCU:\Software\Policies\Microsoft\Windows\CloudContent'

        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\UserProfileEngagement' -Name 'ScoobeSystemSettingEnabled'

        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Messaging' -Name 'CloudServiceSyncEnabled'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Messaging' -Name 'CloudServiceSyncEnabled'

        Set-SettingsPageVisibility -Names 'mobile-devices' -Remove

        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'SystemPaneSuggestionsEnabled' -Type DWord 1

        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'ContentDeliveryAllowed' -Type DWord 0
        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'FeatureManagementEnabled' -Type DWord 0
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'NoTileApplicationNotification'

        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'SilentInstalledAppsEnabled' -Type DWord 1
        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'PreInstalledAppsEnabled' -Type DWord 1
        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'PreInstalledAppsEverEnabled' -Type DWord 1
        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'OemPreInstalledAppsEnabled' -Type DWord 1

        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'SubscribedContentEnabled'

        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'SoftLandingEnabled' -Type DWord 1
        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'RotatingLockScreenEnabled' -Type DWord 1
        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'RotatingLockScreenOverlayEnabled' -Type DWord 1

        # Удалить все индивидуальные отключения подписок
        try
        {
            $SubKey = 'Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager'
            $OpenKey = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($SubKey,'ReadSubTree','QueryValues,EnumerateSubKeys')
            if ( $OpenKey )
            {
                foreach ( $Name in $OpenKey.GetValueNames() )
                {
                    if ( $Name -like 'SubscribedContent-*Enabled' )
                    {
                        Set-Reg Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" -Name $Name
                    }
                }

                $OpenKey.Close()
            }
        }
        catch {}
    }



    $Info = 'Отключить Рекламные картинки и ссылки на Экране Блокировки'
    $Group = 'Apps-LockScreen' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Lock Screen\FeedManager' -Name '' -Type String ''
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Lock Screen\Creative' -Name 'LockImageFlags' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Lock Screen\Creative' -Name 'CreativeId' -Type String ''
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Lock Screen\Creative' -Name 'PortraitAssetPath' -Type String ''
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Lock Screen\Creative' -Name 'LandscapeAssetPath' -Type String ''
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Lock Screen\Creative' -Name 'PlacementId' -Type String ''
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Lock Screen\Creative' -Name 'ImpressionToken' -Type String ''
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Lock Screen\Creative' -Name 'HotspotImageFolderPath' -Type String ''
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Lock Screen\Creative' -Name 'CreativeJson' -Type String ''
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Lock Screen\FeedManager' -Name '' -Type String '{FE6B11C3-C72E-4061-86C6-9D163121F229}'
        Set-Reg Remove-Item -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Lock Screen\Creative'
    }


    $Info = 'Отключить Определение расположения'
    $Group = 'Apps-LocationAndSensors' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # Комп\Адм. Шабл\Компоненты Windows\Расположение и датчики "Отключить расположение"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\LocationAndSensors' -Name 'DisableLocation' -Type DWord 1

        # Комп\Адм. Шабл\Компоненты Windows\Расположение и датчики "Отключить расположение со сценариями"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\LocationAndSensors' -Name 'DisableLocationScripting' -Type DWord 1

        # Комп\Адм. Шабл\Компоненты Windows\Расположение и датчики "Отключить датчики"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\LocationAndSensors' -Name 'DisableSensors' -Type DWord 1

        # Комп\Адм. Шабл\Компоненты Windows\Расположения и датчики\Определитель метосположения Windows\ "Отключить Определитель метосположения"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\LocationAndSensors' -Name 'DisableWindowsLocationProvider' -Type DWord -Value 1
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\LocationAndSensors' -Name 'DisableLocation'
        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\LocationAndSensors' -Name 'DisableLocationScripting'
        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\LocationAndSensors' -Name 'DisableSensors'
        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\LocationAndSensors' -Name 'DisableWindowsLocationProvider'
    }



    $Info = 'Отключить Службы датчиков для планшетов'
    $Group = 'Apps-Tablet-Services' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        "Служба наблюдения за датчиками, яркости дисплея, поворота экрана и т.д.:" | Show-Info -Shift $L.s2 -NotIndent
        Set-Svc -Do:$Act Set-Service -Name 'SensrSvc' -StartupType Disabled

        "Служба датчиков, датчики поворота дисплея, местоположения и т.д.:" | Show-Info -Shift $L.s3
        Set-Svc -Do:$Act Set-Service -Name 'SensorService' -StartupType Disabled

        "Служба данных датчиков:" | Show-Info -Shift $L.s4
        Set-Svc -Do:$Act Set-Service -Name 'SensorDataService' -StartupType Disabled
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Svc Set-Service -Name 'SensrSvc' -StartupType Manual
        Set-Svc Set-Service -Name 'SensorService' -StartupType Manual
        Set-Svc Set-Service -Name 'SensorDataService' -StartupType Manual
    }



    $Info = 'Запретить работу в Фоне для всех Apps'
    $Group = 'Apps-BackgroundAccessAll' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications' -Name 'GlobalUserDisabled' -Type DWord 1
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' -Name 'BackgroundAppGlobalToggle' -Type DWord 0
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications' -Name 'GlobalUserDisabled' -Type DWord 0
        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' -Name 'BackgroundAppGlobalToggle' -Type DWord 1
    }



    $Info = 'Запретить работу в Фоне для Apps (Кроме исключений)'
    $Group = 'Apps-BackgroundAccess' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications' -Name 'GlobalUserDisabled' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' -Name 'BackgroundAppGlobalToggle' -Type DWord 1

        [array] $ExcludedBackgroundApps = @()

        $ListPresets.Where({

            if ( $_ -match '^\s*DoNot-Disable-BG-Access\s*=\s*[*]\s*=(?<AppName>[^\r\n\t\x02\x1c\x1d\x1e\x1f<>|:?*``""=#\\\/]+)=' )
            {
                $ExcludedBackgroundApps += $Matches.AppName.Trim()
            }
        })

        try
        {
            [string] $RegKey = 'Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications'
             [array] $Roots  = 'HKCU:'

            if ( $Global:DataLocalUsers.Redirects.Value )
            {
                @($Global:DataLocalUsers.Where({ $_.Use -and $_.SID -and $_.NTUSER_Load })).ForEach({ $Roots += $_.SID })
            }

            foreach ( $Key in $Roots )
            {
                if ( $Key -eq 'HKCU:' )
                {
                    $OpenRegKey = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($RegKey, 'ReadSubTree','QueryValues,EnumerateSubKeys')
                    $isRoot     = $Key
                }
                else
                {
                    $OpenRegKey = [Microsoft.Win32.Registry]::Users.OpenSubKey("$Key\$RegKey",'ReadSubTree','QueryValues,EnumerateSubKeys')
                    $isRoot     = "Registry::HKU\$Key"
                }

                if ( $OpenRegKey )
                {
                    foreach ( $SubKey in $OpenRegKey.GetSubKeyNames() )
                    {
                        $Path = "$isRoot\$RegKey\$SubKey"

                        if ( $SubKey -notmatch "^$($ExcludedBackgroundApps.ForEach({[regex]::Escape($_)}) -join '|^')" )
                        {
                            Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'Disabled' -Type DWord 1 -OnlyThisPath
                            Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'DisabledByUser' -Type DWord 1 -OnlyThisPath
                        }
                        else
                        {
                            if ( $Act -eq 'Set' )
                            {
                                Set-Reg -Do:$Act Remove-ItemProperty -Path $Path -Name 'Disabled' -OnlyThisPath
                                Set-Reg -Do:$Act Remove-ItemProperty -Path $Path -Name 'DisabledByUser' -OnlyThisPath
                            }
                        }
                    }

                    $OpenRegKey.Close()
                }
            }
        }
        catch {}
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications' -Name 'GlobalUserDisabled' -Type DWord 0
        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' -Name 'BackgroundAppGlobalToggle' -Type DWord 1

        try
        {
            [string] $RegKey = 'Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications'
             [array] $Roots  = 'HKCU:'
            
            if ( $Global:DataLocalUsers.Redirects.Value )
            {
                @($Global:DataLocalUsers.Where({ $_.Use -and $_.SID -and $_.NTUSER_Load })).ForEach({ $Roots += $_.SID })
            }

            foreach ( $Key in $Roots )
            {
                if ( $Key -eq 'HKCU:' )
                {
                    $OpenRegKey = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($RegKey, 'ReadSubTree','QueryValues,EnumerateSubKeys')
                    $isRoot     = $Key
                }
                else
                {
                    $OpenRegKey = [Microsoft.Win32.Registry]::Users.OpenSubKey("$Key\$RegKey",'ReadSubTree','QueryValues,EnumerateSubKeys')
                    $isRoot     = "Registry::HKU\$Key"
                }

                if ( $OpenRegKey )
                {
                    foreach ( $SubKey in $OpenRegKey.GetSubKeyNames() )
                    {
                        $Path = "$isRoot\$RegKey\$SubKey"

                        Set-Reg Remove-ItemProperty -Path $Path -Name 'Disabled' -OnlyThisPath
                        Set-Reg Remove-ItemProperty -Path $Path -Name 'DisabledByUser' -OnlyThisPath
                    }

                    $OpenRegKey.Close()
                }
            }
        }
        catch {}
    }



    # Конец настроек  #####################

    if ( $ApplyGP )
    {
        # Получение перевода
        $L = $Lang.$InfoThisFunction

        # Если есть подготовленные параметры Групповых политик для LGPO.exe в глобальной переменной $Global:SettingsGP, то выполнится применение ГП.
        Set-LGP -ApplyGP

        $text = if ( $L.s1 ) { $L.s1 } else { "Необходимо перезагрузиться!" }

        Write-Host "`n   ••••• $text •••••" -ForegroundColor Yellow

        Get-Pause
    }
}
