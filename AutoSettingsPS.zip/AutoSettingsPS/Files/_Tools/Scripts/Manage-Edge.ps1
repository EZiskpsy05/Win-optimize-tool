﻿
<#
.SYNOPSIS
 Установка или Полное удаление Edge и Edge WebView2

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS

 Используется функция Set-Reg для установки/удаления параметров реестра, с проверкой и выводом результата.
 Используется функция Set-Tsk для настройки/удаления задач, с проверкой и выводом результата.
 Используется функция Get-Task-FullPaths для получения полных путей ко всем задачам, по совпадениям с указанным именем
 Используется функция Test-Internet для проверки состояния интернета и доступа для скрипта (консоли PS) в интернет

 .EXAMPLE
    Manage-Edge -Remove -Act Check 
    Manage-Edge -Remove -Act Check -Componetns Edge
    Manage-Edge -Remove -Act Check -Componetns EdgeWebView
    Manage-Edge -Remove -Act Check -Componetns Edge,EdgeWebView

    Manage-Edge -Remove -Act Set -Componetns EdgeWebView
    Manage-Edge -Remove -Act Set -Componetns Edge

    Manage-Edge -Install -Act Check -Componetns Edge

    Manage-Edge -Install -Act Set -Componetns Edge
    Manage-Edge -Install -Act Set -Componetns EdgeWebView
    Manage-Edge -Install -Act Set -Componetns Edge,EdgeWebView


.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  27-08-2021
 ===============================================

#>
Function Manage-Edge {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param (
        [Parameter( Mandatory = $false, Position = 0 )]
        [ValidateSet( 'Set', 'Check', 'Default' )]
        [string] $Act = 'Set'
       ,
        [Parameter( Mandatory = $true,  ParameterSetName = 'Install' )]
        [switch] $Install
       ,
        [Parameter( Mandatory = $true,  ParameterSetName = 'Remove'  )]
        [switch] $Remove
       ,
        [Parameter( Mandatory = $false )]
        [ValidateSet( 'Edge', 'EdgeWebView' )]
        [string[]] $Componetns = 'Edge'
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    if ( $Act -eq 'Default' ) { $Act = 'Set' }
    if ( $Act -eq 'Check' ) { $Color = 'Yellow' } else { $Color = 'Cyan' }

    # Функция для закачки файлов через System.Net.Http.HttpClient, с показом прогресса, скачивает быстро файлы.
    Function Download-File ( [string] $FileUrl, [string] $DestFile ) {

        if ( -not ( $FileUrl -and $DestFile ))
        {
            $text = if ( $L.s1 ) { $L.s1 } else { "Не указаны параметры" }
            Write-Host "   Download-File: $text`: FileUrl: '$FileUrl', DestFile: '$DestFile'" -ForegroundColor DarkYellow
            Return
        }

        # Подгрузка класса
        if ( -not ( 'System.Net.Http' -as [type] )) { Add-Type -AssemblyName 'System.Net.Http' -ErrorAction Stop }

        [int] $try = 0

        # 2 попытки начать загружать файл, если первая не получила размер данных
        do 
        {
            if ( $try -eq 1 )
            {
                Start-Sleep -Milliseconds 300
                if ( $Response.Result.Content ) { $Response.Result.Content.Dispose() }
                if ( $Response ) { $Response.Dispose() }
                if ( $httpClient ) { $httpClient.Dispose() }
            }
        
            $httpClient = New-Object System.Net.Http.HttpClient
            $httpClient.Timeout = [timespan]::FromSeconds(20) # Максимальное Время задержки ответа (деф 100 сек)
            $Response = $httpClient.GetAsync($FileUrl,'ResponseHeadersRead')  # Начать соединение с сервером и загрузку данных в буфер

            # Пока нет ответа сервера положительного или отрицательного, предел указывается в $httpClient.Timeout
            while ( -not $Response.IsCompleted ) { Start-Sleep -Milliseconds 50 }

            $try++
        } 
        until ( $try -eq 2 -or $Response.Result.Content.Headers.ContentLength )

        [string] $DestFileName = $([System.IO.Path]::GetFileName($DestFile))

        # Если ошибка получения ответа от сервера или вышло время, выйти из функции
        if ( $Response.IsFaulted -or ( -not $Response.Result.IsSuccessStatusCode ) )
        {
            if ( $Response.Result.Content ) { $Response.Result.Content.Dispose() }
            if ( $Response ) { $Response.Dispose() }
            if ( $httpClient ) { $httpClient.Dispose() }

            $text = if ( $L.s2 ) { $L.s2 } else { "Ошибка сервера" }
            Write-Warning "Download-File: $text $DestFileName `n$FileUrl"
        
            Return
        }
        elseif ( -not $Response.Result.Content.Headers.ContentLength )
        {
            if ( $Response.Result.Content ) { $Response.Result.Content.Dispose() }
            if ( $Response ) { $Response.Dispose() }
            if ( $httpClient ) { $httpClient.Dispose() }

            $text = if ( $L.s3 ) { $L.s3 } else { "Размер файла с сервера не получен" }
            Write-Warning "Download-File: $text $DestFileName `n$FileUrl"
        
            Return
        }

        # Создать файловый стрим для записи файла
        try { $OutputFileStream = [System.IO.FileStream]::new($DestFile, [System.IO.FileMode]::Create, [System.IO.FileAccess]::Write) }
        catch
        {
            $text = if ( $L.s4 ) { $L.s4 } else { "Ошибка записи файла" }
            Write-Warning "Download-File: $text $DestFileName`n$($_.CategoryInfo.Category): $($_.Exception.Message)"
            
            Return
        }
        
        # Начать записывать файл на диск из буфера
        $WriteFile = $Response.Result.Content.CopyToAsync($OutputFileStream)

         [int64] $TotalBytes = $Response.Result.Content.Headers.ContentLength
        [string] $FileSize   = ''

        if     ( $TotalBytes -gt 1gb ) { $FileSize = '{0} Gb' -f ( $TotalBytes / 1gb ).ToString('N1') }
        elseif ( $TotalBytes -gt 1mb ) { $FileSize = '{0} Mb' -f ( $TotalBytes / 1mb ).ToString('N1') }
        elseif ( $TotalBytes -gt 0   ) { $FileSize = '{0} Kb' -f ( $TotalBytes / 1kb ).ToString('N1') }
    
        [bool] $isDownloaded  = $false
        [bool] $isDownloading = $true
    
        [int64] $PreviousBytes = 0
          [int] $wait = 0
          [int] $Percent = 0

        # Пока не загружен или пока загружается файл
        while ( -Not $isDownloaded -and $isDownloading )
        {
            # для снятия нагрузки от частоты обработки и вывода прогресса.
            Start-Sleep -Milliseconds 100

            # Получить текущие записанные байты
            [int64] $WritedBytes = $OutputFileStream.Length
        
            # Если есть записанные байты, получить текущий процент записи, округляя всегда в меньшую сторону, 
            # грубо убирая знаки после запятой, чтобы показывало 100% только когда реально 100%
            $Percent = [System.Math]::Truncate(100*($WritedBytes/$TotalBytes))
        
            Write-Progress -Activity "Downloading: $DestFileName" -Status "$Percent % | bytes: $WritedBytes / $TotalBytes | $FileSize" -Id 1

            # Если все байты записаны, выйти из while
            if ( $WritedBytes -eq $TotalBytes ) { $isDownloaded = $true }
        
            # Если нет изменений в записанных байтах, увеличить счетчик ожидания, если есть изменение, то обнулить его.
            if ( $PreviousBytes -eq $WritedBytes ) { $wait++ } else { $wait = 0 }
            $PreviousBytes = $WritedBytes

            # Если счетчик ожидания накопился до 60 (примерно 10 сек, с учетом всех задержек), загрузка остановилась, выйти из while
            if ( $wait -eq 60 ) { $isDownloading = $false }
        }

        Write-Progress -Activity "Downloading: $DestFileName" -Status "$Percent % | bytes: $WritedBytes / $TotalBytes | $FileSize" -Id 1
        Start-Sleep -Milliseconds 500
        Write-Progress -Activity "Downloading: $DestFileName" -Status "$Percent % | bytes: $WritedBytes / $TotalBytes | $FileSize" -Completed -Id 1

        # "wait: $wait | PreviousBytes: $PreviousBytes | WritedBytes: $WritedBytes"

        if ( $TotalBytes -gt 0 ) { [int64] $Global:TotalBytesSize = $TotalBytes } else { [int64] $Global:TotalBytesSize = 0 }
        if ( $FileSize ) { [string] $Global:FileSizeNote = $FileSize } else { [string] $Global:FileSizeNote = '' }

        if ( -not $isDownloaded )
        {
            $text = if ( $L.s5 ) { $L.s5 } else { "Файл не загружен" }
            Write-Warning "Download-File: $text`: $DestFileName"
        }

        # Отключить httpClient
        if ( $Response.Result.Content ) { $Response.Result.Content.Dispose() }
        if ( $Response ) { $Response.Dispose() }
        if ( $httpClient ) { $httpClient.Dispose() }
        # Закрытие файлового стрима, для разблокировки файла.
        if ( $OutputFileStream ) { $OutputFileStream.Close() }
    }

    if ( $Install )
    {
        if ( $Act -eq 'Check' )
        {
            $text = if ( $L.s6 ) { $L.s6 } else { "Проверка Установки" }
            Write-Host "`n██ $text`: " -ForegroundColor Cyan -NoNewline
            Write-Host ($Componetns -join ', ') -ForegroundColor DarkCyan -NoNewline
        }
        else
        {
            $text = if ( $L.s7 ) { $L.s7 } else { "Установка" }
            Write-Host "`n██ $text`: " -ForegroundColor Magenta -NoNewline
            Write-Host ($Componetns -join ', ') -ForegroundColor DarkCyan -NoNewline
        }

        $text = if ( $L.s8 ) { $L.s8 } else { "Функция" }
        Write-Host " | $text`: $NameThisFunction`n" -ForegroundColor DarkGray


        [string[]] $RegKeys = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
                              'SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall'

        [psobject] $OpenSubKey = $null
        [array] $Installed = @()
        [array] $InstallLocations = @()

        foreach ( $RegKey in $RegKeys )
        {
            $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($RegKey,'ReadSubTree','QueryValues,EnumerateSubKeys')

            if ( $OpenSubKey )
            {
                foreach ( $SubKey in ( $OpenSubKey.GetSubKeyNames() ))
                {
                    $InstallLocation = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$RegKey\$SubKey",'InstallLocation',$null)
                    $DisplayName     = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$RegKey\$SubKey",'DisplayName',$null)

                    if (( $InstallLocation -like '*\Edge*\Application*' ) -and $DisplayName )
                    {
                        $Installed += [PSCustomObject] @{
                            DisplayName     = $DisplayName
                            InstallLocation = $InstallLocation
                        }
                    }
                }

                $OpenSubKey.Close()
            }
        }


        if ( $Componetns -like 'Edge' )
        {
            if ( $Installed.Where({ $_.InstallLocation -notlike '*WebView*' }) )
            {
                foreach ( $InstallEdge in ( $Installed.Where({ $_.InstallLocation -notlike '*WebView*' }) ))
                {
                    $text = if ( $L.s9 ) { $L.s9 } else { "Уже Установлен" }
                    Write-Host "   $text`: " -ForegroundColor DarkGreen -NoNewline
                    Write-Host "$($InstallEdge.DisplayName)" -ForegroundColor DarkCyan
                }
            }
            else
            {
                if ( [System.Environment]::Is64BitOperatingSystem )
                {
                    $Target = (Get-ChildItem -Path "$env:SystemDrive\Windows\WinSxS\wow64_microsoft-windows-e..-firsttimeinstaller_*","$env:SystemDrive\Windows\WinSxS\amd64_microsoft-windows-e..-firsttimeinstaller_*" -ErrorAction SilentlyContinue
                    ).Foreach({ Get-ChildItem -File -Path $_ -ErrorAction SilentlyContinue }).Where({$_.Name -like '*Edge*Installer*.exe'},'Last')
                }
                else
                {
                    $Target = (Get-ChildItem -Path "$env:SystemDrive\Windows\WinSxS\x86_microsoft-windows-e..-firsttimeinstaller_*" -ErrorAction SilentlyContinue
                    ).Foreach({ Get-ChildItem -File -Path $_ -ErrorAction SilentlyContinue }).Where({$_.Name -like '*Edge*Installer*.exe'},'Last')
                }

                if ( $Target.FullName )
                {
                    if ( $Act -eq 'Check' )
                    {
                        $text = if ( $L.s10 ) { $L.s10 } else { "Microsoft Edge Chromium не установлен" }
                        Write-Host "   $text" -ForegroundColor Yellow

                        $NeedFix = $true
                    }
                    else
                    {
                        $text = if ( $L.s11 ) { $L.s11 } else { "Восстановление Microsoft Edge Chromium" }
                        Write-Host "   $text " -ForegroundColor Magenta
                        Write-Host "   $($Target.FullName) " -ForegroundColor DarkGray

                        # Удаление запрета запуска всех Exe файлов установщика или Edge, если есть
                        $SubKey = 'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options'
                        $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues,EnumerateSubKeys')
                        if ( $OpenSubKey )
                        {
                            foreach ( $Name in ( $OpenSubKey.GetSubKeyNames() -like '*Edge*' ))
                            {
                                if ( [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$SubKey\$Name",'Debugger',$null) )
                                {
                                    $Path = "HKLM:\$SubKey\$Name"
                                    Set-Reg Remove-ItemProperty -Path $Path -Name 'Debugger'
                                }
                            }

                            $OpenSubkey.Close()
                        }

                        try { [System.Diagnostics.Process]::Start("$($Target.FullName)",'/installsource offline /silent /install "appguid={56EB18F8-B008-4CBD-B6D2-8C97FE7E9062}&appname=Microsoft Edge&needsadmin=true"').WaitForExit() }
                        catch { Write-Host "   Setup Error: $($Target.FullName)" -ForegroundColor Red }

                        Start-Sleep -Milliseconds 200

                        [string[]] $RegKeys = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
                                              'SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall'

                        [psobject] $OpenSubKey = $null
                        $Installed = @()
                        foreach ( $RegKey in $RegKeys )
                        {
                            $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($RegKey,'ReadSubTree','QueryValues,EnumerateSubKeys')

                            if ( $OpenSubKey )
                            {
                                foreach ( $SubKey in ( $OpenSubKey.GetSubKeyNames() ))
                                {
                                    $InstallLocation = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$RegKey\$SubKey",'InstallLocation',$null)
                                    $DisplayName     = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$RegKey\$SubKey",'DisplayName',$null)

                                    if (( $InstallLocation -like '*\Microsoft\Edge\Application*' ) -and $DisplayName )
                                    {
                                        $Installed += $DisplayName
                                    }
                                }

                                $OpenSubKey.Close()
                            }
                        }

                        if ( $Installed.Count )
                        {
                            $text = if ( $L.s12 ) { $L.s12 } else { "Установился" }
                            Write-Host "   $text`: " -ForegroundColor Green -NoNewline
                            Write-Host "$Installed" -ForegroundColor DarkCyan

                            $MSedgeExe = (Get-Item -Path "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
                            "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe" -ErrorAction SilentlyContinue).Where({$_},'First').Fullname

                            if ( $MSedgeExe )
                            {
                                if ( [System.IO.Directory]::Exists("$env:PUBLIC\Desktop") )
                                {
                                    [bool] $Exist = $false

                                    # Поиск ярлыков по названию приложения внутри ярлыка, чтобы не зависеть от названия самого ярлыка
                                    (Get-ChildItem -File -LiteralPath "$env:PUBLIC\Desktop" -ErrorAction SilentlyContinue).Where({ $_.Extension -eq '.lnk' }).Foreach({
                                        if ( (Get-Content -Encoding UTF8 "$($_.FullName)" -ErrorAction SilentlyContinue) -like "*$MSedgeExe*" ) { $Exist = $true }
                                    })

                                    if ( -not $Exist )
                                    {
                                        $text = if ( $L.s13 ) { $L.s13 } else { "Создание Ярлыка" }
                                        Write-Host "   $text`: $env:PUBLIC\Desktop\Microsoft Edge.lnk" -ForegroundColor DarkGray

                                        $WScriptShell = New-Object -ComObject WScript.Shell
                                        $Shortcut = $WScriptShell.CreateShortcut("$env:PUBLIC\Desktop\Microsoft Edge.lnk")
                                        $Shortcut.TargetPath   = "$MSedgeExe"
                                        $shortcut.IconLocation = "$MSedgeExe,0"
                                        $Shortcut.Description  = 'Microsoft Edge'
                                        $Shortcut.Save()
                                    }
                                }
                            }
                        }
                        else
                        {
                            $text = if ( $L.s14 ) { $L.s14 } else { "Не удалось установить" }
                            Write-Host "   $text " -ForegroundColor Yellow

                            $NeedFix = $true
                        }
                    }
                }
                else
                {
                    $text = if ( $L.s15 ) { $L.s15 } else { "Нет компонента Microsoft Edge Chromium в WinSxS, будет загрузка" }
                    Write-Host "   $text " -ForegroundColor DarkGray

                    if ( $Act -eq 'Set' )
                    {
                        $CurLang = [System.Globalization.CultureInfo]::CurrentUICulture.TwoLetterISOLanguageName

                        $text = if ( $L.s16 ) { $L.s16 } else { "Загрузка и установка Microsoft Edge Chromium" }
                        Write-Host "   $text" -ForegroundColor Cyan -NoNewline
                        Write-Host " | " -ForegroundColor DarkGray -NoNewline
                        Write-Host "$CurLang" -ForegroundColor DarkCyan
                        
                        if ( -not ( Test-Internet -Bool -Access ))
                        {
                            $text = if ( $L.s17 ) { $L.s17 } else { "Нет доступа в Интернет для PS" }
                            Write-Host "   $text" -ForegroundColor DarkYellow

                            $NeedFix = $true
                        }
                        else
                        {
                            [string] $TempPath = $([System.IO.Path]::GetFullPath($env:TEMP))

                            $FileExe = "$TempPath\MicrosoftEdgeSetup.exe"
                            Remove-Item -LiteralPath $FileExe -Force -ErrorAction SilentlyContinue

                            Download-File "https://go.microsoft.com/fwlink/?linkid=2108834&Channel=Stable&language=$CurLang" $FileExe
                            
                            Start-Sleep -Milliseconds 200

                            if ( [System.IO.File]::Exists($FileExe) )
                            {
                                # Удаление запрета запуска всех Exe файлов установщика или Edge, если есть
                                $SubKey = 'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options'
                                $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues,EnumerateSubKeys')
                                if ( $OpenSubKey )
                                {
                                    foreach ( $Name in ( $OpenSubKey.GetSubKeyNames() -like '*Edge*' ))
                                    {
                                        if ( [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$SubKey\$Name",'Debugger',$null) )
                                        {
                                            $Path = "HKLM:\$SubKey\$Name"
                                            Set-Reg Remove-ItemProperty -Path $Path -Name 'Debugger'
                                        }
                                    }

                                    $OpenSubkey.Close()
                                }

                                try { [System.Diagnostics.Process]::Start($FileExe,'/silent /install').WaitForExit() }
                                catch { Write-Host "   Setup Error: $FileExe" -ForegroundColor Red }

                                Start-Sleep -Milliseconds 200

                                [string[]] $RegKeys = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
                                                      'SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall'

                                [psobject] $OpenSubKey = $null
                                $Installed = @()
                                foreach ( $RegKey in $RegKeys )
                                {
                                    $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($RegKey,'ReadSubTree','QueryValues,EnumerateSubKeys')

                                    if ( $OpenSubKey )
                                    {
                                        foreach ( $SubKey in ( $OpenSubKey.GetSubKeyNames() ))
                                        {
                                            $InstallLocation = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$RegKey\$SubKey",'InstallLocation',$null)
                                            $DisplayName     = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$RegKey\$SubKey",'DisplayName',$null)

                                            if (( $InstallLocation -like '*\Microsoft\Edge\Application*' ) -and $DisplayName )
                                            {
                                                $Installed += $DisplayName
                                            }
                                        }

                                        $OpenSubKey.Close()
                                    }
                                }

                                if ( $Installed.Count )
                                {
                                    $text = if ( $L.s18 ) { $L.s18 } else { "Установился" }
                                    Write-Host "   $text`: " -ForegroundColor Green -NoNewline
                                    Write-Host "$Installed" -ForegroundColor DarkCyan

                                    $MSedgeExe = (Get-Item -Path "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
                                    "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe" -ErrorAction SilentlyContinue).Where({$_},'First').Fullname

                                    if ( $MSedgeExe )
                                    {
                                        if ( [System.IO.Directory]::Exists("$env:PUBLIC\Desktop") )
                                        {
                                            [bool] $Exist = $false

                                            # Поиск ярлыков по названию приложения внутри ярлыка, чтобы не зависеть от названия самого ярлыка
                                            (Get-ChildItem -File -LiteralPath "$env:PUBLIC\Desktop" -ErrorAction SilentlyContinue).Where({ $_.Extension -eq '.lnk' }).Foreach({
                                                if ( (Get-Content -Encoding UTF8 "$($_.FullName)" -ErrorAction SilentlyContinue) -like "*$MSedgeExe*" ) { $Exist = $true }
                                            })

                                            if ( -not $Exist )
                                            {
                                                $text = if ( $L.s13 ) { $L.s13 } else { "Создание Ярлыка" }
                                                Write-Host "   $text`: $env:PUBLIC\Desktop\Microsoft Edge.lnk" -ForegroundColor DarkGray

                                                $WScriptShell = New-Object -ComObject WScript.Shell
                                                $Shortcut = $WScriptShell.CreateShortcut("$env:PUBLIC\Desktop\Microsoft Edge.lnk")
                                                $Shortcut.TargetPath   = "$MSedgeExe"
                                                $shortcut.IconLocation = "$MSedgeExe,0"
                                                $Shortcut.Description  = 'Microsoft Edge'
                                                $Shortcut.Save()
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    $text = if ( $L.s14 ) { $L.s14 } else { "Не удалось установить" }
                                    Write-Host "   $text " -ForegroundColor Yellow

                                    $NeedFix = $true
                                }
                            }
                            else
                            {
                                $text = if ( $L.s19 ) { $L.s19 } else { "Не удалось загрузить" }
                                Write-Host "   $text " -ForegroundColor Yellow

                                $NeedFix = $true
                            }
                        }
                    }
                    else
                    {
                        $text = if ( $L.s10 ) { $L.s10 } else { "Microsoft Edge Chromium не установлен" }
                        Write-Host "   $text" -ForegroundColor Yellow

                        $NeedFix = $true
                    }
                }
            }
        }

        if ( $Componetns -like 'EdgeWebView' )
        {
            if ( $Installed.Where({ $_.InstallLocation -like '*WebView*' }) )
            {
                foreach ( $InstallEdge in ( $Installed.Where({ $_.InstallLocation -like '*WebView*' }) ))
                {
                    $text = if ( $L.s9 ) { $L.s9 } else { "Уже Установлен" }
                    Write-Host "   $text`: " -ForegroundColor DarkGreen -NoNewline
                    Write-Host "$($InstallEdge.DisplayName)" -ForegroundColor DarkCyan
                }
            }
            else
            {
                if ( $Act -eq 'Set' )
                {
                    $text = if ( $L.s20 ) { $L.s20 } else { "Загрузка и установка Microsoft Edge WebView" }
                    Write-Host "   $text" -ForegroundColor Cyan 

                    if ( -not ( Test-Internet -Bool -Access ))
                    {
                        $text = if ( $L.s17 ) { $L.s17 } else { "Нет доступа в Интернет для PS" }
                        Write-Host "   $text" -ForegroundColor DarkYellow

                        $NeedFix = $true
                    }
                    else
                    {
                        [string] $TempPath = $([System.IO.Path]::GetFullPath($env:TEMP))

                        $FileExe = "$TempPath\MicrosoftEdgeWebview2Setup.exe"
                        Remove-Item -LiteralPath $FileExe -Force -ErrorAction SilentlyContinue

                        Download-File "https://go.microsoft.com/fwlink/?LinkId=2124703" $FileExe
                        
                        if ( [System.IO.File]::Exists($FileExe) )
                        {
                            # Удаление запрета запуска всех Exe файлов установщика или Edge, если есть
                            $SubKey = 'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options'
                            $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues,EnumerateSubKeys')
                            if ( $OpenSubKey )
                            {
                                foreach ( $Name in ( $OpenSubKey.GetSubKeyNames() -like '*Edge*' ))
                                {
                                    if ( [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$SubKey\$Name",'Debugger',$null) )
                                    {
                                        $Path = "HKLM:\$SubKey\$Name"
                                        Set-Reg Remove-ItemProperty -Path $Path -Name 'Debugger'
                                    }
                                }

                                $OpenSubkey.Close()
                            }

                            try { [System.Diagnostics.Process]::Start($FileExe,'/silent /install').WaitForExit() }
                            catch { Write-Host "   Setup Error: $FileExe" -ForegroundColor Red }

                            Start-Sleep -Milliseconds 200

                            [string[]] $RegKeys = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
                                                  'SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall'

                            [psobject] $OpenSubKey = $null
                            $Installed = @()
                            foreach ( $RegKey in $RegKeys )
                            {
                                $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($RegKey,'ReadSubTree','QueryValues,EnumerateSubKeys')

                                if ( $OpenSubKey )
                                {
                                    foreach ( $SubKey in ( $OpenSubKey.GetSubKeyNames() ))
                                    {
                                        $InstallLocation = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$RegKey\$SubKey",'InstallLocation',$null)
                                        $DisplayName     = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$RegKey\$SubKey",'DisplayName',$null)

                                        if (( $InstallLocation -like '*\Microsoft\*Edge*Webview*\Application*' ) -and $DisplayName )
                                        {
                                            $Installed += $DisplayName
                                        }
                                    }

                                    $OpenSubKey.Close()
                                }
                            }

                            if ( $Installed.Count )
                            {
                                $text = if ( $L.s12 ) { $L.s12 } else { "Установился" }
                                Write-Host "   $text`: " -ForegroundColor Green -NoNewline
                                Write-Host "$Installed" -ForegroundColor DarkCyan
                            }
                            else
                            {
                                $text = if ( $L.s14 ) { $L.s14 } else { "Не удалось установить" }
                                Write-Host "   $text " -ForegroundColor Yellow

                                $NeedFix = $true
                            }

                        }
                        else
                        {
                            $text = if ( $L.s19 ) { $L.s19 } else { "Не удалось загрузить" }
                            Write-Host "   $text " -ForegroundColor Yellow

                            $NeedFix = $true
                        }
                    }
                }
                else
                {
                    $text = if ( $L.s21 ) { $L.s21 } else { "Microsoft Edge WebView не установлен" }
                    Write-Host "   $text" -ForegroundColor Yellow

                    $NeedFix = $true
                }

            }
        }

        Return
    }

    # Далее Удаление

    if ( $Act -eq 'Check' )
    {
        $text = if ( $L.s22 ) { $L.s22 } else { "Проверка Удаления" }
        Write-Host "`n██ $text`: " -ForegroundColor Cyan -NoNewline
        Write-Host ($Componetns -join ', ') -ForegroundColor DarkCyan -NoNewline
    }
    else
    {
        $text = if ( $L.s23 ) { $L.s23 } else { "Удаление" }
        Write-Host "`n██ $text`: " -ForegroundColor White -NoNewline
        Write-Host ($Componetns -join ', ') -ForegroundColor DarkCyan -NoNewline
    }

    $text = if ( $L.s8 ) { $L.s8 } else { "Функция" }
    Write-Host " | $text`: $NameThisFunction`n" -ForegroundColor DarkGray

    $EdgeData = 0

    [bool] $RemoveEdge        = $false
    [bool] $RemoveEdgeWebView = $false
    [bool] $RemoveEdgeUpdate  = $false

    if ( $Componetns -like 'Edge'            ) { $RemoveEdge        = $true }
    if ( $Componetns -like 'EdgeWebView'     ) { $RemoveEdgeWebView = $true }
    if ( $RemoveEdge -and $RemoveEdgeWebView ) { $RemoveEdgeUpdate  = $true }

    [string[]] $RegKeys = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
                          'SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall'

    [psobject] $OpenSubKey = $null
    
    [array] $Installed = @()

    foreach ( $RegKey in $RegKeys )
    {
        $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($RegKey,'ReadSubTree','QueryValues,EnumerateSubKeys')

        if ( $OpenSubKey )
        {
            foreach ( $SubKey in ( $OpenSubKey.GetSubKeyNames() ))
            {
                $InstallLocation = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$RegKey\$SubKey",'InstallLocation',$null)
                $DisplayName     = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$RegKey\$SubKey",'DisplayName',$null)

                if ( $InstallLocation -like '*\Edge*WebView*\*' -and $DisplayName )
                {
                    if ( $Componetns -like 'EdgeWebView' )
                    {
                        $Installed += $DisplayName

                        $text = if ( $L.s24 ) { $L.s24 } else { "Установлен" }
                        Write-Host "   $text`: " -ForegroundColor $Color -NoNewline
                        Write-Host "$DisplayName" -ForegroundColor DarkCyan
                    }
                }
                elseif ( $InstallLocation -like '*\Edge*\*' -and $DisplayName )
                {
                    if ( $Componetns -like 'Edge' )
                    {
                        $Installed += $DisplayName

                        $text = if ( $L.s24 ) { $L.s24 } else { "Установлен" }
                        Write-Host "   $text`: " -ForegroundColor $Color -NoNewline
                        Write-Host "$DisplayName" -ForegroundColor DarkCyan
                    }
                }
            }

            $OpenSubKey.Close()
        }
    }

    if ( -not $Installed.Count )
    {
        $text = if ( $L.s25 ) { $L.s25 } else { "Не установлен" }
        Write-Host "   $text`: " -ForegroundColor Green -NoNewline
        Write-Host ($Componetns -join ', ') -ForegroundColor DarkCyan
    }


    $text = if ( $L.s26 ) { $L.s26 } else { "Проверка файлов и параметров Microsoft Edge" } # Checking Edge files and settings
    Write-Host "   $text" -ForegroundColor DarkGray


    Get-ChildItem -Directory -Path "$env:USERPROFILE\AppData\Local\Microsoft\Edge*", "${env:ProgramFiles(x86)}\Microsoft\Edge*",
    "$env:ProgramFiles\Microsoft\Edge*" -ErrorAction SilentlyContinue | ForEach-Object {

        $Exe = (Get-ChildItem -File -Path "$($_.FullName)\Application\*\Installer\*" -ErrorAction SilentlyContinue).Where({$_.Name -like '*.exe'},'Last').FullName

        $Name = '' ; $UninstallArgs = '' ; $All = "| ({0})" -f $(if ( $L.s27 ) { $L.s27 } else { "Все пользователи" })

        if ( $Exe -like '*\Program Files*\Edge SxS\Application\*' )
        {
            if ( -not $RemoveEdge ) { Return } # Пропуск итерации
            
            $Name = 'Microsoft Edge Canary'
            $UninstallArgs = ' --uninstall --force-uninstall --verbose-logging --delete-profile --msedge-sxs --system-level'
        }
        elseif ( $Exe -like '*\Users\*\Edge SxS\Application\*' )
        {
            if ( -not $RemoveEdge ) { Return } # Пропуск итерации
            
            $Name = 'Microsoft Edge Canary' ; $All = ''
            $UninstallArgs = ' --uninstall --force-uninstall --verbose-logging --delete-profile --msedge-sxs'
        }
        elseif ( $Exe -like '*\Program Files*\Edge Dev\Application\*' )
        {
            if ( -not $RemoveEdge ) { Return } # Пропуск итерации
            
            $Name = 'Microsoft Edge Dev'
            $UninstallArgs = ' --uninstall --force-uninstall --verbose-logging --delete-profile --msedge-dev --system-level'
        }
        elseif ( $Exe -like '*\Users\*\Edge Dev\Application\*' )
        {
            if ( -not $RemoveEdge ) { Return } # Пропуск итерации
            
            $Name = 'Microsoft Edge Dev' ; $All = ''
            $UninstallArgs = ' --uninstall --force-uninstall --verbose-logging --delete-profile --msedge-dev'
        }
        elseif ( $Exe -like '*\Program Files*\Edge Beta\Application\*' )
        {
            if ( -not $RemoveEdge ) { Return } # Пропуск итерации
            
            $Name = 'Microsoft Edge Beta'
            $UninstallArgs = ' --uninstall --force-uninstall --verbose-logging --delete-profile --msedge-beta --system-level'
        }
        elseif ( $Exe -like '*\Users\*\Edge Beta\Application\*' )
        {
            if ( -not $RemoveEdge ) { Return } # Пропуск итерации
            
            $Name = 'Microsoft Edge Beta' ; $All = ''
            $UninstallArgs = ' --uninstall --force-uninstall --verbose-logging --delete-profile --msedge-beta'
        }
        elseif ( $Exe -like '*\Program Files*\Edge\Application\*' )
        {
            if ( -not $RemoveEdge ) { Return } # Пропуск итерации
            
            $Name = 'Microsoft Edge Stable'
            $UninstallArgs = ' --uninstall --force-uninstall --verbose-logging --delete-profile --system-level'
        }
        elseif ( $Exe -like '*\Users\*\Edge\Application\*' )
        {
            if ( -not $RemoveEdge ) { Return } # Пропуск итерации
            
            $Name = 'Microsoft Edge Stable' ; $All = ''
            $UninstallArgs = ' --uninstall --force-uninstall --verbose-logging --delete-profile'
        }
        elseif ( $Exe -like '*\Program Files*\EdgeWebView\Application\*' )
        {
            if ( -not $RemoveEdgeWebView ) { Return } # Пропуск итерации
            
            $Name = 'Microsoft Edge WebView2'
            $UninstallArgs = ' --uninstall --force-uninstall --verbose-logging --msedgewebview --system-level'
        }
        elseif ( $Exe -like '*\Users\*\EdgeWebView\Application\*' )
        {
            if ( -not $RemoveEdgeWebView ) { Return } # Пропуск итерации
            
            $Name = 'Microsoft Edge WebView2' ; $All = ''
            $UninstallArgs = ' --uninstall --force-uninstall --verbose-logging --msedgewebview'
        }

        if ( $Exe )
        {
            if ( $UninstallArgs )
            {
                $text = if ( $L.s23 ) { $L.s23 } else { "Удаление" }
                Write-Host "   $text`: " -ForegroundColor $Color -NoNewline
                Write-Host "$Name " -ForegroundColor White -NoNewline
                Write-Host "$All" -ForegroundColor DarkGray
                Write-Host "   $Exe" -ForegroundColor DarkGray
                    
                $EdgeData++
                    
                if ( $Act -eq 'Check' ) { $NeedFix = $true }
                else
                {
                    try { [System.Diagnostics.Process]::Start($Exe,$UninstallArgs).WaitForExit() }
                    catch { Write-Host "   Setup Error: $Exe" -ForegroundColor Red }
                }
            }
            else
            {
                $text = if ( $L.s28 ) { $L.s28 } else { "Не известный Microsoft Edge" }
                Write-Host "   $text`: " -ForegroundColor DarkGray
                Write-Host "   $Exe" -ForegroundColor DarkGray
            }
        }
    }

    Start-Sleep -Milliseconds 200

    [string[]] $RegKeys = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
                          'SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall'

    [psobject] $OpenSubKey = $null
    
    [array] $Installed = @()
    [array] $InstallLocations = @()

    foreach ( $RegKey in $RegKeys )
    {
        $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($RegKey,'ReadSubTree','QueryValues,EnumerateSubKeys')

        if ( $OpenSubKey )
        {
            foreach ( $SubKey in ( $OpenSubKey.GetSubKeyNames() ))
            {
                $InstallLocation = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$RegKey\$SubKey",'InstallLocation',$null)
                $DisplayName     = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$RegKey\$SubKey",'DisplayName',$null)

                $InstallLocations += $InstallLocation

                if ( $InstallLocation -like '*\Edge*WebView*\*' -and $DisplayName )
                {
                    if ( $Componetns -like 'EdgeWebView' )
                    {
                        $Installed += $DisplayName
                        
                        if ( $Act -eq 'Set' )
                        {
                            $text = if ( $L.s24 ) { $L.s24 } else { "Установлен" }
                            Write-Host "   $text`: " -ForegroundColor $Color -NoNewline
                            Write-Host "$DisplayName" -ForegroundColor DarkCyan
                        }
                    }
                }
                elseif ( $InstallLocation -like '*\Edge*\*' -and $DisplayName )
                {
                    if ( $Componetns -like 'Edge' )
                    {
                        $Installed += $DisplayName
                        
                        if ( $Act -eq 'Set' )
                        {
                            $text = if ( $L.s24 ) { $L.s24 } else { "Установлен" }
                            Write-Host "   $text`: " -ForegroundColor $Color -NoNewline
                            Write-Host "$DisplayName" -ForegroundColor DarkCyan
                        }
                    }
                }
            }

            $OpenSubKey.Close()
        }
    }

    if ( $Installed.Count )
    {
        if ( $Act -eq 'Set' )
        {
            $text = if ( $L.s29 ) { $L.s29 } else { "Не все Microsoft Edge удалились" }
            Write-Host "   $text`: " -ForegroundColor Yellow -NoNewline
            Write-Host ($Installed -join ', ') -ForegroundColor DarkYellow
        }

        $NeedFix = $true
        $EdgeData++
    }

    if ( $RemoveEdge        -and -not ( $InstallLocations -like '*\Edge*WebView*\*'                                    )) { $RemoveEdgeUpdate = $true }
    if ( $RemoveEdgeWebView -and -not ( $InstallLocations.Where({ $_ -notlike '*\Edge*WebView*\*' }) -like '*\Edge*\*' )) { $RemoveEdgeUpdate = $true }

    # Удаление Служб
    [array] $Services = @()

    if ( $RemoveEdge       ) { $Services += 'MicrosoftEdgeElevationService' }
    if ( $RemoveEdgeUpdate ) { $Services += 'edgeupdate','edgeupdatem'      }

    foreach ( $Name in $Services )
    {
        try
        {
            if ( [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\$Name",'ImagePath',$null) )
            {
                $EdgeData++

                Set-Svc -Do:$Act Set-Service -Name $Name -StartupType Disabled -Status Stopped -OrigCmdlet
                
                if ( $Act -eq 'Set' )
                {
                    try { (Get-WmiObject win32_service -Filter "name='$Name'").delete() > $null } catch {}
                }
                
                $Path = "HKLM:\SYSTEM\CurrentControlSet\Services\$Name"
                Set-Reg -Do:$Act Remove-Item -Path $Path
            }
        }
        catch {}
    }

    if ( $RemoveEdgeUpdate )
    {
        # Удаление всех найденных задач
        Get-Task-FullPaths -LikeName *MicrosoftEdge* | ForEach-Object {

            Set-Tsk -Do:$Act Unregister-ScheduledTask -TaskName $_

            $EdgeData++
        }
    }

    # Профили
    [array] $Accs = [PSCustomObject] @{ 
        Name    = $env:USERNAME
        Root    = 'HKCU:'
        Profile = $env:USERPROFILE
            
        UserDesktopFolder = [Microsoft.Win32.Registry]::GetValue('HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders','Desktop',$null)
    }

    if ( $Global:DataLocalUsers.Redirects.Value )
    {
        @($Global:DataLocalUsers.Where({ $_.Use -and $_.ProfileType -eq 'User' -and $_.Profile -and $_.SID })).ForEach({
            
            $Accs += [PSCustomObject] @{
                Name    = $_.Name
                Root    = $_.SID
                Profile = $_.Profile
            
                UserDesktopFolder = [Microsoft.Win32.Registry]::GetValue("HKEY_USERS\$($_.SID)\Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders",'Desktop',$null)
            }
        })
    }


    if ( $Act -eq 'Set' ) { Get-Process *edge* -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue }


    [array] $Paths = "${env:ProgramFiles(x86)}\Microsoft\Edge*", "$env:ProgramFiles\Microsoft\Edge*"

    foreach ( $Acc in $Accs )
    {
        if ( $Acc.Profile ) { $Paths += "$($Acc.Profile)\AppData\Local\Microsoft\Edge*" }
    }

    # Удаление папок
    [string] $Folder = ''
     [array] $FolderNames = @()
    
    if ( $RemoveEdge        ) { $FolderNames += 'Edge','Edge SxS','Edge Dev','Edge Beta' }
    if ( $RemoveEdgeWebView ) { $FolderNames += 'EdgeWebView'                            }
    if ( $RemoveEdgeUpdate  ) { $FolderNames += 'EdgeUpdate','EdgeCore'                  } # EdgeUpdate и EdgeCore может быть и от Edge и от WebView

    @(Get-ChildItem -Directory -Path $Paths -Force -ErrorAction SilentlyContinue).Where({ $FolderNames -like $_.Name }).Foreach({

        $Folder = $_.FullName

        $text = if ( $L.s23 ) { $L.s23 } else { "Удаление" }
        Write-Host "   $text`: " -ForegroundColor $Color -NoNewline
        Write-Host "$Folder" -ForegroundColor DarkGray
            
        $EdgeData++

        if ( $Act -eq 'Check' )
        {
            $NeedFix = $true
        }
        else
        {
            Remove-Item -LiteralPath $Folder -Recurse -Force -ErrorAction SilentlyContinue
        }
    })
    
    # Удаление папки EdgeBho, если в ней есть файлы. Её иногда создаёт винда пустую или с пустыми папками.
    if ( $RemoveEdge )
    {
        foreach ( $Acc in $Accs )
        {
            if ( $Acc.Profile )
            {
                $Folder = "$($Acc.Profile)\AppData\Local\Microsoft\EdgeBho"

                if ( @(Get-ChildItem -File -Path $Folder -Recurse -Force -ErrorAction SilentlyContinue).Count )
                {
                    $text = if ( $L.s23 ) { $L.s23 } else { "Удаление" }
                    Write-Host "   $text`: " -ForegroundColor $Color -NoNewline
                    Write-Host "$Folder" -ForegroundColor DarkGray
            
                    $EdgeData++

                    if ( $Act -eq 'Check' )
                    {
                        $NeedFix = $true
                    }
                    else
                    {
                        Remove-Item -LiteralPath $Folder -Recurse -Force -ErrorAction SilentlyContinue
                    }
                }
            }
        }
    }

    # Очистка реестра

    foreach ( $Acc in $Accs )
    {
        if ( $Acc.Root -eq 'HKCU:' )
        {
            $RegRoot = [Microsoft.Win32.Registry]::CurrentUser
            $SubKey  = 'Software\Microsoft\Windows\CurrentVersion\Uninstall'
            $isRoot  = $Acc.Root
        }
        else
        {
            $RegRoot = [Microsoft.Win32.Registry]::Users
            $SubKey  = "$($Acc.Root)\Software\Microsoft\Windows\CurrentVersion\Uninstall"
            $isRoot  = "Registry::HKU"
        }

        try { $OpenSubKey = $RegRoot.OpenSubKey($SubKey,'ReadSubTree','QueryValues,EnumerateSubKeys') }
        catch { $OpenSubKey = $null }
            
        if ( $OpenSubKey )
        {
            [array] $Paths = @()

            foreach ( $Name in ( $OpenSubKey.GetSubKeyNames() -like '*Edge*' ))
            {
                if (( $Name -like '*Update*' -and $RemoveEdgeUpdate ) -or ( $Name -like '*WebView*' -and $RemoveEdgeWebView ) -or 
                    ( $Name -notmatch 'WebView|Update' -and $RemoveEdge ))
                {
                    $EdgeData++

                    $Paths += "$isRoot\$SubKey\$Name"
                }
            }
                
            $OpenSubKey.Close()

            foreach ( $Path in $Paths )
            {
                $text = if ( $L.s23 ) { $L.s23 } else { "Удаление" }
                Write-Host "   $text`: " -ForegroundColor $Color -NoNewline
                Write-Host "$Path" -ForegroundColor DarkGray

                if ( $Act -eq 'Check' ) { $NeedFix = $true }
                else
                {
                    Set-Reg Remove-Item -Path $Path -OnlyThisPath
                }
            }
        }

        if ( $RemoveEdge )
        {
            if ( $Acc.Root -eq 'HKCU:' )
            {
                $SubKey = 'Software\Classes'
            }
            else
            {
                $SubKey = "$($Acc.Root)_Classes"
            }

            $isSubkey = "$SubKey\AppX4hxtad77fbk3jkkeerkrm0ze94wjf3s9"

            try { $OpenSubKey = $RegRoot.OpenSubKey($isSubkey,'ReadSubTree','QueryValues,EnumerateSubKeys') }
            catch { $OpenSubKey = $null }

            if ( $OpenSubKey )
            {
                $OpenSubKey.Close()

                $EdgeData++

                $Path = "$isRoot\$isSubkey"

                $text = if ( $L.s23 ) { $L.s23 } else { "Удаление" }
                Write-Host "   $text`: " -ForegroundColor $Color -NoNewline
                Write-Host "$Path" -ForegroundColor DarkGray

                if ( $Act -eq 'Check' ) { $NeedFix = $true }
                else
                {
                    Set-Reg Remove-Item -Path $Path -OnlyThisPath
                }
            }

            [array] $Paths = @()

            foreach ( $Ext in ( '.html','.htm' ))
            {
                $isSubkey = "$SubKey\$Ext\OpenWithProgids"

                try { $OpenSubKey = $RegRoot.OpenSubKey($isSubkey,'ReadSubTree','QueryValues,EnumerateSubKeys') }
                catch { $OpenSubKey = $null }

                if ( $OpenSubKey )
                {
                    if ( $OpenSubKey.GetValueNames() -like 'AppX4hxtad77fbk3jkkeerkrm0ze94wjf3s9' )
                    {
                        $Paths += "$isRoot\$isSubkey"
                    }

                    $OpenSubKey.Close()
                }
            }

            foreach ( $Path in $Paths )
            {
                $EdgeData++

                $text = if ( $L.s23 ) { $L.s23 } else { "Удаление" }
                Write-Host "   $text`: " -ForegroundColor $Color -NoNewline
                Write-Host "$Path -Name 'AppX4hxtad77fbk3jkkeerkrm0ze94wjf3s9'" -ForegroundColor DarkGray

                if ( $Act -eq 'Check' ) { $NeedFix = $true }
                else
                {
                    Set-Reg Remove-ItemProperty -Path $Path -Name 'AppX4hxtad77fbk3jkkeerkrm0ze94wjf3s9' -OnlyThisPath
                }
            }
        }
    }



    [string[]] $RegKeys = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
                          'SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall'

    foreach ( $RegKey in $RegKeys )
    {
        $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($RegKey,'ReadSubTree','QueryValues,EnumerateSubKeys')

        if ( $OpenSubKey )
        {
            foreach ( $Name in ( $OpenSubKey.GetSubKeyNames() -like '*Edge*' ))
            {
                if (( $Name -like '*Update*' -and $RemoveEdgeUpdate ) -or ( $Name -like '*WebView*' -and $RemoveEdgeWebView ) -or 
                    ( $Name -notmatch 'WebView|Update' -and $RemoveEdge ))
                {
                    $Path = "HKLM:\$RegKey\$Name"

                    $text = if ( $L.s23 ) { $L.s23 } else { "Удаление" }
                    Write-Host "   $text`: " -ForegroundColor $Color -NoNewline
                    Write-Host "$Path" -ForegroundColor DarkGray

                    $EdgeData++

                    if ( $Act -eq 'Check' ) { $NeedFix = $true }
                    else
                    {
                        Set-Reg Remove-Item -Path $Path
                    }
                }
            }

            $OpenSubKey.Close()
        }
    }


    if ( $RemoveEdge )
    {
        [string] $File  = ''
        [string[]] $Paths = @()

        foreach ( $Acc in $Accs )
        {
            $Paths = @()

            if ( $Acc.Profile )
            {
                $Paths = "$($Acc.Profile)\AppData\Roaming\Microsoft\Internet Explorer\Quick Launch",
                         "$($Acc.Profile)\AppData\Roaming\Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar\Tombstones",
                         "$($Acc.Profile)\AppData\Roaming\Microsoft\Windows\Start Menu\Programs"
            }

            if ( $Acc.UserDesktopFolder )
            {
                $Paths += $Acc.UserDesktopFolder
            }

            $Paths += "$env:PUBLIC\Desktop"

            # Поиск ярлыков по названию приложения внутри ярлыка, чтобы не зависеть от названия самого ярлыка
            (Get-ChildItem -File -LiteralPath $Paths -ErrorAction SilentlyContinue).Where({ $_.Extension -eq '.lnk' }).Foreach({

                $File = $_.FullName

                if ( (Get-Content -Encoding UTF8 $File -ErrorAction SilentlyContinue) -like "*\msedge.exe*" )
                {
                    $text = if ( $L.s23 ) { $L.s23 } else { "Удаление" }
                    Write-Host "   $text`: "  -ForegroundColor $Color -NoNewline
                    Write-host "$File" -ForegroundColor DarkGray
                
                    $EdgeData++

                    if ( $Act -eq 'Check' ) { $NeedFix = $true }
                    else
                    {
                            Remove-Item -LiteralPath $File -Force -ErrorAction SilentlyContinue
                    }
                }
            })
        }
    }

    if ( -not $EdgeData )
    {
        $text = if ( $L.s30 ) { $L.s30 } else { "Не найдено" } # Not found
        Write-Host "   $text"  -ForegroundColor DarkGreen
    }
}
