﻿

# Проверка состояния значений реестра.
Function Check-State-Registry {

    [CmdletBinding( SupportsShouldProcess = $false )]
    [OutputType([string],[bool])]
    Param(
        [Parameter( Mandatory = $true,  Position = 0  )]
        [Alias( 'LiteralPath' )]
        [string] $Path
       ,
        [Parameter( Mandatory = $false, Position = 1 )]
        $Name
       ,
        [Parameter( Mandatory = $false, Position = 2 )]
        [ValidateSet( 'String', 'ExpandString', 'MultiString', 'DWord', 'QWord', 'Binary', 'None', 'Unknow' )]
        [string] $Type = 'Unknow'
       ,
        [Parameter( Mandatory = $false, Position = 3 )]
        $Value
       ,
        [Parameter( Mandatory = $false )]
        [Alias( 'Include' )]
        [switch] $IncludeValue  # Значение переданного параметра должно присутствовать в полученном полном параметре: -like '*Value*'
       ,
        [Parameter( Mandatory = $false )]
        [ValidateSet( 'Result', 'Value', 'Bool' )]
        [string] $Return = 'Result'
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    # Получение корневого раздела и поддиректории для методов RegistryKey (.NET), таких как OpenSubKey.
    # Понимает любой тип правильного пути.
    if ( $Path -match "(?<Root>Registry::HK[\w]+\\|HKLM:\\|HKCU:\\)(?<Subkey>[^\s][^\r\n]+[^\s])" )
    {
        [string] $Root   = $matches.Root
        [string] $SubKey = $matches.Subkey

        if     ( $Root -like "*HKCU*" -or $Root -like "*HKEY_CURRENT_USER*"   ) { $RootKey = [Microsoft.Win32.Registry]::CurrentUser   }
        elseif ( $Root -like "*HKLM*" -or $Root -like "*HKEY_LOCAL_MACHINE*"  ) { $RootKey = [Microsoft.Win32.Registry]::LocalMachine  }
        elseif ( $Root -like "*HKCR*" -or $Root -like "*HKEY_CLASSES_ROOT*"   ) { $RootKey = [Microsoft.Win32.Registry]::ClassesRoot   }
        elseif ( $Root -like "*HKU*"  -or $Root -like "*HKEY_USERS*"          ) { $RootKey = [Microsoft.Win32.Registry]::Users         }
        elseif ( $Root -like "*HKCC*" -or $Root -like "*HKEY_CURRENT_CONFIG*" ) { $RootKey = [Microsoft.Win32.Registry]::CurrentConfig }
        else
        {
            $text = if ( $L.s1 ) { $L.s1 } else { "Имя раздела реестра неправильное!`n   Раздел" }
            Write-Warning "`n   $text`: '$Path'"

            Return    # Выходим из функции
        }
    }
    else
    {
        $text = if ( $L.s1 ) { $L.s1 } else { "Имя раздела реестра неправильное!`n   Раздел" }
        Write-Warning "`n   $text`: '$Path'"

        Return   # Выходим из функции
    }

    # Обнуляем важные дополнительные переменные, на всякий случай.
    $isOpenKey = $isValue = $isType = $ValueExist = $isZerolength = $Zerolength = $null
    [bool] $ResultState = $false

    $OFS = ' '

    # Если передано имя '(default)', то имеется в виду параметр "По умолчанию" в разделе, тогда обнуление имени для указания функции на этот параметр.
    if ( $Name -eq '(default)' ) { $Name = $null }

    # Если для проверки передано значение параметра.
    # IsFixedSize отпределяется только на массивах или коллекциях, а 'двоичное значение нулевой длины' является пустым массивом @() для Binary или None.
    # Пустой массив - это не '$null', не пустая строка '' и не значение. Операторы сравнения его не понимают.
    if (( $Value ) -or ( $Value.IsFixedSize -is [bool] ))
    {
        # Параметр передан.
        [bool] $ValueExist = $true

        # Если переданный параметр является пустым массивом.
        if ( $Value.Count -eq 0 ) { $Zerolength = '{0}' -f $(if ( $L.s2 ) { $L.s2 } else { "Двоичное значение нулевой длины" }) }
    }

    # Если передан тип параметра, так как если не передавать, будет указан по умолчанию 'Unknow'.
    if ( $Type -ne 'Unknow' )
    {
        if ( -not $ValueExist )
        {
            if     ( $Type -match "Binary|None"          ) {   [byte[]] $Value = ([byte[]]@())   }
            elseif ( $Type -eq 'MultiString'             ) { [string[]] $Value = ([string[]]@()) }
            elseif ( $Type -like "?word"                 ) {    [int32] $Value = 0               }
            elseif ( $Type -match "^String|ExpandString" ) {   [string] $Value = ''              }
        }
        else
        {
            if ( $Type -match "Binary|None" )
            {
                # Если передать строку для Binary или None, она будет преобразована в массив по 2 символа с добавлением к ним '0x..' (формат HEX)
                # Такой формат в .reg, или слитый. С любыми переносами строк.
                if ( $Value.GetType().Name -eq 'String' )
                {
                    [byte[]] $Value = ($Value -replace ('[\s\\]','') -replace ('([\w]{1,2}),?','0x$1;')).Split(';').Where({$_})
                }
                else                                       {   [byte[]] $Value = $Value }
            }
            elseif ( $Type -eq 'MultiString'             ) { [string[]] $Value = $Value }
            elseif ( $Type -like "?word"                 ) {    [int32] $Value = $Value }
            elseif ( $Type -match "^String|ExpandString" ) {   [string] $Value = $Value }
        }
    }
    else
    {
        if ( -not $ValueExist ) { [string] $Value = '' }
        else
        {
            if     ( $Value.GetType().Name -eq 'Byte[]' ) { [string] $Type = 'Binary'      ;   [byte[]] $Value = $Value }
            elseif ( $Value.GetType().Name -eq 'Int32'  ) { [string] $Type = 'Dword'       ;    [int32] $Value = $Value }
            elseif ( $Value.GetType().IsArray           ) { [string] $Type = 'MultiString' ; [string[]] $Value = $Value }
            else                                          { [string] $Type = 'String'      ;   [string] $Value = $Value }
        }
    }

    try
    {
        # Открываем раздел в режиме минимального доступа.
        $isOpenKey = $RootKey.OpenSubKey($SubKey,'ReadSubTree','QueryValues')  # Если будет ошибка, перейдёт в catch.

        [bool] $isAccess = $true
    }
    catch { [bool] $isAccess = $false }

    try
    {
        # Получаем значение у параметра.
        # не раскрывая системные переменные в значениях, такие как %Temp% и т.д. у параметров с типом ExpandString (REG_EXPAND_SZ).
        # Если параметра не существует, то результат будет указанный $null.
        # Если имя будет $null или '', то проверит параметр (По умолчанию) у раздела.
        $isValue = $isOpenKey.GetValue($Name,$null,'DoNotExpandEnvironmentNames')

        # Получаем тип параметра, если будет получен, значит и параметр существует.
        # Если имя будет $null или '', то проверит тип у параметра (По умолчанию) в разделе.
        $isType  = $isOpenKey.GetValueKind($Name)
    }
    catch {}

    # Если тип параметра получен, значит и параметр существует.
    if ( $isType )
    {
        # Если значение полученного параметра является пустым массивом.
        if (( $isValue.IsFixedSize ) -and ( $isValue.Count -eq 0 )) { $isZerolength = '{0}' -f $(if ( $L.s2 ) { $L.s2 } else { "Двоичное значение нулевой длины" }) }
    }

    # Если раздел существует.
    if ( $isOpenKey )
    {
        # Если значение параметра передано.
        if ( $ValueExist )
        {
            # Если тип параметра получен, значит параметр существует, и передан тип параметра для проверки.
            if ( $isType -and ( $Type -ne 'Unknow' ))
            {
                # "Проверка: Value и Type"

                # Если имя параметра не передали или передали пустую строку ''.
                if ( -not $Name ) { $Name = '{0}' -f $(if ( $L.s3 ) { $L.s3 } else { "(По умолчанию)" }) }

                if ( $IncludeValue )
                {
                    if (( "$isValue" -like "*$Value*" ) -and ( $Type -eq $isType ))
                    {
                        # Выводим полностью совпавшие полученные: 'Имя параметра' [тип параметра] {значение}.
                        Write-Verbose "Все совпадает с '$Name' [$isType] {$isValue$isZerolength}"

                        $ResultState = $true
                    }
                    else
                    {
                        # Иначе, выводим переданные и не совпавшие полученные значения.
                        Write-Verbose "Не совпадает:`n   Проверили: '$Name' [$Type] {$Value$Zerolength}`n    Получили: '$Name' [$isType] {$isValue$isZerolength}"

                        $ResultState = $false
                    }
                }
                else
                {
                    # Если передали имя, даже с пустой строкой '', значение и тип параметра, и они совпали с полученным именем, его значением и типом.
                    # Включая пустые массивы - 'двоичное значение нулевой длины' и пустые строки ''.
                    if (( "$Value" -eq "$isValue" ) -and ( $Type -eq $isType ))
                    {
                        # Выводим полностью совпавшие полученные: 'Имя параметра' [тип параметра] {значение}.
                        Write-Verbose "Все совпадает с '$Name' [$isType] {$isValue$isZerolength}"

                        $ResultState = $true
                    }
                    else
                    {
                        # Иначе, выводим переданные и не совпавшие полученные значения.
                        Write-Verbose "Не совпадает:`n   Проверили: '$Name' [$Type] {$Value$Zerolength}`n    Получили: '$Name' [$isType] {$isValue$isZerolength}"

                        $ResultState = $false
                    }
                }
            }
            elseif ( $isType )
            {
                # Иначе, если тип параметра получен, но тип параметра не передан для проверки,
                # проверяем только значение параметра.
                # "Проверка: только Value"

                # Если имя параметра не передали или передали имя с пустой строкой ''.
                if ( -not $Name ) { $Name = '{0}' -f $(if ( $L.s3 ) { $L.s3 } else { "(По умолчанию)" }) }

                if ( $IncludeValue )
                {
                    if ( "$isValue" -like "*$Value*" )
                    {
                        # Выводим полностью совпавшие полученные: 'Имя параметра' [тип параметра] {значение}.
                        Write-Verbose "Все совпадает с '$Name' [$isType] {$isValue$isZerolength}"

                        $ResultState = $true
                    }
                    else
                    {
                        # Иначе, выводим переданные и не совпавшие полученные значения.
                        Write-Verbose "Не совпадает:`n   Проверили: '$Name' [$Type] {$Value$Zerolength}`n    Получили: '$Name' [$isType] {$isValue$isZerolength}"

                        $ResultState = $false
                    }
                }
                else
                {
                    if ( "$Value" -eq "$isValue" )
                    {
                        # Если переданное значение совпадает с полученым значением,
                        # Включая пустые массивы - 'двоичное значение нулевой длины' и пустые строки ''.

                        Write-Verbose "Значение Cовпадает: '$Name' [$isType] {$isValue$isZerolength}"

                        $ResultState = $true
                    }
                    else
                    {
                        # Иначе значения не совпадают. Выводим все переданные и все полученные параметры.

                        Write-Verbose "Значение не совпадает:`n  Проверили: '$Name' [-] {$Value$Zerolength}`n   Получили: '$Name' [$isType] {$isValue$isZerolength}"

                        $ResultState = $false
                    }
                }
            }
            else
            {
                # Иначе, тип параметра не получен, а значит и имя параметра не существует,
                # Выводится, если переданно для проверки имя параметра и значение, без типа параметра.

                if ( -not $Name )
                {
                    # Если имя параметра не передано, или передано имя с пустой строкой ''.

                    Write-Verbose "Параметр отсутствует: '(По умолчанию)'"

                    $ResultState = $false
                }
                else
                {
                    # Иначе имя параметра было передано. Выводим переданное имя параметра, из-за отсутствия.

                    Write-Verbose "Параметр отсутствует: '$Name'"

                    $ResultState = $false
                }
            }
        }
        else
        {
            # Иначе, значение параметра не передано для проверки, но раздел существует.
            # "Проверка: Name". Все варианты.

            if ( $null -eq $Name )
            {
                # Если имя и значение не передано. Значит хотим проверить только раздел.

                Write-Verbose "Раздел$ChildPath существует: '$($isOpenKey.Name)'"

                $ResultState = $true

            }
            elseif (( $Name -eq '' ) -and $isType )
            {
                # Иначе, Если Имя параметра передано с пустой строкой '', без значения параметра, а тип параметра получен.
                # Значит хотели проверить параметр (По умолчанию).

                Write-Verbose "Параметр существует: '(По умолчанию)' [$isType] {$isValue$isZerolength}"

                $ResultState = $true

            }
            elseif ( $isType )
            {
                # Иначе, Если Имя параметра передали и тип параметра получили.

                Write-Verbose "Параметр существует: '$Name' [$isType] {$isValue$isZerolength}"

                $ResultState = $true
            }
            elseif ( $Name )
            {
                # Иначе, Если Имя параметра передали, а тип параметра не получили.

                Write-Verbose "Параметр отсутствует: '$Name'"

                $ResultState = $false
            }
            else
            {
                # Иначе, раз все выше проверенное не подошло, остается только,
                # что Имя параметра передали с пустой строкой '', а тип параметра не получили,
                # значит хотели проверить параметр (По умолчанию).

                Write-Verbose "Параметр отсутствует: '(По умолчанию)'"

                $ResultState = $false
            }
        }
    }
    else
    {
        # Иначе, раз раздела не существует, выводим переданный раздел, из-за его отсутствия.
        # "Проверка: Path"
        Write-Verbose "Раздел$ChildPath отсутствует: '$Path'"

        $ResultState = $false
    }

    # Закрываем открытый раздел, для возможности выгрузки подключенных разделов, после очистки.
    if ( $isOpenKey ) { $isOpenKey.Close() }

    if  ( $ResultState ) { $StateREG = "#Green#{0}#" -f $(if ( $L.s4 ) { $L.s4 } else { "Верно  " }) }
    elseif ( $isAccess ) { $StateREG =   "#Red#{0}#" -f $(if ( $L.s5 ) { $L.s5 } else { "Неверно" }) }
    else                 { $StateREG =   "#Red#{0}#" -f $(if ( $L.s6 ) { $L.s6 } else { "Нет доступа" }) }

    if     ( $Return -eq 'Result' ) { [string] "$StateREG" }
    elseif ( $Return -eq 'Value'  ) { [string] $isValue    }
    else { [bool] $ResultState }
}
