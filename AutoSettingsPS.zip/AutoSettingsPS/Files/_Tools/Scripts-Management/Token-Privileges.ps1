﻿
<#
.SYNOPSIS
 Выдает или забирает у текущего процесса привилегии.

.DESCRIPTION
 Функция написана для скриптов AutoSettingsPS и RepackWIMPS.
 Нужны права администратора.

 Список минимально необходимых привилегий, можно добавить и другие:

 SeAssignPrimaryTokenPrivilege  Замена маркера уровня процесса
 SeBackupPrivilege              Архивация файлов и каталогов
 SeLoadDriverPrivilege          Загрузка и выгрузка драйверов устройств
 SeRestorePrivilege             Восстановление файлов и каталогов
 SeSecurityPrivilege            Управление аудитом и журналом безопасности
 SeSystemEnvironmentPrivilege   Изменение параметров среды изготовителя
 SeTakeOwnershipPrivilege       Смена владельцев файлов и других объектов

 SeDebugPrivilege               Отладка программ
 SeImpersonatePrivilege         Имитация клиента после проверки подлинности
 SeSystemProfilePrivilege       Профилирование производительности системы

 Привилегия не будет выдана, если ее нет в списке возможных для выдачи
 привилегий для текущего процесса.

.EXAMPLE
    Token-Privileges -Enable -Privileges 'SeTakeOwnershipPrivilege', 'SeRestorePrivilege', 'SeBackupPrivilege'

    Описание
    --------
    Выдать указанные привилегии текущему процессу.


.NOTES
 ==================================================
      Автор:  westlife (ru-board)  Версия: 1.0
       Дата:  10-10-2018
 ==================================================

#>
Function Token-Privileges {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param (
        [parameter( Mandatory = $true, Position = 0 )]
        [ValidateSet( 'SeAssignPrimaryTokenPrivilege','SeIncreaseQuotaPrivilege','SeLoadDriverPrivilege',
                      'SeTakeOwnershipPrivilege','SeBackupPrivilege', 'SeRestorePrivilege',
                      'SeSecurityPrivilege','SeShutdownPrivilege','SeSystemEnvironmentPrivilege','SeManageVolumePrivilege',
                      'SeTrustedCredmanAccessPrivilege','SeUndockPrivilege','SeSystemTimePrivilege','SeTrustedCredmanAccessPrivilege',
                      'SeCreateSymbolicLinkPrivilege','SeSystemProfilePrivilege','SeDebugPrivilege','SeDelegateSessionUserImpersonatePrivilege',
                      'SeIncreaseBasePriorityPrivilege','SeProfileSingleProcessPrivilege' )]
        [string[]] $Privileges
       ,
        [parameter( Mandatory = $true, ParameterSetName = 'Enable' )]
        [switch] $Enable
       ,
        [parameter( Mandatory = $true, ParameterSetName = 'Disable' )]
        [switch] $Disable
    )

    Begin
    {
        # Перехват ошибок в блоке Begin, для выхода из функции,
        # без отображения ошибки тут, и передача ее в глобальный trap для отображения и записи в лог.
        trap { break }

        # Подключаем .Net code для управления привилегиями, нужны права администратора.
        [string] $TokenManipulatorAPI = @'
using System;
using System.Runtime.InteropServices;

namespace WinAPI
{
    public class TokenManipulator
    {
        [DllImport("kernel32.dll", ExactSpelling = true)]
        internal static extern IntPtr GetCurrentProcess();

        [DllImport("advapi32.dll", ExactSpelling = true, SetLastError = true)]
        internal static extern bool AdjustTokenPrivileges(IntPtr htok, bool disall, ref TokPriv1Luid newst, int len, IntPtr prev, IntPtr relen);
        [DllImport("advapi32.dll", ExactSpelling = true, SetLastError = true)]
        internal static extern bool OpenProcessToken(IntPtr h, int acc, ref IntPtr phtok);
        [DllImport("advapi32.dll", SetLastError = true)]
        internal static extern bool LookupPrivilegeValue(string host, string name, ref long pluid);

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        internal struct TokPriv1Luid
        {
            public int Count;
            public long Luid;
            public int Attr;
        }

        internal const int SE_PRIVILEGE_DISABLED = 0x00000000;
        internal const int SE_PRIVILEGE_ENABLED = 0x00000002;
        internal const int TOKEN_QUERY = 0x00000008;
        internal const int TOKEN_ADJUST_PRIVILEGES = 0x00000020;

        public static bool AddPrivilege(string privilege)
        {
            bool retVal;
            TokPriv1Luid tp;
            IntPtr hproc = GetCurrentProcess();
            IntPtr htok = IntPtr.Zero;
            retVal = OpenProcessToken(hproc, TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, ref htok);
            tp.Count = 1;
            tp.Luid = 0;
            tp.Attr = SE_PRIVILEGE_ENABLED;
            retVal = LookupPrivilegeValue(null, privilege, ref tp.Luid);
            retVal = AdjustTokenPrivileges(htok, false, ref tp, 0, IntPtr.Zero, IntPtr.Zero);
            return retVal;
        }

        public static bool RemovePrivilege(string privilege)
        {
            bool retVal;
            TokPriv1Luid tp;
            IntPtr hproc = GetCurrentProcess();
            IntPtr htok = IntPtr.Zero;
            retVal = OpenProcessToken(hproc, TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, ref htok);
            tp.Count = 1;
            tp.Luid = 0;
            tp.Attr = SE_PRIVILEGE_DISABLED;
            retVal = LookupPrivilegeValue(null, privilege, ref tp.Luid);
            retVal = AdjustTokenPrivileges(htok, false, ref tp, 0, IntPtr.Zero, IntPtr.Zero);
            return retVal;
        }
    }
}
'@

        if ( -not ( 'WinAPI.TokenManipulator' -as [type] )) { Add-Type $TokenManipulatorAPI -ErrorAction Stop }
    }

    Process
    {
        # Перехват ошибок в блоке Begin, для выхода из функции,
        # без отображения ошибки тут, и передача ее в глобальный trap для отображения и записи в лог.
        trap { break }

        if ( $Enable )
        {
            foreach ( $Privilege in $Privileges )
            {
                Write-Verbose "Выдача привилегии: '$Privilege'"
                [void][WinAPI.TokenManipulator]::AddPrivilege($Privilege)
            }
        }
        else
        {
            foreach ( $Privilege in $Privileges )
            {
                Write-Verbose "Отключение привилегии: '$Privilege'"
                [void][WinAPI.TokenManipulator]::RemovePrivilege($Privilege)
            }
        }
    }
}
