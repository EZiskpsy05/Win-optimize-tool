﻿
<#
.SYNOPSIS
 Перезапуск/Запуск или остановка процесса Проводника, корректная "Gracefully".

.DESCRIPTION
 Функция написана для скриптов AutoSettingsPS и RepackWIMPS.

 Используется утилита ExitExplorer.exe от winaero.com
 http://winaero.com/blog/exitexplorer-and-restartexplorer-two-tools-to-exit-and-restart-the-explorer-shell-properly/
 Для завершения процесса проводника "Gracefully".

 Запоминает открытые окна проводника, и открывает их в свернутом виде после перезапуска, или остановки и затем запуска.
 Понимает все типы путей, с поддержкой в путях кириллицы, спецсимволов и пробелов.

.EXAMPLE
    ReStart-Explorer

    Описание
    --------
    Запуск или перезапуск проводника. Зависит от ситуации.

.EXAMPLE
    ReStart-Explorer -Stop -Verbose

    Описание
    --------
    Остановка процесса проводника, если он существует.
    С отображением происходящих действий.


.NOTES
 ==================================================
      Автор:  westlife (ru-board)  Версия: 1.0
       Дата:  17-11-2018
 ==================================================

#>
Function ReStart-Explorer {

    [CmdletBinding( SupportsShouldProcess = $false, DefaultParameterSetName = 'All' )]
    Param (
        [Parameter( Mandatory = $false, Position = 0, ParameterSetName = 'Stop' )]
        [switch] $Stop
       ,
        [Parameter( Mandatory = $false, Position = 1, ParameterSetName = 'DoNot' )]
        [switch] $DoNotOpenWindows
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    # Проверка существования утилиты для корректного завершения процесса проводника "Gracefully"
    $text = if ( $L.s1 ) { $L.s1 } else { "Не будет корректного перезапуска проводника!`n Не найдена утилита" }
    if ( -not ( [System.IO.File]::Exists($ExitExplorerExe) ))
    { Write-Warning "`n   $NameThisFunction`: $text`: '$ExitExplorerExe'`n" }

    # Если есть процессы с именем Explorer.
    if ( [System.Diagnostics.Process]::GetProcessesByName('Explorer').Count )
    {
        Write-Verbose "Сохраняем все открытые окна Проводника"

        Set-Variable -Name OpenedFolders -Value ([psobject] $null) -Scope Global -Option AllScope -Force -ErrorAction SilentlyContinue
        [psobject] $Global:OpenedFolders = { (New-Object -ComObject Shell.Application).Windows() | ForEach-Object -Process { $_.Document.Folder.Self.Path } }.Invoke()

        Write-Verbose "Закрываем все окна Проводника"

        # Закрываем все открытые окна проводника, так как ExitExplorer.exe не всегда закрывает все окна.
        [psobject] $ShellWindows = (New-Object -ComObject Shell.Application).Windows() |
            Where-Object { ( $null -ne $_.FullName ) -and ( $_.FullName.ToLower().EndsWith('explorer.exe')) }
        ForEach-Object -InputObject $ShellWindows { try { $_.Quit() } catch {} }
        Start-Sleep -Milliseconds 200

        # Завершаем процесс проводника корректно, с необходимыми задержками.
        # И принудительно завершаем последний процесс проводника, который выполняет проверочные действия перед выходом.
        # Повторяем пока есть запущенные процессы проводника, но не больше 3 раз.
        [int] $TryExit = 0
        do
        {
            Write-Verbose "$TryExit. Завершаем процесс Проводника"

            try { & $ExitExplorerExe } catch {}
            Start-Sleep -Milliseconds 1000
            taskkill /f /IM Explorer.exe *> $null
            Start-Sleep -Milliseconds 1000
            $TryExit++
        }
        until (( $TryExit -eq 3 ) -or ( -not ( [System.Diagnostics.Process]::GetProcessesByName('Explorer').Count ) ))

        # Если процесс проводника все еще существует, вывести предупреждение
        $text = if ( $L.s2 ) { $L.s2 } else { "Завершить процесс проводника не удалось!" }
        if ( [System.Diagnostics.Process]::GetProcessesByName('Explorer').Count ) { Write-Warning "$text" }
    }
    else { Write-Verbose "Нет процессов Проводника" }

    # Если не указано остановить процесс, выполняем запуск проводника, повторяя, пока не запустится.
    if ( -not $Stop )
    {
        Write-Verbose "Указано запустить Проводник после его завершения"

        while ( -not ( [System.Diagnostics.Process]::GetProcessesByName('Explorer').Count ))
        {
           Write-Verbose "Запускаем Проводник, пока не будет запущен"
           try { Start-Process -FilePath Explorer -ErrorAction SilentlyContinue } catch {}
           Start-Sleep -Milliseconds 400
        }

        if ( -not $DoNotOpenWindows -and $Global:OpenedFolders.Count )
        {
            Write-Verbose "Открываем обратно все открытые папки в свёрнутом виде"

            foreach ( $OpenedFolder in $Global:OpenedFolders | Sort-Object -Unique )
            {
                if (( $OpenedFolder -like '::{*}') )
                {
                    # Открывает пути вида: Shell:::{GUID}
                    try { Start-Process -WindowStyle Minimized -FilePath "$env:windir\Explorer.exe" -ArgumentList "/e,shell:$OpenedFolder" -ErrorAction SilentlyContinue } catch {}
                }
                elseif (( Test-Path -PathType Container -Path $OpenedFolder -ErrorAction SilentlyContinue ))
                {
                    # Открывает пути с поддержкой в путях кириллицы, спецсимволов и пробелов
                    try { Start-Process -WindowStyle Minimized -FilePath "$env:windir\Explorer.exe" -ArgumentList "/e,""$OpenedFolder""" -ErrorAction SilentlyContinue } catch {}
                }
            }

            Remove-Variable -Name OpenedFolders -Scope Global -Force -ErrorAction SilentlyContinue
        }
    }
    else { Write-Verbose "Процесс Проводника остановлен" }
}
