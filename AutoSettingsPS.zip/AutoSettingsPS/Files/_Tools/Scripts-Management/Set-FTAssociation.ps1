﻿
<#
.SYNOPSIS
 Функция для назначения файловых ассоциаций, с возможностью регистрации программы.

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS
 Поддержка от Windows 10 17763 x64/x86 (1809)
 
 Используется функция Set-Reg для установки параметров реестра, с проверкой и выводом результата.

 Корректное назначение, с правильной генерацией Hash и установкой запрета доступа на изменение на раздел реестра расширения.
 После назначения не предлагается выбрать приложение при открытии файла.
 Возможна Регистрация портабельной программы, если указать путь вместо ProgId. 
 Без использования утилит.
 Поддерживаются системные переменные в пути к файлам, например: %ProgramFiles(x86)% или %SystemDrive%


.PARAMETER Extension
 Указать расширение или протокол

.PARAMETER ProgId
 Можно указать ID программы для расширения. Его нужно знать. ID существует если приложение установлено и было назначено хотябы один раз.
 У каждой программы и под каждое расширение ID может отличаться.
 Или указать путь до портабельной программы для полной регистрации.
 В этом случае ProgId создается из имени файла exe + расширение в верхнем регистре, пример: AkelPad.TXT
 Такой ProgId для того, чтобы на каждое расширение можно было указать свою иконку.
 Путь к программе указывать в кавычках, если есть пробелы.

.PARAMETER Icon
 Указать иконку для конкретного расширения, только если указан путь до программы, чтобы можно было сгенерировать правильный ProgId
 При указании пути до портабельного браузера будет только одна иконка, вот для этих протоколов/расширений: http/https/ftp/.htm/.html/.shtml/.xht/.xhtml
 Если вы сами указываете ProgId и один на все расширения, то указанная иконка будет одна на все файлы назначенные на этот ProgId, которая была назначена последней.
 Путь к иконке всегда указывать в кавычках, если есть пробелы или указан индекс иконки через запятую.
 Чтобы удалить ошибочно назначенную иконку, применить повторно, с указанием вместо файла иконки такой строки: RemoveIcon

.EXAMPLE
    Set-FTAssociation -Extension .txt -ProgPath "%ProgramFiles(x86)%\AkelPad\AkelPad.exe" -Icon "%ProgramFiles(x86)%\AkelPad\AkelPad.exe,0"

.EXAMPLE
    Set-FTAssociation .inf Applications\AkelPad.exe

.EXAMPLE
    Set-FTAssociation .inf Applications\AkelPad.exe RemoveIcon

.EXAMPLE
    Set-FTAssociation .jpg PhotoViewer.FileAssoc.Jpeg  # Если восстановлен PhotoViewer

.EXAMPLE
    Set-FTAssociation -Protocol http -ProgId IE.HTTP  # Установка на открытие протокола http через IE

.EXAMPLE
    Set-FTAssociation https IE.HTTPS
    Set-FTAssociation http  IE.HTTP
    Set-FTAssociation .html IE.AssocFile.HTM
    Set-FTAssociation .htm  IE.AssocFile.HTM
    
    Set-FTAssociation http  -ProgPath "C:\Firefox.ESR.x64.LibPortablePlus\core\firefox.exe"
    Set-FTAssociation https -ProgPath "C:\Firefox.ESR.x64.LibPortablePlus\core\firefox.exe"
    Set-FTAssociation .html -ProgPath "C:\Firefox.ESR.x64.LibPortablePlus\core\firefox.exe"
    Set-FTAssociation .htm  -ProgPath "C:\Firefox.ESR.x64.LibPortablePlus\core\firefox.exe"

    Set-FTAssociation .jpg  -ProgPath "C:\FSViewer75\FSViewer.exe" -Icon "C:\FSViewer75\FSViewer.exe,0"
    Set-FTAssociation .jpeg -ProgPath "C:\FSViewer75\FSViewer.exe" -Icon "C:\FSViewer75\FSViewer.exe,0"
    Set-FTAssociation .jpe  -ProgPath "C:\FSViewer75\FSViewer.exe" -Icon "C:\FSViewer75\FSViewer.exe,0"
    Set-FTAssociation .bmp  -ProgPath "C:\FSViewer75\FSViewer.exe" -Icon "C:\FSViewer75\FSViewer.exe,0"
    Set-FTAssociation .dib  -ProgPath "C:\FSViewer75\FSViewer.exe" -Icon "C:\FSViewer75\FSViewer.exe,0"
    Set-FTAssociation .png  -ProgPath "C:\FSViewer75\FSViewer.exe" -Icon "C:\FSViewer75\FSViewer.exe,0"
    
    Set-FTAssociation .tif  "C:\FSViewer75\FSViewer.exe" "C:\FSViewer75\FSViewer.exe,0"
    Set-FTAssociation .tiff "C:\FSViewer75\FSViewer.exe" "C:\FSViewer75\FSViewer.exe,0"

    Set-FTAssociation .inf Applications\AkelPad.exe
    Set-FTAssociation .csv Applications\AkelPad.exe
    Set-FTAssociation .txt Applications\AkelPad.exe
    Set-FTAssociation .ini Applications\AkelPad.exe
    Set-FTAssociation .log Applications\AkelPad.exe RemoveIcon

    Set-FTAssociation .cab CABFolder
    Set-FTAssociation .cab CABFolder -Icon "%SystemRoot%\system32\cabview.dll,0" 

    # Для открытия через Microsoft.Windows.Photos
    Set-FTAssociation .bmp  -ProgId AppX43hnxtbyyps62jhe9sqpdzxn1790zetc

    # Если уже был назначен хотябы один раз Windows, иначе надо настраивать с путями к exe, как с портабл программами
    Set-FTAssociation http MSEdgeHTM
    Set-FTAssociation https MSEdgeHTM
    Set-FTAssociation .htm MSEdgeHTM
    Set-FTAssociation .html MSEdgeHTM



.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      инфо:  За основу взяты скрипты: https://github.com/DanysysTeam/PS-SFTA | https://github.com/default-username-was-already-taken/set-fileassoc
      Дата:  04-03-2021
 ===============================================

#>
Function Set-FTAssociation {

    [CmdletBinding()]
    Param(
        [Parameter( Mandatory = $false, Position = 0 )]
        [Alias( 'Protocol' )]
        [String] $Extension
       ,
        [Parameter( Mandatory = $false, Position = 1 )]
        [Alias( 'ProgPath' )]
        [String] $ProgId
       ,
        [Parameter( Mandatory = $false, Position = 2 )]
        [String] $Icon
    )

    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    #region Check variable

    if ( -not ( $Extension -and $ProgId ))
    { Write-Warning "$NameThisFunction`: You must specify Extension and ProgId" ; Return }

    # Раскрытие переменных, если они есть
    $ProgId = [System.Environment]::ExpandEnvironmentVariables($ProgId)

    # Если в ProgId указали путь к программе и она найдена, а если не найдена вывести поредупреждение и выйти из функции
    if ( $ProgId.Contains(':') -and [System.IO.File]::Exists($ProgId) )
    {
        # Назначение пути к программе и генерация ProgId, с установкой только первой буквы в верхний регистр
        # для красоты, чтобы не затрагивать другие буквы с разными типами регистра.
        $RegisterProgPath = $ProgId
        $FileEXE  = [System.IO.Path]::GetFileName($RegisterProgPath) -Replace ('\s','')
        $FileEXE  = "{0}{1}" -f $FileEXE.Substring(0, 1).ToUpperInvariant(), $FileEXE.Remove(0, 1)
        $FileName = [System.IO.Path]::GetFileNameWithoutExtension($FileEXE)
        $ProgId   = "$FileName{0}" -f $Extension.ToUpper()
    }
    elseif ( $ProgId.Contains(':') )
    {
        Write-Warning "$NameThisFunction`: Program not exist: $ProgId" ; Return
    }

    # Если не указан путь к программе
    if ( -not $RegisterProgPath )
    {
        try   { $OpenSubKey = [Microsoft.Win32.Registry]::ClassesRoot.OpenSubKey($ProgID,'ReadSubTree','QueryValues') }
        catch { $OpenSubKey = $null }
        
        # Если указанный ProgID не зарегистрирован, то выйти из функции 
        if ( -not $OpenSubKey.Name ) { Write-Warning "$NameThisFunction`: ProgID not registered: '$ProgID'" ; Return }
        else { $OpenSubKey.Close() }
    }

    if ( $Icon )
    {
        if ( $Icon -ne 'RemoveIcon' -and $Icon -ne '%1' )
        {
            # Раскрытие переменных
            $Icon     = [System.Environment]::ExpandEnvironmentVariables($Icon)
            $IconFile = @($Icon.Split(','))[0].Trim()

            # Если файл иконки не найден, вывести предупреждение, обнулить иконку и продолжить
            if ( -not [System.IO.File]::Exists($IconFile) -and $IconFile -notlike '*ms-resource://*' )
            {
                $Icon = ''
                Write-Warning "$NameThisFunction`: Icon File not exist: $IconFile"
            }
        }
    }

    # Глобальное Отключение разрешения перенаправления для настройки реестра у дефолтного профиля, если он настраивается
    @($Global:DataLocalUsers.Where({ $_.Redirects },'First')).ForEach({ $_.Redirects.DefaultAccount = $false })

    Write-Verbose "             Ext: $Extension"
    Write-Verbose "          ProgId: $ProgId"
    Write-Verbose "         FileEXE: $FileEXE"
    Write-Verbose "        FileName: $FileName"
    Write-Verbose "RegisterProgPath: $RegisterProgPath"
    Write-Verbose "            Icon: $Icon"

    #endregion Check variable

    #region func

    # C#; Используется часть кода для получения времени последней записи в раздел и удаление раздела.
    $RegistryUtils = @'
using System;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Text;
using Microsoft.Win32;
using FILETIME = System.Runtime.InteropServices.ComTypes.FILETIME;

namespace RegistryUtils
{
    public static class Action
    {
        [DllImport("advapi32.dll", CharSet = CharSet.Auto)]
        private static extern int RegOpenKeyEx(UIntPtr hKey, string subKey, int ulOptions, int samDesired, out UIntPtr hkResult);

        [DllImport("advapi32.dll", SetLastError = true)]
        private static extern int RegCloseKey(UIntPtr hKey);

        [DllImport("advapi32.dll", SetLastError=true, CharSet = CharSet.Unicode)]
        private static extern uint RegDeleteKey(UIntPtr hKey, string subKey);

        [DllImport("advapi32.dll", EntryPoint = "RegQueryInfoKey", CallingConvention = CallingConvention.Winapi, SetLastError = true)]
        private static extern int RegQueryInfoKey(UIntPtr hkey, out StringBuilder lpClass, ref uint lpcbClass, IntPtr lpReserved,
            out uint lpcSubKeys, out uint lpcbMaxSubKeyLen, out uint lpcbMaxClassLen, out uint lpcValues, out uint lpcbMaxValueNameLen,
            out uint lpcbMaxValueLen, out uint lpcbSecurityDescriptor, ref FILETIME lpftLastWriteTime);

        [DllImport("advapi32.dll", ExactSpelling = true, SetLastError = true)]
        internal static extern bool OpenProcessToken(IntPtr h, int acc, ref IntPtr phtok);

        [DllImport("kernel32.dll", ExactSpelling = true)]
        internal static extern IntPtr GetCurrentProcess();

        [DllImport("advapi32.dll", SetLastError = true)]
        internal static extern bool LookupPrivilegeValue(string host, string name, ref long pluid);

        [DllImport("advapi32.dll", ExactSpelling = true, SetLastError = true)]
        internal static extern bool AdjustTokenPrivileges(IntPtr htok, bool disall, ref TokPriv1Luid newst, int len, IntPtr prev, IntPtr relen);

        [DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern int RegLoadKey(uint hKey, string lpSubKey, string lpFile);

        [DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern int RegUnLoadKey(uint hKey, string lpSubKey);

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        internal struct TokPriv1Luid
        {
            public int Count;
            public long Luid;
            public int Attr;
        }

        public static void DeleteKey(RegistryHive registryHive, string subkey)
        {
            UIntPtr hKey = UIntPtr.Zero;

            try
            {
                var hive = new UIntPtr(unchecked((uint)registryHive));
                RegOpenKeyEx(hive, subkey, 0, 0x20019, out hKey);
                RegDeleteKey(hive, subkey);
            }
            finally
            {
                if (hKey != UIntPtr.Zero)
                {
                    RegCloseKey(hKey);
                }
            }
        }

        private static DateTime ToDateTime(FILETIME ft)
        {
            IntPtr buf = IntPtr.Zero;
            try
            {
                long[] longArray = new long[1];
                int cb = Marshal.SizeOf(ft);
                buf = Marshal.AllocHGlobal(cb);
                Marshal.StructureToPtr(ft, buf, false);
                Marshal.Copy(buf, longArray, 0, 1);
                return DateTime.FromFileTime(longArray[0]);
            }
            finally
            {
                if (buf != IntPtr.Zero) Marshal.FreeHGlobal(buf);
            }
        }

        public static DateTime? GetLastModified(RegistryHive registryHive, string subKey)
        {
            var lastModified = new FILETIME();
            var lpcbClass = new uint();
            var lpReserved = new IntPtr();
            UIntPtr hKey = UIntPtr.Zero;

            try
            {
                try
                {
                    var hive = new UIntPtr(unchecked((uint)registryHive));
                    if (RegOpenKeyEx(hive, subKey, 0, (int)RegistryRights.ReadKey, out hKey) != 0)
                    {
                        return null;
                    }

                    uint lpcbSubKeys;
                    uint lpcbMaxKeyLen;
                    uint lpcbMaxClassLen;
                    uint lpcValues;
                    uint maxValueName;
                    uint maxValueLen;
                    uint securityDescriptor;
                    StringBuilder sb;
                    
                    if (RegQueryInfoKey(hKey, out sb, ref lpcbClass, lpReserved, out lpcbSubKeys, out lpcbMaxKeyLen, out lpcbMaxClassLen,
                        out lpcValues, out maxValueName, out maxValueLen, out securityDescriptor, ref lastModified) != 0)
                    {
                        return null;
                    }

                    var result = ToDateTime(lastModified);
                    return result;
                }
                finally
                {
                    if (hKey != UIntPtr.Zero)
                    {
                        RegCloseKey(hKey);
                    }
                }
            }
            catch (Exception)
            {
                return null;
            }
        }

        internal const int SE_PRIVILEGE_DISABLED = 0x00000000;
        internal const int SE_PRIVILEGE_ENABLED = 0x00000002;
        internal const int TOKEN_QUERY = 0x00000008;
        internal const int TOKEN_ADJUST_PRIVILEGES = 0x00000020;

        public enum RegistryHives : uint
        {
            HKEY_USERS = 0x80000003,
            HKEY_LOCAL_MACHINE = 0x80000002
        }

        public static void AddPrivilege(string privilege)
        {
            bool retVal;
            TokPriv1Luid tp;
            IntPtr hproc = GetCurrentProcess();
            IntPtr htok = IntPtr.Zero;
            retVal = OpenProcessToken(hproc, TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, ref htok);
            tp.Count = 1;
            tp.Luid = 0;
            tp.Attr = SE_PRIVILEGE_ENABLED;
            retVal = LookupPrivilegeValue(null, privilege, ref tp.Luid);
            retVal = AdjustTokenPrivileges(htok, false, ref tp, 0, IntPtr.Zero, IntPtr.Zero);
            ///return retVal;
        }

        public static int LoadHive(RegistryHives hive, string subKey, string filePath)
        {
            AddPrivilege("SeRestorePrivilege");
            AddPrivilege("SeBackupPrivilege");

            uint regHive = (uint)hive;
            
            int result = RegLoadKey(regHive, subKey, filePath);

            return result;
        }

        public static int UnloadHive(RegistryHives hive, string subKey)
        {
            AddPrivilege("SeRestorePrivilege");
            AddPrivilege("SeBackupPrivilege");

            uint regHive = (uint)hive;
            
            int result = RegUnLoadKey(regHive, subKey);

            return result;
        }  
    }
}
'@
    if ( -not ( 'RegistryUtils.Action' -as [type] )) { Add-Type -TypeDefinition $RegistryUtils -ErrorAction Stop }

    Function Refresh-Explorer {

        $Code = @'
using System;
using System.Runtime.InteropServices;

namespace Explorer
{
    public class RefreshRegistry
    {
        [System.Runtime.InteropServices.DllImport("Shell32.dll", CharSet = CharSet.Auto, SetLastError = false)]
        private static extern int SHChangeNotify(int eventId, int flags, IntPtr item1, IntPtr item2);
        public static void Refresh() {
            SHChangeNotify(0x8000000, 0, IntPtr.Zero, IntPtr.Zero);
        }
    }
}
'@
        try { if ( -not ( 'Explorer.RefreshRegistry' -as [type] )) { Add-Type -TypeDefinition $Code -ErrorAction Stop } } catch {}

        try { [Explorer.RefreshRegistry]::Refresh() } catch {}
    }

    Function Set-Icon {

        Param(
            [Parameter( Position = 0, Mandatory = $true )] [String] $ProgId
           ,[Parameter( Position = 1, Mandatory = $true )] [String] $Icon
        )

        $Path  = "HKCU:\Software\Classes\$ProgId\DefaultIcon"

        if ( $Icon -ne 'RemoveIcon' )
        {
            $Value = $Icon
            Set-Reg New-ItemProperty -Path $Path -Name '' -Type String $Value
        }
        else
        {
            Set-Reg Remove-ItemProperty -Path $Path -Name ''
        }
    }

    # Профили
    [array] $Accs = [PSCustomObject] @{ 
        Root = 'HKCU:'
        SID  = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    }

    if ( $Global:DataLocalUsers.Redirects.Value )
    {
        @($Global:DataLocalUsers.Where({ $_.Use -and $_.ProfileType -eq 'User' -and $_.Profile -and $_.SID })).ForEach({
            
            $Accs += [PSCustomObject] @{
                Root = $_.SID
                SID  = $_.SID
            }
        })
    }
    
    [array] $Script:RegisteredProgIDs = @() # Для Регистрации всех ProgID для указанного расширения в ApplicationAssociationToasts

    Function Remove-UserChoiceKey {

        Param(
            [Parameter( Position = 0, Mandatory = $true )] [String] $SubKey
        )

        foreach ( $Acc in $Accs )
        {
            if ( $Acc.Root -eq 'HKCU:' )
            {
                $RegHive = [Microsoft.Win32.RegistryHive]::CurrentUser
                $isSubKey = $SubKey
            }
            else
            {
                $RegHive = [Microsoft.Win32.RegistryHive]::Users
                $isSubKey = "$($Acc.Root)\$SubKey"
            }
            
            # удаляет, не смотря на конкретные запреты доступа для текущего пользователя, хоть он и админ. Если есть доступ к разделу уровня текущей оболочки.
            # Оставлено это удаление, чтобы функция Set-Reg не тратила время на получение имперсонейшн от System, при ошибке удаления в первый раз
            try { [RegistryUtils.Action]::DeleteKey($RegHive,$isSubKey) } catch {}
        }

        $Path = "HKCU:\$SubKey"
        Set-Reg Remove-Item -Path $Path
    }

    Function Set-UserAccessKey {

        Param(
            [Parameter( Position = 0, Mandatory = $true )] [String] $SubKey
        )

        foreach ( $Acc in $Accs )
        {
            if ( $Acc.Root -eq 'HKCU:' )
            {
                $RegRoot  = [Microsoft.Win32.Registry]::CurrentUser
                $isSubKey = $SubKey
            }
            else
            {
                $RegRoot  = [Microsoft.Win32.Registry]::Users
                $isSubKey = "$($Acc.Root)\$SubKey"
            }

            try
            {
                $OpenSubKey = $RegRoot.OpenSubKey($isSubKey,'ReadWriteSubTree','TakeOwnership')

                if ( $OpenSubKey )
                {
                    $Acl = [System.Security.AccessControl.RegistrySecurity]::new()
                    $UserSID = $Acc.SID
                    $Acl.SetSecurityDescriptorSddlForm("O:$UserSID`G:$UserSID`D:AI(D;;DC;;;$UserSID)")
                    try { $OpenSubKey.SetAccessControl($Acl) } catch {}
                    $OpenSubKey.Close()
                }

                Write-Verbose "Set User Access Ok: HKCU:\$isSubKey"
            }
            catch { Write-Warning "$NameThisFunction`: Set User Access FAIL: HKCU:\$isSubKey" }
        }
    }

    Function Write-ExtensionKeys {

        Param(
            [Parameter( Position = 0, Mandatory = $true )] [String] $ProgId
           ,[Parameter( Position = 1, Mandatory = $true )] [String] $Extension
        )

        $OrigProgID = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\SOFTWARE\Classes\$Extension",'',$null)

        if ( $OrigProgID )
        {
            # Сохранить историю возможных ProgId с Extension или protocol для системного ProgID
            $Script:RegisteredProgIDs += $OrigProgID
        }

        # Для Extension и protocol
        # Сохранить историю возможных ProgId с Extension или protocol
        $Name = "{0}" -f [System.IO.Path]::GetFileName($ProgId)
        $Script:RegisteredProgIDs += $Name

        if ( $ProgId -ne $Name )
        {
            $Script:RegisteredProgIDs += $ProgId
        }
        
        # Если нет системного ProgId, задать указанный ProgId для расширения
        if ( -not $OrigProgID )
        {
            $Path  = "HKCU:\Software\Classes\$Extension"
            $Value = $ProgId
            Set-Reg New-ItemProperty -Path $Path -Name '' -Type String $Value
        }
        
        # Задать указанный ProgId в варианты возможных для назначения
        $Path = "HKCU:\Software\Classes\$Extension\OpenWithProgids"
        $Name = $ProgId
        Set-Reg New-ItemProperty -Path $Path -Name $Name -Type None ([byte[]]@())

        # Задать системный ProgId в параметры расширения для проводника в варианты возможных для назначения, а если его нет, то указанный ProgId
        $Path = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\$Extension\OpenWithProgids"
        if ( $OrigProgID )
        {
            $Name = $OrigProgID
            Set-Reg New-ItemProperty -Path $Path -Name $Name -Type None ([byte[]]@())
        }

        $Name = $ProgID
        Set-Reg New-ItemProperty -Path $Path -Name $Name -Type None ([byte[]]@())

        # удаление раздела UserChoice
        $Subkey = "Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\$Extension\UserChoice"
        $Path   = "HKCU:\$Subkey"
        Remove-UserChoiceKey -SubKey $Subkey

        # Установка параметров в UserChoice, раздел создается автоматически
        $Value = $ProgId
        Set-Reg New-ItemProperty -Path $Path -Name 'ProgId' -Type String $Value

        foreach ( $Acc in $Accs )
        {
            if ( $Acc.Root -eq 'HKCU:' )
            {
                $RegRoot  = [Microsoft.Win32.Registry]::CurrentUser
                $RegHive  = [Microsoft.Win32.RegistryHive]::CurrentUser
                $isRoot   = $Acc.Root
                $isSubKey = $Subkey
            }
            else
            {
                $RegRoot  = [Microsoft.Win32.Registry]::Users
                $RegHive  = [Microsoft.Win32.RegistryHive]::Users
                $isRoot   = "Registry::HKU"
                $isSubKey = "$($Acc.Root)\$SubKey"
            }

            # Получение хэша на основе времени последней модификации раздела, после создания и установки первого параметра
            $ProgHash = Get-Hash -ProgId $ProgId -Extension $Extension -SubKey $isSubKey -SID $Acc.SID -HIVE $RegHive

            $Path  = "$isRoot\$isSubKey"
            $Value = $ProgHash

            Set-Reg New-ItemProperty -Path $Path -Name 'Hash' -Type String $Value -OnlyThisPath
        }

        # Установка запрета на изменение на раздел UserChoice, который ставит винда при назначении
        Set-UserAccessKey -SubKey $Subkey
    }

    Function Write-ProtocolKeys {

        Param(
            [Parameter( Position = 0, Mandatory = $true )] [String] $ProgId
           ,[Parameter( Position = 1, Mandatory = $true )] [String] $Protocol
        )
        
        $SubKey = "Software\Microsoft\Windows\Shell\Associations\UrlAssociations\$Protocol\UserChoice"
        $Path   = "HKCU:\$SubKey"

        # удаление раздела UserChoice протокола
        Remove-UserChoiceKey -SubKey $Subkey

        # Установка параметров в UserChoice протокола (запрет на раздел устанавливать не надо)
        $Value = $ProgId
        Set-Reg New-ItemProperty -Path $Path -Name 'ProgId' -Type String $Value

        foreach ( $Acc in $Accs )
        {
            if ( $Acc.Root -eq 'HKCU:' )
            {
                $RegRoot  = [Microsoft.Win32.Registry]::CurrentUser
                $RegHive  = [Microsoft.Win32.RegistryHive]::CurrentUser
                $isRoot   = $Acc.Root
                $isSubKey = $SubKey
            }
            else
            {
                $RegRoot  = [Microsoft.Win32.Registry]::Users
                $RegHive  = [Microsoft.Win32.RegistryHive]::Users
                $isRoot   = "Registry::HKU"
                $isSubKey = "$($Acc.Root)\$SubKey"
            }

            # Получение хэша на основе времени последней модификации раздела, после создания и установки первого параметра
            $ProgHash = Get-Hash -ProgId $ProgId -Extension $Extension -SubKey $isSubKey -SID $Acc.SID -HIVE $RegHive

            $Path  = "$isRoot\$isSubKey"
            $Value = $ProgHash

            Set-Reg New-ItemProperty -Path $Path -Name 'Hash' -Type String $Value -OnlyThisPath
        }
    }

    # Регистрация расширения со всеми зарегистрированными ProgID
    Function Add-Registered-ProgID {

        Param(
           [Parameter( Position = 0, Mandatory = $true )] [String] $Extension
        )

        if ( $Extension.Contains('.') ) { [string] $Assocs = 'FileAssociations' } else { [string] $Assocs = 'UrlAssociations' }

        [string] $RegKey = 'SOFTWARE\RegisteredApplications'

        try { $OpenRegKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($RegKey, 'ReadSubTree','QueryValues') } catch {}

        if ( $OpenRegKey )
        {
            foreach ( $ValueName in $OpenRegKey.GetValueNames() )
            {
                $Subkey = $OpenRegKey.GetValue($ValueName,$null)

                if ( $Subkey )
                {
                    try { $OpenKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey("$Subkey\$Assocs", 'ReadSubTree','QueryValues') } catch {}
            
                    if ( $OpenKey )
                    {
                        $isProgID = $Openkey.GetValue($Extension,$null)

                        if ( $isProgID )
                        {
                            $Script:RegisteredProgIDs += $isProgID
                        }

                        $Openkey.Close()
                    }
                }
            }

            $OpenRegKey.Close()
        }

        foreach ( $Acc in $Accs )
        {
            if ( $Acc.Root -eq 'HKCU:' )
            {
                $RegRoot  = [Microsoft.Win32.Registry]::CurrentUser
                $isRoot   = $Acc.Root
                $isRegKey = $RegKey
            }
            else
            {
                $RegRoot  = [Microsoft.Win32.Registry]::Users
                $isRoot   = "Registry::HKU\$($Acc.Root)"
                $isRegKey = "$($Acc.Root)\$RegKey"
            }

            $OpenRegKey = $RegRoot.OpenSubKey($isRegKey, 'ReadSubTree','QueryValues')

            [array] $UserRegisteredProgIDs = @()

            if ( $OpenRegKey )
            {
                foreach ( $ValueName in $OpenRegKey.GetValueNames() )
                {
                    $Subkey = $OpenRegKey.GetValue($ValueName,$null)

                    if ( $Subkey )
                    {
                        $OpenKey = $RegRoot.OpenSubKey("$Subkey\$Assocs", 'ReadSubTree','QueryValues')
            
                        if ( $OpenKey )
                        {
                            $isProgID = $Openkey.GetValue($Extension,$null)

                            if ( $isProgID )
                            {
                                $UserRegisteredProgIDs += $isProgID
                            }

                            $Openkey.Close()
                        }
                    }
                }

                $OpenRegKey.Close()
            }

            $UserRegisteredProgIDs = ( $Script:RegisteredProgIDs + $UserRegisteredProgIDs | Sort-Object -Unique )

            foreach ( $UserProgID in $UserRegisteredProgIDs )
            {
                $Path = "$isRoot\Software\Microsoft\Windows\CurrentVersion\ApplicationAssociationToasts"
                $Name = "$UserProgID`_$Extension"

                Set-Reg New-ItemProperty -Path $Path -Name $Name -Type DWord 0 -OnlyThisPath
            }
        }
    }

    Function Write-AdditionalKeys {

        Param(
            [Parameter( Position = 0, Mandatory = $true )] [String] $ProgId
           ,[Parameter( Position = 1, Mandatory = $true )] [String] $Extension
        )

        # Все эти параметры для соблюдения основных условий, для предотвращения сброса в будущем назначенного приложения на расширение.
        
        $OrigProgID = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\SOFTWARE\Classes\$Extension",'',$null)

        # Для Extension и protocol
        # Если есть системный ProgId для расширения или протокола, то записать его в уже настроенное по умолчанию 
        if ( $OrigProgID )
        {
            $Path = "Registry::HKU\.DEFAULT\Software\Microsoft\Windows\CurrentVersion\FileAssociations\ProgIds"
            $Name = "_$Extension"
            Set-Reg New-ItemProperty -Path $Path -Name $Name -Type DWord 1
        }

        # Только Extension. 
        if ( $Extension.Contains('.') )
        {
            [bool] $isEdge = $false

            foreach ( $Acc in $Accs )
            {
                if ( $Acc.Root -eq 'HKCU:' )
                {
                    $RegRoot  = [Microsoft.Win32.Registry]::CurrentUser
                    $RegHive  = 'HKEY_CURRENT_USER'
                    $isRoot   = $Acc.Root
                    $isRegKey = "Software\Classes"
                }
                else
                {
                    $RegRoot  = [Microsoft.Win32.Registry]::Users
                    $RegHive  = 'HKEY_USERS'
                    $isRoot   = "Registry::HKU"
                    $isRegKey = "$($Acc.Root)_Classes"
                }

                # Установка 'NoOpenWith' для всех зарегистрированных ProgID у расширения от Appx. Это не скрывает приложение из выбора.  
                try { [psobject] $OpenSubkey = $RegRoot.OpenSubKey("$isRegKey\$Extension\OpenWithProgids",'ReadSubTree','QueryValues') }
                catch { [psobject] $OpenSubkey = $null }

                if ( $OpenSubkey )
                {
                    foreach ( $AppxProgID in ( $OpenSubkey.GetValueNames() -like 'AppX*' ))
                    {
                        # Если приложение установлено            
                        if ( [Microsoft.Win32.Registry]::GetValue("$RegHive\$isRegKey\$AppxProgID\Shell\open",'PackageId',$null) )
                        {
                            $Path = "$isRoot\$isRegKey\$AppxProgID"
                            
                            if ( $ProgId -like '*edge*' ) { $isEdge = $true } else { $isEdge = $false }

                            # Если указанный ProgId для назначения равен найденному ProgId от установленного UWP
                            if (( $ProgId -eq $AppxProgID ) -or $isEdge )
                            {
                                # Удаление запретов назначения для этого UWP
                                Set-Reg Remove-ItemProperty -Path $Path -Name 'NoOpenWith' -OnlyThisPath
                                Set-Reg Remove-ItemProperty -Path $Path -Name 'NoStaticDefaultVerb' -OnlyThisPath
                            }
                            else
                            {
                                # Иначе, Запрет открытия файлов этим App, чтобы не сбрасывались ассоциации на него. Это не мешает назначить на открытие этим Apps
                                # только исчезает галочка (всегда использовать) при настройке на отдельные расширения, если для него назначено это приложение
                                Set-Reg New-ItemProperty -Path $Path -Name 'NoOpenWith' -Type String '' -OnlyThisPath
                            }

                            $Script:RegisteredProgIDs += $AppxProgID
                        }
                    }

                    $OpenSubkey.Close()
                }
            }

            # Восстановление необходимых параметров для расширений графических файлов
            if ( 'picture' -eq [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\KindMap",$Extension,$null) -and 
                 [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\SOFTWARE\Classes\PBrush\CLSID",'',$null) )
            {
                $Script:RegisteredProgIDs += 'PBrush'
            }
        }

        # Регистрация всех нужных и дополнительно полученных далее ProgID для этого расширения в ApplicationAssociationToasts
        Add-Registered-ProgID -Extension $Extension
    }

    Function Get-Hash {

        [CmdletBinding()]
        [OutputType([string])]
        Param(
            [Parameter( Position = 0, Mandatory = $true )] [String] $ProgId
           ,[Parameter( Position = 1, Mandatory = $true )] [String] $Extension
           ,[Parameter( Position = 2, Mandatory = $true )] [String] $SubKey
           ,[Parameter( Position = 3, Mandatory = $true )] [String] $SID
           ,[Parameter( Position = 4, Mandatory = $true )] [String] $HIVE
        )

        # C# код для генерации хэша
        $PatentHash = @'
using System;

namespace FileAssoc
{
    public static class PatentHash
    {
        public static uint[] WordSwap(byte[] a, int sz, byte[] md5)
        {
            if (sz < 2 || (sz & 1) == 1) {
                throw new ArgumentException(String.Format("Invalid input size: {0}", sz), "sz");
            }

            unchecked {
                uint o1 = 0;
                uint o2 = 0;
                int ta = 0;
                int ts = sz;
                int ti = ((sz - 2) >> 1) + 1;

                uint c0 = (BitConverter.ToUInt32(md5, 0) | 1) + 0x69FB0000;
                uint c1 = (BitConverter.ToUInt32(md5, 4) | 1) + 0x13DB0000;

                for (uint i = (uint)ti; i > 0; i--) {
                    uint n = BitConverter.ToUInt32(a, ta) + o1;
                    ta += 8;
                    ts -= 2;

                    uint v1 = 0x79F8A395 * (n * c0 - 0x10FA9605 * (n >> 16)) + 0x689B6B9F * ((n * c0 - 0x10FA9605 * (n >> 16)) >> 16);
                    uint v2 = 0xEA970001 * v1 - 0x3C101569 * (v1 >> 16);
                    uint v3 = BitConverter.ToUInt32(a, ta - 4) + v2;
                    uint v4 = v3 * c1 - 0x3CE8EC25 * (v3 >> 16);
                    uint v5 = 0x59C3AF2D * v4 - 0x2232E0F1 * (v4 >> 16);

                    o1 = 0x1EC90001 * v5 + 0x35BD1EC9 * (v5 >> 16);
                    o2 += o1 + v2;
                }

                if (ts == 1) {
                    uint n = BitConverter.ToUInt32(a, ta) + o1;

                    uint v1 = n * c0 - 0x10FA9605 * (n >> 16);
                    uint v2 = 0xEA970001 * (0x79F8A395 * v1 + 0x689B6B9F * (v1 >> 16)) -
                              0x3C101569 * ((0x79F8A395 * v1 + 0x689B6B9F * (v1 >> 16)) >> 16);
                    uint v3 = v2 * c1 - 0x3CE8EC25 * (v2 >> 16);

                    o1 = 0x1EC90001 * (0x59C3AF2D * v3 - 0x2232E0F1 * (v3 >> 16)) +
                         0x35BD1EC9 * ((0x59C3AF2D * v3 - 0x2232E0F1 * (v3 >> 16)) >> 16);
                    o2 += o1 + v2;
                }

                uint[] ret = new uint[2];
                ret[0] = o1;
                ret[1] = o2;
                return ret;
            }
        }

        public static uint[] Reversible(byte[] a, int sz, byte[] md5)
        {
            if (sz < 2 || (sz & 1) == 1) {
                throw new ArgumentException(String.Format("Invalid input size: {0}", sz), "sz");
            }

            unchecked {
                uint o1 = 0;
                uint o2 = 0;
                int ta = 0;
                int ts = sz;
                int ti = ((sz - 2) >> 1) + 1;

                uint c0 = BitConverter.ToUInt32(md5, 0) | 1;
                uint c1 = BitConverter.ToUInt32(md5, 4) | 1;

                for (uint i = (uint)ti; i > 0; i--) {
                    uint n = (BitConverter.ToUInt32(a, ta) + o1) * c0;
                    n = 0xB1110000 * n - 0x30674EEF * (n >> 16);
                    ta += 8;
                    ts -= 2;

                    uint v1 = 0x5B9F0000 * n - 0x78F7A461 * (n >> 16);
                    uint v2 = 0x1D830000 * (0x12CEB96D * (v1 >> 16) - 0x46930000 * v1) +
                              0x257E1D83 * ((0x12CEB96D * (v1 >> 16) - 0x46930000 * v1) >> 16);
                    uint v3 = BitConverter.ToUInt32(a, ta - 4) + v2;

                    uint v4 = 0x16F50000 * c1 * v3 - 0x5D8BE90B * (c1 * v3 >> 16);
                    uint v5 = 0x2B890000 * (0x96FF0000 * v4 - 0x2C7C6901 * (v4 >> 16)) +
                              0x7C932B89 * ((0x96FF0000 * v4 - 0x2C7C6901 * (v4 >> 16)) >> 16);

                    o1 = 0x9F690000 * v5 - 0x405B6097 * (v5 >> 16);
                    o2 += o1 + v2;
                }

                if (ts == 1) {
                    uint n = BitConverter.ToUInt32(a, ta) + o1;

                    uint v1 = 0xB1110000 * c0 * n - 0x30674EEF * ((c0 * n) >> 16);
                    uint v2 = 0x5B9F0000 * v1 - 0x78F7A461 * (v1 >> 16);
                    uint v3 = 0x1D830000 * (0x12CEB96D * (v2 >> 16) - 0x46930000 * v2) +
                              0x257E1D83 * ((0x12CEB96D * (v2 >> 16) - 0x46930000 * v2) >> 16);
                    uint v4 = 0x16F50000 * c1 * v3 - 0x5D8BE90B * ((c1 * v3) >> 16);
                    uint v5 = 0x96FF0000 * v4 - 0x2C7C6901 * (v4 >> 16);

                    o1 = 0x9F690000 * (0x2B890000 * v5 + 0x7C932B89 * (v5 >> 16)) -
                         0x405B6097 * ((0x2B890000 * v5 + 0x7C932B89 * (v5 >> 16)) >> 16);
                    o2 += o1 + v2;
                }

                uint[] ret = new uint[2];
                ret[0] = o1;
                ret[1] = o2;
                return ret;
            }
        }

        public static long MakeLong(uint left, uint right) {
           return (long)left << 32 | (long)right;
        }
    }
}
'@
        if ( -not ( 'FileAssoc.PatentHash' -as [type] )) { Add-Type -TypeDefinition $PatentHash -ErrorAction Stop }

        Function Get-KeyLastWriteTime ( $SubKey ) {

            try {
                $LM = [RegistryUtils.Action]::GetLastModified($HIVE,$SubKey)
                $FT = ([DateTime]::New($LM.Year, $LM.Month, $LM.Day, $LM.Hour, $LM.Minute, 0, $LM.Kind)).ToFileTime()

                return [string]::Format("{0:x8}{1:x8}", $FT -shr 32, $FT -band [uint32]::MaxValue)

            } catch {
                Write-Warning "Failed to get last write time for UserChoice subkey: $SubKey"
            }
        }

        # Получение секретной строки: User Choice set via Windows User Experience {D18B6DD5-6124-4341-9318-804003BAFA0B}, пока везде одинаковая
        Function Get-UserExperience {

            [OutputType([string])]

            $userExperienceSearch = "User Choice set via Windows User Experience"
            $user32Path = "$([Environment]::GetFolderPath([Environment+SpecialFolder]::SystemX86))\Shell32.dll"
            $fileStream = [System.IO.File]::Open($user32Path, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
            $binaryReader = New-Object System.IO.BinaryReader($fileStream)
            [Byte[]] $bytesData = $binaryReader.ReadBytes(5mb)
            $fileStream.Close()
            $dataString = [Text.Encoding]::Unicode.GetString($bytesData)
            $position1 = $dataString.IndexOf($userExperienceSearch)
            $position2 = $dataString.IndexOf("}", $position1)

            Return $dataString.Substring($position1, $position2 - $position1 + 1)
        }

        Function Get-DataArray {
        
            [OutputType([array])]

           #$userExperience   = Get-UserExperience
            $userExperience   = 'User Choice set via Windows User Experience {D18B6DD5-6124-4341-9318-804003BAFA0B}'
            $userSid          = $SID
            $KeyLastWriteTime = Get-KeyLastWriteTime $SubKey
            $baseInfo         = ("{0}{1}{2}{3}{4}" -f $Extension, $userSid, $ProgId, $KeyLastWriteTime, $userExperience).ToLowerInvariant()
        
            $StringToUTF16LEArray = [System.Collections.ArrayList]@([System.Text.Encoding]::Unicode.GetBytes($baseInfo))
            $StringToUTF16LEArray += (0,0)

            Return $StringToUTF16LEArray
        }

        Function Get-PatentHash ([byte[]]$A, [byte[]]$MD5) {
    
            [OutputType([string])]

            $Size = $A.Count
            $ShiftedSize = ($Size -shr 2) - ($Size -shr 2 -band 1) * 1

            [uint32[]]$A1 = [FileAssoc.PatentHash]::WordSwap($A, [int]$ShiftedSize, $MD5)
            [uint32[]]$A2 = [FileAssoc.PatentHash]::Reversible($A, [int]$ShiftedSize, $MD5)

            $Ret = [FileAssoc.PatentHash]::MakeLong($A1[1] -bxor $A2[1], $A1[0] -bxor $A2[0])

            Return [System.Convert]::ToBase64String([System.BitConverter]::GetBytes([Int64]$Ret))
        }

        $DataArray = Get-DataArray
        $DataMD5   = [System.Security.Cryptography.HashAlgorithm]::Create("MD5").ComputeHash($DataArray)
        $Hash      = Get-PatentHash $DataArray $DataMD5

        Return $Hash
    }

    #endregion func

    # Далее выполнение действий ....

    # Если надо зарегистрировать Portable программу
    if ( $RegisterProgPath )
    {
        $progCommand = """$RegisterProgPath"" ""%1"""

        # Register Classes\$ProgId
        $Path  = "HKCU:\Software\Classes\$ProgId\shell\open\command"
        $Value = $progCommand
        Set-Reg New-ItemProperty -Path $Path -Name '' -Type String $Value

        $ProgFullName = "$FileName Portable"

        if ( $Extension -match '^(http|https|ftp|microsoft-edge|[.]htm|[.]html|[.]shtml|[.]xht|[.]xhtml|[.]webp)$' )
        {
            # Регистрация Браузера

            $Path  = "HKCU:\Software\Clients\StartMenuInternet\$ProgFullName\Capabilities"
            $Value = $FileName
            Set-Reg New-ItemProperty -Path $Path -Name 'ApplicationName' -Type String $Value
            $Value = $ProgFullName
            Set-Reg New-ItemProperty -Path $Path -Name 'ApplicationDescription' -Type String $Value

            $Path  = "HKCU:\Software\Clients\StartMenuInternet\$ProgFullName\Capabilities\Startmenu"
            Set-Reg New-ItemProperty -Path $Path -Name 'StartMenuInternet' -Type String $Value

            $OpenCommand = """$RegisterProgPath"""

            $Path  = "HKCU:\Software\Clients\StartMenuInternet\$ProgFullName\shell\open\command"
            $Value = $OpenCommand
            Set-Reg New-ItemProperty -Path $Path -Name '' -Type String $Value

            if ( $Extension -match '^([.]htm|[.]html|[.]shtml|[.]xht|[.]xhtml|[.]webp)$' )
            {
                $Path  = "HKCU:\Software\Clients\StartMenuInternet\$ProgFullName\Capabilities\FileAssociations"
                $Name  = $Extension
                $Value = $ProgId
                Set-Reg New-ItemProperty -Path $Path -Name $Name -Type String $Value
            }
            elseif ( $Extension -match '^(http|https|ftp|microsoft-edge)$' )
            {
                $Path  = "HKCU:\Software\Clients\StartMenuInternet\$ProgFullName\Capabilities\URLAssociations"
                $Name  = $Extension
                $Value = $ProgId
                Set-Reg New-ItemProperty -Path $Path -Name $Name -Type String $Value
            }

            if ( $Icon )
            {
                $Path  = "HKCU:\Software\Clients\StartMenuInternet\$ProgFullName\DefaultIcon"
                
                if ( $Icon -ne 'RemoveIcon' )
                {
                    $Value = $Icon
                    Set-Reg New-ItemProperty -Path $Path -Name '' -Type String $Value
                }
                else
                {
                    Set-Reg Remove-ItemProperty -Path $Path -Name ''
                }
            }

            $Path  = "HKCU:\Software\RegisteredApplications"
            $Name  = $ProgFullName
            $Value = "SOFTWARE\Clients\StartMenuInternet\$ProgFullName\Capabilities"
            Set-Reg New-ItemProperty -Path $Path -Name $Name -Type String $Value
        }
        elseif ( $Extension.Contains('.') )
        {
            # Регистрация как обычной программы, не интернет клиента: браузер, мэйл, контакт

            # Register Applications\$FileEXE
            $Path  = "HKCU:\Software\Classes\Applications\$FileEXE\shell\open\command"
            $Value = $progCommand
            Set-Reg New-ItemProperty -Path $Path -Name '' -Type String $Value

            # Register PortableProgram\$ProgFullName
            $Path  = "HKCU:\Software\PortableProgram\$ProgFullName\Capabilities"
            $Value = $FileName
            Set-Reg New-ItemProperty -Path $Path -Name 'ApplicationName' -Type String $Value
            $Value = $ProgFullName
            Set-Reg New-ItemProperty -Path $Path -Name 'ApplicationDescription' -Type String $Value

            $Path  = "HKCU:\Software\PortableProgram\$ProgFullName\Capabilities\FileAssociations"
            $Name  = $Extension
            $Value = $ProgId
            Set-Reg New-ItemProperty -Path $Path -Name $Name -Type String $Value

            # Register RegisteredApplications
            $Path  = "HKCU:\Software\RegisteredApplications"
            $Name  = $ProgFullName
            $Value = "SOFTWARE\PortableProgram\$ProgFullName\Capabilities"
            Set-Reg New-ItemProperty -Path $Path -Name $Name -Type String $Value
        }
    }

    if ( $Icon )
    {
        Write-Verbose "Set Icon: $Icon"
        Set-Icon $ProgId $Icon
    }

    Write-Verbose "Write Additional Keys For: $ProgId | $Extension"

    # Если указано расширение файла, настраиваем расширение, иначе протокол
    if ( $Extension.Contains('.') )
    {
        Write-Verbose "Write Registry Extension: $Extension"
        Write-ExtensionKeys -ProgId $ProgId -Extension $Extension
    }
    else
    {
        Write-Verbose "Write Registry Protocol: $Extension"
        Write-ProtocolKeys -ProgId $ProgId -Protocol $Extension
    }

    # Установка дополнительных параметров для соблюдения выжных условий
    Write-AdditionalKeys -ProgId $ProgId -Extension $Extension

    Refresh-Explorer

    # Возврат разрешения перенаправления на дефолтный профиль, если он настраивается 
    @($Global:DataLocalUsers.Where({ $_.Redirects },'First')).ForEach({ $_.Redirects.DefaultAccount = $true })
}
