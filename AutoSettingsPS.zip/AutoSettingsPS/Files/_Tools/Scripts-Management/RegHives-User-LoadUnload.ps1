﻿
<#
.SYNOPSIS
 Подгрузка и выгрузка кустов реестра других аккаунтов.

.DESCRIPTION
 Сделана для скрипта AutoSettingsPS
 
 Используется функция RegHive-LoadUnload для подгрузки/выгрузки кустов реестра на C#
 Использует глобальную переменную $Global:DataLocalUsers из функции Select-Load-LocalUsers, с нужным набором данных.
 
 Пример:

 [array] $Global:DataLocalUsers = @()
 $Global:DataLocalUsers = [PSCustomObject] @{ Redirects = @{ Value = $true ; DefaultAccount = $true }}
 $Global:DataLocalUsers += [PSCustomObject] @{ 
     Name          = $User.Name
     SID           = $User.SID
     Profile       = [System.Environment]::ExpandEnvironmentVariables($Profile)
     ProfileType   = $ProfileType
     NTUSER_Load   = $false  # Загружен ли был куст
     UsrClass_Load = $false  # Загружен ли был куст
     Use           = $Use
 }

.PARAMETER DefaultProfile
 Указывает подгрузить/выгрузить куст дефолтного профиля, если он не используется для полной настройки в глобальной переменной.
 Можно вызывать в нужных местах для точечной его настройки

.EXAMPLE
    RegHives-User-LoadUnload -DefaultProfile -Load
    RegHives-User-LoadUnload -DefaultProfile -Unload
    $TestUser = RegHives-User-LoadUnload $User -Silent -Load
    $TestUser = RegHives-User-LoadUnload $User -Silent -UnLoad

    RegHives-User-LoadUnload -Unload -UnloadOnlyDefault
    RegHives-User-LoadUnload -Unload -UnloadOnlyDefault -Silent

.NOTES
 =================================================
     Автор:  westlife (ru-board)   Версия 1.0
      Дата:  18-07-2021
 =================================================

#>
Function RegHives-User-LoadUnload {

    [CmdletBinding( SupportsShouldProcess = $false )]
    [OutputType([array])]
    Param (
        [Parameter( Mandatory = $false, ValueFromPipeline = $false, Position = 0 )]
        [AllowEmptyCollection()]
        [array] $Users
       ,
        [Parameter( Mandatory = $true,  ValueFromPipeline = $false, ParameterSetName = 'Load' )]
        [switch] $Load
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false, ParameterSetName = 'Load' )]
        [switch] $LoadExceptDefault
       ,
        [Parameter( Mandatory = $true,  ValueFromPipeline = $false, ParameterSetName = 'Unload' )]
        [switch] $Unload
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false, ParameterSetName = 'Unload' )]
        [switch] $UnloadOnlyDefault
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false )]
        [switch] $Silent
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false )]
        [switch] $DefaultProfile
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false, ParameterSetName = 'Load' )]
        [switch] $IndentBefore
    )

    $Global:LastExitCode = 0

    if ( $UnloadOnlyDefault )
    {
        # Получить данные профиля по умолчанию из глобальной переменной, если он не используется для полной настройки
        [array] $DefAccount = @($Global:DataLocalUsers.Where({ $_.ProfileType -eq 'DefaultAccount' },'First'))

        if ( $DefAccount.SID )
        {
            if ( -not $Silent ) { Write-Host }

            # Индивидуальная выгрузка куста реестра дефолтного профиля, с отображением в консоли
            RegHive-LoadUnload -RegRoot 'USERS' -RegPrefix "$($DefAccount.SID)" -SpecialPathLoad -Silent:$Silent -Unload
                
            if ( -not $Silent ) { Write-Host }
        }
    }
    elseif ( $DefaultProfile )
    {
        # Получить данные профиля по умолчанию из глобальной переменной, если он не используется для полной настройки
        [array] $DefAccount = @($Global:DataLocalUsers.Where({ $_.ProfileType -eq 'DefaultAccount' },'First'))

        if ( $DefAccount.SID -and $DefAccount.Profile )
        {
            if ( $DefAccount.Use ) { $Silent = $true }

            if ( $Load )
            {
                $HiveFile       = "$($DefAccount.Profile)\NTUSER.DAT"
                $HiveFileBackUP = "$HiveFile`_orig"

                if ( [System.IO.File]::Exists($HiveFile) -and -not [System.IO.File]::Exists($HiveFileBackUP))
                { Copy-Item -LiteralPath $HiveFile -Destination $HiveFileBackUP -Force -ErrorAction SilentlyContinue }

                if ( $IndentBefore -and -not $Silent ) { Write-Host }

                # Индивидуальная подгрузка куста реестра дефолтного профиля, с отображением в консоли
                RegHive-LoadUnload -RegRoot 'USERS' -RegPrefix "$($DefAccount.SID)" -HiveFile $HiveFile -SpecialPathLoad -Silent:$Silent -Load

                if (( -not $DefAccount.Use ) -and ( -not $Global:LastExitCode ))
                {
                    # Разрешение глобальной настройки дефолтного профиля
                    @($Global:DataLocalUsers.Where({ $_.ProfileType -eq 'DefaultAccount' },'First')).ForEach({ $_.NTUSER_Load = $true })

                    if ( -not $Global:DataLocalUsers.Redirects.Value )
                    {
                        # Включение разрешения перенаправления, если было отключено
                        @($Global:DataLocalUsers.Where({ $_.Redirects },'First')).ForEach({ $_.Redirects.Value = $true })
                    }
                }

                if ( -not $Silent ) { Write-Host }
            }
            else
            {
                if ( -not $Silent ) { Write-Host }

                # Индивидуальная выгрузка куста реестра дефолтного профиля, с отображением в консоли
                RegHive-LoadUnload -RegRoot 'USERS' -RegPrefix "$($DefAccount.SID)" -SpecialPathLoad -Silent:$Silent -Unload
                
                if ( -not $Silent ) { Write-Host }

                if ( -not $DefAccount.Use )
                {
                    # Запрет глобальной настройки дефолтного профиля
                    @($Global:DataLocalUsers.Where({ $_.ProfileType -eq 'DefaultAccount' },'First')).ForEach({ $_.NTUSER_Load = $false })
                }
            }
        }
    }
    else
    {
        foreach ( $User in $Users )
        {
            if ( $Load )
            {
                if ( $User.Use -and $User.SID -and $User.Profile )
                {
                    if ( $User.ProfileType -eq 'DefaultAccount' )
                    {
                        $HiveFile = "$($User.Profile)\NTUSER.DAT"
                        $HiveFileBackUP = "$HiveFile`_orig"

                        if ( [System.IO.File]::Exists($HiveFile) -and -not [System.IO.File]::Exists($HiveFileBackUP))
                        { try { Copy-Item -LiteralPath $HiveFile -Destination $HiveFileBackUP -Force -ErrorAction SilentlyContinue } catch {} }
                       
                        # Если не подгружать куст профиля по умолчанию. То включить разрешение его подгружать.
                        # Его будет подгружать при необходимости через Set-Reg или Set-LGP, и в конце выполнения выгружать во время паузы. Чтобы не блокировало его файл куста.
                        if ( $LoadExceptDefault ) { $User.NTUSER_Load = $true ; continue }
                    }

                    RegHive-LoadUnload -RegRoot 'USERS' -RegPrefix "$($User.SID)" -HiveFile "$($User.Profile)\NTUSER.DAT" -SpecialPathLoad -Silent:$Silent -Load

                    # Если куст подгрузился или был уже подгружен, указать что можно настраивать раздел
                    if ( $Global:LastExitCode ) { $User.NTUSER_Load = $false } else { $User.NTUSER_Load = $true }

                    if ( $User.ProfileType -eq 'DefaultAccount' ) { continue }

                    RegHive-LoadUnload -RegRoot 'USERS' -RegPrefix "$($User.SID)_Classes" -HiveFile "$($User.Profile)\AppData\Local\Microsoft\Windows\UsrClass.dat" -SpecialPathLoad -Silent:$Silent -Load
    
                    if ( $Global:LastExitCode ) { $User.UsrClass_Load = $false } else { $User.UsrClass_Load = $true }
                }
            }
            else
            {
                if ( $User.Use -and $User.SID )
                {
                    RegHive-LoadUnload -RegRoot 'USERS' -RegPrefix "$($User.SID)" -SpecialPathLoad -Silent:$Silent -Unload

                    if ( $Global:LastExitCode ) { $User.NTUSER_Load = $true } else { $User.NTUSER_Load = $false }
                
                    if ( $User.ProfileType -eq 'DefaultAccount' ) { continue }

                    RegHive-LoadUnload -RegRoot 'USERS' -RegPrefix "$($User.SID)_Classes" -SpecialPathLoad -Silent:$Silent -Unload
    
                    if ( $Global:LastExitCode ) { $User.UsrClass_Load = $true } else { $User.UsrClass_Load = $false }
                }
            }
        }

        Return $Users
    }
}
