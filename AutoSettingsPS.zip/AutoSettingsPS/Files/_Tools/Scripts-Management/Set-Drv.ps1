﻿
<#
.SYNOPSIS
 Настройка и/или проверка состояния драйверов.

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.
 Выполняет команду (настраивает) и/или делает проверку состояния или наличия драйвера.
 Настройка при любом уровне доступа, кроме блокированного раздела драйвером.

 Данная функция вместо вымышленного командлета 'Set-Driver',
 и выполняет действия, предназначенные для нее, по принципу командлета 'Set-Service'.
 Определяется тип: служба или драйвер. Если не драйвер, то будет пропуск.

 Используется функция Set-Reg для установки параметров в реестре в разделе для служб и драйверов, независимо от доступа.
 Используется функция Show-Result для отображения результата в нужном виде.
 Используется функция Token-Impersonate для олицетворения за TrustedInstaller,
 но только если указано остановить драйвер, а доступа на остановку нет,
 будет попытка сделать под олицетворением.

 Выполняет команды или делает проверку параметра,
 через методы в RegistryKey [Microsoft.Win32.Registry]
 и ServiceController [System.ServiceProcess.ServiceController] из .NET,
 так как общее выполнение быстрее минимум в 2 раза,
 чем стандартными командлетами + есть дополнительные возможности.

 Нельзя использовать маски '*', кроме одного варианта, будут поняты буквально,
 в том числе все фильтры и т.д. Любые хитрые варианты используем оригинальными командлетами!

 Добавлены возможности: Применить, а затем проверить или только проверить.

 Для определения места ошибки можно указать вывод подробных действий: -Verbose.

.PARAMETER Do
 Указывает, что нужно сделать.
 Варианты:
 1. Set    = Выполнить и проверить (по умолчанию).
 2. Check  = Только проверить.

.PARAMETER Name
 Понимает только реальное имя драйвера, никаких отображаемых имен.

.INPUTS
 Строка с командой для вымышленного командлета 'Set-Driver' по принципу командлета 'Set-Service'.
 Для понимания.

.EXAMPLE
    Set-Drv -Do:$Act Set-Driver -Name WdNisDrv -StartupType Manual -Status Running

    Описание
    --------
    Если $Act = 'Set' Попытается Установить Запуск вручную и запустить драйвер.
    С выводом результата и скрытием ошибок при выполнении,
    Если $Act = 'Check', только проверит.

.EXAMPLE
    Set-Drv -Do Set Set-Driver -Name WdNisDrv -StartupType Disabled

    Описание
    --------
    Попытается Установить тип запуска 'Отключено' у драйвера WdNisDrv.
    С выводом результата, и скрытием ошибок при выполнении, кроме прерывающих.

.EXAMPLE
    Set-Drv -Do Set Set-Driver -Name WdNisDrv -Status Stopped


.NOTES
 ==================================================
      Автор:  westlife (ru-board)  Версия:  1.0
       Дата:  11-10-2018
 ==================================================

#>
Function Set-Drv {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $true,  ValueFromPipeline = $false, Position = 0 )]
        [ValidateSet( 'Set-Driver' )]
        [string] $Cmdlet
       ,
        [Parameter( Mandatory = $true,  ValueFromPipeline = $false, Position = 1 )]
        [Alias( 'Name', 'SN' )]
        [string] $DriverName
       ,
        [Parameter( Mandatory = $true,  ValueFromPipeline = $false, ParameterSetName = 'All' )]
        [Alias( 'StartMode', 'SM', 'ST' )]
        [ValidateSet( 'Boot', 'System', 'Automatic', 'Manual', 'Disabled' )]
        [string] $StartupType
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false, ParameterSetName = 'All' )]
        [Parameter( Mandatory = $true,  ValueFromPipeline = $false, ParameterSetName = 'Status' )]
        [ValidateSet( 'Running', 'Stopped' )]
        [string] $Status
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false )]
        [ValidateSet( 'Set', 'Check', 'Default' )]  # Default чтобы применялось как Set и не было ошибок
        [string] $Do = 'Set'
    )

    Begin
    {
        # Получение имени этой функции.
        [string] $NameThisFunction = $MyInvocation.MyCommand.Name

        # Получение перевода
        [hashtable] $L = $Lang.$NameThisFunction
        [string] $text = ''

        if ( $Do -eq 'Default' ) { $Do = 'Set' }

        # Перехват ошибок, только прерываемых исключений, в блоке Begin, для выхода из функции.
        # И если есть глобальный trap, не отображать ошибку тут, а передать ее ему, для отображения и/или записи в лог.
        trap
        {
            $text = if ( $L.s1 ) { $L.s1 } else { "Ошибка в Begin" }
            Write-Warning "$NameThisFunction`: $text`: '$ActionDRV'`n   $($_.CategoryInfo.Category): $($_.Exception.Message)"
            break
        }

        # Получение команды действия для отображения, при необходимости.
        [string] $ActionDRV = ($MyInvocation.Line.Replace($NameThisFunction,'') -Replace '(\s*-Do[:]?\s*[^\s]*\s*)',' '
                              ).Replace('$Name',        "'$DriverName'"           # Замена на значение вместо переменной '$Name'
                              ).Replace('$_.Name',      "'$DriverName'"           # Замена на значение вместо переменной '$_.Name'
                              ).Replace('$StartupType', "'$StartupType'"          # Замена на значение вместо переменной '$StartupType'
                              ).Replace('$Status',      "'$Status'").Trim()       # Замена на значение вместо переменной '$Status'

        Write-Verbose "Команда:`n $ActionDRV"

        # Создаем хэш-таблицу $ShowResult, с возможностью изменять ее во внутренних временных функциях.
        # И наполняем полученными данными для вывода в консоль, через фукнцию Show-Result.
        Set-Variable -Name ShowResult -Value @{} -Option AllScope -Force
        $ShowResult['Do']   = $Do
        $ShowResult['Type'] = '{0}' -f $(if ( $L.s2 ) { $L.s2 } else { "Драйвер" })
        $ShowResult['Info'] = "$ActionDRV | $DriverName"

        # Также добавляем тип ServiceProcess из .NET к текущему сеансу, для управления службами и драйверами.
        if ( -not ( 'System.ServiceProcess.ServiceController' -as [type] )) { Add-Type -AssemblyName 'System.ServiceProcess' -ErrorAction Stop }

        # Пробуем подключение к драйверу.
        $Driver = [System.ServiceProcess.ServiceController]::new($DriverName)

        # Если контроллер служб получил пустые данные в любом из 3 параметров
        if (( -not $Driver.Name ) -or ( -not [string] $Driver.StartType ) -or ( -not $Driver.Status ))
        {
            Write-Verbose "Драйвер: '$DriverName' не существует!"

            [bool] $NotExist = $true ; Return
        }
        elseif ( -not ( [string] $Driver.ServiceType -like '*Driver*' ))
        {
            Write-Verbose "Это не Драйвер: '$DriverName'"

            [bool] $NotExist = $true ; Return
        }

        # Указываем раздел служб и драйверов в реестре.
        [string] $Root = 'HKLM:'
        [string] $DriverPath = 'SYSTEM\CurrentControlSet\Services'
    }

    Process
    {
        # Перехват ошибок, только прерываемых исключений, в блоке Process, для выхода из функции.
        # И если есть глобальный trap, не отображать ошибку тут, а передать ее ему, для отображения и/или записи в лог.
        trap
        {
            $text = if ( $L.s3 ) { $L.s3 } else { "Ошибка в Process" }
            Write-Warning "$NameThisFunction`: $text`: '$ActionDRV'`n   $($_.CategoryInfo.Category): $($_.Exception.Message)"
            break
        }

        # Если нужно выйти или выполнить только проверку, переходим в End.
        if ( $Exit ) { Return }
        elseif (( $Do -eq 'Check' ) -or $NotExist ) { $isAct = '(Только проверено)' ; Return } else { $isAct = "(Выполнено, затем проверено)" }

        Write-Verbose "Выполняем настройку: '$Do'"

        # Boot      = 0
        # System    = 1
        # Automatic = 2
        # Manual    = 3
        # Disabled  = 4

        # Если указано настроить драйвер
        if ( $StartupType )
        {
            Write-Verbose "Настраиваем драйвер на '$StartupType'"

            [string] $Path = "$Root\$DriverPath\$DriverName"

            # Устанавливаем параметр в реестре, согласно указанному типу запуска.
            if ( $StartupType -eq 'Boot' )
            {
                Set-Reg -NoCheck New-ItemProperty -Path $Path -Name 'Start' -Type DWord -Value 0
            }
            elseif ( $StartupType -eq 'System' )
            {
                Set-Reg -NoCheck New-ItemProperty -Path $Path -Name 'Start' -Type DWord -Value 1
            }
            elseif ( $StartupType -eq 'Automatic' )
            {
                Set-Reg -NoCheck New-ItemProperty -Path $Path -Name 'Start' -Type DWord -Value 2
            }
            elseif ( $StartupType -eq 'Manual' )
            {
                Set-Reg -NoCheck New-ItemProperty -Path $Path -Name 'Start' -Type DWord -Value 3
            }
            elseif ( $StartupType -eq 'Disabled' )
            {
                Set-Reg -NoCheck New-ItemProperty -Path $Path -Name 'Start' -Type DWord -Value 4
            }
        }

        # Если указано изменить состояние драйвера
        if ( $Status )
        {
            if ( $Status -eq 'Running' ) { try { Write-Verbose "Запускаем драйвер" ; $Driver.Start() } catch { Write-Verbose "Ошибка запуска" } }
            else
            {
                Write-Verbose "Останавливаем драйвер"

                try { $Driver.Stop() }
                catch
                {
                    Write-Verbose "Не получилось остановить"

                    # Подключаем токен от TrustedInstaller
                    Token-Impersonate -Token TI

                    Write-Verbose "Пробуем еще раз"

                    try { $Driver.Stop() }
                    catch
                    {
                        Write-Verbose "Не остановился драйвер"
                    }
                    finally { Token-Impersonate -Reset }
                }
            }

            # Ожидание результата остановки, но не более 3 сек.
            [int] $WaitCount = 0
            do
            {
                try { $Driver.Refresh() } catch {}
                Start-Sleep -Milliseconds 100
                $WaitCount++
            }
            until (( $Driver.Status -notlike '*Pending*' ) -or ( $WaitCount -ge 30 ))
        }
    }

    End
    {
        # Перехват ошибок, только прерываемых исключений, в блоке End, для выхода из функции.
        # И если есть глобальный trap, не отображать ошибку тут, а передать ее ему, для отображения и/или записи в лог.
        trap
        {
            $text = if ( $L.s4 ) { $L.s4 } else { "Ошибка в End" }
            Write-Warning "$NameThisFunction`: $text`: '$ActionDRV'`n   $($_.CategoryInfo.Category): $($_.Exception.Message)"
            break
        }

        # Выйти при ошибке.
        if ( $Exit )
        {
            # Освобождаем ресурсы контроллера.
            if ( $Driver ) { $Driver.Close() }

            Return  # выходим из функции
        }
        elseif ( $NotExist )
        {
            # Передаем таблицу с итоговыми данными в функцию для форматированного под стандарт вывода в консоль.
            Show-Result @ShowResult

            # Освобождаем ресурсы контроллера.
            if ( $Driver ) { $Driver.Close() }

            Return  # выходим из функции
        }

        Write-Verbose "Начало проверки. Действие: '$Do'"
        
        if ( $Driver ) { $Driver.Refresh() }

        [string] $isStartupType = $Driver.StartType

        # Получаем отображаемое имя драйвера.
        [string] $DisplayName = $Driver.DisplayName

        [string] $isStatus = $Driver.Status

        # Освобождаем ресурсы контроллера.
        if ( $Driver ) { $Driver.Close() }

        [string] $StateDRV = '{0}' -f $(if ( $L.s5 ) { $L.s5 } else { "Не драйвер" })

        if     ( 'Boot'      -eq $isStartupType ) { $StateDRV = '{0}' -f $(if ( $L.s6  ) { $L.s6  } else { "Загрузка"  }) }  # Start = 0
        elseif ( 'System'    -eq $isStartupType ) { $StateDRV = '{0}' -f $(if ( $L.s7  ) { $L.s7  } else { "Система"   }) }  # Start = 1
        elseif ( 'Automatic' -eq $isStartupType ) { $StateDRV = '{0}' -f $(if ( $L.s8  ) { $L.s8  } else { "Авто"      }) }  # Start = 2
        elseif ( 'Manual'    -eq $isStartupType ) { $StateDRV = '{0}' -f $(if ( $L.s9  ) { $L.s9  } else { "Вручную"   }) }  # Start = 3
        elseif ( 'Disabled'  -eq $isStartupType ) { $StateDRV = '{0}' -f $(if ( $L.s10 ) { $L.s10 } else { "Отключена" }) }  # Start = 4

        if ( $StartupType )
        {
            # Если все совпадает.
            if ( $StartupType -eq $isStartupType )
            {
                # Выводим полностью совпавшие полученные: 'Имя Драйвера' [тип запуска] (Отображаемое имя).
                Write-Verbose "Все совпадает с '$DriverName' [$isStartupType] ($DisplayName)"

                $ShowResult['Result'] = '+'
                $ShowResult['Status'] = $StateDRV
                $ShowResult['Info']   = "$DriverName [$isStatus] | $ActionDRV | $DisplayName"

                [bool] $ResultFunc = $true
            }
            else
            {
                Write-Verbose "`nНе совпадает: `n   Проверили: '$DriverName' [$StartupType] '$DisplayName'`n    Получили: '$DriverName' [$isStartupType] '$DisplayName'"

                $ShowResult['Result'] = '!!!'
                $ShowResult['Status'] = $StateDRV
                $ShowResult['Info']   = "$DriverName [$isStatus] | $ActionDRV | $DisplayName"

                [bool] $ResultFunc = $false
            }
        }
        elseif ( $Status )
        {
            # Если все совпадает.
            if ( $Status -eq $isStatus )
            {
                # Выводим полностью совпавшие полученные: 'Имя драйвера' [тип статуса] (Отображаемое имя).
                Write-Verbose "Все совпадает с '$DriverName' [$isStatus] ($DisplayName)"

                $ShowResult['Result'] = '+'
                $ShowResult['Status'] = $isStatus
                $ShowResult['Info']   = "$DriverName [$isStatus] | $ActionDRV | $DisplayName"

                [bool] $ResultFunc = $true
            }
            else
            {
                Write-Verbose "`nНе совпадает: `n   Проверили: '$DriverName' [$Status] '$DisplayName'`n    Получили: '$DriverName' [$isStatus] '$DisplayName'"

                $ShowResult['Result'] = '!!!'
                $ShowResult['Status'] = $isStatus
                $ShowResult['Info']   = "$DriverName [$isStatus] | $ActionDRV | $DisplayName"

                [bool] $ResultFunc = $false
            }
        }

        # Если параметр неверный, специальная глобальная переменная $NeedFix будет установлена в $true.
        if ( $ResultFunc )
        {
            Write-Verbose "   Вернo   [Параметр правильный]  $isAct"
        }
        else
        {
            $NeedFix = $true

            Write-Verbose "   Неверно   [Параметр неверный]  $isAct"
        }

        # Передаем таблицу с итоговыми данными в функцию для форматированного под стандарт вывода в консоль.
        Show-Result @ShowResult
    }
}
