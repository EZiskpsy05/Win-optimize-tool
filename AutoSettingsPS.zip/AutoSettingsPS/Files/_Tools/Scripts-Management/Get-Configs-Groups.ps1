﻿
<#
.SYNOPSIS
 Получение списка подгрупп из пресетов.

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS

 Используется для получения списка подгрупп в функциях Set-Configs-......ps1
 Для принятияе решения, что сделать для полгруппы:
 примененить, только проверить или восстановить, для каждой индивидуально.

 Если указан вариант Actions = 'Check', то не добавлять в список подгруппу со значением: 'D'

.PARAMETER FuncName
 Имя функции с настройками для получения из неё имени общей подгруппы настроек

.PARAMETER Actions
 Указанный вариант настройки

.PARAMETER FilePresets
 Файл с пресетами настроек групп

.EXAMPLE
    Get-Configs-Groups -FuncName 'Set-Configs-Other2' -Actions Set

    Описание
    --------
    Получить список подгрупп настроек, с учётом варианта настройки параметров

.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  20.06.2020
 ===============================================

#>
Function Get-Configs-Groups {

    [CmdletBinding( SupportsShouldProcess = $false )]
    [OutputType( [string[]] )]
    Param(
        [Parameter( Mandatory = $true,  Position = 0 )]
        [string] $FuncName
       ,
        [Parameter( Mandatory = $true,  Position = 1 )]
        [ValidateSet( 'Set', 'Check', 'Default' )]
        [string] $Actions
       ,
        [Parameter( Mandatory = $false, Position = 2 )]
        [string] $FilePresets = $FilePresetsGlobal
    )

    # Если будут найдены другие файлы для настроек, состоящих из имени и расширения заданного оригинала,
    # то будет использоваться как пресет для настроек первый из дополнительных найденных.
    try
    {
        [string] $PresetsPath = [System.IO.Path]::GetDirectoryName($FilePresets)
        [string] $PresetsName = [System.IO.Path]::GetFileNameWithoutExtension($FilePresets)
        [string] $PresetsExt  = [System.IO.Path]::GetExtension($FilePresets)

        [string] $FoundPresetsMy = ((Get-ChildItem -File -LiteralPath $PresetsPath -ErrorAction Stop).Where({
            $_.Name -like "$PresetsName`?*$PresetsExt"
        },'First',1)).FullName
    }
    catch { [string] $FoundPresetsMy = '' }

    if ( $FoundPresetsMy ) { $FilePresets = $FoundPresetsMy }

    [hashtable] $TableOptions = @{}

    # Если файл с пресетами существует.
    if ( [System.IO.File]::Exists($FilePresets) )
    {
        [string] $GroupName = $FuncName.Replace('Set-Configs-','')

        # Получение пресетов в переменную.
        try
        {
            $Global:CurrentListPresets = Get-Content -LiteralPath \\?\$FilePresets -Encoding UTF8 -ErrorAction SilentlyContinue
            $Global:CurrentListPresets | Where-Object {

                [string] $SubName = ''

                if ( $_ -match "^\s*Sub-Options-$GroupName\s*=\s*(?<Value>[1D])\s*=\s*(?<SubName>[^#=\s]+)" )
                {
                    if ( $Actions -ne 'Check' )
                    {
                        # Если Set или 'Default'

                        if ( $matches.Value -eq 'D' -or $Actions -eq 'Default' )
                        {
                            # Если буква D в пресете или указан сброс параметров, то записать группу в список, с добавлением к имени -Default
                            $SubName = "$($matches.SubName)-Default"
                        }
                        elseif ( $matches.Value -eq 1 )
                        {
                            # Если цифра 1 в пресете, то просто записать имя в список для использования.
                            $SubName = $matches.SubName
                        }
                    }
                    else
                    {
                        # Если 'Check', то не добавлять в список для использования группы с параметром D

                        if ( $matches.Value -eq 1 )
                        {
                            # Если цифра 1 в пресете, то просто записать имя в список для использования.
                            $SubName = $matches.SubName
                        }
                    }

                    if ( $SubName ) { $TableOptions[$TableOptions.Count] = $SubName }
                }
            }

            # Добавление в список подпунктов у подгрупп с именем заканчивающимся на два двоеточия ::
            foreach ( $SubOption in @($TableOptions.Values).Where({ $_ -like '*::*' }) )
            {
                $SubSection = $SubOption -Replace('(.+)::.*','$1')
                
                $Global:CurrentListPresets | Where-Object {

                    [string] $SubName = ''

                    if ( $_ -match "^\s*[[]::[]]-$SubSection\s*=\s*(?<Value>[1D])\s*=\s*(?<SubName>[^#=\s]+)" )
                    {
                        if ( $Actions -ne 'Check' )
                        {
                            # Если Set или 'Default'

                            if (( $matches.Value -eq 'D' ) -or ( $Actions -eq 'Default' ) -or ( $SubOption -like '*-Default' ))
                            {
                                # Если буква D в пресете или указан сброс параметров, то записать группу в список, с добавлением к имени -Default
                                $SubName = "$($matches.SubName)-Default"
                            }
                            elseif ( $matches.Value -eq 1 )
                            {
                                # Если цифра 1 в пресете, то просто записать имя в список для использования.
                                $SubName = $matches.SubName
                            }
                        }
                        else
                        {
                            # Если 'Check', то не добавлять в список для использования группы с параметром D

                            if ( $matches.Value -eq 1 )
                            {
                                # Если цифра 1 в пресете, то просто записать имя в список для использования.
                                $SubName = $matches.SubName
                            }
                        }

                        if ( $SubName ) { $TableOptions[$TableOptions.Count] = $SubName }
                    }
                }
                
            }
        }
        catch {}
    }

    $TableOptions.Values
}