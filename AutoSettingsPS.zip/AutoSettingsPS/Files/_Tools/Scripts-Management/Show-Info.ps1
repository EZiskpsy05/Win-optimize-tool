﻿
<#
.SYNOPSIS
 Вывод форматированной информации, в зависимости от действия

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS
 Используется в функциях Set-Configs-......ps1


.PARAMETER Names
 Информация для вывода

.PARAMETER Actions
 Указанный вариант настройки

.EXAMPLE
    "Text" | Show-Info

    Описание
    --------
    Вывести название

.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  21.06.2020
 ===============================================

#>
Function Show-Info {

    [CmdletBinding( SupportsShouldProcess = $false, DefaultParameterSetName = 'Action' )]
    Param(
        [Parameter( Mandatory = $false, ValueFromPipeline = $true,  Position = 0 )]
        [string] $Info
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false, Position = 1 )]
        [string] $Shift
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false, Position = 2, ParameterSetName = 'Action' )]
        [ValidateSet( 'Set', 'Check', 'Default' )]
        [string] $Action
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false, ParameterSetName = 'Action' )]
        [switch] $Deleted
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false, ParameterSetName = 'Action' )]
        [switch] $NoIndentAfter
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false, ParameterSetName = 'Indent' )]
        [switch] $NotIndent
    )

    # Получение имени этой функции.
    [string] $InfoThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$InfoThisFunction
    [string] $text = ''

    # Если указан $Shift то выполнить замену на него, используется для подстановки перевода, при наличии.
    if ( $Shift ) { $Info = $Shift }
    elseif ( -not $Info ) { $Info = '$Info' }

    if ( $Action )
    {
        if ( $Group ) { $isSubGroup = "$Group | " } else { $isSubGroup = '' }  # Отображение названия подгруппы после её описания

        if ( 'Set' -eq $Action )
        {
            $text = if ( $L.s1 ) { $L.s1 } else { "Настройка" }

            Write-Host "`n > "          -ForegroundColor White    -NoNewline ; Write-Host $Info -ForegroundColor White -NoNewline
            Write-Host " | $isSubGroup" -ForegroundColor DarkGray -NoNewline ; Write-Host $text -ForegroundColor Green -NoNewline
        }
        elseif ( 'Check' -eq $Action )
        {
            $text = if ( $L.s2 ) { $L.s2 } else { "Проверка" }

            Write-Host "`n > "          -ForegroundColor White    -NoNewline ; Write-Host $Info -ForegroundColor White -NoNewline
            Write-Host " | $isSubGroup" -ForegroundColor DarkGray -NoNewline ; Write-Host $text -ForegroundColor Cyan  -NoNewline
        }
        else
        {
            $text = if ( $L.s3 ) { $L.s3 } else { "По умолчанию" }

            Write-Host "`n > "          -ForegroundColor Magenta  -NoNewline ; Write-Host $Info -ForegroundColor Magenta -NoNewline
            Write-Host " | $isSubGroup" -ForegroundColor DarkGray -NoNewline ; Write-Host $text -ForegroundColor White   -NoNewline
        }

        if ( $Deleted )
        {
            $text = if ( $L.s4 ) { $L.s4 } else { "Компонент Удалён" }
            Write-Host " | " -ForegroundColor DarkGray -NoNewline ; Write-Host $text`n -ForegroundColor Blue
        }
        else
        {
            if ( $NoIndentAfter ) { Write-Host      } 
            else                  { Write-Host "`n" }
        }
    }
    else
    {
        # Если указано не добавлять отступ
        if ( $NotIndent )
        {
            Write-Host   "   • $Info" -ForegroundColor DarkCyan
        }
        else
        {
            Write-Host "`n   • $Info" -ForegroundColor DarkCyan
        }
    }
}