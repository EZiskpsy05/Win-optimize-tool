﻿
<#
.SYNOPSIS
 Подгрузка и выгрузка кустов реестра.

.DESCRIPTION
 Сделана для скрипта RepackWIMPS и AutoSettingsPS
 Корневой куст для подгрузки куста по умолчанию: HKLM. Можно указать HKU
 Используется winapi на C# вместо reg.exe

 Бывает блокируются хэндлы открытого куста, после использования команды создания разделов,
 или задержка при освобождении хэндлов, и не дает выгрузить куст.
 Этот момент учитывается, и используются дополнительные команды для освобождения хэндлов
 и выгрузки куста. Выполняются эти действия пока куст не будет выгружен.

.PARAMETER RegRoot
 Корневой раздел для подгрузки: HKLM или HKU. Нет разницы куда подгружать любой куст, но иногда нужно использовать конкретный раздел.

.PARAMETER SpecialPathLoad
 Указывает использовать только переданный префикс для создания подраздела для подгрузки 
 Иначе используется сложение: префикс + имя файла и расширение 

.PARAMETER Silent
 Указывает не выводить информации при выполнении, но возвращает 0 (без ошибок) или 1 (была ошибка).
 Так же всего 4 попытки выгрузки куста (вместо бесконечных), и если не получится, возврат 1
 

.EXAMPLE
    RegHive-LoadUnload -RegPrefix '_TEMP_' -HiveFile "...\Offline\Windows\System32\config\SOFTWARE" -Load

    Описание
    --------
    Подгрузит куст в HKLM\_TEMP_SOFTWARE

.EXAMPLE
    RegHive-LoadUnload -RegPrefix '_TEMP_' -HiveFile "...\Offline\Windows\System32\config\SYSTEM" -SpecialPathLoad -Load 

    Описание
    --------
    Подгрузит куст в HKLM\_TEMP_

.EXAMPLE
    RegHive-LoadUnload -RegPrefix '_TEMP_' -HiveFile "...\Offline\Windows\System32\config\SYSTEM" -Unload

    Описание
    --------
    Выгрузит куст HKLM\_TEMP_SYSTEM

.EXAMPLE
    RegHive-LoadUnload -RegPrefix '_TEMP_' -HiveFile '%UserProfile%\NTUSER.DAT' -RegRoot USERS -Unload

    Описание
    --------
    Выгрузит куст HKU\_TEMP_NTUSER.DAT


.NOTES
 =================================================
     Автор:  westlife (ru-board)   Версия 1.01
      Дата:  12-06-2020
 =================================================

#>
Function RegHive-LoadUnload {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $true,  ValueFromPipeline = $false, Position = 0 )]
        [string] $RegPrefix
       ,
        [Parameter( Mandatory = $true,  ValueFromPipeline = $false, Position = 1, ParameterSetName = 'Load' )]
        [Parameter( Mandatory = $false, ValueFromPipeline = $false, Position = 1, ParameterSetName = 'Unload' )]
        [string] $HiveFile
       ,
        [Parameter( Mandatory = $true,  ValueFromPipeline = $false, ParameterSetName = 'Load' )]
        [switch] $Load
       ,
        [Parameter( Mandatory = $true,  ValueFromPipeline = $false, ParameterSetName = 'Unload' )]
        [switch] $Unload
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false )]
        [ValidateSet( 'USERS', 'MACHINE' )]
        [string] $RegRoot = 'MACHINE'
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false )]
        [switch] $SpecialPathLoad
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false )]
        [switch] $Silent
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    if ( $RegPrefix -notmatch '^[\d\w-]+$' )
    {
        $Global:LastExitCode = 1

        if ( $Silent ) { Return }

        $text = if ( $L.s1 ) { $L.s1 } else { "Неверный префикс" }
        Write-Warning "$NameThisFunction`: $text`: '$RegPrefix'"

        $text = if ( $L.s2 ) { $L.s2 } else { "Должен соответствовать шаблону: '^[\d\w-]+$' (Буквы, цифры, символы: '-', '_')" }
        Write-Warning "$NameThisFunction`: $text" 

        Return  # Выход из функции
    }

    $HiveFile = [System.Environment]::ExpandEnvironmentVariables($HiveFile)

    if ( $Load -and ( -not [System.IO.File]::Exists($HiveFile) ))
    {
        $Global:LastExitCode = 1

        if ( $Silent ) { Return }

        $text = if ( $L.s3 ) { $L.s3 } else { "Не найден файл куста реестра" }
        Write-Host "    $NameThisFunction`: $text`: '$HiveFile'" -ForegroundColor DarkYellow
        
        Return   # Выход из функции
    }

    # C#; Используется часть кода для подгрузки и выгрузки кустов реестра.
    $RegistryUtils = @'
using System;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Text;
using Microsoft.Win32;
using FILETIME = System.Runtime.InteropServices.ComTypes.FILETIME;

namespace RegistryUtils
{
    public static class Action
    {
        [DllImport("advapi32.dll", CharSet = CharSet.Auto)]
        private static extern int RegOpenKeyEx(UIntPtr hKey, string subKey, int ulOptions, int samDesired, out UIntPtr hkResult);

        [DllImport("advapi32.dll", SetLastError = true)]
        private static extern int RegCloseKey(UIntPtr hKey);

        [DllImport("advapi32.dll", SetLastError=true, CharSet = CharSet.Unicode)]
        private static extern uint RegDeleteKey(UIntPtr hKey, string subKey);

        [DllImport("advapi32.dll", EntryPoint = "RegQueryInfoKey", CallingConvention = CallingConvention.Winapi, SetLastError = true)]
        private static extern int RegQueryInfoKey(UIntPtr hkey, out StringBuilder lpClass, ref uint lpcbClass, IntPtr lpReserved,
            out uint lpcSubKeys, out uint lpcbMaxSubKeyLen, out uint lpcbMaxClassLen, out uint lpcValues, out uint lpcbMaxValueNameLen,
            out uint lpcbMaxValueLen, out uint lpcbSecurityDescriptor, ref FILETIME lpftLastWriteTime);

        [DllImport("advapi32.dll", ExactSpelling = true, SetLastError = true)]
        internal static extern bool OpenProcessToken(IntPtr h, int acc, ref IntPtr phtok);

        [DllImport("kernel32.dll", ExactSpelling = true)]
        internal static extern IntPtr GetCurrentProcess();

        [DllImport("advapi32.dll", SetLastError = true)]
        internal static extern bool LookupPrivilegeValue(string host, string name, ref long pluid);

        [DllImport("advapi32.dll", ExactSpelling = true, SetLastError = true)]
        internal static extern bool AdjustTokenPrivileges(IntPtr htok, bool disall, ref TokPriv1Luid newst, int len, IntPtr prev, IntPtr relen);

        [DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern int RegLoadKey(uint hKey, string lpSubKey, string lpFile);

        [DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern int RegUnLoadKey(uint hKey, string lpSubKey);

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        internal struct TokPriv1Luid
        {
            public int Count;
            public long Luid;
            public int Attr;
        }

        public static void DeleteKey(RegistryHive registryHive, string subkey)
        {
            UIntPtr hKey = UIntPtr.Zero;

            try
            {
                var hive = new UIntPtr(unchecked((uint)registryHive));
                RegOpenKeyEx(hive, subkey, 0, 0x20019, out hKey);
                RegDeleteKey(hive, subkey);
            }
            finally
            {
                if (hKey != UIntPtr.Zero)
                {
                    RegCloseKey(hKey);
                }
            }
        }

        private static DateTime ToDateTime(FILETIME ft)
        {
            IntPtr buf = IntPtr.Zero;
            try
            {
                long[] longArray = new long[1];
                int cb = Marshal.SizeOf(ft);
                buf = Marshal.AllocHGlobal(cb);
                Marshal.StructureToPtr(ft, buf, false);
                Marshal.Copy(buf, longArray, 0, 1);
                return DateTime.FromFileTime(longArray[0]);
            }
            finally
            {
                if (buf != IntPtr.Zero) Marshal.FreeHGlobal(buf);
            }
        }

        public static DateTime? GetLastModified(RegistryHive registryHive, string subKey)
        {
            var lastModified = new FILETIME();
            var lpcbClass = new uint();
            var lpReserved = new IntPtr();
            UIntPtr hKey = UIntPtr.Zero;

            try
            {
                try
                {
                    var hive = new UIntPtr(unchecked((uint)registryHive));
                    if (RegOpenKeyEx(hive, subKey, 0, (int)RegistryRights.ReadKey, out hKey) != 0)
                    {
                        return null;
                    }

                    uint lpcbSubKeys;
                    uint lpcbMaxKeyLen;
                    uint lpcbMaxClassLen;
                    uint lpcValues;
                    uint maxValueName;
                    uint maxValueLen;
                    uint securityDescriptor;
                    StringBuilder sb;
                    
                    if (RegQueryInfoKey(hKey, out sb, ref lpcbClass, lpReserved, out lpcbSubKeys, out lpcbMaxKeyLen, out lpcbMaxClassLen,
                        out lpcValues, out maxValueName, out maxValueLen, out securityDescriptor, ref lastModified) != 0)
                    {
                        return null;
                    }

                    var result = ToDateTime(lastModified);
                    return result;
                }
                finally
                {
                    if (hKey != UIntPtr.Zero)
                    {
                        RegCloseKey(hKey);
                    }
                }
            }
            catch (Exception)
            {
                return null;
            }
        }

        internal const int SE_PRIVILEGE_DISABLED = 0x00000000;
        internal const int SE_PRIVILEGE_ENABLED = 0x00000002;
        internal const int TOKEN_QUERY = 0x00000008;
        internal const int TOKEN_ADJUST_PRIVILEGES = 0x00000020;

        public enum RegistryHives : uint
        {
            HKEY_USERS = 0x80000003,
            HKEY_LOCAL_MACHINE = 0x80000002
        }

        public static void AddPrivilege(string privilege)
        {
            bool retVal;
            TokPriv1Luid tp;
            IntPtr hproc = GetCurrentProcess();
            IntPtr htok = IntPtr.Zero;
            retVal = OpenProcessToken(hproc, TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, ref htok);
            tp.Count = 1;
            tp.Luid = 0;
            tp.Attr = SE_PRIVILEGE_ENABLED;
            retVal = LookupPrivilegeValue(null, privilege, ref tp.Luid);
            retVal = AdjustTokenPrivileges(htok, false, ref tp, 0, IntPtr.Zero, IntPtr.Zero);
            ///return retVal;
        }

        public static int LoadHive(RegistryHives hive, string subKey, string filePath)
        {
            AddPrivilege("SeRestorePrivilege");
            AddPrivilege("SeBackupPrivilege");

            uint regHive = (uint)hive;
            
            int result = RegLoadKey(regHive, subKey, filePath);

            return result;
        }

        public static int UnloadHive(RegistryHives hive, string subKey)
        {
            AddPrivilege("SeRestorePrivilege");
            AddPrivilege("SeBackupPrivilege");

            uint regHive = (uint)hive;
            
            int result = RegUnLoadKey(regHive, subKey);

            return result;
        }  
    }
}
'@
    if ( -not ( 'RegistryUtils.Action' -as [type] )) { Add-Type -TypeDefinition $RegistryUtils -ErrorAction Stop }

    if ( $SpecialPathLoad )
    {
        [string] $Subkey = $RegPrefix
    }
    else
    {
        if ( $Unload -and -not $HiveFile )
        {
            $Global:LastExitCode = 1

            if ( $Silent ) { Return }

            $text = if ( $L.s3_1 ) { $L.s3_1 } else { "Не указан файл куст реестра" } # Без SpecialPathLoad Префикс складывается из префикса и имени файла куста
            Write-Host "    $NameThisFunction`: $text`: '$HiveFile'" -ForegroundColor DarkYellow

            Return   # Выход из функции
        }

        [string] $Subkey = '{0}{1}' -f $RegPrefix, [System.IO.Path]::GetFileName($HiveFile)
    }

    if ( $RegRoot -eq 'MACHINE' )
    {
        $Root     = [Microsoft.Win32.Registry]::LocalMachine
        $RootHive = [Microsoft.Win32.RegistryHive]::LocalMachine

        [string] $ShowPathLoad = "HKLM\$Subkey"
    }
    else
    {
        $Root     = [Microsoft.Win32.Registry]::Users
        $RootHive = [Microsoft.Win32.RegistryHive]::Users

        [string] $ShowPathLoad = "HKU\$Subkey"
    }

    if ( $Load )
    {
        if ( -not $Silent )
        {
            $text = if ( $L.s4 ) { $L.s4 } else { "Загрузка куста реестра" }
            Write-Host "    $text`: " -ForegroundColor Blue -NoNewline
            Write-Host "$($ShowPathLoad.PadRight(21,' ')) " -ForegroundColor White -NoNewline

            $text = if ( $L.s4_1 ) { $L.s4_1 } else { "из" }
            Write-Host "| $text $HiveFile" -ForegroundColor DarkGray -NoNewline
        }

        [psobject] $OpenSubKey = $Root.OpenSubKey($Subkey)

        if ( $OpenSubKey )
        {
            $OpenSubKey.Close()

            $Global:LastExitCode = 0

            if ( $Silent ) { Return }

            $text = if ( $L.s5 ) { $L.s5 } else { "Пропущено, по этому пути куст реестра уже подгружен!" }
            Write-Host " | $text" -ForegroundColor DarkGray
        }
        else
        {
            $Global:LastExitCode = [RegistryUtils.Action]::LoadHive( $RootHive, $Subkey, $HiveFile )

            if ( $Global:LastExitCode )
            {
                if ( $Silent ) { Return }

                Write-Host "`n"

                $text = if ( $L.s6 ) { $L.s6 } else { "Ошибка при загрузке куста" }
                Write-Warning "$NameThisFunction`: $text`: '$HiveFile' | Error: $Global:LastExitCode`n"
            }
            else
            {
                if ( $Silent ) { Return }

                Write-Host " | " -ForegroundColor DarkGray -NoNewline ; Write-Host "●" -ForegroundColor Green
            }
        }
    }
    else
    {
        [psobject] $OpenSubKey = $Root.OpenSubKey($Subkey)

        if ( $OpenSubKey )
        {
            $OpenSubKey.Close()

            if ( -not $Silent )
            {
                $text = if ( $L.s7 ) { $L.s7 } else { "Выгрузка куста" }
                Write-Host "    $text`: " -ForegroundColor Blue -NoNewline
                Write-Host $ShowPathLoad -ForegroundColor White -NoNewline
            }

            [System.GC]::Collect([System.GC]::MaxGeneration, [System.GCCollectionMode]::Forced, $true)
            Start-Sleep -Milliseconds 10

            [RegistryUtils.Action]::UnloadHive( $RootHive, $Subkey ) > $null

            $OpenSubKey = $Root.OpenSubKey($Subkey)

            if ( $OpenSubKey )
            {
                [int] $TryUnload = 0
                [int] $TrySilent = 0

                do
                {
                    $TryUnload++
                    $OpenSubKey.Close()

                    if ( -not $Silent )
                    {
                        $text = if ( $L.s8 ) { $L.s8 } else { "Повторная попытка выгрузки куста" }
                        Write-Host "`n    $text`: " -ForegroundColor DarkMagenta -NoNewline
                        Write-Host $ShowPathLoad -ForegroundColor White -NoNewline
                    }
                    else { $TrySilent = $TryUnload }

                    if ( $TryUnload -eq 2 ) { Stop-Process -Name regedit -Force -ErrorAction SilentlyContinue }

                    [System.GC]::Collect([System.GC]::MaxGeneration, [System.GCCollectionMode]::Forced, $true)

                    if ( $TryUnload -ge 3 )
                    {
                        if ( -not $Silent )
                        {
                            $text = if ( $L.s9 ) { $L.s9 } else { "Что то блокирует куст, закройте все другие приложения!" }
                            Write-Host "`n      $text" -ForegroundColor Red -NoNewline
                        }

                        Start-Sleep -Milliseconds 1000
                    }
                    else
                    {
                        Start-Sleep -Milliseconds 300
                    }
 
                    [RegistryUtils.Action]::UnloadHive( $RootHive, $Subkey ) > $null

                    $OpenSubKey = $Root.OpenSubKey($Subkey)
                }
                until ( -not $OpenSubKey -or $TrySilent -ge 3 )
            }

            if ( $Silent )
            {
                if ( $OpenSubKey -and $TrySilent -ge 3 )
                {
                    $OpenSubKey.Close()
                    
                    $Global:LastExitCode = 1
                }
                else
                {
                    $Global:LastExitCode = 0
                }

                Return
            }
            else
            {
                $Global:LastExitCode = 0

                Write-Host " | " -ForegroundColor DarkGray -NoNewline ; Write-Host "●" -ForegroundColor Green
            }
        }
        else
        {
            $Global:LastExitCode = 0

            if ( $Silent ) { Return }

            $text = if ( $L.s10 ) { $L.s10 } else { "Куст реестра не подгружен" }
            Write-Host "    $NameThisFunction`: $text`: '$ShowPathLoad'" -ForegroundColor DarkGray
        }
    }
}
