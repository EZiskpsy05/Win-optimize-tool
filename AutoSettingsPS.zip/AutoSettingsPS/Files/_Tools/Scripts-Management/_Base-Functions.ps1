﻿
# Для указания не скролить консоль в строке меню, для открытия отдельных окон или приложений, чтобы команды не передавались открываемым окнам.
# Сбрасывается сама после первого использования.
Function Set-NoConsole-Scroll {
    [bool] $Global:NoConsoleScroll = $true
}

Function Get-ArchOS {
    if ( [System.Environment]::Is64BitOperatingSystem ) { 'x64' } else { 'x86' }
}

Function Get-VersOS {
    [System.Environment]::OSVersion.Version.ToString(3)
}

Function Get-RevisionOS {
    [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion','UBR',$null)
}

Function Get-LangOS {
    # Показывает Изначальный язык Windows (GetSystemDefaultUILanguage)
    #[System.Globalization.CultureInfo]::InstalledUICulture.Name 
    # Показывает Установленный языковой пакет (MUI) и настроенный у текущего пользователя.
    [System.Globalization.CultureInfo]::CurrentUICulture.Name
}

Function Get-NameOS
{
    [string] $NameOS      = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion','ProductName',$null)
    [string] $ReleaseId   = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion','ReleaseId',$null)
    [string] $DisplayVers = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion','DisplayVersion',$null)

    if ( [System.Environment]::OSVersion.Version.Build -ge 22000 ) { $NameOS = $NameOS -replace ('Windows 10','Windows 11') }

    if     ( $ReleaseId -and $DisplayVers ) { "$NameOS #DarkGray#($ReleaseId, $DisplayVers)#" }
    elseif ( $ReleaseId                   ) { "$NameOS #DarkGray#($ReleaseId)#" }
    else                                    { "$NameOS" }
}

Function Get-Delay ( [Uint16] $ms = 1000 ) {
    Start-Sleep -Milliseconds $ms
}

Function Test-Internet ( [switch] $Bool, [switch] $Access, [string] $TestURL, [switch] $Menu )
{
    if ( -not $TestURL )
    {
        # Взять адрес из Системных настроек для проверки сети
        $KeyInternet = 'HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet'
        $TestURL = [Microsoft.Win32.Registry]::GetValue($KeyInternet,'ActiveWebProbeHost',$null)
    }

    if ( -not $TestURL ) { $TestURL = 'google.com' }

    # Исключение проверки и отображения состояния интернета для меню, если так настроено в пресете
    if ( $Menu )
    {
        [string] $FilePresets = $FilePresetsGlobal

        # Если будут найдены другие файлы для настроек, состоящих из имени и расширения заданного оригинала,
        # то будет использоваться как пресет для настроек первый из дополнительных найденных.
        try
        {
            [string] $PresetsPath = [System.IO.Path]::GetDirectoryName($FilePresets)
            [string] $PresetsName = [System.IO.Path]::GetFileNameWithoutExtension($FilePresets)
            [string] $PresetsExt  = [System.IO.Path]::GetExtension($FilePresets)

            [string] $FoundPresetsMy = ((Get-ChildItem -File -LiteralPath $PresetsPath -ErrorAction Stop).Where({
                $_.Name -like "$PresetsName`?*$PresetsExt"
            },'First',1)).FullName
        }
        catch { [string] $FoundPresetsMy = '' }

        if ( $FoundPresetsMy ) { $FilePresets = $FoundPresetsMy }

        # Если файл с пресетами существует.
        if ( [System.IO.File]::Exists($FilePresets) )
        {
            # Получение пресетов в переменную.
            try { [string[]] $ListPresets = Get-Content -LiteralPath \\?\$FilePresets -Encoding UTF8 -ErrorAction SilentlyContinue }
            catch { [string[]] $ListPresets = $null }
        }

        if ( $ListPresets.Where({ $_ -match '^\s*Do-not-check-Internet\s*=\s*1\s*=' },'First',1) )
        {
            [bool] $NotCheckInternet = $true
        }
        else { [bool] $NotCheckInternet = $false }
    }

    # Отключение вывода прогресс бара
    $Global:ProgressPreference = 'SilentlyContinue'

    if ( $NotCheckInternet )
    {
        "#DarkGray#{0}#" -f $(if ( $L.s4 ) { $L.s4 } else { "Не проверялся       " })
    }
    elseif ( $Bool -and $Access )
    {
        Test-NetConnection -InformationLevel Quiet -ComputerName $TestURL -ErrorAction SilentlyContinue -WarningAction SilentlyContinue -CommonTCPPort HTTP
    }
    elseif ( $Bool )
    {
        Test-Connection $TestURL -Count 1 -BufferSize 512 -Delay 1 -Quiet -ErrorAction SilentlyContinue
    }
    elseif ( $Access )
    {
        # Получение имени этой функции.
        [string] $NameThisFunction = $MyInvocation.MyCommand.Name

        # Получение перевода
        [hashtable] $L = $Lang.$NameThisFunction
        [string] $text = ''

        if ( Test-NetConnection -InformationLevel Quiet -ComputerName $TestURL -ErrorAction SilentlyContinue -WarningAction SilentlyContinue -CommonTCPPort HTTP )
        {
            "#Green#{0} #DarkCyan#{1}#" -f $(if ( $L.s1 ) { $L.s1,$L.s1_1 } else { "OnLine", "(+ PS Доступ)" })
        }
        elseif ( Test-Connection $TestURL -Count 1 -BufferSize 512 -Delay 1 -Quiet -ErrorAction SilentlyContinue )
        {
            "#Green#{0} #Red#{1}#" -f $(if ( $L.s2 ) { $L.s2,$L.s2_1 } else { "OnLine", "(Нет Доступа)" })
        }
        else
        {
            "#Red#{0}#" -f $(if ( $L.s3 ) { $L.s3 } else { "OffLine             " })
        }
    }
    else
    {
        if ( Test-Connection $TestURL -Count 1 -BufferSize 512 -Delay 1 -Quiet -ErrorAction SilentlyContinue )
        {
            "#Green#OnLine #"
        }
        else
        {
              "#Red#OffLine#"
        }
    }

    # Возврат показа прогресс бара
    $Global:ProgressPreference = 'Continue'
}


# Функция для проверки длины строки и подсветки любых нежелательных или проблемных символов в строке
# Для вывода через функцию Write-HostColor. Нужна для проверки пути к скрипту
Function Highlight-Problem-Symbols ( [string] $StringLine = '', [string] $MainColor = 'Cyan', [string] $HighlightColor = 'White:DarkRed' ) {

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    [string] $NotProblemColor = 'DarkGray'

    if ( $StringLine )
    {
        if ( $StringLine -match '[^a-z0-9 ():\\._\-]+' )
        {
            $StringLine = ($StringLine.ToCharArray() | ForEach-Object {

                if ( $_ -match '[^a-z0-9 ():\\._\-]+' ) { "#$HighlightColor#$_#$NotProblemColor#" }
                else                                    { $_ }

            }) -join ''

            $StringLine = "#Red#{0} #DarkGray#| #$NotProblemColor#$StringLine#" -f $(if ( $L.s1 ) { $L.s1 } else { "Проблемные символы в пути!" })
        }
        elseif ( $StringLine.Length -gt 70 )
        {
            $StringLine = "#Red#{0} #DarkGray#| #$MainColor#$StringLine#" -f $(if ( $L.s2 ) { $L.s2 } else { "Путь слишком длинный!" })
        }

        "#$MainColor#$StringLine#"
    }
}


# Получение полных путей ко всем задачам по совпадениям с поисковым отрезком в имени, или полным путём
Function Get-Task-FullPaths {

    [CmdletBinding( SupportsShouldProcess = $false )]
    [OutputType( [string[]] )]
    Param(
        [Parameter( Mandatory = $false, ValueFromPipeline = $true, Position = 0 )]
        [string[]] $LikeNames
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false )]
        [switch] $CompareFullPath  # Сравнение шаблона -LikeNames с полным путём, а не только с именем задачи
    )

    Process
    {
        if ( -not $LikeNames ) { Return }

        [string[]] $TaskPaths = $null
        [psobject] $OpenRegKey = $null
        [psobject] $OpenSubKey = $null
          [string] $RegKeyTasks = 'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tasks'
          [string] $Path = ''
          [string] $Name = ''

        try
        {
            $OpenRegKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($RegKeyTasks,'ReadSubTree','QueryValues,EnumerateSubKeys')
        }
        catch { $OpenRegKey = $null }

        if ( $OpenRegKey )
        {
            foreach ( $LikeName in $LikeNames )
            {
                try
                {
                    # Поиск полного пути в разделах задач в реестре по значениям параметра Path
                    foreach ( $SubKey in $OpenRegKey.GetSubKeyNames() )
                    {
                        try { $OpenSubKey = $OpenRegKey.OpenSubKey($SubKey,'ReadSubTree','QueryValues') }
                        catch { $OpenSubKey = $null }

                        if ( $OpenSubKey )
                        {
                            $Path = $OpenSubKey.GetValue('Path',$null)

                            if ( $Path -like '\*' )
                            {
                                if ( -not $CompareFullPath )
                                {
                                    $Name = $Path -Replace ('.*\\([^\\]+$)','$1')
                                    if ( $Name -like $LikeName ) { $TaskPaths += $Path }
                                }
                                else
                                {
                                    if ( $Path -like $LikeName ) { $TaskPaths += $Path }
                                }
                            }

                            $OpenSubKey.Close()
                        }
                    }
                }
                catch {}
            }

            $OpenRegKey.Close()
        }

        $TaskPaths.Where({$_})
    }
}

# Функция для получения пути к файлу для сохранения информации + Создание глобальной переменной,
# с нужным названием и полученным путём внутри этой переменной
Function Get-SaveListPath ( [string] $FileName = 'FileName', [string] $isVarNameGlobal = 'GlobalVarName' ) {

    if ( $CurrentRoot ) { $FileRoot = $CurrentRoot } else { $FileRoot = $env:SystemDrive }
    $VarValue = "$FileRoot\$FileName`_$((Get-Date).ToString('yyyyMMdd-HHmmss')).txt"

    # переменная с полученным путём
    Set-Variable -Name $isVarNameGlobal -Value $VarValue -Scope Global -Force

    # вывод полученного пути из созданной переменной
    Return (& $([scriptblock]::Create("`$$isVarNameGlobal")))
}


<#
Пример 1: Write-Warning-Log "`n Пример предупреждения 1 `n "

Пример 2: Write-Warning-Log "`n   Пример предупреждения `n   еще одного " "D:\Warnings.log"
#>
Function Write-Warning-Log {

    [CmdletBinding()]
    Param (
        [Parameter( Mandatory = $true,  ValueFromPipeline = $false, Position = 0 )]
        [string] $Line
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false, Position = 1 )]
        [string] $FileLog = $WarningsLogFile   # По умолчанию задан глобальный лог для предупреждений, если есть.
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    Write-Warning "$Line"

    # Если не передан файл для сохранения или не назначен $WarningLog по умолчанию, сохранит в папку Temp пользователя.
    if ( $FileLog -eq '' )
    {
        # Расскрываем короткие имена в пути
        [string] $TempPath = $([System.IO.Path]::GetFullPath($env:TEMP))

        $FileLog = "$TempPath\AutoSettings-Warnings.log"

        $text = if ( $L.s1 ) { $L.s1 } else { "Это предупреждение записано в" }
        Write-host "   $text`: '$FileLog', " -BackgroundColor DarkYellow -NoNewline

        $text = if ( $L.s1_1 ) { $L.s1_1 } else { "так как файл не был назначен" }
        Write-host "$text   " -BackgroundColor DarkYellow
    }
    else
    {
        $text = if ( $L.s1 ) { $L.s1 } else { "Это предупреждение записано в" }
        Write-host "   $text`: '$FileLog'   " -BackgroundColor DarkYellow
    }

    # Out-File -FilePath $File -InputObject "$(Get-Date -Format "yyyy-MM-dd HH:mm:ss"), Warning`t$Line" -Append -Encoding utf8

    [System.Collections.Generic.List[string]] $log = "$(Get-Date -Format "yyyy-MM-dd HH:mm:ss"), Warning`t$Line"
    [System.IO.File]::AppendAllLines($FileLog,$log,[System.Text.Encoding]::GetEncoding('utf-8'))
}


<#
примеры
Save-Error
или
Save-Error D:\Errors.log
#>
Function Save-Error {

    [CmdletBinding()]
    Param (
        [Parameter( Mandatory = $false, ValueFromPipeline = $false, Position = 1 )]
        [string] $FileLog = $ErrorsLogFile  # По умолчанию задан глобальный лог для ошибок, если есть.
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    if ( $Error[0] -ne $null )
    {
        # Если не передан файл для сохранения или не назначен $ErrorsLog по умолчанию, сохранит лог в папку Temp пользователя.
        if ( $FileLog -eq '' )
        {
            $FileLog = "$env:TEMP\AutoSettings-Errors.log"

            $text = if ( $L.s1 ) { $L.s1 } else { "Эта ошибка записана в" }
            Write-host "   $text`: '$FileLog', " -BackgroundColor DarkBlue -NoNewline

            $text = if ( $L.s1_1 ) { $L.s1_1 } else { "так как файл не был назначен" }
            Write-host "$text   " -BackgroundColor DarkBlue

            try { Out-File -FilePath $FileLog -InputObject "$(Get-Date -Format "yyyy-MM-dd HH:mm:ss"), Error: ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄`n", $Error[0] -Append -Encoding utf8 -Force -ErrorAction Stop }
            catch { throw }
        }
        else
        {
            $text = if ( $L.s1 ) { $L.s1 } else { "Эта ошибка записана в" }
            Write-host "   $text`: '$FileLog'   " -BackgroundColor DarkBlue

            try { Out-File -FilePath $FileLog -InputObject "$(Get-Date -Format "yyyy-MM-dd HH:mm:ss"), Error: ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄`n", $Error[0] -Append -Encoding utf8 -Force -ErrorAction Stop }
            catch
            {
                # Если нет доступа на запись к директории скрипта, сохранить файл в папке темп пользователя
                $FileLog = "$env:TEMP\AutoSettings-Errors.log"

                $text = if ( $L.s1 ) { $L.s1 } else { "Эта ошибка записана в" }
                Write-host "   $text`: '$FileLog', " -BackgroundColor DarkBlue -NoNewline

                $text = if ( $L.s2 ) { $L.s2 } else { "так как нет доступа на запись в папку скрипта" }
                Write-host "$text   " -BackgroundColor DarkBlue

                try { Out-File -FilePath $FileLog -InputObject "$(Get-Date -Format "yyyy-MM-dd HH:mm:ss"), Error: ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄`n", $Error[0] -Append -Encoding utf8 -Force -ErrorAction Stop }
                catch { throw }
            }
        }
    }
}
