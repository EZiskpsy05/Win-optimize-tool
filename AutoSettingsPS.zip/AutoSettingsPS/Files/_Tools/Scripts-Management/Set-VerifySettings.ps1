﻿
<#
.SYNOPSIS
 Добавление, изменение в глобальной переменной $Global:VerifySettings (таблице)
 информации по проверкам функций.

.DESCRIPTION
 Написана для скрипта AutoSettingsPS.

.PARAMETER FuncName
 Принимает имя функции для добавления в таблицу по проверкам.

.PARAMETER Add
 Принимает тип добавления для имени функции.
 'Check' = Добавить, без указания необходимости исправления параметров в функции.
 'Fix'   = Добавить, с указанием необходимости исправления параметров в функции.

.PARAMETER Default
 Укзаываает, что функция выполнялась с параметром восстановления и все восстановилось без ошибок.

.EXAMPLE
    Set-VerifySettings -FuncName $FunctionName -Add Check

    Описание
    --------
    Добавит имя функции в таблицу, без пометки необходимости исправления.

.EXAMPLE
    Set-VerifySettings -FuncName $FunctionName -Default

    Описание
    --------
    Добавит к имени функции параметр Default = $true,
    что функция выполнялась для восстановления параметров, и все восстановлено.

.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  08-10-2018
 ===============================================

 #>
Function Set-VerifySettings {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $true,  Position = 0 )]
        [string] $FuncName
       ,
        [Parameter( Mandatory = $false, Position = 1 )]
        [string] $FuncArgs = ''
       ,
        [Parameter( Mandatory = $false, Position = 2, ParameterSetName = 'Add' )]
        [ValidateSet( 'Check', 'Fix' )]
        [string] $Add = 'Check'
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Default' )]
        [switch] $Default
    )

    # Проверяем существование глобальной переменной VerifySettings.
    [psobject] $VerifyFound = Get-Variable -Name VerifySettings -Scope Global -ErrorAction SilentlyContinue

    if ( -not ( $VerifyFound -and $VerifyFound.Value.GetType().Name -eq 'Hashtable' ))
    {
        Set-Variable -Name VerifySettings -Value @{} -Scope Global -Option AllScope -Force
        [hashtable] $Global:VerifySettings = @{}
    }

    # Для Поиска по имени в таблице, состоящей из имени и аргументов, необходимо, когда несколько строк с одной функцией, но разными аргументами.
    # Что бы записать их в разные ячейки таблицы.
    $FuncName = "$FuncName$FuncArgs"

    # Если в таблице по проверкам существует переданная функция и соответствует переданный аргумент.
    if ( $Global:VerifySettings[$FuncName] )
    {
        # Если не указано выполнить удаление функции из проверок.
        if ( -not $Default )
        {
            # Если указано что для функции необходимо исправление.
            if ( $Add -eq 'Fix' )
            {
                # Заменяем значение исправления Fix на $true,
                # то есть указываем на необходимость исправления параметров в этой функции, т.е. есть несоответствия.

                $Global:VerifySettings[$FuncName]['Fix']     = $true
                $Global:VerifySettings[$FuncName]['Default'] = $false
            }
            else
            {
                # Заменяем значение исправления Fix на $false,
                # то есть указываем, что нет необходимости исправления параметров в этой функции, т.е. все выполнилось без ошибок.

                $Global:VerifySettings[$FuncName]['Fix']     = $false
                $Global:VerifySettings[$FuncName]['Default'] = $false
            }
        }
        else
        {
            # Иначе, Заменяем значение 'Default' на $true у функции в таблице,
            # что функция выполнялась для восстанавления параметров, и все восстановилось.

            $Global:VerifySettings[$FuncName]['Fix']     = $false
            $Global:VerifySettings[$FuncName]['Default'] = $true
        }
    }
    else
    {
        # Иначе, функция не была еще добавлена в таблицу, и если не указано выполнение восстановления параметров.
        if ( -not $Default )
        {
             # Если указано добавить функцию, с пометкой необходимости исправления.
            if ( $Add -eq 'Fix' )
            {
                # Добавляем раздел с именем функции, и задаем значение Fix в $true.
                # то есть указываем на необходимость исправления параметров в этой функции, т.е. есть несоответствия.

                $Global:VerifySettings[$FuncName] = @{ Fix = $true  ; Default = $false }
            }
            else
            {
                # Иначе, добавляем раздел с именем функции, и задаем значение Fix и Default в $false.
                # то есть указываем, что нет необходимости исправления параметров в этой функции, т.е. все выполнилось без ошибок.

                $Global:VerifySettings[$FuncName] = @{ Fix = $false ; Default = $false }
            }
        }
        else
        {
            # Иначе, Добавляем значение 'Default' у функции в таблицу,
            # что функция выполнялась для восстанавления параметров, и все восстановилось.

            $Global:VerifySettings[$FuncName] = @{ Fix = $false ; Default = $true }
        }
    }
}
