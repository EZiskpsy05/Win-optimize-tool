﻿
<#
.SYNOPSIS
    Главный Скрипт комплекса настроек AutoSettingsPS (PowerShell 5) для настройки Windows 10 от v.17763

.DESCRIPTION
    Поддерживаемые Windows:
    Windows 10 x86/x64 от 1809 v.17763 до 2009 v.19042


.LINK
    http://forum.ru-board.com/topic.cgi?forum=62&topic=30617&start=1600#14

.NOTES
 ================================================
     Автор:  westlife (ru-board)
      Дата:  01-05-2019
 ================================================
#>

#Requires -RunAsAdministrator
#Requires -Version 5


# Определение оболочки.
if ( $host.Name -eq 'ConsoleHost' ) { [bool] $isConsole = $true }

# Если консоль, то установить параметры цвета и вывода кодировки для текущей консоли.
if ( $isConsole )
{
    $host.UI.RawUI.BackgroundColor = "Black"
    $host.PrivateData.WarningForegroundColor = "Yellow"
    $host.PrivateData.VerboseForegroundColor = "Blue"

    $BufferHeight = $host.UI.RawUI.BufferSize.Height
    if ( $BufferHeight -lt 9000 )
    {
        $BufferHeightNew = New-Object System.Management.Automation.Host.Size($host.UI.RawUI.BufferSize.Width,9000)
        $host.UI.RawUI.BufferSize = $BufferHeightNew
    }

    [Console]::OutputEncoding = [System.Text.Encoding]::GetEncoding('utf-8')
}

# Предварительное определение языка системы
if ( 'ru-RU' -ceq [System.Globalization.CultureInfo]::CurrentUICulture.Name )
{ $Ru = $true } else { $Ru = $false }

# Остановка выполнения, если скрипт запущен из 32 битной программы в 64 битной системе.
if ( [System.Environment]::Is64BitOperatingSystem -and -not [System.Environment]::Is64BitProcess )
{
    $text = if ( $Ru ) { 'Скрипт запущен из 32 битной программы. Повторите запуск из 64 битной. Выход' } else {
                         'The script is run from a 32-bit program. Repeat run from a 64-bit program. Exit' }
    Write-Host
    Write-Warning "  $text"

    $text = if ( $Ru ) { 'Для выхода нажмите любую клавишу ...' } else { 'Press any key to exit ...' }
    Write-Host "`n $text"

    if ( $isConsole ) { $host.UI.RawUI.ReadKey('NoEcho, IncludeKeyDown') > $null }
    
    Exit
}

$BuildOS = [System.Environment]::OSVersion.Version.Build

if ( $BuildOS -lt 17763 )
{
    $text = if ( $Ru ) { "Скрипт не может работать на версии Windows старше 17763, ваша версия" } else {
                         "The script cannot work on Windows version older than 17763, your version is" }
    Write-Host
    Write-Warning "  $text`: $BuildOS"

    $text = if ( $Ru ) { 'Для выхода нажмите любую клавишу ...' } else { 'Press any key to exit ...' }
    Write-Host "`n $text"

    if ( $isConsole ) { $host.UI.RawUI.ReadKey('NoEcho, IncludeKeyDown') > $null }
    
    Exit
}

# Полученные аргументы запуска этого скрипта.
[string[]] $GetArgs = $args

# Проверочные параметры аргументов запуска этого скрипта.
[string] $isArg1 = '/RunQuickSettings'
[string] $isArg2 = '/QuickExit'

# Установка постоянных переменных для быстрых настроек.
if ( $GetArgs -like $isArg1 ) { [bool] $RunQuickSettings = $true } else { [bool] $RunQuickSettings = $false }
if ( $GetArgs -like $isArg2 ) { [bool] $QuickExit        = $true } else { [bool] $QuickExit        = $false }

# Разрядность Windows
if ( [System.Environment]::Is64BitOperatingSystem ) { Set-Variable -Name ArchOS -Value ([string] 'x64') -Option Constant -Force }
else { Set-Variable -Name ArchOS -Value ([string] 'x86') -Option Constant -Force }

# Функция определения текущего расположения корневой папки в зависимости от оболочки: ISE или Консоль.
Function Get-CurrentRoot { if ( $isConsole ) { $CurrentRoot = $PSScriptRoot }
    else { $CurrentRoot = [System.IO.Path]::GetDirectoryName($psISE.CurrentFile.Fullpath) }
    $CurrentRoot = [System.IO.Path]::GetDirectoryName($CurrentRoot)
    [System.IO.Path]::GetDirectoryName($CurrentRoot)
}

################################################################################
#######################  Параметры основных переменных  ########################

$CurrentDate = Get-Date
$CurrentDateFile = $CurrentDate.ToString('yyyyMMdd-HHmmss')
$CurrentDateText = $CurrentDate.ToString('yyyy.MM.dd HH:mm:ss')

# Текущее расположение скрипта, постоянная переменная.
Set-Variable -Name CurrentRoot -Value (Get-CurrentRoot) -Option Constant -Force

# Папка для управляющих скриптов и модулей, обеспечиващих выполнение действий или отображения информации.
$ScriptsManagFolder = "$CurrentRoot\Files\_Tools\Scripts-Management"

# Папка для настраивающих систему скриптов, которые при выполнении вносят изменения в систему.
$ScriptsFolder = "$CurrentRoot\Files\_Tools\Scripts"

# Папка со всеми языковыми файлами
$LanguagePath = "$CurrentRoot\Files\_Tools\Lang"

# Папка со всеми меню.
$MenuFolder = "$CurrentRoot\Files\_Tools\Menu"

# Папка для файлов обновлений MSU и CAB.
$UpdatesFolderGlobal = "$CurrentRoot\Files\Updates"

# Папка для сохранения драйверов.
$DriversFolderGlobal = "$CurrentRoot\Files\Updates\Drivers"

# Временная папка для Dism.exe.
$DismScratchDirGlobal = "$UpdatesFolderGlobal\DismTemp"

# Папка с параметрами Групповой политики.
$GPfolderGlobal = "$CurrentRoot\Files\GP"

# Папка для папок с файлами Appx
$AppxfolderGlobal = "$CurrentRoot\Files\Appx"

# Папка для файлов со своими настройками: ps1, cmd, bat, reg.
$FolderForMySettingsGlobal = "$CurrentRoot\Files\CustomFiles"

# Папка для графических файлов Обоев рабочего стола.
$GraphicsFileFolderGlobal = "$CurrentRoot\Files"

# Файл пресетов, для указания своих параметров к некоторым функциям.
# Если рядом будет найден другой с именем начинающимся на Presets, то будет использоваться он.
$FilePresetsGlobal = "$CurrentRoot\Presets.txt"

# Файл пресетов для быстрых настроек.
# Если рядом будет найден другой с именем начинающимся на QuickPresets, то будет использоваться он.
$FileQuickPresetsGlobal = "$CurrentRoot\QuickPresets.txt"

# Файл для автоматического добавления/удаления необходимости проверки или применения,
# выполнявшяхся ранее функций, для меню проверки.
$FileVerifySettings = "$CurrentRoot\Files\VerifySettings.txt"

# Указываем файл утилиты LGPO.exe для настройки Групповых политик, через функцию Set-LGP.
$LGPOExeGlobal = "$CurrentRoot\Files\_Tools\LGPO.exe"

# Файл с текущим временем запуска для сохранения проблемных параметров ГП.
$ErrorFileGP = "$CurrentRoot\Error_LGPO_$CurrentDateFile.txt"

# Утилита MS Handle.exe, используется тут для получения списка блокирующих папки процессов (Для функции Move-Temp-Folders).
$HandleExe  = "$CurrentRoot\Files\_Tools\Handle.exe"

# Утилита ExitExplorer.exe от winaero.com, для корректного завершения процесса проводника. (Для функции ReStart-Explorer).
# http://winaero.com/blog/exitexplorer-and-restartexplorer-two-tools-to-exit-and-restart-the-explorer-shell-properly/
$ExitExplorerExe = "$CurrentRoot\Files\_Tools\ExitExplorer.exe"

# Утилита 7z.exe для извлечения отдельных файлов из архива cab,
# или чтения файла внутри архива CAB (update.mum), и распаковки cab и msu файлов.
$7z = "$CurrentRoot\Files\_Tools\7z.exe"

# Утилита Smartctl.exe v7.0 для получения смарт дисков. (Для функции Set-Drives-Icons).
# https://sourceforge.net/projects/smartmontools/
$SmartctlExe = "$CurrentRoot\Files\_Tools\Smartctl.exe"

# Утилита ffmpeg.exe v4.3.1 тут используется для обработки wav файлов
# https://ffmpeg.org/
$ffmpegExe = "$CurrentRoot\Files\_Tools\ffmpeg.exe"

# Лог для сохранения предупреждений.
$WarningsLogFile = "$CurrentRoot\AutoSettings-Warnings.log"  # Сохранение в корневой папке.

# Лог для сохранения ошибок.
$ErrorsLogFile = "$CurrentRoot\AutoSettings-Errors.log"      # Сохранение в корневой папке.

# Файл для сохранения экрана консоли, один в один, в HTML формате.
$FileHtmlLogName = "AutoSettings-HtmlLog-$CurrentDateFile.html"  # Сохранение с таким именем, ниже сценарий определения папки сохранения.

# Специальная глобальная переменная для указания необходимости исправления после проверок,
# и возможности ее изменения в любой области выполнения, при необходимости.
Set-Variable -Name NeedFix -Value $false -Option AllScope -Force

# Специальная глобальная переменная для указания что в функции или действии параметры по умолчанию не предусмотрены,
# и возможности ее изменения в любой области выполнения, при необходимости.
Set-Variable -Name noDefault -Value $false -Option AllScope -Force

###############################################################################
###############################################################################


# Результат состояния наличия прав Администратора у текущей оболочки.
$AdminRight = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
               [Security.Principal.WindowsBuiltInRole]::Administrator)

$GetLocalUsers = Get-LocalUser

# Получение типа доступа и названия, для отображения его в заголовке окна.
if ( $AdminRight )
{
    if ( [System.Security.Principal.WindowsIdentity]::GetCurrent().IsSystem )
    {
        if ( [System.Security.Principal.WindowsIdentity]::GetCurrent().Groups.Value.Where({ $_ -like 'S-1-5-80-*' },'First',1) )
        {
            [string] $CurrentRight = 'TrustedInstaller'
        }
        else
        {
            [string] $CurrentRight = 'System'
        }
    }
    else
    {
        [string] $AdminDefaultLocalUserName = ($GetLocalUsers).Where({ $_.SID.Value -match '^S-1-5-21-[\d-]+-500$'}).Name
        [string] $CurrentRight = $AdminDefaultLocalUserName
    }
}

# Изменение заголовка окна консоли, в зависимости от прав доступа.
if ( -not $AdminRight ) { $isWindowTitle = 'AutoSettingsPS' } else { $isWindowTitle = "$CurrentRight`: AutoSettingsPS" }
$host.UI.RawUI.WindowTitle = $isWindowTitle


Function Get-Preset ($File) {

    # Если будут найдены другие файлы пресетов для настроек, состоящих из имени и расширения заданного оригинала имени пресета,
    # то будет использоваться как пресет для настроек первый из дополнительно найденных файлов. например: "Presets — копия.txt"
    try
    {
        [string] $PresetsPath = [System.IO.Path]::GetDirectoryName($File)
        [string] $PresetsName = [System.IO.Path]::GetFileNameWithoutExtension($File)
        [string] $PresetsExt  = [System.IO.Path]::GetExtension($File)

        [string] $FoundPresets = ((Get-ChildItem -File -LiteralPath $PresetsPath -ErrorAction Stop).Where({
            $_.Name -like "$PresetsName`?*$PresetsExt"
        },'First',1)).FullName
    }
    catch { [string] $FoundPresets = '' }

    if ( $FoundPresets ) { $FoundPresets } else { $File }
}

# Специальная глобальная переменная для подгрузки имени файла пресета из любой области выполнения
Set-Variable -Name CurrentPresetsFile -Value '' -Option AllScope -Force
$CurrentPresetsFile = Get-Preset -File $FilePresetsGlobal

# Специальная глобальная переменная для подгрузки пресетов
Set-Variable -Name ListPresetsGlobal -Value '' -Option AllScope -Force
# Получение всех настроек из файла пресетов для использования из указанного или дополнительно найденного файла, если он существует.
$ListPresetsGlobal = Get-Content -LiteralPath \\?\$CurrentPresetsFile -Encoding UTF8 -ErrorAction SilentlyContinue

# Переменная для подстановки перевода
[string] $text = ''

# Функция для установки паузы в зависимости от оболочки: ISE или Консоль.
# Но только если запуск скрипта без аргументов автозапуска выполнения быстрых настроек.
# То есть не будет пауз при вызове функции Get-Pause во всех функциях, во время автоматического выполнения быстрых настроек.
Function Get-Pause ( [switch] $Simple ) {

    if ( -not $RunQuickSettings )
    {
        [string] $NameThisFunction = $MyInvocation.MyCommand.Name
        # Получение перевода
        [hashtable] $L = $Lang.$NameThisFunction

        if ( -not $Simple ) { RegHives-User-LoadUnload -Unload -UnloadOnlyDefault -Silent }

        if ( $isConsole )
        {
            if ( -not $Simple )
            {
                # Если в пресетах задано сохранять лог HTML, то вызов функции сохранения консоли, дополняя существующий, при каждом вызове паузы.
                # И указание на добавление к существующему всего текущего буфера с самого начала,
                # так как в функции Show-Menu выполняется очистка консоли Clear-Host.
                if ( $SaveHtmlLogGlobal )
                {
                    if ( Get-Command -CommandType Function -Name Save-HtmlLog -ErrorAction SilentlyContinue )
                    {
                        Save-HtmlLog -AllBuffer -ShowSave
                    }
                }
            }

            $text = if ( $L.s1 ) { $L.s1 } else { "Для продолжения нажмите любую клавишу ..." }
            Write-Host "`n $text"

            # Сброс нажатых клавиш клавиатуры в процессе выполнения,
            # чтобы консоль не обрабатывала эти действия после вызова паузы.
            $Host.UI.RawUI.FlushInputBuffer()

            $host.UI.RawUI.ReadKey("NoEcho, IncludeKeyDown") > $null
        }
        else
        {
            $text = if ( $L.s2 ) { $L.s2 } else { "Для продолжения нажмите 'Enter'" }
            Read-Host -Prompt "`n $text"
        }
    }
}


# Функция для подгрузки языка согласно пресету в настройке Language-Script-Forced,
# И для возможности менять перевод при загрузке/перезагрузке меню, если был изменен пресет перед этим.
Function Get-Scripts-Language {

    $Preset = Get-Preset -File $FilePresetsGlobal

    # Получение всех настроек из файла пресетов для использования из указанного или дополнительно найденного файла, если он существует.
    $ListPresetsGlobal = Get-Content -LiteralPath \\?\$Preset -Encoding UTF8 -ErrorAction SilentlyContinue

    # Получение тага принудительного языка из пресета
    if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Language-Script-Forced\s*=\s*1\s*=\s*(?<LangTagForce>[a-z-]*)\s*=' },'First',1) )
    {
        [string] $LangTagForce = $Matches.LangTagForce.Trim()
    }
    else { [string] $LangTagForce = '' }

    # [string] $CurrentLangTag = $LangTag
    # if ( $LangTag -eq $LangTagForce ) { Return }  # Для исключения подгрузки меню, если таг принудительного языка совпадает с тагом текущего | Отключил что бы изменения языкового файла обновлялись при перезагрузке меню

    $GetMUILang        = [System.Globalization.CultureInfo]::CurrentUICulture.Name
    $GetDefaultMUILang = [System.Globalization.CultureInfo]::InstalledUICulture.Name

    if ( $LangTagForce -and $LangFiles.BaseName -clike $LangTagForce ) { $LangTag = $LangTagForce      } # Перевод согласно пресету, если есть такой перевод
    elseif ( $LangFiles.BaseName -clike $GetMUILang                  ) { $LangTag = $GetMUILang        } # Иначе Установленный языковой пакет (MUI), если есть такой перевод
    elseif ( $LangFiles.BaseName -clike $GetDefaultMUILang           ) { $LangTag = $GetDefaultMUILang } # Иначе Изначальный язык Windows, если есть такой перевод
    else                                                               { $LangTag = 'en-US'            } # Иначе Дефолтный перевод en-US

    # if ( $CurrentLangTag -eq $LangTag ) { Return } # Для исключения подгрузки меню, если определённый сейчас таг языка совпадает с тагом текущего | Отключил что бы изменения языкового файла обновлялись при перезагрузке меню

    if ( 'ru-RU' -ceq $LangTag ) { $Ru = $true } else { $Ru = $false }

    $CurrentLangFile = $LangFiles.Where({ $_.BaseName -ceq $LangTag },'First',1).FullName

    try { Import-Module -Name $CurrentLangFile -Force -ErrorAction Stop }
    catch
    {
        $text = if ( $Ru ) { "Ошибка при импортировании языкового файла" } else { "Error importing language file" }
        Write-Warning "`n  $text`: '$CurrentLangFile' `n "

        throw     # При ошибке перекинуть в trap для снятий блокировок и выхода.
    }
}


################### Translation Selection start ###################

# Получение всех файлов для перевода
[array] $LangFiles = (Get-ChildItem -File -LiteralPath $LanguagePath -ErrorAction SilentlyContinue).Where({ $_.Name -match "^[a-z-]+[.]ps1$" })

if ( -not $LangFiles.Count )
{
    $text = if ( $Ru ) { "Ошибка. Не найдены языковые файлы в" } else { "Error. No language files found in" }
    Write-Warning "`n  $text '$LanguagePath' `n  Exit `n "

    Get-Pause -Simple ; Exit
}

# Переменная для изменения вывода на Русском из любой области, переменная только для главного скрипта и личных скриптов из папки \Files\...
Set-Variable -Name Ru -Value ( [bool] $false ) -Scope Global -Option AllScope -Force

# Переменная для подгрузки перевода из файлов с переводами из любой области
Set-Variable -Name Lang -Value ( [hashtable] @{} ) -Scope Global -Option AllScope -Force

# Переменная для тага языка скрипта, для изменения в любой области
Set-Variable -Name LangTag -Value ( [string] '' ) -Scope Global -Option AllScope -Force

# Получение тага принудительного языка из пресета
if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Language-Script-Forced\s*=\s*1\s*=\s*(?<LangTagForce>[a-z-]*)\s*=' },'First',1) )
{
    [string] $LangTagForce = $Matches.LangTagForce.Trim()
}
else { [string] $LangTagForce = '' }

$GetMUILang        = [System.Globalization.CultureInfo]::CurrentUICulture.Name
$GetDefaultMUILang = [System.Globalization.CultureInfo]::InstalledUICulture.Name

if ( $LangTagForce -and $LangFiles.BaseName -clike $LangTagForce ) { $LangTag = $LangTagForce      } # Перевод согласно пресету, если есть такой перевод
elseif ( $LangFiles.BaseName -clike $GetMUILang                  ) { $LangTag = $GetMUILang        } # Иначе Установленный языковой пакет (MUI), если есть такой перевод
elseif ( $LangFiles.BaseName -clike $GetDefaultMUILang           ) { $LangTag = $GetDefaultMUILang } # Иначе Изначальный язык Windows, если есть такой перевод
else                                                               { $LangTag = 'en-US'            } # Иначе Дефолтный перевод en-US

# Определить русский ли язык интерфейса, нужно до подгрузки языковых файлов и в местах где не предусмотрена поддержка языковых файлов
if ( 'ru-RU' -ceq $LangTag ) { $Ru = $true } else { $Ru = $false }

$CurrentLangFile = $LangFiles.Where({ $_.BaseName -ceq $LangTag },'First',1).FullName

try { Import-Module -Name $CurrentLangFile -Scope Global -Force -ErrorAction Stop }
catch
{
    $text = if ( $Ru ) { "Ошибка при импортировании языкового файла" } else { "Error importing language file" }
    Write-Warning "`n  $text`: '$CurrentLangFile' `n "

    throw     # При ошибке перекинуть в trap для снятий блокировок.
}

# Подгрузить перевод согласно пресету в настройке Language-Script-Forced
Get-Scripts-Language


################### Translation Selection end ###################


# Имя этого скрипта
$NameThisScript = $MyInvocation.MyCommand.Name
# Получение перевода для этого скрипта
[hashtable] $L = $Lang.$NameThisScript


if (( $CurrentRight -match 'TrustedInstaller|System' ) -or ( -not $AdminRight ))
{
    $text = if ( $L.s2 ) { $L.s2 } else { "Скрипт должен быть запущен с правами Администратора. Текущие права" }
    Write-Warning "`n  $text`: '$CurrentRight'`n`n  $($L.s0) `n"

    Get-Pause -Simple ; Exit
}


# Получение имени текущего и залогиненного пользователя, для проверки отсутствия запуска скрипта от другого пользователя. Работает на любой редакции Windows
$Process = Get-Process -IncludeUserName -ErrorAction SilentlyContinue
$CurrentUserName  = ($Process.Where({ $_.Id -eq $PID })).UserName | Split-Path -leaf -ErrorAction SilentlyContinue
$CurrentSessionId = ($Process.Where({ $_.Id -eq $PID })).SessionId
$LoginUserName = ($Process.Where({ $_.Name -match '^(svchost|sihost|taskhostw|explorer|RuntimeBroker|ctfmon)$' -and $_.SessionId -eq $CurrentSessionId },'First',1)).UserName | Split-Path -leaf -ErrorAction SilentlyContinue
# Дополнительная проверка совпадения имени пользователя и названия компьютера,
# так как это проблема и такое допускать нельзя, и это так же приводит к ошибке в "Translate()".
if ( $LoginUserName -eq $env:COMPUTERNAME )
{
    $text = if ( $L.s3 ) { $L.s3 } else { "Проблема: Имя текущего залогиненного пользователя (аккаунта) совпадает с именем компьютера`n  Переименуйте компьютер уникальным именем, они не должны совпадать!`n  Выход" }
    Write-Warning "`n  $text `n"

    $text = if ( $L.s3_1 ) { $L.s3_1 } else { "Имя пользователя" }
    Write-Warning "    $text`: '$LoginUserName'"

    $text = if ( $L.s3_2 ) { $L.s3_2 } else { "  Имя компьютера" }
    Write-Warning "    $text`: '$env:COMPUTERNAME'"

    Get-Pause -Simple ; Exit
}

if ( -not $LoginUserName )
{
    $text = if ( $L.s4_3 ) { $L.s4_3 } else { "Ошибка. Не полученно Имя залогиненного пользователя" }
    Write-Warning "`n  $text `n "
    
    $text = if ( $L.s4_1 ) { $L.s4_1 } else { " Имя запустившего пользователя" }
    Write-Host " $text`: '$CurrentUserName'" -ForegroundColor Yellow
    
    Get-Pause -Simple ; Exit
}

try { $LoginUserSID = ([System.Security.Principal.NTAccount]"$LoginUserName").Translate([System.Security.Principal.SecurityIdentifier]).Value }
catch
{
    $text = if ( $L.s4_4 ) { $L.s4_4 } else { "Ошибка при получении SID залогиненного пользователя" }
    Write-Warning "`n  $text `n "
    
    $text = if ( $L.s4_1 ) { $L.s4_1 } else { " Имя запустившего пользователя" }
    Write-Host " $text`: '$CurrentUserName'" -ForegroundColor Yellow

    $text = if ( $L.s4_2 ) { $L.s4_2 } else { "Имя залогиненного пользователя" }
    Write-Host " $text`: '$LoginUserName'" -ForegroundColor Yellow

    Get-Pause -Simple ; Exit
}

$CurrentUserSID = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
if ( -not ( $LoginUserSID -eq $CurrentUserSID ))
{
    $text = if ( $L.s4 ) { $L.s4 } else { "Скрипт должен быть запущен от текущего залогиненного пользователя (аккаунта)`n  Выход" }
    Write-Warning "`n  $text `n "

    $text = if ( $L.s4_1 ) { $L.s4_1 } else { " Имя запустившего пользователя" }
    Write-Warning "    $text`: '$CurrentUserName'"

    $text = if ( $L.s4_2 ) { $L.s4_2 } else { "Имя залогиненного пользователя" }
    Write-Warning "    $text`: '$LoginUserName'"

    Get-Pause -Simple ; Exit
}


########################################

# Проверки существования важных файлов.
if ( -not [System.IO.File]::Exists($7z) )
{
    $text = if ( $L.s5 ) { $L.s5 } else { "Не найдена утилита" }
    Write-Warning "`n   $text 7z.exe: '$7z'`n "

    Get-Pause -Simple ; Exit
}

if ( -not [System.IO.File]::Exists("$CurrentRoot\Files\_Tools\7z.dll") )
{
    $text = if ( $L.s5_1 ) { $L.s5_1 } else { "Не найден файл 7z.dll для 7z.exe" }
    Write-Warning "`n   $text`: '$CurrentRoot\Files\_Tools\7z.dll'`n "

    Get-Pause -Simple ; Exit
}

if ( -not [System.IO.File]::Exists($HandleExe) )
{
    $text = if ( $L.s5 ) { $L.s5 } else { "Не найдена утилита" }
    Write-Warning "`n   $text handle.exe: '$HandleExe'`n "

    Get-Pause -Simple ; Exit
}

if ( -not [System.IO.File]::Exists($ExitExplorerExe) )
{
    $text = if ( $L.s5 ) { $L.s5 } else { "Не найдена утилита" }
    Write-Warning "`n   $text ExitExplorer.exe: '$ExitExplorerExe'`n "

    Get-Pause -Simple ; Exit
}

if ( -not [System.IO.File]::Exists($LGPOExeGlobal) )
{
    $text = if ( $L.s5 ) { $L.s5 } else { "Не найдена утилита" }
    Write-Warning "`n   $text LGPO.exe: '$LGPOExeGlobal'`n "

    Get-Pause -Simple ; Exit
}

if ( -not [System.IO.File]::Exists($SmartctlExe) )
{
    $text = if ( $L.s5 ) { $L.s5 } else { "Не найдена утилита" }
    Write-Warning "`n   $text Smartctl.exe: '$SmartctlExe'`n "

    Get-Pause -Simple ; Exit
}


# Создание важных или нужных папок, если они не существуют.
[string[]] $FoldersGlobal =
    $UpdatesFolderGlobal,
    $DismScratchDirGlobal,
    $GPfolderGlobal,
    $AppxfolderGlobal

foreach ( $Folder in $FoldersGlobal )
{
    if ( -not [System.IO.Directory]::Exists($Folder) )
    {
        try { New-Item -ItemType Directory -Path $Folder -Force -ErrorAction Stop > $null }
        catch
        {
            $text = if ( $L.s6 ) { $L.s6 } else { "Ошибка при создании папки" }
            Write-Warning "$text`: '$Folder'`n`t$($_.exception.Message)"

            Get-Pause -Simple ; Exit
        }
    }
}
Remove-Variable -Name FoldersGlobal -Force -ErrorAction Stop


# Функция для получения версии AutoSettings из файла пресетов глобального или найденного дополнительного.
Function Get-Presets-Version {

    # Получение версии AutoSettings из пресетов.
    if ( $ListPresetsGlobal.Where({ $_ -match '^\s*AutoSettings-Version\s*=\s*(?<Version>[^=#\n\r]+)\s*=' },'First',1) )
    {
        [string] $Version = $Matches.Version.Trim()
    }
    else { [string] $Version = '' }

    $Version
}

# Получение версии AutoSettings из файла пресетов глобального или найденного дополнительного.
[string] $AutoSettingsVersion = Get-Presets-Version

if ( -not $AutoSettingsVersion )
{
    $text = if ( $L.s7 ) { $L.s7 } else { "Не найден основной файл пресетов, или он неверный" }
    Write-Warning "`n  $text`: '$FilePresetsGlobal'. `n  $($L.s0) `n "

    Get-Pause -Simple ; Exit
}

$isWindowTitle = "$isWindowTitle | $AutoSettingsVersion"
$host.UI.RawUI.WindowTitle = $isWindowTitle

# Функция для получения лога и его переменных.
Function Get-HtmlLog {

    [string] $NameThisFunction = $MyInvocation.MyCommand.Name
    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction

    # Получение из пресетов разрешающего параметра по сохранению консоли в HTML файл,
    # И если сохранять, то создать глобальную константную переменную, разрешающую сохранять.
    if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Save-HTML-Log\s*=\s*1\s*=(\s*(?<FolderLogs>[a-z0-9]*)\s*=)?' },'First',1) )
    {
        # Если указано в пресете имя папки для логов внутри папки скрипта, то сохранять в эту папку, если папки нет, то создать её, иначе сохранять в корень папки.
        if ( $Matches.FolderLogs )
        {
            $FolderLogs = $Matches.FolderLogs.Trim()
            $Path       = "$CurrentRoot\$FolderLogs"

            Set-Variable -Name FileHtmlLogGlobal -Value "$Path\$FileHtmlLogName" -Scope Global -Option ReadOnly -Force

            if ( -not [System.IO.Directory]::Exists($Path) )
            {
                try { New-Item -ItemType Directory -Path $Path -Force -ErrorAction Stop > $null }
                catch
                {
                    $text = if ( $L.s1 ) { $L.s1 } else { "Ошибка при создании папки" }
                    Write-Warning "$text`: '$Path'`n`t$($_.exception.Message)"

                    Get-Pause -Simple ; Exit
                }
            }
        }
        else
        {
            Set-Variable -Name FileHtmlLogGlobal -Value "$CurrentRoot\$FileHtmlLogName" -Scope Global -Option ReadOnly -Force
        }

        Set-Variable -Name SaveHtmlLogGlobal -Value ( [bool] $true ) -Scope Global -Option ReadOnly -Force

        $ShowLogInMainMenu = "#DarkGray#{0}#" -f $FileHtmlLogGlobal.Replace("$CurrentRoot\",'')
    }
    else
    {
        Set-Variable -Name SaveHtmlLogGlobal -Value ( [bool] $false ) -Scope Global -Option ReadOnly -Force

        $ShowLogInMainMenu = "#DarkGray#{0}#" -f $(if ( $L.s2 ) { $L.s2 } else { "Не сохраняется" })
    }

    $ShowLogInMainMenu
}


# Получение лога и создание глобальных переменных с лог файлом и разрешением/запретом сохранения лога
Get-HtmlLog > $null


# Получение списка с полными путями всех скриптов и модулей '.ps1' и '.psm1' из указанной папки, включая поддиректории.
Function Get-Scripts {
    [CmdletBinding( SupportsShouldProcess = $false )]
    Param (
        [Parameter( Mandatory = $true, ValueFromPipeline = $false, Position = 0 )]
        [ValidatePattern("^[a-z]:\\.+")]
        [string] $Path
    )
    [string[]] $Scripts = ((Get-ChildItem -File -LiteralPath $Path -Recurse -ErrorAction SilentlyContinue).Where({ $_.Name -match "[.]ps1$|[.]psm1$" })).FullName
    $Scripts
}

# Получение списка всех настраивающих систему модулей и скриптов с полными путями.
$ScriptsFiles = Get-Scripts -Path $ScriptsFolder

# Подключение настраивающих систему скриптов и модулей. При ошибке импорта будет перехватывать в trap для удаления меток Zone.Identifier
if ( $ScriptsFiles )
{
    foreach ( $ScriptsFile in $ScriptsFiles )
    {
        try   { Import-Module -Name $ScriptsFile -Scope Global -Force -ErrorAction Stop }
        catch
        {
            $text = if ( $L.s8 ) { $L.s8 } else { "Ошибка при импортировании скрипта" }
            Write-Warning "`n  $text`: '$ScriptsFile' `n "

            throw  # При ошибке перекинуть в trap для снятий блокировок.
        }
    }
}

# Получение списка управляющих модулей и скриптов с полными путями.
$ScriptsManagFiles = Get-Scripts -Path $ScriptsManagFolder

# Подключение управляющих скриптов и модулей, в последнюю очередь, так как эти в приоритете.
# Перекроют все функции из других скриптов, при совпадении имен.
if ( $ScriptsManagFiles )
{
    foreach ( $ScriptsManagFile in $ScriptsManagFiles )
    {
        try   { Import-Module -Name $ScriptsManagFile -Scope Global -Force -ErrorAction Stop }
        catch
        {
            $text = if ( $L.s8 ) { $L.s8 } else { "Ошибка при импортировании скрипта" }
            Write-Warning "`n  $text`: '$ScriptsManagFile' `n "

            throw # При ошибке перекинуть в trap для снятий блокировок.
        }
    }
}
else
{
    $text = if ( $L.s9 ) { $L.s9 } else { "Ошибка. Не найдены cкрипты в папке" }
    Write-Warning "`n  $text '$ScriptsManagFolder' `n  $($L.s0) `n "

    Get-Pause -Simple ; Exit
}

# Получение типа ОС (Virtual/Physical) из инструкции процессора CPUID (по 31 биту)
$isWindowTitle = "$isWindowTitle | $(Get-CpuID isTypeOS)"
$host.UI.RawUI.WindowTitle = $isWindowTitle

# Получение списка всех скриптов с меню, с полными путями.
$MenuFiles = Get-Scripts -Path $MenuFolder

# Подключение всех меню.
if ( $MenuFiles )
{
    foreach ( $Menu in $MenuFiles )
    {
        try { Import-Module -Name $Menu -Scope Global -Force -ErrorAction Stop }
        catch
        {
            $text = if ( $L.s10 ) { $L.s10 } else { "Ошибка при импортировании скрипта с меню" }
            Write-Warning "`n  $text`: '$Menu' `n  $($L.s0) `n "

            Get-Pause -Simple ; Exit
        }
    }
}
else
{
    $text = if ( $L.s11 ) { $L.s11 } else { "Ошибка. Не найдены cкрипты с меню в папке" }
    Write-Warning "`n  $text '$MenuFolder' `n $($L.s0) `n "

    Get-Pause -Simple ; Exit
}


$BuildOS = [System.Environment]::OSVersion.Version.Build
# Если версия Windows старее 1809 или новее 21H2 (В том числе W11)
if ( $BuildOS -lt 17763 -or $BuildOS -gt 22000 )
{
    [string] $UnsupportedOS = "#White:DarkRed# {0} #" -f $(if ( $L.s12 ) { $L.s12 } else { "Неподдерживаемая версия Windows!" })
}
else { [string] $UnsupportedOS = '' }


##########################################################################

# Получение данных по локальным пользователям
[array] $Global:DataLocalUsers = @()

# Функция для получения списка пользователей, которых нужно настраивать вместе с основным аккаунтом и подгрузки их кустов
Function Select-Load-LocalUsers {

    # Получение выбора нужных пользователей
    if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Configure-Local-Users\s*=\s*(?<SelectUsers>[1234])\s*=' },'First',1) )
    {
        [string] $SelectUsers = $Matches.SelectUsers.Trim()
    }
    else { [string] $SelectUsers = '' }

    # Глобальное разрешение на перенаправление для Set-Reg и Set-LGP, для возможности временного запрета перенаправления:
    # для всех параметров в нужных местах для всех пользователей или только дефолтного профиля
    [array] $Global:DataLocalUsers = [PSCustomObject] @{ Redirects = @{ Value = $true ; DefaultAccount = $true }}

    [array] $LocalUsers = @()
    [array] $LocalUsersUseSIDs = @()
     [bool] $Use = $false   # Если true - Загружать сразу и не выгружать кусты

    # Добавление в список локальных профилей
    $LocalUsers = @($GetLocalUsers).Where({ $_.PrincipalSource -eq 'Local' -and $_.SID.Value -match '^S-1-5-21-.+-(50[03]|1[\d]{3})$' })

    # Добавление в список не локальных профилей из реестра (домен)
    $RegKey = 'SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList'
    try { $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($RegKey,'ReadSubTree','QueryValues,EnumerateSubKeys') } catch {}

    if ( $OpenSubKey )
    {
        foreach ( $RegSID in ( $OpenSubKey.GetSubKeyNames() -match '^S-1-5-21-.+-[\d]{4,8}$' ))
        {
            if ( -not ( $LocalUsers.SID.Value -like $RegSID ))
            {
                try
                {
                    [psobject] $ProfileSID  = $null
                      [string] $ProfileName = ''

                    $ProfileSID  = [System.Security.Principal.SecurityIdentifier]::new($RegSID)
                    $ProfileName = $ProfileSID.Translate([System.Security.Principal.NTAccount]).Value -Replace ('.+\\','')

                    if ( $ProfileName )
                    {
                        $LocalUsers += New-Object PSObject -Property @{ Name = $ProfileName ; SID = $ProfileSID ; Enabled = $true }
                    }
                }
                catch {}
            }
        }

        $OpenSubKey.Close()
    }

    if ( '1' -eq $SelectUsers )
    {
        $LocalUsersUseSIDs = @($LocalUsers).Where({ $_.SID.Value -like 'S-1-5-21-*-503' }).SID.Value # Только DefaultAccount
    }
    elseif ( '2' -eq $SelectUsers )
    {
        $LocalUsersUseSIDs = @($LocalUsers).Where({ $_.SID.Value -match '^S-1-5-21-.+-1[\d]{3}$' }).SID.Value # Только Users
    }
    elseif ( '3' -eq $SelectUsers )
    {
        $LocalUsersUseSIDs = $LocalUsers.SID.Value  # Все
    }
    elseif ( '4' -eq $SelectUsers )
    {
        # Получение выбора нужных пользователей
        if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Configure-Local-Users\s*=\s*4\s*=(?<SpecifiedUsers>[^\r\n\t\x02\x1c\x1d\x1e\x1f<>|:?*``""=#\\\/]+)==' },'First',1) )
        {
            [string[]] $SpecifiedUsers = @($Matches.SpecifiedUsers.Split(',').Trim()).Where({$_})
        }
        else { [string[]] $SpecifiedUsers = @() }

        if ( $SpecifiedUsers.Count )
        {
            $LocalUsersUseSIDs = @($LocalUsers).Where({ $_.Name -match "^($($SpecifiedUsers -join '|'))$" }).SID.Value  # Только Указанные в пресете
        }
    }

    foreach ( $User in $LocalUsers )
    {
        if ( $User.SID -eq [Security.Principal.WindowsIdentity]::GetCurrent().User.Value ) { Continue }
        elseif ( $User.SID -like 'S-1-5-21-*-503' )
        {
            $Profile = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList",'Default',$null)
            $ProfileType = 'DefaultAccount'
            $UserEnabled = $true
        }
        else
        {
            $Profile = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList\$($User.SID)",'ProfileImagePath',$null)
            $ProfileType = 'User'
            $UserEnabled = $User.Enabled
        }
        
        if ( $LocalUsersUseSIDs -like $User.SID ) { $Use = $true } else { $Use = $false }

        # Если профиль найден и аккаунт включен
        if ( $Profile -and $UserEnabled )
        {
            $Global:DataLocalUsers += [PSCustomObject] @{ 
                Name          = $User.Name
                SID           = $User.SID
                Profile       = [System.Environment]::ExpandEnvironmentVariables($Profile)
                ProfileType   = $ProfileType
                NTUSER_Load   = $false  # Загружен ли был куст
                UsrClass_Load = $false  # Загружен ли был куст
                Use           = $Use
            }
        }
    }

    # Подгрузить все кусты, кроме профиля по умолчанию. Его будет подгружать при необходимости через Set-Reg или Set-LGP, и в конце выполнения выгружать во время паузы.
    $Global:DataLocalUsers = RegHives-User-LoadUnload $Global:DataLocalUsers -LoadExceptDefault -Silent -Load
}

Function Show-Selected-Users ( [switch] $OnlyUsers ) {
    
    # Получение перевода
    [hashtable] $L = $Lang.$($MyInvocation.MyCommand.Name)

    [array] $AccNames = @()

    if ( $Global:DataLocalUsers.Redirects.Value )
    {
        [PSObject] $OpenSubKey = $null
        [bool] $UserOnline = $false

        if ( $OnlyUsers )
        {
            @($Global:DataLocalUsers.Where({ $_.Use -and $_.ProfileType -eq 'User' -and $_.Profile -and $_.SID -and $_.NTUSER_Load })).ForEach({
            
                $OpenSubKey = [Microsoft.Win32.Registry]::Users.OpenSubKey("$($_.SID)\Software\Classes",'ReadSubTree','QueryValues,EnumerateSubKeys')
                if ( $OpenSubKey ) { $UserOnline = $true ; $OpenSubKey.Close() } else { $UserOnline = $false }
                
                $AccNames += [PSCustomObject] @{
                    Name   = $_.Name
                    Online = $UserOnline
                }
            })
        }
        else
        {
            @($Global:DataLocalUsers.Where({ $_.Use -and $_.Profile -and $_.SID -and $_.NTUSER_Load })).ForEach({
            
                if ( $_.ProfileType -eq 'User' )
                {
                    $OpenSubKey = [Microsoft.Win32.Registry]::Users.OpenSubKey("$($_.SID)\Software\Classes",'ReadSubTree','QueryValues,EnumerateSubKeys')
                    if ( $OpenSubKey ) { $UserOnline = $true ; $OpenSubKey.Close() } else { $UserOnline = $false }
                }

                $AccNames += [PSCustomObject] @{
                    Name   = $_.Name
                    Online = $UserOnline
                }
            })
        }
    }

    if ( $AccNames.Count )
    {
        $text = if ( $L.s1 ) { $L.s1 } else { "Залогинен" }

        $N = 0

        foreach ( $AccName in $AccNames )
        {
            if ( -not $N )
            {
                if ( $AccName.Online ) { $ShowUsers = "#Green#$env:UserName# + #Yellow#$($AccName.Name) ($text)" }
                else { $ShowUsers = "#Green#$env:UserName# + #White#$($AccName.Name)" }
            }
            else
            {
                if ( $AccName.Online ) { $ShowUsers += "#DarkGray#, #Yellow#$($AccName.Name) ($text)" }
                else { $ShowUsers += "#DarkGray#, #White#$($AccName.Name)" }
            }
            $N++
        }
    }
    else
    {
        $ShowUsers = "#Green#$env:UserName#"
    }

    $ShowUsers
}


##########################################################################


# Если скрипт запущен с правильными аргументами для запуска быстрых настроек.
if ( $RunQuickSettings )
{
    $text = if ( $L.s13 ) { $L.s13 } else { "Запуск Quick Settings на выполнение" }
    Write-Host "`n██████████████████ $text`n" -ForegroundColor Cyan

    # Получить данные локальных аккаунтов и подгрузить их кусты реестра, согласно текущему пресету. Кроме дефолтного профиля.
    Select-Load-LocalUsers

    Run-QuickSettings -Options SetConfigs,SetMySettingsPS,SetMySettingsCMD,SetMySettingsREG -Act Set

    $text = if ( $L.s14 ) { $L.s14 } else { "Quick Settings выполнены" }
    Write-Host "`n██████████████████ $text`n" -ForegroundColor Cyan

    RegHives-User-LoadUnload -Unload -UnloadOnlyDefault -Silent

    # Если в пресетах задано сохранять лог HTML, то вызов функции сохранения консоли, дополняя существующий.
    if ( $SaveHtmlLogGlobal ) { Save-HtmlLog -ShowSave }

    if ( $QuickExit ) { Exit }

    if ( $isConsole )
    {
        $text = if ( $L.s15 ) { $L.s15 } else { "Для выхода нажмите любую клавишу ..." }
        Write-Host "`n $text"

        $Host.UI.RawUI.FlushInputBuffer()
        $host.UI.RawUI.ReadKey("NoEcho, IncludeKeyDown") > $null
    }

    Exit
}


# Назначение главного меню '$MainMenu' в переменную '$isStartMenu' для текущего меню, так как все начинается с этого меню.
# В этом главном меню указываются переходы в какие либо другие меню, или какие либо действия.
# По описанию (Description) определяется какое именно текущее меню в данный момент.
Set-Variable -Name isStartMenu -Value $MainMenu -Description '$MainMenu' -Scope Global -Option AllScope -Force

# Бесконечный цикл для запуска/перезапуска любого меню, заданного в глобальной переменной $isStartMenu в данный момент,
# выполняется после каждого выхода из функции Show-Menu по обработке меню.
# Перед завершением функции Show-Menu, для входа в любое указанное меню, перезадается нужное меню в глобальную переменную $isStartMenu.
# Для обеспечения, каждый раз, новой точки входа в функцию Show-Menu, а не запуск функции Show-Menu внутри функции Show-Menu, что приведет к проблеме.
do
{
    # Получение названия переменной текущего меню из $isStartMenu, оно указывается в описании этой переменной.
    [string] $CurrentMenuName = (Get-Variable -Name isStartMenu -ErrorAction SilentlyContinue).Description

    # Подгрузить перевод согласно текущему пресету. После получения текущего файла пресетов и его данных.
    Get-Scripts-Language

    # Получить данные локальных аккаунтов и подгрузить их кусты реестра, согласно текущему пресету. Кроме дефолтного профиля.
    Select-Load-LocalUsers

    # Получение перевода для текущего меню, чтобы переменные с переводом расскрылись внутри меню из своей таблицы, при импорте скрипта с меню.
    [hashtable] $L = $Lang.$CurrentMenuName

    # Ищем во всех найденных файлах с меню, полный путь к текущему меню, и переподключаем его.
    # Чтобы не переподключать все меню каждый раз, а только нужное в данный момент. Для обновления переменных, указанных в нем.
    $MenuFiles.Where({ $_ -like "*$CurrentMenuName*" }).ForEach(
    {
        try { Import-Module -Name $_ -Scope Global -Force -ErrorAction Stop }
        catch
        {
            # Получение перевода этого скрипта, так как в начале do идет получение перевода для меню
            [hashtable] $L = $Lang.$NameThisScript

            $text = if ( $L.s10 ) { $L.s10 } else { "Ошибка при импортировании скрипта с меню" }
            Write-Warning "`n  $text`: '$_' `n  $($L.s0) `n "

            Get-Pause ; Exit
        }
    })

    # Создание скриптблока для возможности перевода имени переменной, в объект из этой переменной. В данном случае hashtable меню.
    [psobject] $MenuScriptBlock = [scriptblock]::Create( $CurrentMenuName )

    # Назначение в переменную $isStartMenu текущего меню с именем из $CurrentMenuName по новой, с обновленными переменными,
    # после перевода скриптблока $MenuScriptBlock в объект hashtable.
    Set-Variable -Name isStartMenu -Value ( & $MenuScriptBlock ) -Description $CurrentMenuName -Scope Global -Option AllScope -Force

    # Вывод текущего обновленного меню.
    Show-Menu -Menu $isStartMenu
}
while ( $true )



##########################################################################

# Получение перевода этого скрипта, так как в do идет получение перевода для меню
[hashtable] $L = $Lang.$NameThisScript

# Сообщение о Выходе из скрипта, если такое произойдет из-за ошибки.
$text = if ( $L.s16 ) { $L.s16 } else { "Ошибка. Выполнен переход в конец скрипта. Выход" }
Write-Warning "`n     $text `n "

Get-Pause
Exit

trap
{
    # Если есть функция Save-Error
    if ( Get-Command -CommandType Function -Name 'Save-Error' -ErrorAction SilentlyContinue )
    {
        $text = if ( $Ru ) { 'Перехвачена ошибка для сохранения' } else { 'An error was intercepted for saving' }
        Write-Host "   --- $text ---   " -BackgroundColor DarkGray

        Save-Error
    }
    else
    {
        Write-Output "`n" $Error[-1]

        $text = if ( $Ru ) { 'Произошла ошибка в главном скрипте AutoSettingsPS.ps1' } else { 'An error has occurred in the main AutoSettingsPS.ps1 script' }
        Write-Host "`n   !!! $text !!!`n" -ForegroundColor White -BackgroundColor DarkRed

        [int] $ZoneCount = 0

        # Поиск и удаление Zone.Identifier у файлов.
        try
        {
            (Get-ChildItem -File -LiteralPath $CurrentRoot -Recurse -ErrorAction SilentlyContinue).FullName | ForEach-Object {

                if ( Get-Item $_ -Stream Zone.Identifier -ErrorAction SilentlyContinue )
                {
                    $ZoneCount++

                    $text = if ( $Ru ) { 'Удаление Zone.Identifier' } else { 'Removing Zone.Identifier' }
                    Write-Host "   $ZoneCount. $text`: " -ForegroundColor Cyan -NoNewline

                    Write-Host "$($_ | Split-Path -Leaf)" -ForegroundColor DarkGray
                    try { Unblock-File -LiteralPath \\?\$_ -ErrorAction SilentlyContinue } catch {}
                }
            }
        }
        catch {}

        if ( $ZoneCount )
        {
            $text = if ( $Ru ) { 'Удаление блокирующих меток Zone.Identifier выполнено, перезапустите скрипт' }
                    else       { 'Removing the Zone.Identifier blocking marks is done, restart the script'    }
        }
        else
        {
            $text = if ( $Ru ) { 'Не найдено блокирующих меток Zone.Identifier' } else { 'No Zone.Identifier blocking marks found' }
        }

        Write-Host "`n   $text" -ForegroundColor Green

        if ( $host.Name -eq 'ConsoleHost' ) { $Root = [System.IO.Path]::GetDirectoryName([System.IO.Path]::GetDirectoryName($PSScriptRoot)) }
        try { $VersASPS = [regex]::Match((Get-Content -LiteralPath \\?\$Root\Presets.txt -Encoding UTF8 -ErrorAction SilentlyContinue),
        '\s*AutoSettings-Version\s*=\s*(?<Version>[^=#\n\r]+)\s*=','IgnorePatternWhitespace').Groups.Where({$_.Name -eq 'Version'}).Value } catch {}
        Write-Host "`n   AutoSettingsPS: v." -ForegroundColor DarkGray -NoNewline ; "$VersASPS "

        try { [string] $NameOS      = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion','ProductName',$null) } catch {}
        try { [string] $ReleaseId   = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion','ReleaseId',$null) } catch {}
        try { [string] $DisplayVers = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion','DisplayVersion',$null) } catch {}
        try { [string] $BuildLab    = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion','BuildLab',$null) } catch {}
        
        Write-Host "          Name OS: " -ForegroundColor DarkGray -NoNewline
        
        if ( $ReleaseId -and $DisplayVers ) { "$NameOS ($ReleaseId, $DisplayVers) " }
        elseif ( $ReleaseId )               { "$NameOS ($ReleaseId) " }
        else                                { "$NameOS " }

        try { [string] $VersOS = "$([System.Environment]::OSVersion.Version.ToString(3)).$([Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion','UBR',$null))" } catch {}
        Write-Host   "       Version OS: " -ForegroundColor DarkGray -NoNewline ; Write-Host   "$VersOS" -NoNewline ; Write-Host "   ($BuildLab)" -ForegroundColor DarkGray

        try { $Arch = "{0}" -f $(if ( [System.Environment]::Is64BitOperatingSystem ) { 'x64' } else { 'x86' }) } catch {}
        Write-Host   "          Arch OS: " -ForegroundColor DarkGray -NoNewline ; "$Arch "

        try { $ArchProcess = "{0}" -f $(if ( [System.Environment]::Is64BitProcess ) { 'x64' } else { 'x86' }) } catch {}
        Write-Host   "     Arch Process: " -ForegroundColor DarkGray -NoNewline ; "$ArchProcess "

        try { [string] $MUI = [System.Globalization.CultureInfo]::CurrentUICulture.Name } catch {}
        Write-Host   "              MUI: " -ForegroundColor DarkGray -NoNewline ; "$MUI "
        try { [string] $DefaultMUI = [System.Globalization.CultureInfo]::InstalledUICulture.Name } catch {}
        Write-Host   "      Default MUI: " -ForegroundColor DarkGray -NoNewline ; "$DefaultMUI "
        try { [string] $PSVers = $PSversionTable.PSVersion.ToString() } catch {}
        Write-Host   "          PS Vers: " -ForegroundColor DarkGray -NoNewline ; "$PSVers "

        $text = if ( $Ru ) { 'Для выхода нажмите любую клавишу ...' } else { 'Press any key to exit ...' }
        Write-Host "`n $text" -ForegroundColor Gray

        $host.UI.RawUI.ReadKey("NoEcho, IncludeKeyDown")
        Exit
    }
}
