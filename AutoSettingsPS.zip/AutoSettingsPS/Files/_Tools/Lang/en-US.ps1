﻿
# Language en-US

$Lang = @{

    'AutoSettings.ps1' = @{

        s0 = 'Exit'
        s1 = ""
        s2 = "The script must be run with Administrator rights. Current rights"
        s3 = "Problem: The name of the current logged-in user (account) matches the computer name`n  Rename the computer with a unique name, they must not match! `n  Exit"
      s3_1 = "    User name"
      s3_2 = "Computer name"

        s4 = "The script must be run from the current logged-in user (account) `n  Exit"
      s4_1 = "  The name of the running user"
      s4_2 = "The name of the logged in user"
      s4_3 = "Error. Not received logged in user name"
      s4_4 = "Error getting the SID of a logged in user"

        s5 = 'Utility not found'
      s5_1 = 'The 7z.dll file was not found for 7z.exe'

        s6 = 'Error creating folder'
        s7 = 'The main preset file was not found, or it is not correct'
        s8 = 'Error importing script'
        s9 = 'Error. No scripts found in the folder'
       s10 = 'Error importing script with menu'
       s11 = 'Error. No scripts found with menu in folder'
       s12 = 'Unsupported version of Windows!'
       s13 = 'Starting the Quick Settings to perform'
       s14 = 'Quick Settings completed'
       s15 = 'Press any key to exit ...'
       s16 = 'Error. The transition to the end of the script is performed. Exit'
    }

    'Get-Pause' = @{
        s1 = 'Press any key to continue ...'
        s2 = "Press 'Enter'to continue"
    }

    'Show-Selected-Users' = @{
        s1 = 'Logged'
    }

    'Test-Internet' = @{
        s1 = "OnLine" ; s1_1 = "(+ PS Access)"
        s2 = "OnLine" ; s2_1 = "(No Access)  "
        s3 = "OffLine             "
        s4 = "Not checked         "
    }

    'Get-HtmlLog' = @{
        s1 = 'Error creating folder'
        s2 = "Not saved"
    }

    '$MainMenu' = @{

        s1 = ' Configuring'

        s2 = 'Your Windows'

        s3 = '      Folder'

      s3_1 = '     Presets'
      s3_2 = 'QuickPresets'
      s3_3 = '         Log'
      s3_4 = '     Account'

        s4 = 'Options for selection'

        s5 = 'Menu for Applying or Restoring all Settings to Default | QuickPresets*.txt'
        s6 = 'Menu for Applying, Checking or Restoring Important Settings | Presets*.txt'
        s7 = 'Menu for Windows Personal Settings'
        s8 = 'Group Policy  ' ;  s8_1 = 'Menu for applying or resetting Group Policy'
        s9 = 'Windows Update' ;  s9_1 = 'Menu for managing Windows Update Center and drivers'
       s10 = 'Maintenance   ' ; s10_1 = 'Menu for managing and performing Windows Maintenance'

       s11 = 'Restart Computer' ; s11_1 = 'Forced'

       s20 = 'Restoration' ; s20_1 = 'Menu for Restoring all settings at once to Default'

       s21 = 'No input' ; s21_1 = 'Exit                                                                              ' ; s21_2 = 'Version'

    }

    'Show-Menu' = @{

        s1 = "No 'Exit' menu item" ; s1_1 = 'section' ; s1_2 = 'Menu Execution Line'
        s2 = 'Error executing command' ; s2_1 = 'In function' ; s2_2 = 'when processing the menu' ; s2_3 = 'in section' ; s2_4 = 'in the section line'
        s3 = 'Your choice'
        s4 = 'No matches. Option' ; s4_1 = 'does not exist!'
        s5 = 'No such command (function or cmdlet)'
        s6 = 'No such menu'
        s7 = 'Error in function' ; s7_1 = 'command' ; s7_2 = 'Problem in choosing' ; s7_3 = 'and line execution'
        s8 = 'Error in Process'
    }

    'Show-MenuLine' = @{

        s1 = 'Error in command'
    }

    '$Menu_SelfMenu' = @{

        s1 = 'Windows Personal Settings for Experienced!'
        s2 = 'Configurable parameters can be changed in the preset file, the current file'

        s3 = 'Defender'  ; s3_1 = ' · · · · · · · ' ;  s3_2 = 'Tamper Protection'
        s4 = 'Boot optimization'  ; s4_1 = '  · · ' ;  s4_2 = 'Hibernate' ; s4_3 = 'Fast boot' ; s4_4 = 'Optimization Service'
        s5 = 'Search, Cortana, Index' ;  s5_1 = ' ' ;  s5_2 = 'Cortana' ; s5_3 = 'Indexing Component'

        s6 = 'Network'  ; s6_1 = '  · · · · · · · ' ;  s6_2 = 'Menu for network settings'
        s7 = 'Explorer'  ; s7_1 = ' · · · · · · · ' ;  s7_2 = 'Menu for customizing showing of Explorer items'

        s8 = 'Windows Photo Viewer'  ; s8_1 = ' · ' ;  s8_2 = 'Support'
        s9 = 'Event logs'  ; s9_1 = ' · · · · · · ' ;  s9_2 = 'Logs' ; s9_3 = 'Service'
       s10 = 'User Account Control' ; s10_1 = ' · '
       s11 = 'Registry Backup' ; s11_1 = '  · · · ' ; s11_2 = 'Task'

       s12 = 'User Folders' ; s12_1 = ' · · · · · ' ; s12_2 = 'Menu to change the location (My Documents, Music etc.)'
       s13 = 'Temp Folder: User' ; s13_1 = '  · · ' ; s13_2 = 'SymLink'
       s14 = 'Temp Folder: System' ; s14_1 = '  · ' ; s14_2 = 'SymLink'
       s15 = 'Prevent run of EXE' ; s15_1 = ' · · ' ; s15_2 = 'Locked Files'

       s16 = 'Manage Apps/Appx' ; s16_1 = ' · · · ' ; s16_2 = 'Download/Install/Re-registration/Uninstall Modern Applications'
       s17 = 'Sound profiles' ; s17_1 = ' · · · · ' ; s17_2 = 'Profile'
       s18 = 'Features/Capabilities' ; s18_1 = '  ' ; s18_2 = 'Configuring Windows Optional Features and Capabilities'

       s19 = 'File associations' ; s19_1 = '  · · ' ; s19_2 = 'Configuring File Associations and Protocols'

       s30 = 'No input' ; s30_1 = 'Return to Main Menu'
    }

    '$Menu_Move_Temp_System' = @{

        s1 = 'Changing the location of the' ; s1_1 = 'Temp system folder'
        s2 = 'Ability to create a' ; s2_1 = 'symbolic link' ; s2_2 = 'instead of the default folder, for compatibility.'
        s3 = 'Close all programs before executing!' ; s3_1 = "You can specify one location with the user's Temp folder"
        s4 = 'You can set your location in the preset file, the current file'

        s5 = 'At the moment'
        s6 = '  Folder Temp'
        s7 = 'Symbolic link'
        s8 = 'Options for selection'

        s9 = 'Change' ;  s9_1 = 'to' ; s9_2 = 'And make a' ; s9_3 = 'link' ; s9_4 = 'instead'
       s10 = 'Restore' ; s10_1 = 'to' ; s10_2 = 'Default'
       s11 = 'No input' ; s11_1 = 'Return to the Personal Settings menu'
    }

    '$Menu_Move_Temp_User' = @{

        s1 = 'Changing the location of the' ; s1_1 = 'Temp folder' ; s1_2 = 'for the' ; s1_3 = 'current user'
        s2 = 'Ability to create a' ; s2_1 = 'symbolic link' ; s2_2 = 'instead of the default folder, for compatibility.'
        s3 = 'Close all programs before executing!' ; s3_1 = 'You can specify one location with the Temp system folder'
        s4 = 'You can set your location in the preset file, the current file'

        s5 = 'At the moment'
        s6 = '  Folder Temp'
        s7 = 'Symbolic link'
        s8 = 'Options for selection'

        s9 = 'Change' ;  s9_1 = 'to' ; s9_2 = 'And make a' ; s9_3 = 'link' ; s9_4 = 'instead'
       s10 = 'Restore' ; s10_1 = 'to' ; s10_2 = 'Default'
       s11 = 'No input' ; s11_1 = 'Return to the Personal Settings menu'
    }

    'Move-Temp-Folders' = @{

        s1 = 'To check the preset, you can specify only one target!'
        s2 = ''
        s3 = 'Wrong Path or does not fit!'
        s4 = 'Wrong Path or not specified!'

        s5 = 'To check the status, you can specify only one target!'
        s6 = 'Default' ; s6_1 = 'Changed'
        s7 = 'Folder exists' ; s7_1 = "Folder doesn't exist"
        s8 = 'The path was not found in the registry!'
        s9 = 'Created' ; s9_1 = 'Not created' ; s9_2 = 'Do not need'
       s10 = 'Configure the location of the Temp folder for'
       s11 = 'Changing the folder location'
       s12 = 'Checking the specified path in the preset'
       s13 = 'Checking the path'
       s14 = 'The path is correct'
       s15 = 'Restoring the location' ; s15_1 = 'to Default'
       s16 = 'Setting access rights' ; s16_1 = 'to the folder' ; s16_2 = 'Profile'
       s17 = 'Failed to remove file or symbolic link'
       s18 = 'Create a folder'
       s19 = 'The folder could not be created'
       s20 = 'Create a folder' ; s20_1 = 'with access rights'
       s21 = 'Setting parameters in the registry'
       s22 = 'Creating a symbolic link' ; s22_1 = 'at a location' ; s22_2 = 'Default'
       s23 = 'Removing the folder'
       s24 = 'Folder locked, closing blocking processes'
       s25 = 'Completing the process correctly'
       s26 = 'Completing the process'
       s27 = 'Start the process'
       s28 = 'The folder is locked, unable to remove!' ; s28_1 = 'A symbolic link will not be created!'
       s29 = 'Creating a symbolic link' ; s29_1 = 'instead'
       s30 = 'Symbolic link creation not specified'
       s31 = 'Failed to remove the symbolic link!' ; s31_1 = 'The symbolic link is removed!'
       s32 = 'Completed' ; s32_1 = 'Reboot required!'

       s33 = "The 'Set-OwnerAndAccess' function is not loaded!"
       s34 = "The 'ReStart-Explorer' function is not loaded!"
       s35 = "Handle.exe file not found or not specified"
    }

    '$Menu_Move_User_Folders' = @{

        s1 = 'Changing' ; s1_1 = 'the folder location' ; s1_2 = 'of the current user'
        s2 = 'Skipping copying/removing the source folder if there is not enough or little space left on the destination drive'
        s3 = 'Deleting the source folder only after copying without errors. Access rights and attributes are configured'
        s4 = 'Restores and in the absence of folders or parameters in the registry.' ; s4_1 = 'Complete everything before doing it!'
        s5 = 'Symbolic links' ; s5_1 = 'are created in the location to default, leading to a new location'
        s6 = 'You can set your location in the preset file, the current file'
        s7 = 'Current folder location'
        s8 = 'Options for selection'

        s9 = 'Video      '
       s10 = 'Documents  '
       s11 = 'Downloads  '
       s12 = 'Images     '
       s13 = 'Music      '
       s14 = 'Desktop    '
       s15 = 'All folders'
     s15_1 = 'Saved Games'

       s16 = 'Move all folders to their paths                        '
       s17 = 'Restore'
       s18 = 'Move to'

       s19 = 'Clear' ; s19_1 = 'Quick Access in File Explorer' ; s19_2 = 'from your pinned items' ; s19_3 = 'If you cannot remove'
       s20 = 'No input' ; s20_1 = 'Return to the Personal Settings menu'
    }

    'Move-User-Folders' = @{

        s1 = 'Clearing Quick Access from pinned items by the user'
        s2 = 'Closing all Explorer windows'
        s3 = 'Removing items'
        s4 = 'Completed'
        s5 = 'To check the preset, you can specify only one folder!'
        s6 = ''
        s7 = "The path is wrong or doesn't fit!"
        s8 = 'The path is wrong or not specified!'
        s9 = 'To check the status, you can specify only one folder!'
       s10 = '(Default)'
       s11 = 'Skipping the change!'
       s12 = 'Without copying!' ; s12_1 = 'There is not enough or little space left on the destination disk' ; s12_2 = 'Need' ; s12_3 = 'Total'
       s13 = 'Folder exists' ; s13_1 = 'Gb' ; s13_2 = 'Mb' ; s13_3 = 'Kb'
       s14 = "Folder doesn't exist!"
       s15 = 'Path was not found in the registry!'
       s16 = 'The symlink leads to the wrong place!'
       s17 = 'Symlink Not Created'
       s18 = 'It will be skipped. The script in the folder to move'
       s19 = "Restore 'default location' for the folder"
       s20 = 'Changing the folder location' ; s20_1 = 'Profile'
       s21 = 'Not set or wrong path for' ; s21_1 = 'in the preset file'
       s22 = 'Wrong path' ; s22_1 = 'specified in the preset file'
       s23 = 'Wrong path or cannot be created' ; s23_1 = 'To support the configuration of other profiles, the specified path must end with the variable: %sdf%' ; s23_2 = 'Specified Path'
       s24 = 'The script is located in the transfer folder' ; s24_1 = 'skipping!'
       s25 = 'Removing a symlink or file'
       s26 = 'Failed to delete a link or file'
       s27 = 'Creating the missing folder'
       s28 = 'Unable to move folder to'
       s29 = 'Creating the missing destination folder'
       s30 = 'Setting access rights'
       s31 = 'Creating the missing INI файл'
       s32 = 'Setting attributes' ; s32_1 = 'for' ; s32_2 = 'and'
       s33 = 'Setting of the INI file attributes is' ; s33_1 = 'complete'
       s34 = 'The folder in the registry is already set to'
       s35 = 'Creating a symbolic link' ; s35_1 = 'instead'
       s36 = "The folder exists in default location, the symlink won't be created"
       s37 = 'Changing the folder location in the registry and via WinAPI' ; s37_1 = 'Changing the folder location in the registry only'
       s38 = 'Skipping copying files from'; s38_1 = 'Not enough or little space left on the destination disk'
       s39 = '    Free disk space' ; s39_1 = 'byte'
       s40 = 'Required disk space'
       s41 = "Source folder doesn't exist" ; s40_1 = 'nothing to copy'
       s42 = 'Robocopy: Copying Files' ; s42_1 = 'from' ; s42_2 = 'to' ; s42_3 = 'wait ...'
       s43 = 'Problem copying, error code' ; s43_1 = "the source folder won't be removed!"
       s44 = 'Copied without errors. Removing the source folder'
       s45 = 'The folder is locked. Completing the process correctly'
       s46 = 'Retrying remove folder'
       s47 = 'Starting the process' ; s47_1 = 'Stop the process'
       s48 = 'Failed to remove the source folder!'
       s49 = 'Re-creating the desktop.ini file and setting attributes after copying'

       s50 = "The 'Set-OwnerAndAccess' function is not loaded!"
       s51 = "The 'ReStart-Explorer' function is not loaded!"
    }

    'Pin-UnPin-QuickAccess' = @{

        s1 = 'Resetting Quick Access'
        s2 = 'Removing'
        s3 = 'Unpining'
        s4 = '  Pining'
        s5 = 'Unpining all Quick Access items'
        s6 = 'Parameters are not specified'
        s7 = 'Unpining: The folder does not exist'
        s8 = 'Folder is not unpined from the Quick Access'
        s9 = 'Folder unpined from Quick Access'
       s10 = 'Unpining: The folder is not pined in Quick Access'
       s11 = 'Folder is pined to the Quick Access'
       s12 = '  Pining: Folder does not exist'
    }

    'Manage-Edge' = @{

        s1 = 'Parameters not specified'
        s2 = 'Server error'
        s3 = 'File size is not received from the server'
        s4 = 'File write error'
        s5 = 'File not downloaded'

        s6 = 'Check Installation'
        s7 = 'Installing'
        s8 = 'Function'
        s9 = 'Already Installed'
       s10 = 'Microsoft Edge Chromium is not installed'
       s11 = 'Restoring Microsoft Edge Chromium'
       s12 = 'Installed'
       s13 = 'Creating a Shortcut'
       s14 = "Couldn't install"

       s15 = 'There is no Microsoft Edge Chromium component in WinSxS, there will be a download'
       s16 = 'Downloading and installing Microsoft Edge Chromium'
       s17 = 'No Internet access for PS'
       s18 = 'Installed'
       s19 = 'Failed to download'
       s20 = 'Downloading and installing Microsoft Edge WebView'
       s21 = 'Microsoft Edge WebView is not installed'

       s22 = 'Check Removal'
       s23 = 'Removal'
       s24 = 'Installed'
       s25 = 'Not installed'
       s26 = 'Checking Microsoft Edge files and settings'
       s27 = 'All users'
       s28 = 'Unknown Microsoft Edge'
       s29 = 'Not all Microsoft Edge is uninstalled'
       s30 = 'Not found'
    }

    'Manage-OneDrive' = @{

        s1 = 'Checking OneDrive installation'
        s2 = 'Installing OneDrive'
        s3 = 'Function'
        s4 = 'OneDrive is already installed'
        s5 = 'OneDrive installer not found'
        s6 = 'OneDrive Not Installed'
        s7 = 'Installing OneDrive for the current User' ; s7_1 = 'Wait'
        s8 = 'Restoring a system shortcut'
        s9 = 'All actions completed'
       s10 = 'OneDrive installation error'
       
       s11 = 'OneDrive Uninstall' ; s11_1 = 'OneDrive Uninstall Check' ; s11_2 = 'Function'
       s12 = 'OneDrive is already Uninstall' ; s12_1 = 'OneDrive is not Uninstalled'
       s13 = '        User folder'
       s14 = 'Installed in folder'
       s15 = '  Uninstall command'
       s16 = 'Uninstalling OneDrive ...'
       s17 = 'OneDrive uninstallation completed'
       
       s18 = 'Clean Windows from OneDrive'
       s19 = 'OneDrive cleanup check'
       s20 = 'Profile'
       s21 = 'Parameters not found in the registry'
       s22 = 'Cleaning OneDrive files'
       s23 = 'Checking OneDrive Files'
       s24 = 'Skipped deletion of OneDrive folder with user files'
       s25 = 'OneDrive folder with user files will not be deleted'
       s26 = "Deleting a user's empty OneDrive folder"
       s27 = "User's OneDrive folder was not found"
       s28 = 'Restarting the Explorer'
       s29 = 'Deleting a folder' ; s29_1 = 'Failed to delete the folder'
       s30 = '  Deleting a file'
       s31 = '        Not exist'
       
       s32 = 'Restoring a system shortcut'
       s33 = 'The "OneDrive.lnk" system shortcut does not need to be restored from WinSxS'
       s34 = 'The shortcut exists'
       s35 = 'Profile folder "DefaultAccount" not found'
       s36 = 'Check completed'
    }

    '$Menu_Run_Configs' = @{

        s1 = 'Apply' ; s1_1 = 'Check' ; s1_2 = 'or' ; s1_3 = 'Restore' ; s1_4 = 'settings'
      s1_5 = 'For the current account'
        s2 = 'The list of parameter groups can be changed in the preset file, the current file'
        s3 = 'All Parameter Groups'
        s4 = 'Options for selection'

        s5 = 'Apply all' ; s5_1 = 'parameters' ; s5_2 = 'Apply all showed parameter groups'
        s6 = 'Apply' ; s6_1 = 'selectively   ' ; s6_2 = 'With a request for parameter groups numbers'

        s7 = 'Check all' ; s7_1 = 'Check all showed parameter groups'
        s8 = 'Check'

        s9 = 'Restore'
       s10 = 'Restore all' ; s10_1 = "Restore 'Default' from all showed parameter groups"

       s11 = 'No input' ; s11_1 = 'Return to Main Menu'
    }

    'Run-Configs' = @{

        s1 = 'No groups specified in preset file'
        s2 = 'Preset file not found'
        s3 = 'No description'
        s4 = "Doesn't exist"

        s5 = 'Problems found'
        s6 = 'Restored'
        s7 = 'Checked'
        s8 = 'No data'
        s9 = 'arg'

       s10 = 'Enter group numbers separated by spaces'
       s11 = 'Wrong choice!'
       s12 = 'Selected Groups'
       s13 = 'Restoring default Parameters'
       s14 = 'Checking Parameters'
       s15 = 'Applying Parameters'

       s16 = "Function to configure Doesn't exist!"

       s17 = 'Restoring'
       s18 = 'Checking'
       s19 = 'Applying'

       s20 = "Function launch problem!`n`tCommand"
       s21 = 'Parameters restored (Default)'
       s22 = 'All parameters are correct'
       s23 = 'No parameters'
    }

    '$Menu_Run_QuickSettings' = @{

        s1 = 'Quick Application' ; s1_1 = 'Of Parameters.' ; s1_2 = 'The list of parameter groups can be changed in preset file'
      s1_3 = 'For the current account'
        s2 = 'Current Quick Settings Preset File'

        s3 = 'All Parameter Groups'

        s4 = 'Apply all' ; s4_1 = 'at once' ; s4_2 = 'Apply all showed parameter groups and found files'

        s5 = 'Apply' ; s5_1 = 'Only Parameters' ; s5_2 = 'Apply only showed parameter groups'
        s6 = 'Apply' ; s6_1 = 'Files Only:'     ; s6_2 = 'Apply only found ps1 files in the folder:'
        s7 = 'Apply' ; s7_1 = 'Files Only:'     ; s7_2 = 'Apply only found cmd files in the folder:'
        s8 = 'Apply' ; s8_1 = 'Files Only:'     ; s8_2 = 'Apply only found reg files in the folder:'

        s9 = 'Restoration' ; s9_1 = 'Menu for Restoring all settings at once to Default'

       s10 = 'No input' ; s10_1 = 'Return to Main Menu'
    }

    'Run-QuickSettings' = @{

        s1 = 'No groups specified in preset file'
        s2 = 'Preset file not found'
        s3 = 'No description'
        s4 = "Doesn't exist"

        s5 = 'arg'

        s6 = 'Files ps1'
        s7 = 'Files ps1: Ps1 files execution is disabled in the preset file'  ; s7_1 = 'Execution with a connected token from'
        s8 = 'Files ps1: Your ps1 files not found'
        s9 = 'Files ps1: No folder for your ps1 files'

       s10 = 'Files cmd'
       s11 = 'Files cmd: Cmd files execution is disabled in the preset file'
       s12 = 'Files cmd: Your cmd files not found'
       s13 = 'Files cmd: No folder for your cmd files'

       s14 = 'Files reg'
       s15 = 'Files reg: Reg files execution is disabled in the preset file'
       s16 = 'Files reg: Your reg files not found'
       s17 = 'Files reg: No folder for your reg files'

       s18 = 'Restoring default parameters'
       s19 = 'Function'
       s20 = 'Applying Parameters'
       s21 = "Function to configure Doesn't exist!"
       s22 = 'Restoring' ; s22_1 = 'Applying'
       s23 = "Function launch problem!`n`tCommand"
       s24 = 'Problems found'
       s25 = 'No parameters'
       s26 = 'There were problems during' ; s26_1 = 'restoring!!!' ; s26_2 = 'application!!!'
       s27 = 'All parameters have been restored' ; s27_1 = 'There were no errors'
       s28 = 'All parameters have been applied'

       s29 = 'Executing Files'
       s30 = 'Files' ; s30_1 = 'File'

       s31 = 'Ps1 files execution is disabled in the preset file'
       s32 = 'Your ps1 files not found'
       s33 = 'No folder for your ps1 files'

       s34 = 'Cmd files execution is disabled in the preset file'
       s35 = 'Your cmd files not found'
       s36 = 'No folder for your cmd files'

       s37 = 'Reg files execution is disabled in the preset file'
       s38 = 'Your reg files not found'
       s39 = 'No folder for your reg files'
    }

    '$Menu_Set_Apps_Management' = @{

        s1 = 'Manage Apps/Appx' ; s1_1 = 'Download/Install/Re-registration/Uninstall Modern Applications' ; s1_2 = '(For all users!)'
        s2 = 'For Uninstalled System Apps, a task is created to AutoClean Parameters, which are restored during Updates (CU)'
        s3 = "Uninstalled System Apps are updated, but not Restored on their own. Subfolder is cleaned on Download, except XML"
        s4 = 'Installed' ; s4_1 = 'Appx present' ; s4_2 = 'You can change Apps/Appx list in preset file'

        s5 = 'Specified' ; s5_1 = 'to Install/Uninstall' ; s5_2 = '     Internet'
        s6 = 'Found/Configured' ; s6_1 = 'to Install/Uninstall/Download to its subfolders'
        s7 = 'Options for selection'

        s8 = 'Save' ; s8_1 = 'the list of installed Apps for the preset file'

        s9 = 'Uninstall' ;  s9_1 = 'All' ;  s9_2 = 'Specified to Uninstall Apps  ' ;      s9_3 = 'selectively' ; s9_4 = 'Entering numbers (1 3 5 ...)'
       s10 = 'Install' ; s10_1 = 'All  ' ; s10_2 = 'Specified to Install Apps    ' ;   s10_3 = 'selectively  '

       s11 = 'Download' ; s11_1 = 'All ' ; s11_2 = 'Customized for Download Appx ' ;    s11_3 = 'selectively '
       s12 = 'Install' ; s12_1 = 'All  ' ; s12_2 = 'Found Appx in Subfolders     ' ;   s12_3 = 'selectively  '
       s13 = 'Uninstall' ; s13_1 = 'All' ; s13_2 = 'Found/Configured Appx        ' ;     s13_3 = 'selectively'
       s14 = 'Clean' ; s14_1 = 'Folder ' ; s14_2 = 'Files\Appx\ from subfolders  ' ; s14_3 = 'selectively    '

       s18 = 'Install' ; s18_1 = 'All  ' ; s18_2 = 'Appx files from folder' ; s18_3 = ' (Skipping subfolders)'

       s19 = 'Show' ; s19_1 = 'Names   ' ; s19_2 = 'for AutoСlean + Apps Problems' ; s19_3 = 'Clean' ; s19_4 = 'Parameters     '

       s20 = 'Install' ; s20_1 = 'All  ' ; s20_2 = 'Uninstalled System Apps      ' ;   s20_3 = 'selectively  '

       s21 = 'No input' ; s21_1 = 'Return to the Personal Settings menu      ' ; s21_2 = 'Fix' ; s21_3 = 'Apps Problems    ' ; s21_4 = 'Staged Apps (Entering numbers)'

       s22 =        '                                                        ' ; s22_1 = 'Restart' ; s22_2 = 'Explorer' ; s22_3 = '(Correctly)'

       s23 = 'Restart Explorer (correct) ...'
    }

    'Set-Apps-Management' = @{

        s1 = 'No description'
        s2 = 'Skip Uninstall/Install (match exceptions)'
        s3 = 'Framework will not be installed separately'
        s4 = 'Applications for Uninstall/Install are not specified!'
        s5 = 'Certificate' ; s5_1 = 'Subfolder with Appx files'
        s6 = 'Appx is not configured to download'
        s7 = 'Found files' ; s7_1 = 'No files found'

        s8 = 'Developer Mode' ; s8_1 = 'Apps from Store/Downloaded' ; s8_2 = 'Default'
        s9 = 'AutoCleaning for' ; s9_1 = 'No AutoClean task' ; s9_2 = 'AutoClean State'
                                  s9_3 = 'Task' ; s9_4 = 'Task State' ; s9_5 = 'Enabled' ; s9_6 = 'Disabled'
                                  s9_7 = 'Last Run' ; s9_8 = 'Result' ; s9_9 = 'Error' ; s9_10 = 'Successful' ; s9_11 = "Didn't have time to complete"
                                 s9_12 = 'Names of Uninstalled System Apps and Names Specified in Task' ; s9_13 = 'Match' ; s9_14 = 'Do not match' ; s9_15 = "Hasn't been completed"

       s10 = "Installed  " ; s10_1 = "is AutoCleaning" ; s10_2 = "Problem   " ; s10_3 = "AutoСlean Problems Found"
       s11 = "Uninstalled" ; s11_1 = "No Autocleaning" ; s11_2 = "No problem" ; s11_3 = "No AutoClean Problems"
       s12 = "This Task cleans Parameters of Uninstalled System Apps, which are restored during Cumulative Updates. `nEach time the computer is turned on. `nDoesn't affect Windows boot speed"
              s12_1 = 'Updating AutoClean task | Found a difference in the Names of Uninstalled System Apps and the Names in the task'
              s12_2 = 'Creating the AutoClean task | Uninstalled System Apps Found'
              s12_3 = 'Deleting the AutoCleanup Task | No Uninstalled System Apps'

       s13 = 'Prepared and unregistered New versions of Apps'
     s13_1 = "You can try to selectively install, with fixing problems | Menu item: [222]"
     s13_2 = "You can try to install, with fixing problems"
     s13_3 = "No unregistered Apps found"
       
       s14 = 'Removing' ; s14_1 = 'Search shortcut from the Win + X menu' ; s14_2 = 'Restore'

       s15 = 'SQLite.dll not found' ; s15_1 = 'Error connecting SQLite.dll'
       s16 = 'Manage Modern Applications' ; s16_1 = 'Function'

       s17 = 'The folder does not exist' ; s17_1 = 'There are no suitable files in the folder'

       s18 = 'Installing' ; s18_1 = 'All Appx Framework Files' ; s18_2 = 'Certificate' ; s18_3 = 'All Appx/Msix Non Framework Files' ; s18_4 = 'All AppxBundle/MsixBundle Files'
       s19 = '    Result' ; s19_1 = 'Installed'
     s19_2 = '  Register'
       s20 = '     Error' ; s20_1 = "You need to install the certificate for the application in Cert:\LocalMachine\Root" ; s20_2 = "A higher version of this package is already installed"
       s21 = '   License' ; s21_1 = "Without License"
       s22 = '      Skip' ; s22_1 = 'Already installed' ; s22_2 = 'Certificate is incorrect'
       s23 = '     Pause' ; s23_1 = 'Waiting before completion'
       s24 = '  Removing' ; s24_1 = 'Certificate' ; s24_2 = 'Has been installed temporarily'
     s24_3 = '  Shortcut' ; s24_4 = 'Creating shortcut on desktop'
     s24_5 = '  Registry' ; s24_6 = 'Restoring registry key for System App' ; s24_7 = 'Registry key for System App not restored'
                            s24_8 = 'Changing the registry value to show the search bar on Taskbar' ; s24_9 = 'Removing the problematic parameter'
                           s24_10 = 'Do not remove the Win + X shortcut from the profile folder the first time you login'
                           s24_11 = 'Allow the TextInput service to start'

       s25 = 'Saving' ; s25_1 = 'the List of Installed Applications'
       s26 = 'File'
       s27 = 'Next is a list of installed applications from the store for use in the preset'
       s28 = 'Next is the list of common components for all installed applications, Framework! for use in preset'
       s29 = 'Next is the list of System Applications, for use in preset'
       s30 = 'Completed'

       s31 = 'Uninstalling' ; s31_1 = 'Installed Apps by choice' ; s31_2 = 'Installed Apps'
       s32 = 'Enter the Apps numbers separated by a space'
       s33 = 'Cancel' ; s33_1 = 'Wrong choice!' ; s33_2 = 'Selected Numbers'
       s34 = 'Wait' ; s34_1 = 'Receiving data for all found Appx in the folder' ; s34_2 = 'Apps not found in a folder and subfolders'
       s35 = 'Uninstalling' ; s35_1 = 'Apps found in the folder and installed, by choice' ; s35_2 = 'Apps found in the folder and installed'
       s36 = 'Installed    ' ; s36_1 = 'Selected Apps from those found in the folder and installed' ; s36_2 = 'Found Apps in folder and installed'
       s37 = 'Not installed' ; s37_1 = 'No Apps installed from those found in the folder'
       s38 = 'Selected Apps to uninstall' ; s38_1 = 'Specified Apps to uninstall' ; s38_2 = 'Apps to uninstall not specified!'

       s39 = '    DataBase' ; s39_1 = 'Connection'
       s40 = '     Trigger' ; s40_1 = 'Found' ; s40_2 = 'Not found blocking triggers in the database'
       s41 = '     IsInbox'
       s42 = 'The specified applications to remove were not found in the database!'
       s43 = 'Performing Database Actions' ; s43_1 = 'No blocking triggers in the database!'
       s44 = '  Removing'
       s45 = '   Setting'
       s46 = 'Unlocking Apps is not required'
       s47 = 'Restoring Trigger'
       s48 = 'Restored'
       s49 = 'Disconnecting'
       s50 = 'Uninstalling selected applications'
       s51 = 'Uninstalling specified applications'

       s52 = 'Uninstalling'
     s52_1 = '      Search'
     s52_2 = '     Closing'
       s53 = '       Error' ; s53_1 = 'This error is due to the dependency of installed applications on this component'
       s54 = '    Registry' ; s54_1 = 'Creation The registry key' ; s54_2 = 'Creation the registry value to hide the search bar from Taskbar'
                              s54_3 = 'Removing registry key of the system App'
                              s54_4 = 'Remove the Win + X shortcut from the profile folder the first time you login'
                              s54_5 = 'Hide the "Chat" icon from taskbar (W11)' ; s54_6 = 'Show the "Chat" icon on taskbar (W11)'

       s55 = '    Skipping' ; s55_1 = 'Create registry key for Framework' ; s55_2 = "Create registry key for ResourcePackage"
       s56 = '     Taskbar' ; s56_1 = 'Unpinning a shortcut from Taskbar'
     s56_2 = '    Shortcut' ; s56_3 = 'Deleting found shortcut' ; s56_4 = 'Desktop'

       s57 = 'Installing' ; s57_1 = 'Apps of choice' ; s57_2 = 'Apps' ; s57_3 = 'Fix'
       s58 = 'Selected applications to install' ; s58_1 = 'Found applications to fix' ; s58_2 = 'Selected applications to fix'
       s59 = 'Specified applications to install'
       s60 = 'Apps to install not specified!'
       s61 = '    Status' ; s61_1 = 'Already installed | Re-registration' ; s61_2 = 'Registered' ; s61_3 = 'Not installed | Registration'
       s62 = '    Search' ; s62_1 = 'App not found in' ; s62_2 = 'Application not installed' ; s62_3 = 'App found in'
                            s62_4 = 'System folder problem'

       s63 = '       Wait' ; s63_1 = 'Receiving links ...'
       s64 = 'Downloading Appx' ; s64_1 = 'from microsoft.com | Getting links through store.rg-adguard.net'
       s65 = 'Appx Not Configured to Download' ; s65_1 = 'No Internet Access for PS' ; s65_2 = "Can't access website"
       s66 = 'Parameters not specified' ; s66_1 = 'Server error.' ; s66_2 = 'The file size was not received from the server.'
     s66_3 = 'File write error.' ; s66_4 = 'File not loaded' ; s66_5 = 'The folder cannot be created in'

       s67 = 'Downloading' ; s67_1 = 'Additional files for Apps'
       s68 = 'Description'
       s69 = '     Folder'
       s70 = '       Type' ; s70_1 = 'Wrong'
       s71 = '        Url'
       s72 = '       Ring' ; s72_1 = 'No file links received'
       s73 = '      Links' ; s73_1 = 'File not found' ; s73_2 = 'No matching links in file'
     s73_3 = '     Access' ; s73_4 = 'Repeat' ; s73_5 = 'Skip' ; s73_6 = 'Links received'
       s74 = '   Skipping' ; s74_1 = "File extensions or links don't match"
       s75 = 'Downloading'
       s76 = '       Link'
       s77 = ' Downloaded' ; s77_1 = 'Checksums matched' ; s77_2 = 'File size matched'
       s78 = '   Removing' ; s78_1 = 'Checksums did not match' ; s78_2 = "File size didn't match" ; s78_3 = "Zero file size"
       s79 = '   Internet'
       s80 = '     Repeat'
       s81 = '     Result' ; s81_1 = 'Not downloaded' ; s81_2 = 'No access to the website'

       s82 = 'Installing Found Appx in Subfolders' ; s82_1 = 'No Appx Found in Subfolders'
       s83 = 'No matching files in the folder' ; s83_1 = 'No folder'

       s84 = 'Folder not specified for function in'
       s85 = 'Installing files'
       s86 = '     From folder' ; s86_1 = 'Search this folder only, subfolders are skipped!'

       s87 = 'No subfolders with Appx in' ; s87_1 = 'Found folders with Appx files'
       s88 = 'Enter folder numbers separated by a space'
       s89 = 'Removing'
       s90 = '  Result' ; s90_1 = 'Not removed' ; s90_2 = 'Removed' ; s90_3 = 'No folder'

       s91 = 'Skip Cleaning/Checking Uninstalled System Apps parameters'
       s92 = 'Checking' ; s92_1 = 'Cleaning' ; s92_2 = 'Uninstalled System Apps parameters'
       s93 = 'Clean' ; s93_1 = 'Cleanup for uninstalled Apps'
       s94 = 'Completed' ; s94_1 = 'No cleaning required'

       s95 = "Skipping Fixes installed Apps"
       s96 = "Checking" ; s96_1 = "installed Apps"

       s97 = 'Services enabled'
     s97_1 = 'Reboot required: After enabling AppXSvc service'
     s97_2 = 'Get-AppxPackage -AllUsers execution error'

      s150 = 'It is advisable to reboot'
    }

    '$Menu_Run_QuickSettingsDefault' = @{

        s1 = 'Restoring' ; s1_1 = 'all parameters from all menus' ; s1_2 = 'Except some'
      s1_3 = 'For the current account'
        s2 = 'The list of parameter groups can be changed in preset file, current file'

        s3 = 'All groups оf parameters to restore' ; s3_1 = 'Options for selection'

        s4 = 'Restore all' ; s4_1 = 'parameters' ; s4_2 = "Apply 'to Default' parameters from all showed parameter groups"
        s5 = 'No input' ; s5_1 = 'Return to Main Menu'
    }

    '$Menu_Set_Boot_Optimization' = @{

        s1 = 'Configuring' ; s1_1 = 'Windows Boot Optimization and Launching Programs, Hibernation, and Fast Boot'
        s2 = 'Boot Optimization can be disabled if the system drive is SSD'
        s3 = 'Fast Booting often leads to problems, it is recommended to disable'

        s4 = '         Service SysMain' ; s4_1 = '           Parameter Superfetch'
        s5 = '      Analysis ReadyBoot' ; s5_1 = '           Parameter Prefetcher'

        s6 = '                   Tasks'

        s7 = '             Hibernation'
        s8 = '               Fast Boot'

        s9 = '      Options for selection'

       s10 = 'Disable Boot Optimization' ; s10_1 = 'All Parameters, SysMain Service, and Tasks'
       s11 = 'Disable Hibernation      ' ; s11_1 = 'Fast Booting will stop working'
       s12 = 'Disable Fast Boot        ' ; s12_1 = 'For a complete shutdown of Windows'

       s13 = 'Enable' ; s13_1 = 'Boot optimization' ; s13_2 = 'Default'
       s14 = 'Enable' ; s14_1 = 'Hibernation      ' ; s14_2 = 'Default'
       s15 = 'Enable' ; s15_1 = 'Fast Boot        ' ; s15_2 = 'Default. Uses hibernation instead of shutdown Windows'

       s16 = 'No input' ; s16_1 = 'Return to the Personal Settings menu'
    }

    'Set-Boot-Optimization' = @{

        s1 = 'Disabled'
        s2 = 'Enabled '
        s3 = 'Disabled'
        s4 = 'Enabled '
        s5 = 'Configuring Windows Boot Optimization'
        s6 = 'Function'
        s7 = 'Disabling'  ; s7_1 = 'Boot Optimization'
        s8 = 'Enabling'   ; s8_1 = 'Boot Optimization' ; s8_2 = '(Default)'
        s9 = 'Disabling'  ; s9_1 = 'Hibernation'
       s10 = 'Enabling'  ; s10_1 = 'Hibernation'
       s11 = "'Check' is not provided for 'HibernateDisable'"
       s12 = 'Disabling' ; s12_1 = 'Fast Boot'
       s13 = 'Enabling'  ; s13_1 = 'Fast Boot'
       s14 = "'Check' is not provided for 'FastBootDisable'"
       s15 = 'Completed'
    }

    '$Menu_Set_Drives_Icons' = @{

        s1 = 'Configuring' ; s1_1 = 'drive Icons' ; s1_2 = 'Setting your icons for RAM and USB/Flash drives'
        s2 = "You can't know in advance what drive letters the connected USB devices will have, but there is a solution:"
        s3 = 'For permanent letters, set forced icons of Local/RAM drives, and globally for all, set the flash drive icon'
        s4 = 'You can change to your icons in the current preset file'

        s5 = '     Preset Icon for Local drives'
        s6 = '       Preset Icon for RAM drives'
        s7 = '       Preset Icon for USB drives'

        s8 = 'Global Icon are set on All drives'
        s9 = 'Global Icon are set on USB drives'
       s10 = ' Personal icons are set on drives'

       s11 = 'Options for selection'

       s12 = 'Set Icons' ; s12_1 = 'based on '
       s13 = 'Restore' ; s13_1 = 'Drive Icons' ; s13_2 = 'Default'

       s14 = 'Restart' ; s14_1 = 'Explorer' ; s14_2 = 'Correctly'
       s15 = 'No input' ; s15_1 = 'Return to Explorer settings menu             '
       s16 = 'Explorer'
    }

    'Set-Drives-Icons' = @{

        s1 = 'Smartctl.exe utility not specified or not found'
        s2 = "    Drive size         Volume label     F/s     Type        bus    Device                                "
        s3 = 'Local' ; s3_1 = 'All other'
        s4 = 'Error, drives not found'
        s5 = 'Not set icon for Local drives in preset'
        s6 = 'Not set icon for RAM drives in preset'
        s7 = 'Not set icon for USB drives in preset'
        s8 = 'Not configured' ; s8_1 = '(Default)'
        s9 = 'Configured'
       s10 = 'Configured'
       s11 = 'Not configured' ; s11_1 = '(Default)'

       s12 = 'Configuring drive Icons'
       s13 = 'Function'
       s14 = 'Setting' ; s14_1 = 'the global icon parameters' ; s14_2 = 'for all drives'
       s15 = 'Icon'
       s16 = 'Setting' ; s16_1 = 'individual icons' ; s16_2 = 'For Local Drives'
       s17 = 'Icon for'
       s18 = 'Setting' ; s18_1 = 'individual icons' ; s18_2 = 'For RAM Drives'
       s19 = 'Local drives not found or no icons for Local/USB drives set'

       s20 = 'Restoring' ; s20_1 = 'of the icons' ; s20_2 = 'For all drives'
       s21 = "'Check' not provided for 'Settings drive icons'"
       s22 = 'All completed' ; s22_1 = 'Need to restart the Explorer'
    }

    '$Menu_Set_Drives_Optimization' = @{

        s1 = 'Configuring' ; s1_1 = 'Separate Optimization of' ; s1_2 = 'and' ; s1_3 = 'drives.' ; s1_4 = 'To prevent defragmentation of SSD'
        s2 = 'Separate tasks will be executed instead of the ScheduledDefrag task,' ; s2_1 = 'during Windows AutoMaintenance'
        s3 = 'Or' ; s3_1 = 'Independently' ; s3_2 = 'TRIM for SSD drives every 3 days, and HDD drives defragmentation once a week'
        s4 = 'Drive detection can be slow if they shutdown when idle'

        s5 = '          Tasks'
        s6 = '   Local drives'

        s7 = 'Create separate tasks for drive optimization'  ; s7_1 = 'Only during AutoMaintenance'
        s8 = 'Create one separate task for your SSD drives'  ; s8_1 = 'Only during AutoMaintenance'

        s9 = 'Create separate tasks for drive optimization'  ; s9_1 = 'Independent'  ; s9_2 = 'of AutoMaintenance'
       s10 = 'Create one separate task for your SSD drives' ; s10_1 = 'Independent' ; s10_2 = 'of AutoMaintenance'

       s11 = 'Restore' ; s11_1 = "Default. Enable/Create a 'ScheduledDefrag' task and remove all other"

       s12 = 'Start system utility:' ; s12_1 = 'Manual diagnosis and/or drive optimization'
       s13 = 'Show Maintenance Log:' ; s13_1 = 'Show drives maintenance history for information'

       s14 = 'Perform' ; s14_1 = 'TRIM' ; s14_2 = 'SSD' ; s14_3 = 'drives             '
       s15 = 'Perform' ; s15_1 = 'Defragment' ; s15_2 = 'HDD' ; s15_3 = 'drives       '

       s16 = 'No input' ; s16_1 = 'Return to the Maintenance menu'
    }

    'Set-Drives-Optimization' = @{

        s1 = "Smartctl.exe utility not specified or not found"
        s2 = 'No HDD drives in the system'
        s3 = 'No SSD drives in the system'
        s4 = 'Microsoft Corporation'
        s5 = 'This task optimizes computer hard drives.'
        s6 = 'Configure or optimization drives'
        s7 = 'Function'
        s8 = 'Creating Separate Drives Optimization Tasks'

        s9 = 'Creating' ; s9_1 = 'SSD-Trim Task for SSD Drive Optimization'
       s10 = 'This task performs TRIM on your SSD drives' ; s10_1 = 'It is carried out independently, without Windows AutoMaintenance, once every 3 days!'
                                                            s10_2 = 'Runs only with Windows AutoMaintenance, if not disabled!'
       s11 = 'Skip creating' ; s11_1 = 'a separate task for optimizing SSD drives'

       s12 = 'Creating' ; s12_1 = 'HDD-Defrag Task for defragmenting HDD drives'
       s13 = 'This task defrags your HDD drives' ; s13_1 = 'It is carried out independently, without Windows AutoMaintenance, once a week!'
                                                   s13_2 = 'Runs only with Windows AutoMaintenance, if not disabled!'

       s14 = 'Disabling' ; s14_1 = 'the Original ScheduledDefrag Drives Optimization Task'
       s15 = 'Removing'  ; s15_1 = 'Separate Drives Optimization Tasks'
       s16 = 'Enabling'
       s17 = 'Creating'
       s18 = "'Check' is not provided for 'CreateTasks'"

       s19 = 'Launching' ; s19_1 = 'the dfrgui.exe Utility ...'
       s20 = 'Show EventLog' ; s20_1 = 'of Drives Maintenance' ; s20_2 = 'through defrag.exe'
       s21 = 'retrim - is TRIM'
       s22 = 'Running' ; s22_1 = 'TRIM on SSD Drives'
       s23 = 'Command'
       s24 = 'Running' ; s24_1 = 'HDD drives Defragmentation'

       s25 = 'Enabling'
       s26 = 'Disabling'
       s27 = 'SSD-Trim Task'
       s28 = 'HDD-Defrag Task'
       s29 = 'ScheduledDefrag Task'
       s30 = 'All completed'
    }

    '$Menu_Set_Event_Logs' = @{

        s1 = 'Configuring' ; s1_1 = 'Event Logs' ; s1_2 = 'Disabling Logs reduces drive and processor load'
        s2 = 'System Logs will be left: Security, Installation, System, etc. But the PowerShell log will be disabled'
      s2_1 = 'List of Exclusion Patterns can be changed in the presets file, the current file is'

        s3 = '     EventLog Service'

        s4 = '                 Logs' ; s4_1 = 'System logs do not count'
      s4_2 = '   Exclusion patterns'

        s5 = 'Options for selection'

        s6 = 'Disable all logging' ; s6_1 = 'Except System logs and excluded'
        s7 = 'Clear all logs'
        s8 = 'Perform all actions' ; s8_1 = 'Disable and Clear'

        s9 = 'Show list of Running logs' ; s9_1 = 'Without system logs'
      s9_2 = 'Show list of Exclusion Patterns' ; s9_3 = 'In the presets file'

       s10 = 'Enable' ; s10_1 = 'Logs' ; s10_2 = 'Matching Exclusion Patterns and not Enabled'
       s11 = 'Enable' ; s11_1 = 'All Logs' ; s11_2 = 'Which are enabled by default (317-341 pcs)'

       s12 = 'No input' ; s12_1 = 'Return to the Personal Settings menu'
    }

    'Set-Event-Logs' = @{

        s1 = 'Enabled' ; s1_1 = 'pcs' ; s1_2 = 'Disabled'
        s2 = 'Configuring Event Logs'
        s3 = 'Function'
        s4 = 'Disabling' ; s4_1 = 'Event Logging' ; s4_2 = 'Except System logs and excluded'
        s5 = 'Disabling' ; s5_1 = 'Log'
        s6 = 'All logs are already' ; s6_1 = 'Disabled'
        s7 = 'Enabling'  ; s7_1 = 'Event Logging' ; s7_2 = 'Which are enabled to default' ; s7_3 = 'By exclusion patterns that are disabled'
        s8 = 'Enabling'  ; s8_1 = 'Log'
        s9 = 'All logs are already' ; s9_1 = 'Enabled' ; s9_2 = 'Which are enabled by default' ; s9_3 = 'No disabled' ; s9_4 = 'Excluded logs'
       s10 = "'Check' not provided for 'EventLogsDisable'" ; s10_1 = "'Check/Default' not provided for 'EnableExcludedLogs'"

       s11 = 'Clearing' ; s11_1 = 'Event Logs' ; s11_2 = 'Only with entries'
       s12 = 'Clearing' ; s12_1 = 'Entries'  ; s12_2 = 'Log'
       s13 = "'Check' and 'Default' not provided for 'ClearEventLogs'"

       s14 = 'Running'  ; s14_1 = 'Event Logs' ; s14_2 = 'Except System logs'
       s15 = 'Log'
       s16 = 'All logs' ; s16_1 = 'Disabled'

       s17 = 'Exclusion' ; s17_1 = 'Patterns' ; s17_2 = 'No Exclusion Patterns'

       s18 = 'Completed'
    }

    '$Menu_Set_Explorer_Settings' = @{

        s1 = 'Configuring Explorer' ; s1_1 = 'User folders, Duplicates of removable devices, Network icon, Quick access, etc.'
        s2 = 'Configurable without changing the permissions for the current account'
        s3 = "Before setting the Wallpaper, the file will be copied to the 'Images' folder of the user"

        s4 = '       Video' ;  s4_1 = '      Duplicates'
        s5 = '   Documents' ;  s5_1 = '    Network Icon'
        s6 = '   Downloads' ;  s6_1 = '    Quick Access'
        s7 = '      Images'
        s8 = '       Music'
        s9 = '     Desktop' ;  s9_1 = '  Icons globally'
       s10 = '  3d objects' ; s10_1 = '     Drive icons'

       s11 = '   Wallpaper'

       s12 = 'Options for selection'

       s13 = 'Hide' ; s13_1 = 'Restore      '
                    ; s13_2 = 'Restore all 7'

       s14 = 'All 7 folders' ; s14_1 = 'Duplicates  '
       s15 = 'Video        ' ; s15_1 = 'Network Icon'
       s16 = 'Documents    ' ; s16_1 = 'Quick Access'
       s17 = 'Downloads    '
       s18 = 'Images       '
       s19 = 'Music        '
       s20 = 'Desktop      '
       s21 = '3d objects   '

       s22 = 'Drive icons' ; s22_1 = 'Menu for managing drive icons'
       s23 = 'Clear' ; s23_1 = 'Explorer icon cache     '
       s24 = 'Clear' ; s24_1 = 'Explorer thumbnail cache'
       s25 = 'Restart' ; s25_1 = 'Explorer' ; s25_2 = '(Correctly)'

       s26 = 'Set' ; s26_1 = 'Desktop Wallpaper    ' ; s26_2 = 'File'
       s27 = 'Restore' ; s27_1 = 'Desktop Wallpaper' ; s27_2 = 'Default'

       s28 = 'Restore all' ; s28_1 = 'Default (except drive icons)'

       s29 = 'No input' ; s29_1 = 'Return to the Personal Settings menu'

       s30 = 'Restart Explorer (correct) ...'
    }

    'Set-Explorer-Settings' = @{

        s1 = 'Video'
        s2 = 'Documents'
        s3 = 'Downloads'
        s4 = 'Images'
        s5 = 'Music'
        s6 = 'Desktop'
        s7 = '3d objects'

        s8 = 'Hidden          '
        s9 = 'Hidden' ; s9_1 = '(Not all)'
       s10 = 'Showed          '

       s11 = 'Hidden' ; s11_1 = 'Displayed'

       s12 = 'Hidden'
       s13 = 'Showed'
       s14 = 'Hidden' ; s14_1 = '(Not all)'

       s15 = 'Not known'
       s16 = 'Not found' ; s16_1 = 'Location'
       s17 = 'Restoring' ; s17_1 = 'folder'
       s18 = 'Hiding' ; s18_1 = 'folder'

       s19 = 'Configuring Explorer settings' ; s19_1 = 'Function'
       s20 = "'Check' not provided for"

       s21 = 'Hiding'    ; s21_1 = 'Duplicates of removable devices'
       s22 = 'Restoring' ; s22_1 = 'Duplicates of removable devices'
       s23 = "'Check' not provided for 'DuplicateDevicesHide'"

       s24 = 'Hiding'    ; s24_1 = 'Network Icon' ; s24_2 = 'Need to restart Explorer'
       s25 = 'Restoring' ; s25_1 = 'Network Icon' ; s25_2 = 'Need to restart Explorer'
       s26 = "'Check' not provided for 'NetIconHide'"

       s27 = 'Hiding'    ; s27_1 = 'Fast access' ; s27_2 = 'Need to restart Explorer'
       s28 = 'Restoring' ; s28_1 = 'Fast access' ; s28_2 = 'Need to restart Explorer'
       s29 = "'Check' not provided for 'FastAccessHide'"

       s30 = 'Clearing' ; s30_1 = 'Explorer icon Cache (iconcache*.db)'
       s31 = 'Removing'
       s32 = "'Check' and 'Default' not provided for 'ClearIconCache'"

       s33 = 'Clearing' ; s33_1 = 'Explorer Thumbnail Cache (thumbcache*.db)'
       s34 = "'Check' and 'Default' not provided for 'ClearThumbCache'"

       s35 = 'Setting' ; s35_1 = 'desktop Wallpapers' ; s35_2 = 'Disabled desktop wallpaper setting'
       s36 = 'Copying the file'
       s37 = ' Into the folder'
       s38 = '         Setting'
       s39 = "The file was not copied to the 'Images' folder of the current user!"
       s40 = "The location of the 'Images' folder of the current user was not found!"
       s41 = "Not Found Image File for Desktop Wallpaper, Location"
       s42 = 'Restoring' ; s42_1 = 'desktop Wallpapers'
       s43 = 'Setting'
       s44 = 'Not Found Desktop Wallpaper File Default'
       s45 = "'Check' not provided for 'SetWallPaper'"
    }

    '$Menu_Set_Group_Policy' = @{

        s1 = 'Configuring' ; s1_1 = 'Group Policy' ; s1_2 = 'using the utility' ; s1_3 = 'from MS'
        s2 = 'Just one .txt file of LGPO format is enough to configure GP. Parameters will be showed in the GP snap-in'
        s3 = 'Parameters will be added/replaced if already configured. GP comment files are copied during creation/config'
        s4 = 'Resetting the GP will also reset parameters from other menus configured through LGPO or GP snap-in'

        s5 = 'Current Status Group Policy'
        s6 = ' Configuration for' ; s6_1 = 'Computer'
        s7 = '     Configuration for' ; s7_1 = 'User'
        s8 = 'Options for selection'

        s9 = 'Configure GP from file     '
       s10 = 'Configure GP' ; s10_1 = 'with Your file'

       s11 = 'Create a Backup' ; s11_1 = 'of configured GP to' ; s11_2 = 'An existing file will be renamed'

       s12 = 'Reset all GP settings' ; s12_1 = 'Default, except those configured through Registry. Only .pol files are removed'

       s13 = 'No input' ; s13_1 = 'Return to Main Menu'
    }

    'Set-Group-Policy' = @{

        s1 = 'LGPO.exe utility not set or not found'
        s2 = 'No Group Policy Management snap-in in Windows, skipping execution'
        s3 = 'Error creating folder'
        s4 = 'No path specified for Group Policy settings files'
        s5 = 'GP settings file not found'

        s6 = 'Configuring Group Policies' ; s6_1 = 'Function'
        s7 = 'Close all windows of MMC snap-ins'
        s8 = 'Copying file'
      s8_1 = '          to'
        s9 = 'Applying' ; s9_1 = 'GP settings' ; s9_2 = 'from a file'
       s10 = "Failed to apply Group Policy settings.`n   Error in file"
       s11 = 'Completed'
       s12 = 'The parameters will take effect immediately, but it is better to reboot!'
       s13 = 'Found' ; s13_1 = 'Not found'
       s14 = 'Applied parameters found' ; s14_1 = 'Not configured'
       s15 = 'File creation'
       s16 = 'No Group Policy configured, skip!'
       s17 = 'Found your GP settings'
       s18 = 'Backup your GP settings in'
       s19 = 'Removing file'
       s20 = 'Getting GP parameters from configuration for Computer'
       s21 = 'Saving a Backup of your file'
       s22 = 'Copying file from Windows folder'
       s23 = 'No configured GP with configuration for Computer!'
       s24 = 'Getting GP parameters from configuration for User'
       s25 = 'No configured GP with configuration for User'

       s26 = 'Reset all Group Policies' ; s26_1 = 'Function'
       s27 = 'Updating GP parameters ...'
       s28 = 'No Group Policy configured'
    }

    '$Menu_Set_Lock_FilesExe' = @{

        s1 = 'Prevent run of EXE files by name' ; s1_1 = 'Use carefully, files can affect Windows boot!'
        s2 = 'A Lock can lead to errors in Eventlog due to the inability to start the application, but not for all files'
        s3 = '● = Already locked; ○ = Not locked'
        s4 = 'The list of exe files can be changed in the preset file, the current file'

        s5 = 'Current status'
        s6 = 'Options for selection'

        s7 = 'Lock' ; s7_1 = 'All' ; s7_2 = 'No message                      ' ; s7_3 = 'selectively' ; s7_4 = 'Entering numbers (1 3 5 ...)'
        s8 = 'Lock' ; s8_1 = 'All' ; s8_2 = 'When starting up, show a message' ; s8_3 = 'selectively' ; s8_4 = 'Entering numbers (1 3 5 ...)'

        s9 = 'Restore' ; s9_1 = 'All' ; s9_2 = 'Unlock files (Default)       ' ; s9_3 = 'selectively' ; s9_4 = 'Entering numbers (1 3 5 ...)'

       s10 = 'No input' ; s10_1 = 'Return to the Personal Settings menu'
    }

    'Set-Lock-FilesExe' = @{

        s1 = 'No description'
        s2 = 'No locks'
        s3 = 'Prevent run of EXE files' ; s3_1 = 'Function'
        s4 = 'Unlock files (Default)'
        s5 = 'Checking file locks'
        s6 = 'Configuring file locks'
        s7 = 'Enter the numbers with a space (Unlock)'
        s8 = 'Enter the numbers with a space (Lock)'
        s9 = 'Wrong choice!'
       s10 = 'Selected numbers'
       s11 = 'Not in preset'
       s12 = 'Program Locked'
       s13 = 'No locked and specified EXEs in the presets file'
       s14 = 'Completed'
    }

    '$Menu_Set_Network_Local' = @{

        s1 = 'Local Network' ; s1_1 = 'Configuring the minimum required network settings for sharing and other conditions'
        s2 = 'Automation of actions that are performed during manual configuration in sharing settings, + additional settings'
        s3 = 'IP settings, sharing your folders, access settings for them you need to do yourself'

        s4 = '         FDResPub Service' ;     s4_1 = '      mpssvc Service' ; s4_2 = 'BFE Service'
        s5 = '          fdPHost Service' ;     s5_1 = '       mpsdrv Driver'

        s6 = '            SMB1 Protocol' ;     s6_1 = ' Discovery (Private)'
        s7 = '      Unsafe guest logons' ;     s7_1 = '   Sharing (Private)'
        s8 = '          Automatic setup' ;     s8_1 = '  Discovery (Public)'
        s9 = '                                             Sharing (Public)'
      s9_1 = '                                           Discovery (Domain)'
      s9_2 = '                                             Sharing (Domain)'

       s10 = '     Public Folders (All)'
       s11 = 'Password protection (All)'

       s12 = 'Options for selection'

       s13 = 'Enable: ' ; s13_1 = 'SMB1 Protocol + Unsafe logons ' ; s13_2 = 'Needed to connect to legacy Windows' ; s13_3 = 'Disable'
       s14 = 'Enable: ' ; s14_1 = 'Network discovery/Services/Drv' ; s14_2 = 'For Private Network                ' ; s14_3 = 'Restore'
       s15 = 'Enable: ' ; s15_1 = 'File and Printer Sharing      ' ; s15_2 = 'For Private Network                ' ; s15_3 = 'Disable'
       s16 = 'Enable: ' ; s16_1 = 'Public Folder Sharing         ' ; s16_2 = 'All Networks                       ' ; s16_3 = 'Disable'
       s17 = 'Disable:' ; s17_1 = 'Password protection Sharing   ' ; s17_2 = 'All Networks                       ' ; s17_3 = 'Enable'

       s18 = 'Enable: ' ; s18_1 = 'Network discovery             ' ; s18_2 = 'For Public Network                 ' ; s18_3 = 'Disable'
       s19 = 'Enable: ' ; s19_1 = 'File and Printer Sharing      ' ; s19_2 = 'For Public Network                 ' ; s19_3 = 'Disable'

       s20 = 'Perform' ; s20_1 = '1-5 settings at once' ; s20_2 = 'First 5 options'

       s21 = 'Reset All Windows Firewall Rules' ; s21_1 = 'Default (Additional opportunity)'

       s22 = 'Restore All Settings' ; s22_1 = 'Default (And disable SMB1)'

       s23 = 'No input' ; s23_1 = 'Return to the Personal Settings menu'
    }

    'Set-Network-Local' = @{

        s1 = 'Disabled   '
        s2 = 'Enabling   '
        s3 = 'Disabling  '
        s4 = 'Enabled    '
        s5 = 'Unknown    '

        s6 = 'Allowed  '
        s7 = 'Denied   '

        s8 = 'Enabled ' ; s8_1 = 'Rules'
        s9 = 'Disabled' ; s9_1 = 'Rules' ; s9_2 = 'No access'

       s10 = 'Enabled   '
       s11 = 'Disabled  '
       s12 = 'Error     '

       s13 = 'Enabled ' ; s13_1 = 'Rules'
       s14 = 'Disabled' ; s14_1 = 'Rules'

       s15 = 'Enabled   '
       s16 = 'Disabled  '

       s17 = 'Enabled' ; s17_1 = 'Guest'
       s18 = 'Disabled'
       s19 = 'No access'

       s20 = 'Configuring Local Network Sharing' ; s20_1 = 'Function'
       s21 = 'SMB1 component will Enabled after reboot' ; s21_1 = 'SMB1 Component will Disabled after reboot'
       s22 = 'SMB1 component is already Enabled'        ; s22_1 = 'SMB1 component is already Disabled'
       s23 = 'Enabling'  ; s23_1 = 'SMB1 Component'
       s24 = 'Disabling' ; s24_1 = 'SMB1 Component'
       s25 = "'Check' not provided for 'SetSMB1'"

       s26 = 'Enabling Discovery (for Private Network)'
       s27 = 'Windows Firewall'; s27_1 = "Enabled 'Network Discovery' Rules"
       s28 = 'Enabling automatic setup of network connected devices'
       s29 = 'Enabling' ; s29_1 = "2 services in Automatic mode"
       s30 = 'Enabling Discovery (for Private Network)'
       s31 = 'Enabling' ; s31_1 = "2 services in Manual mode"
       s32 = "'Check' not provided for 'SetPrNetworkDiscovery'"

       s33 = 'Enabling: File and Printer Sharing (for Private Network)'
       s34 = 'Windows Firewall' ; s34_1 = "Enabled 'File and Printer Sharing' Rules"
       s35 = 'Disabling: File and Printer Sharing (for Private Network)'
       s36 = "'Check' not provided for 'SetPrivateSharing'"

       s37 = 'Enabling: Public Folder Sharing (for All Networks)'
       s38 = 'Configuring' ; s38_1 = "Sharing Settings"
       s39 = 'Access Rights Setting' ; s39_1 = "SecurityDescriptor for Sharing"
       s40 = "Adding full access rights for 'Everyone' group to a sharing folder"
       s41 = 'Disabling: Public Folder Sharing (for All Networks)'
       s42 = 'Removing' ; s42_1 = "Sharing Settings"
       s43 = 'Removing Access Rights' ; s43_1 = "SecurityDescriptor for Sharing"
       s44 = "Removing 'Everyone' group from sharing folder"
       s45 = "'Check' not provided for 'SetAllPublicFolders'"

       s46 = 'Disabling: Password protection Sharing'
       s47 = 'Enabling account' ; s47_1 = "Guest"
       s48 = 'Guest Account' ; s48_1 = "Enabled" ; s48_2 = "Disabled"
       s49 = 'Disabling' ; s49_1 = "Password protection"
       s50 = 'Enabling: Password protection Sharing'
       s51 = 'Disabling account' ; s51_1 = "Guest"
       s52 = 'Enabling' ; s52_1 = "Password protection"
       s53 = "'Check' not provided for 'AllPasswordProtect'"
       s54 = 'Need to reboot!'

       s55 = 'Enabling Discovery (for Public Network)'
       s56 = 'Disabling Discovery (for Public Network)'
       s57 = "'Check' not provided for 'SetPubNetworkDiscovery'"

       s58 = 'Enabling: File and Printer Sharing (for Public Network)'
       s59 = 'Disabling: File and Printer Sharing (for Public Network)'
       s60 = "'Check' not provided for 'SetPublicSharing'"

       s61 = 'Resetting all Windows Firewall Rules' ; s61_1 = "to Default"
       s62 = "Reset"
       s63 = "Reset Error"
       s64 = "'Check/Set' not provided for 'ResetAllFirewallRules'"
    }

    'Set-Sharing-Profile' = @{

        s1 = 'Cannot access the Windows Firewall registry key'
        s2 = 'No LLMNR default rules found for group'
        s3 = 'Restoring sharing settings rules'
        s4 = 'Configuring sharing settings rules'
        s5 = 'Function'
        s6 = 'File and Printer Sharing'
        s7 = 'Network discovery'
        s8 = 'Configuring' ; s8_1 = 'Rules' ; ; s8_2 = 'Current Profile Status'
        s9 = 'Restoring' ; s9_1 = 'Rules'
       s10 = 'Removing rule '
       s11 = 'Removing rules'
       s12 = 'Creating rule '
       s13 = 'All Rules restored'
       s14 = 'All Rules re-created'
       s15 = 'Based on the default Windows Firewall rule patterns'
    }

    '$Menu_Set_Network_Settings' = @{

        s1 = 'Network' ; s1_1 = 'Parameter Settings' ; s1_2 = 'For security' ; s1_3 = 'The first item [1] will disable the LAN!'
        s2 = 'For the Internet, an IPv4 component in a network connection is enough'
        s3 = 'But you need to leave the components: Bridges of Virtual Machines and Firewall (Antivirus)'

        s4 = ' LanmanServer Service' ; s4_1 = '    NetMeeting' ; s4_2 = '     Remote Assistance'
        s5 = '       NetBios driver' ; s5_1 = '    Remote MDM' ; s5_2 = 'Remote Assistance Task'
        s6 = '        DCOM protocol' ; s6_1 = '  Remote WinRM' ; s6_2 = 'RemoteRegistry Service'
        s7 = 'Administrative Shares' ; s7_1 = 'TrkWks Service' ; s7_2 = '        IKEEXT Service'

        s8 = '   Context Menu Share' ; s8_1 = ' IPv6 Protocol'
        s9 = '             DnsLLMNR' ; s9_1 = ' DnsResolution' ; s9_2 = '   NCSI Connect Status'
      s9_3 = '          DnsParallel' ; s9_4 = ' DnsDevolution'

       s10 = '  Web Blocking Bypass'

       s11 = 'Options for selection'

       s12 = 'Disable'                                      ; s12_2 = 'Disabling LAN Services                              ' ; s12_3 = 'Restore'
       s13 = 'Disable' ; s13_1 = 'Remote Access           ' ; s13_2 = 'And enable Manual mode of services: TrkWks, IKEEXT  ' ; s13_3 = 'Restore'
       s14 = 'Disable' ; s14_1 = 'Administrative Shares   ' ; s14_2 = 'C$, D$ etc.                                         ' ; s14_3 = 'Restore'
       s15 = 'Hide   ' ; s15_1 = 'Context Menu            ' ; s15_2 = 'Share and Give access to                            ' ; s15_3 = 'Restore'
       s16 = 'Disable' ; s16_1 = 'IPv6 protocol           ' ; s16_2 = 'Loopback for programs will work                     ' ; s16_3 = 'Restore'
       s17 = 'Disable' ; s17_1 = 'DNS Functions           ' ; s17_2 = 'LLMNR, Resolution, Devolution, ParallelAandAAAA     ' ; s17_3 = 'Restore'
       s18 = 'Set    ' ; s18_1 = 'NCSI Connect Status     '                                                                  ; s18_3 = 'Restore'
       s19 = 'Enable ' ; s19_1 = 'Websites Blocking Bypass'                                                                  ; s19_3 = 'Restore'

       s20 = 'Perform' ; s20_1 = '1-6 at Once' ; s20_2 = 'First 6 options'

       s21 = 'Open Network Connections' ; s21_1 = 'For manual settings'
       s22 = 'Local Network Menu      ' ; s22_1 = 'Configuring LAN Sharing'

       s23 = 'Restore All Settings' ; s23_1 = 'Default'

       s24 = 'No input' ; s24_1 = 'Return to the Personal Settings menu'
    }

    'Set-Network-Settings' = @{

        s1 = 'Enabled   '
        s2 = 'Disabled  '
        s3 = 'Error     '

        s4 = 'Disabled  '
        s5 = 'Enabled   '

        s6 = 'Hidden    '
        s7 = 'Not hidden'

        s8 = 'Enabled'
        s9 = 'Disabled' ;  s9_1 = 'value'
       s10 = 'Unknown'  ; s10_1 = 'value'

       s11 = 'Disabled'
       s12 = 'Disabled' ; s12_1 = '(Not all)'
       s13 = 'Disabled' ; s13_1 = '(Not GP)'
       s14 = 'Disabled' ; s14_1 = '(Not all, Not GP)'
       s15 = 'Not Disabled'

       s16 = 'Disabled    '
       s17 = 'Not Disabled'

       s18 = 'Disabled    '
       s19 = 'Not Disabled'

       s20 = 'Applied'
       s21 = 'No bypass'

       s22 = 'No address in presets'

       s23 = 'Configuring Network Settings' ; s23_1 = 'Function'
       s24 = 'Disabling LanmanServer Services, DCOM Protocol, NetBios Drivers'
       s25 = 'Disabling LanmanServer Services (port 445)'
       s26 = 'Disabling network service performance counters'
       s27 = '  Completed'
       s28 = 'Disabling NetBios Driver'
       s29 = 'Disabling DCOM Protocol'
       s30 = 'Restoring of LanmanServer Service, DCOM Protocol, NetBios Driver (Default)'

       s31 = "Hiding 'Share' and 'Give access to' items from the context menu"
       s32 = "Restoring 'Share' and 'Give access to' items in the context menu"

       s33 = 'Disabling NetMeeting, Remote MDM, Remote WinRM, Remote Assistance'
       s34 = 'Disabling NetMeeting'
       s35 = 'Disabling Remote MDM'
       s36 = 'Disabling Remote WinRM'
       s37 = 'Disabling Remote Assistance'
       s38 = 'Configuring 2 additional services in manual mode'
       s39 = 'Restoring NetMeeting, Remote MDM, Remote WinRM, Remote Assistance (Default)'

       s40 = 'Disabling Administrative Shares, Except IPC$ and Your Created'
       s41 = 'some backup tools need access to them'
       s42 = 'Restoring Administrative Shares (Default)'

       s43 = 'Disabling IPv6. Loopback for programs will work'
       s44 = 'Restoring IPv6 (Default)'
     s44_1 = 'Disabling DNS Functions' ; s44_2 = 'Restoring DNS Functions (Default)'

       s45 = 'Website blocking bypass already enabled' ; s45_1 = 'address'
       s46 = 'Enabling Website Block Bypass'
       s47 = 'No address in presets to bypass website blocking'
       s48 = 'Removing Website Block Bypass (Default)'
       
       s49 = 'Configuring NCSI (Network Connectivity Status Indicator)'
       s50 = 'Check NCSI (Network Connectivity Status Indicator)'
       s51 = 'Skipping NCSI configuring'
       s52 = 'Disabled NCSI setting'
       s53 = 'Restore NCSI (Network Connectivity Status Indicator) | Default'
      
      s100 = 'Need to reboot!'
    }

    '$Menu_Set_Photo_Viewer' = @{

        s1 = 'Restore the Standard Photo Viewer for'
        s2 = 'Restore support for image files and add to the menu to open them'
        s3 = 'Correct setting to open the specified image files, with the generation of Hash'
        s4 = 'You can change the list of extensions in the preset file, the current file'

        s5 = ' At the moment'
        s6 = '       Support'
        s7 = 'Extension'
        s8 = 'Options for selection'

        s9 = 'Restore Support Only' ; s9_1 = 'Restores all Windows Photo Viewer parameters'
       s10 = 'Restore Support + Assign' ; s10_1 = 'to the opening'

       s11 = 'No input' ; s11_1 = 'Return to the Personal Settings menu'
    }

    'Set-Photo-Viewer' = @{

        s1 = 'There are no specified extensions in the preset file'
        s2 = 'There are no specified extensions!'
        s3 = 'Restored' ; s3_1 = 'Probably'
        s4 = 'Not Restored'
        s5 = 'Assigned'
        s6 = 'Not Assigned'
        s7 = 'Check only one extension at a time!'
        s8 = "'Check/Default' not provided for setting up Standard Photo Viewer"
        s9 = "The 'Set-OwnerAndAccess' function is not loaded!"
       s10 = "The 'Set-Reg' function is not loaded!"
       s11 = 'Restoring' ; s11_1 = 'Standard Photo Viewer' ; s11_2 = 'Function'
       s12 = 'Returning support graphic files'
       s13 = 'Adding to the menu to support opening files'
       s14 = 'Restoring parameters' ; s14_1 = 'for'

       s15 = ""
       s16 = 'The correct assigning of these extensions' ; s16_1 = 'to open'
       s17 = 'With the restoration of the ban on changes to the registry key and the generation of Hash'
       s18 = 'Extension'

       s19 = 'Presets file not found'
    }

    'Set-PrivacySettingsOOBE' = @{

        s1 = 'Disable all privacy settings for OOBE mode, and in NTUSER.DAT'
    }

    '$Menu_Set_Program_Association' = @{

        s1 = 'Configuring File Associations and Protocols' ; s1_1 = 'For the current account'
        s2 = 'Correct setting, with HASH generation, optional parameters + access rights to the registry key'
        s3 = '● = Already Configured; ○ = Not configured; х = Skip settings'
        s4 = 'You can change the list of parameters in the preset file, the current file'

        s5 = 'Parameters in the preset'
        s6 = 'Options for selection'
        
        s7 = 'Configure' ; s7_1 = 'Specified Parameters for File Associations and Protocols'
        s8 = 'Configure by choice' ; s8_1 = 'It will be offered a choice of parameter numbers'

        s9 = 'No input' ; s9_1 = 'Return to the Personal Settings menu'
    }

    'Set-Program-Association' = @{

        s1 = 'Error in the preset string'
        s2 = 'Program file not found'
        s3 = 'Progid is not registered'
        s4 = 'Prohibited characters in the preset string'
        s5 = "'Check/Default' is not provided"
        s6 = 'Configuring' ; s6_1 = 'File Associations' ; s6_2 = 'Function'
        s7 = 'Enter parameter numbers'
        s8 = 'Wrong choice!'
        s9 = 'Selected parameters'
       s10 = 'Icon File not found'
       s11 = 'Skipped'
       s12 = 'Not specified parameters in the presets file'
    }

    '$Menu_Set_Registry_BackUp' = @{

        s1 = 'Backup registry hives' ; s1_1 = 'Creating Tasks for automatic backup of registry hives'
        s2 = 'The original RegIdleBackup backup task no longer works and will be disabled'
        s3 = 'You can restore registry hives through MSDaRT, if integrated into Windows (enter the menu: Shift + Reboot)'
        s4 = 'Backup folder'

        s5 = 'Task at the moment'
        s6 = 'Reserved registry hives'
        s7 = 'Options for selection'

        s8 = 'Create task ' ; s8_1 = 'Backup once a week on Mondays'
        s9 = 'Run the task' ; s9_1 = 'Backup now'

       s10 = 'Restore' ; s10_1 = 'Default. Remove task'
       s11 = 'No input' ; s11_1 = 'Return to the Personal Settings menu'
    }

    'Set-Registry-BackUp' = @{

        s1 = 'Reserved registry hives is not found'
        s2 = 'Exist'
        s3 = 'Does not exist'
        s4 = 'The task of backing up registry hives' ; s4_1 = 'Function'
        s5 = 'Creating' ; s5_1 = 'a task'
        s6 = 'Unable to create folder'
        s7 = 'Task to backup registry hives. To be able to restore Windows in case of problems. Folder'
        s8 = 'Runing' ; s8_1 = 'the task'
        s9 = 'Task started'
       s10 = 'Task not started, missing, or disabled'
       s11 = 'Removing' ; s11_1 = 'Task' ; s11_2 = 'to Default'
       s12 = 'Completed'
    }

    '$Menu_Set_Sound_VolumeDown' = @{

        s1 = 'Managing' ; s1_1 = 'Sound Profiles' ; s1_2 = 'For the current account'
      s1_3 = 'Decreasing the volume of wav audio files with the ffmpeg.exe utility'
        s2 = 'The volume level is approximately divided on a scale from 99% to 1% (Minimum volume)'
        s3 = 'Setting the Lower volume threshold is necessary to limit the decrease in the level of initially quiet audio files'
        s4 = 'The volume parameters can be changed in the preset file, the current file'

        s8 = '        Sound profile'

        s9 = 'Options for selection'

       s10 = 'Set Sound Profile'
       s11 = 'Set Profile without sound'

       s12 = 'Open Sound Control Panel'

       s13 = 'Restore' ; s13_1 = 'Sound Profile' ; s13_2 = 'Default'

       s14 = 'No input' ; s14_1 = 'Return to the Personal Settings menu'
    }

    'Set-Sound-VolumeDown' = @{

        s1 = 'Default'
        s2 = 'Without sound'
        s3 = 'Not known'
        s4 = 'Volume'
        s5 = 'Lower threshold'
        s6 = 'Preset not set'
        s7 = 'ffmpeg.exe file not found or not specified'
        s8 = 'Setting a sound profile' ; s8_1 = 'Function'
        s9 = 'Setting' ; s9_1 = 'a sound profile'
       s10 = 'Decrease' ; s10_1 = 'the Volume of audio files to'
       s11 = 'Lower threshold limit'
       s12 = 'Folder for modified files' ; s12_1 = 'Folder not created'
       s13 = 'Threshold'
       s14 = 'Result'
       s15 = 'No parameters'
       s16 = 'There was no file processing'
       s17 = 'Restoring' ; s17_1 = "the 'Default' Sound Profile"
       s18 = "'Check' not provided for 'SetVolumeDown'"
       s19 = 'Setting' ; s19_1 = "the Sound Profile 'No sound'"
       s20 = "'Check', 'Default' not provided for 'SetNoSound'"
    }

    '$Menu_Set_UAC' = @{

        s1 = 'User Account Control'
        s2 = 'Disabling or auto agreement with UAC leads to a serious security hole!'
        s3 = "If UAC isn't disabled, and disable Appinfo service, there will be an error instead of requesting admin rights!"
        s4 = 'It is strongly not recommended to disable or weaken UAC!'

        s5 = '        At the moment'
        s6 = '             UAC mode'

        s7 = '     UAC luafv driver' ; s7_1 = '                                     Appinfo Service (UAC)'
        s8 = '             Requests'
        s9 = '   Request processing'
       s10 = 'Access virtualization'
       s11 = '       Query behavior'

       s12 = 'Options for selection'

       s13 = 'Strengthened mode' ; s13_1 = 'UAC requests for all programs when accessing system data (Safer)'
       s14 = 'Weak mode        ' ; s14_1 = 'UAC requests Without darkening'
       s15 = 'Auto agreement   ' ; s15_1 = 'No UAC Requests Only for Users from the Administrators Group'
       s16 = 'Disable          ' ; s16_1 = 'No UAC Requests. Complete disable for all users'

       s17 = 'Restore' ; s17_1 = 'UAC Mode' ; s17_2 = 'Default' ; s17_3 = 'Recommended if UAC is disabled!'

       s18 = 'No input' ; s18_1 = 'Return to the Personal Settings menu'
    }

    'Set-UAC' = @{

        s1 = 'Default'
        s2 = 'Weak mode' ; s2_1 = 'Without darkening'
        s3 = 'Strengthened mode' ; s3_1 = 'Queries for all programs'
        s4 = 'Auto agreement' ; s4_1 = 'For Administrators only'
        s5 = 'Auto agreement' ; s5_1 = 'Configured via control panel'
        s6 = 'Disabled'
        s7 = 'Unknown mode'

        s8 = 'Not displayed'
        s9 = 'Are Displayed'; s9_1 = 'Default'
       s10 = 'Parameter Invalid'

       s11 = 'Through Interactive Desktop'
       s12 = 'Through Secure Desktop' ; s12_1 = 'Default'
       s13 = 'Parameter Invalid'

       s14 = 'Disabled'
       s15 = 'Enabled' ; s15_1 = 'Default'
       s16 = 'Parameter Invalid'

       s17 = 'Parameter does not exist'
       s18 = 'Agree Automatically'
       s19 = 'Strengthened mode' ; s19_1 = 'Queries for all programs'
       s20 = 'Queries for non-system programs' ; s20_1 = 'Default'
       s21 = 'Unknown'

       s22 = 'Configuring User Account Control' ; s22_1 = 'Function'
       s23 = 'Restoring' ; s23_1 = 'UAC mode' ; s23_2 = 'Default'
       s24 = 'Enabling' ; s24_1 = 'UAC Strengthened mode'
       s25 = 'Enabling' ; s25_1 = 'UAC Weak mode'
       s26 = 'Enabling' ; s26_1 = 'UAC Auto agreement mode'
       s27 = 'Complete Disable'
       s28 = 'Completed'
    }

    '$Menu_Set_Update_Windows' = @{

        s1 = 'Manage' ; s1_1 = 'Windows Update' ; s1_2 = 'Reduction: WU'
        s2 = 'Sometimes you need to reconfigure the WU after a reboot, as the parameters are not immediately accepted'
        s3 = 'The wuauserv service is needed for some types of Windows activations!'

        s4 = '          Update Mode' ;                             s4_1 = '                   Delivery Mode'
      s4_2 = '   Update MS Products' ; s4_3 = '                                                   Stub file'

        s5 = '           WU Showing' ; s5_1 =  '                                           Delivery Showing'
        s6 = '  wuauserv WU Service' ; s6_1 = 'WaaSMedicSvc Service' ;        s6_2 = '  DoSvc Delivery Serv'
        s7 = '       UsoSvc Service' ; s7_1 =    '                                             BITS Service'

        s8 = '             WU Tasks'
        s9 = '     Languages Update'
       s10 = '       LxpSvc Service'
       s11 = '           Lang Tasks'

       s12 = 'Disable Updates Completely'
       s13 = 'Manual Update Installation'
       s14 = 'Check and Notify updates only'

       s15 = 'Menu for Managing Driver Updates'; s15_1 = 'Disable or force deny driver updates'

     s15_2 = 'Disable update of language components' ; s15_3 = 'Enable ' ; s15_4 = 'Default'
     s15_5 = 'Enable updates for other MS products ' ; s15_6 = 'Disable' ; s15_7 = 'Default'

       s16 = 'Clear' ; s16_1 = 'Update Cache without Log' ; s16_2 = 'In case of update problems (Update log will remain)'
       s17 = 'Clear' ; s17_1 = 'Update Cache with Log   ' ; s17_2 = 'Complete cleaning'

       s18 = 'Restore all' ; s18_1 = 'Default'
       s19 = 'No input' ; s19_1 = 'Return to Main Menu             '
    }

    'Set-Update-Windows' = @{

        s1 = 'All options disabled                '
        s2 = 'Disabled (Not all options)          '
        s3 = 'Manually                            '
        s4 = 'Notify about availability           '
        s5 = 'Download and Notify to install      '
        s6 = 'Download and installation           '
        s7 = 'Default                             '
        s8 = 'Default                             '

        s9 = 'HTTP, without peering  '
       s10 = 'HTTP + (local network) '
       s11 = 'HTTP + (Private group) '
       s12 = 'HTTP + Internet peering'
       s13 = 'HTTP, without peering  '
       s14 = 'Disabled               '
       s15 = 'Default                '

     s15_1 = 'Enabled '
     s15_2 = 'Disabled'
     s15_3 = '--------'
     s15_4 = 'Skipped '

       s16 = 'Configuring Windows Update' ; s16_1 = 'Function'
       s17 = 'Disabling Updates Completely' ; s17_1 = 'Creating a stub file'
                                              s17_2 = 'Created    '
                                              s17_3 = 'Not created' ; s17_4 = 'A stub file exists' ; s17_5 = 'Deleting a stub file'
       
       s18 = 'The wuauserv service, needed for some types of Windows activations'
       s19 = '  Completed'

       s20 = 'Check and Notify updates only'
       s21 = 'Manual Update Installation'
       s22 = 'Complete Cleanup Updates Cache'
       s23 = 'Clearing Update Cache (without update log)'
       s24 = 'Removing cache in'
       s25 = '        Removing:'
       s26 = "'Check' not provided for 'ClearCache'"

       s27 = 'Restoring Updates (Default)' ; s27_1 = 'Disable Updates for Other MS Products (Default)'
                                           ; s27_2 = 'Enable Updates for Other MS Products' ; s27_3 = 'Completed'
       
       s28 = 'Disabling update of language components'
       s29 = 'Restoring a Language Components Update (Default)'
       
       s30 = 'Need to reboot!'
    }

    '$Menu_Set_Update_Drivers' = @{

        s1 = 'Driver Updates' ; s1_1 = 'Disable or Block'
        s2 = 'The first menu item [1] is official and is valid only for' ; s2_1 = 'Windows AutoUpdate!'
        s3 = "And drivers will be updated if you click the 'Check for Updates' button or if MS considers it necessary!"

        s4 = 'Blocking the ability of the WU to search for drivers by changing system parameters and rights to change them'
        s5 = 'After unblock, to search for a driver through the WU, you must remove or update the device driver manually'

        s6 = '              Drivers' ; s6_1 = 'Getting Metadata'
        s7 = '   Search for Drivers' ; s7_1 = '    Search Order'
        s8 = 'Installation Priority' ; s8_1 = '         Reports'
        s9 = '        Update Wizard'

       s10 = ' Ability to Determine'
       s11 = '    Ability to Search'

       s12 = 'Options for selection'

       s13 = 'Disable' ; s13_1 = 'AutoInstall Drivers' ; s13_2 = 'Not affected if MS considers installation necessary'
       s14 = 'Disable AutoInstall +' ; s14_1 = 'Block' ; s14_2 = 'Disable + Block the ability to search and update'

       s15 = 'Restore all' ; s15_1 = 'Default'

       s16 = 'No input' ; s16_1 = 'Return to Windows Update Menu'
    }

    'Set-Update-Drivers' = @{

        s1 = 'Download disabled          '
        s2 = 'Default                    '

        s3 = 'Disabled                   '
        s4 = 'Default                    '

        s5 = 'Equal                      '
        s6 = 'Default                    '

        s7 = 'Disabled                   '
        s8 = 'Default                    '

        s9 = 'Prohibited                 '
       s10 = 'Default                    '

       s11 = 'Disabled                   '
       s12 = 'Default                    '

       s13 = 'Sending disabled           '
       s14 = 'Partially disabled         '
       s15 = 'Default                    '

       s16 = 'Default                    '
       s17 = 'Blocked                    '

       s18 = 'Default                    '
       s19 = 'Blocked                    '

       s20 = 'Configuring Driver Updates' ; s20_1 = 'Function'

       s21 = 'Disabling Autoinstall Drivers'
       s22 = 'Force blocking driver updates'
       s23 = 'Blocking'
       s24 = 'Removing driver update Block'
       s25 = 'Removing Block from'
       s26 = 'Restoring Driver Updates (Default)'
       s27 = 'Need to reboot!'
    }

    '$Menu_Set_Windows_Defender' = @{

        s1 = 'Windows Defender' ; s1_1 = 'Add Exclusions or Configure'
        s2 = 'The script folder will be added to exclusions if it is not added through the GP or Defender'
        s3 = "If something doesn't configuring, try again after rebooting"
      s3_1 = "To disable Defender, you may need to manually disable 'Tamper Protection' in its settings"
        s4 = 'In the Preset File'

        s5 = '   Folder Exclusion'

        s6 = '           Defender'
        s7 = '            Startup' ;  s7_1 = '           Showing in Settings'
      s7_2 = '  Tamper Protection' ;  s7_3 = '                  Context menu'

        s8 = '  WinDefend Service' ;  s8_1 = ' SecurityHealthService Service'
        s9 = '   WdNisSvc Service' ;  s9_1 = '                 Sense Service'

       s10 = '    WdFilter Driver' ; s10_1 = '                 WdBoot Driver'
       s11 = '    WdNisDrv Driver' ; s11_1 = '               MsSecFlt Driver'

       s12 = '              Tasks'

       s13 = 'Options for selection'

       s14 = 'Add to List Defender Exclusions' ; s14_1 = 'Only Exclusions, and only if not yet added'
       s15 = ''
       s16 = 'Disable all' ; s16_1 = 'Autorun, Tasks, Services/Drivers, Hide context menu and Settings + Exclusions'

       s17 = 'Restore all' ; s17_1 = 'Default. After rebooting Defender is restored with a delay'

       s18 = 'No input' ; s18_1 = 'Return to Personal Settings menu'
    }

    'Set-Windows-Defender' = @{

        s1 = 'Removed and Disabled'
        s2 = 'Removed, not disabled'
        s3 = 'Disabled'
        s4 = 'Default'

        s5 = 'Enabled                '
        s6 = 'Disabled               '
        s7 = 'Disabled               '

        s8 = 'Hidden                 '
        s9 = 'Default                '
       s10 = 'Missing                '
       s11 = 'Error                  '

       s12 = 'Not required'
       s13 = 'Not added'
       s14 = 'Added'

       s15 = 'Specified exclusions' ; s15_1 = 'pcs'
       s16 = 'No exclusions specified'

       s17 = 'Adding folders or files to exclusions'
       s18 = 'Adding to exclusions' ; s18_1 = 'Skipped' ; s18_2 = 'Already added'

       s19 = 'Configuring Windows Defender' ; s19_1 = 'Function'

       s20 = '' ; s20_1 = ''
       s21 = 'Waiting for a'  ; s21_1 = 'driver to stop' ; s21_2 = 'after applying GP. No more than 10 sec'
       s22 = 'Disabling Defender Components' ; s22_1 = 'Checking disabled Defender Components'
       s23 = 'Deleting Tasks'
       s24 = 'Removing Autorun'
       s25 = 'Removing from the Autorun Old options that Defender adds. Apparently a bug'
       s26 = 'Hiding the context menu'
       s27 = 'No Windows Defender' ; s27_1 = 'Skiping remaining actions'
       s28 = 'Disabling Windows Defender Completely' ; s28_1 = 'Checking Completely Disable Windows Defender'
       s29 = 'Disabling Windows Defender'
       s30 = 'Disabling Services'
       s31 = 'Disabling Drivers'
       s32 = 'Adding to Windows Defender exclusions, if not already added'
       s33 = 'Windows Defender does not exist, skip adding to exclusions'
       s34 = 'Exclusions'
       s35 = 'Not provided removing added Windows Defender exclusions'

       s36 = 'Restoring Windows Defender (default)'
       s37 = 'Enabling Services'
       s38 = 'Enabling Drivers'
       s39 = 'Enabling Tasks'
       s40 = 'Returning Autorun'
       s41 = 'Restoring Context Menu'
       s42 = 'Removing the hide of the defender parameters from the settings'
       s43 = 'No Windows Defender' ; s43_1 = 'Skipping actions for restore'
       s44 = 'Need to reboot!'

       s45 = "Protection is not disabled, but the system app is already uninstalled: Microsoft.Windows.SecHealthUI"
     s45_1 = "Disable the 'Tamper Protection' option in the Defender settings to continue" ; s45_2 = 'AppXSvc services disabled'
       s46 = "Virus & threat protection" ; s46_1 = "'Virus & threat protection' settings" ; s46_2 = "Select 'Manage settings'"
       s47 = "Change the Tamper Protection setting to Off"
       s48 = "Waiting for Disabling"
       s49 = "'Tamper Protection' missing"
       s50 = "Skipping Windows Defender Settings, 'Tamper Protection' not disabled!"
       s51 = "'Tamper Protection' is disabled"
       s52 = "'Tamper Protection' not disabled!"
    }

    '$Menu_Set_Windows_Maintenance' = @{

        s1 = 'Windows Maintenance' ; s1_1 = 'Management and Perform'
        s2 = 'The ability to carry out 5 important sequential actions, with prohibited Maintenance'
        s3 = 'Or use the built-in standard Maintenance from the Security and Maintenance Center'
        s4 = 'It is enough to do the cleaning once every half a year. Depends on the situation and free disk space'
        s5 = 'Before performing any maintenance, close all applications and wait for completion!'

        s6 = 'At the moment'
        s7 = '  Maintenance' ; s7_1 = 'WakeUp' ; s7_2 = 'Internet'

        s8 = 'Menu for Installing Update Files  ' ; s8_1 = 'Install of MSU/CAB files from a folder:  \Files\Update'
        s9 = 'Menu for BackUp/Installing Drivers' ; s9_1 = 'BackUp/installing drivers from a folder: \Files\Update\Drivers'

       s10 = 'Perform' ; s10_2 = '4 options at a time' ; s10_3 = 'min'

       s11 = 'Generate' ; s11_1 = '.NET image  ' ; s11_2 = '.NET Framework for programs (Ngen.exe)'
       s12 = 'Clear' ; s12_1 = 'WinSxS folder  ' ; s12_2 = 'Cleaning and compressing old updates  '
       s13 = 'Clear' ; s13_1 = "System Drive $env:SystemDrive" ; s13_2 = 'Folders temp, logs, dumps, etc.       '
       s14 = 'Synchronize' ; s14_1 = 'time     ' ; s14_2 = 'Addit. servers' ; s14_3 = '(Possible delay)'

       s15 = 'Menu for disk optimization' ; s15_1 = 'Defragmentation, TRIM, Creating Separate Tasks'

       s16 = 'Start' ; s16_1 = 'Standard Windows Maintenance' ; s16_2 = 'Enables Maintenance and important tasks'
       s17 = 'Stop ' ; s17_1 = 'Standard Windows Maintenance'

       s18 = 'Deny Standard Windows Maintenance' ; s18_1 = 'Allow' ; s18_2 = 'Default'
       s19 = 'Deny WakeUp for Maintenance      ' ; s19_1 = 'Allow' ; s19_2 = 'Default'

       s20 = 'No input' ; s20_1 = 'Return to Main Menu'
    }

    'Set-Windows-Maintenance' = @{

        s1 = 'Prohibited'
        s2 = 'Allowed   '
        s3 = 'pcs' ; s3_1 = 'No' ; s3_2 = 'min' ; s3_3 = '/ResetBase' ; s3_4 = 'Without /ResetBase'

        s4 = 'Configuring Windows Maintenance' ; s4_1 = 'Function'
        s5 = 'Prohibiting of' ; s5_1 = 'Maintenance'
        s6 = 'Enabling' ; s6_1 = 'Maintenance Permission'
        s7 = 'Prohibition' ; s7_1 = 'WakeUp for Maintenance'
        s8 = 'Enabling' ; s8_1 = 'WakeUp Permission for Maintenance'

        s9 = 'Performing Windows Maintenance' ; s9_1 = 'Function'
       s10 = 'Performing' ; s10_1 = 'validation and/or generation of .NET Framework images'
       s11 = 'Command'
       s12 = 'Performing' ; s12_1 = 'Cleanup and Compressing the WinSxS Folder' ; s12_2 = 'Command'
       s13 = 'Upon completion by 20.0% - WinSxS cleaning was not required'
       s14 = "It happens 'Error: 2' - this is a small defect of Dism.exe or makecab.exe"
       s15 = "They cannot find the file $env:SystemDrive\Windows\Logs\CBS\CbsPersist_***.log after archiving it and removing it with makecab.exe"

       s16 = 'Performing' ; s16_1 = 'system disk Cleanup'
       s17 = 'Evaluation of files for cleaning occurs for all items, but there will be a pass for'
       s18 = "'Downloads' folder, Trash, Updates, Icon cache, User file history, BranchCache"
       s19 = 'Running' ; s19_1 = 'cleaning'
       s20 = 'Command: Сleanmgr.exe /sagerun:7777 | With the given parameters'
       s21 = 'Waiting for' ; s21_1 = 'the process to complete Cleanmgr.exe ...'
       s22 = 'Changing' ; s22_1 = 'the state of the window of the Cleanmgr.exe process, to help it terminate after Performed'
       s23 = 'Its window will be minimized periodically until the process is completed ...'
       s24 = 'The process Cleanmgr.exe has not yet completed, changing the window state'

       s25 = 'Performing' ; s25_1 = 'Time Synchronization' ; s25_2 = 'Internet' ; s25_3 = 'The result may be delayed'
       s26 = 'Command'
       s27 = 'Final list and order of servers' ; s27_1 = 'Removed'
       s28 = 'Synchronization' ; s28_1 = 'with all' ; s28_2 = 'servers in the list'
       s29 = 'Synchronization' ; s29_1 = 'with the first' ; s29_2 = 'server in the list'
       s30 = 'Server Sync Result' ; s30_1 = 'If multiple servers, then will showed any of the successful'
       s31 = 'Skipping' ; s31_1 = 'Time Synchronization' ; s31_2 = 'Internet'

       s32 = 'Preparing' ; s32_1 = 'for Standard Windows Maintenance'
       s33 = 'Enabling' ; s33_1 = 'important maintenance options'
       s34 = 'Running in the background' ; s34_1 = 'of Windows Standard Maintenance'
       s35 = 'Command' ; s35_1 = 'Running in the background can last up to 2 hours'
       s36 = 'Stoping' ; s36_1 = 'Standard Windows Maintenance' ; s36_2 = 'Command'
       s37 = 'Completed'
    }

    '$Menu_Set_Windows_Search' = @{

        s1 = 'Search, Indexing' ; s1_1 = 'Speeds up Windows Search' ; s1_2 = 'Cortana' ; s1_3 = 'Internet Search & Sync'
        s2 = "Indexing collects and updates the local catalog of all your files. Cortana collects everything in the 'Cloud'"
        s3 = 'Search service is needed for File Archiving and Windows Media Player Network Sharing Service'

        s4 = '   WSearch Service' ; s4_1 = '            Cortana'
        s5 = 'Indexing component' ; s5_1 = '         Web Search'
        s6 = '     Indexing task' ; s6_1 = '       Taskbar Icon'
                                    s7_1 = 'Showing in Settings'

        s8 = 'Options for selection'

        s9 = 'Disable Indexing      ' ;  s9_1 = 'Component Only          ' ;  s9_2 = 'Enable' ;  s9_3 = 'Default'
       s10 = 'Disable Search Service' ; s10_1 = 'WSearch service only    ' ; s10_2 = 'Enable' ; s10_3 = 'Default'
       s11 = 'Disable Cortana       ' ; s11_1 = 'And hide icon on taskbar' ; s11_2 = 'Enable' ; s11_3 = 'Default'

       s12 = 'Restore all' ; s12_1 = 'Default'

       s13 = 'No input' ; s13_1 = 'Return to Personal Settings menu'
    }

    'Set-Windows-Search' = @{

        s1 = 'Disabled  '
        s2 = 'Enabled   '
        s3 = 'Disabled  '

        s4 = 'Disabled' ; s4_1 = 'Disabled (Not Removed)'
        s5 = 'Not Disabled' ; s5_1 = 'Not Disabled (Not Removed)'

        s6 = 'Removed and Disabled'
        s7 = 'Removed (Not Disabled)' ; s7_1 = 'Removed' ; s7_2 = 'AppXSvc service disabled' ; s7_3 = 'AppXSvc and ClipSVC services disabled'

        s8 = 'Disabled'
        s9 = 'Not Disabled'
       s10 = 'Cortana Removed' ; s10_1 = 'Cortana Not Removed'

       s11 = 'Hidden                '
       s12 = 'Not hidden            ' ; s12_1 = 'No need'

       s13 = 'Configuring Windows Search' ; s13_1 = 'Function'
       s14 = 'Disabling' ; s14_1 = 'Indexing'
       s15 = 'Indexing component is already disabled'
       s16 = 'Restoring' ; s16_1 = 'Indexing'
       s17 = 'Indexing component is already enabled'
       s18 = "'Check' not provided for 'IndexDisable'"

       s19 = 'Disabling' ; s19_1 = 'Search Service'
       s20 = 'Enabling' ; s20_1 = 'Search Service'
       s21 = "'Check' not provided for 'WSearchDisable'"

       s22 = 'Disabling' ; s22_1 = 'Cortana' ; s22_2 = 'No Cortana package, not restored' ; s22_3 = 'Cortana is already installed'
       s23 = 'Removing' ; s23_1 = 'the Search shortcut from the Win + X menu'
       s24 = 'Not removed' ; s24_1 = 'the Search shortcut from the Win + X menu'
       s25 = 'Enabling' ; s25_1 = 'Cortana'
       s26 = 'Restoring' ; s26_1 = 'the Search shortcut in the Win + X menu'

       s27 = 'Need to reboot!'
    }

    '$Menu_Install_Offline_UpdateFiles' = @{

        s1 = 'Install updates' ; s1_1 = 'from folder' ; s1_2 = 'with files' ; s1_3 = 'Drivers are ignored'
        s2 = 'Windows Update is not needed because DISM is used. File names only affect sorting'
        s3 = 'The necessary sequence for updates is set: Cumulative (CU), Service Stack and Language (LIP)'
        s4 = 'CU update must be installed last and after Service Stack, both in one copy!'
        s5 = 'To reinstall the' ; s5_1 = 'for each file you need to press the number key' ; s5_2 = '20 seconds to choose'

        s6 = 'Installed Updates'

        s7 = 'CAB/ESD/WIM files in the \Files\Updates folder'
        s8 = 'MSU files in the \Files\Updates folder'

        s9 = 'Install' ;  s9_1 = 'Suitable' ; s9_2 = 'Update packages from full Editions (for LTSC)'
       s10 = 'Install' ; s10_1 = '     '

       s11 = 'No input' ; s11_1 = 'Return to Maintenance Menu'
    }

    'Install-Offline-UpdateFilesCAB' = @{

        s1 = 'The folder for updates does not exist'
        s2 = '7z.exe file not specified or not found'
        s3 = 'Temporary folder for Dism.exe not specified or not found'
        s4 = 'Not installed'
        s5 = 'Starting installing CAB/ESD/WIM files' ; s5_1 = 'Function'
        s6 = 'Pending   ' ; s6_1 = 'Request'
        s7 = 'Installed ' ; s7_1 = 'Request'
        s8 = 'Suitable  ' ; s8_1 = 'Install'
        s9 = 'Unsuitable' ; s9_1 = 'Skip   '
       s10 = 'Language pack'
       s11 = 'Cumulative Update' ; s11_1 = 'File Not suitable' ; s11_2 = 'File not Cumulative Update'
       s12 = 'Installation' ; s12_1 = 'With the update of integrated packages from full Editions'
                              s12_2 = 'No need to update integrated packages from full Editions'
                              s12_3 = 'Cumulative update is pending for installation to complete, reboot!'
                              s12_4 = 'First, install Latest Cumulative Update normally!'
       s13 = 'To re-install the update' ; s13_1 = 'press the number key'
       s14 = 'To skip any other'
       s15 = 'Skiping after 20 seconds'
       s16 = 'Waiting'
       s17 = 'Your choice'
       s18 = 'Key pressed' ; s18_1 = 'Install'
       s19 = 'Re-installing'
       s20 = 'Skiping installation'
       s21 = 'Creating a temporary folder'
       s22 = 'Extract file to'
       s23 = 'Perfoming installation'
       s24 = 'Command'
       s25 = 'Installation' ; s25_1 = 'Reboot required' ; s25_2 = 'Error' ; s25_3 = 'Done'
       s26 = 'Repeated installation' ; s26_1 = 'Command'
       s27 = 'Retrying Installation' ; s27_1 = 'Reboot required' ; s27_2 = 'Error' ; s27_3 = 'Done'
       s28 = 'Removing the temporary folder'
       s29 = 'Getting data from the update files ...' ; s29_1 = 'Suitable CAB/ESD/WIM update files Not found'
       s30 = 'Done'
       s31 = 'After installing the updates, a reboot is required!'
    }

    'Install-Offline-UpdateFilesMSU' = @{

        s1 = 'The folder for updates does not exist'
        s2 = '7z.exe file not specified or not found'
        s3 = 'Temporary folder for Dism.exe not specified or not found'
        s4 = 'Starting installing MSU files' ; s4_1 = 'Function'
        s5 = 'Getting data from the update files ...' ; s5_1 = 'Suitable MSU files not found'
        s6 = 'Cumulative Update'
        s7 = 'Bit architecture MSU is not suitable'
        s8 = 'Installing MSU' ; s8_1 = 'With the update of integrated packages from full Editions'
                                s8_2 = 'No need to update integrated packages from full Editions'
                                s8_3 = 'Cumulative update is pending for installation to complete, reboot!'
                                s8_4 = 'First, install Latest Cumulative Update normally!'
                                s8_5 = 'MSU file not Cumulative Update'
        s9 = 'Pending  '
       s10 = 'Installed'
       s11 = '---------'
       s12 = 'Creating a temporary folder' ; s12_1 = 'Extracting CAB from MSU' ; s12_2 = 'Installing extracted CAB' ; s12_3 = 'Installing MSU'
       s13 = 'Command'
       s14 = 'Installation' ; s14_1 = 'Reboot required' ; s14_2 = 'Error' ; s14_3 = 'Done'
       s15 = 'Removing the temporary folder'
       s16 = 'CAB file not extracted!'
       s17 = 'Completed'
       s18 = 'After installing the updates, a reboot is required!'
    }

    '$Menu_BackUp_Install_Drivers' = @{

        s1 = 'Saving Drivers' ; s1_1 = 'Backup or Installing Drivers from a folder'
        s2 = 'Allows you to restore drivers after a clean install of Windows'

        s3 = 'Saved drivers'
        s4 = 'Options for selection'

        s5 = 'Save' ; s5_1 = 'Drivers   ' ; s5_2 = 'To folder:   \Files\Update\Drivers'
        s6 = 'Install' ; s6_1 = 'Drivers' ; s6_2 = 'From folder: \Files\Update\Drivers'

        s7 = 'No input' ; s7_1 = 'Return to Maintenance Menu'
    }

    'BackUp-Install-Drivers' = @{

        s1 = 'No saved drivers in'
        s2 = 'Saving drivers' ; s2_1 = 'Function'
        s3 = 'To folder'
        s4 = 'Error creating folder'
        s5 = 'Completed'

        s6 = 'Adding drivers to the repository and installing' ; s6_1 = 'Function'
        s7 = 'From folder'
        s8 = 'Installing'
    }

    '$Menu_Features_Capabilities' = @{

        s1 = 'Configuring Windows Optional Features and Capabilities'
        s2 = 'Internet and WU is required to Install all Capabilities and Enable some Optional Features'
        s3 = '○ = Not configured;  ● = Already Configured (Skip settings);  х = Error (Skip settings)'
        s4 = 'You can change the list of parameters in the preset file, the current file'

        s5 = 'Optional Features' ; s5_1 = 'in the preset' ; s5_2 = '                                                Internet'
        s6 = 'Capabilities' ; s6_1 = 'in the preset'
        s7 = 'Options for selection'
        
        s8 = 'Save' ; s8_1 = 'a list of all possible Features/Capabilities for the preset file'

        s9 = 'Configure All' ;  s9_1 = 'Features    ' ;  s9_2 = 'Disable/Enable' ;  s9_3 = 'Configure selectively' ;  s9_4 = 'Entering numbers (1 3 5 ...)'
       s10 = 'Configure All' ; s10_1 = 'Capabilities' ; s10_2 = 'Remove/Install' ; s10_3 = 'Configure selectively' ; s10_4 = 'Entering numbers (1 3 5 ...)'

       s11 = 'Configure All' ; s11_1 = 'Features' ; s11_2 = 'Capabilities'

       s20 = 'No input' ; s20_1 = 'Return to the Personal Settings menu'
    }

    'Manage-Optional-Features' = @{

        s1 = 'Saving' ; s1_1 = 'a List of All Possible Optional Features (Except Exclusions)' ; s1_2 = 'File'
        s2 = 'Exclusion Patterns'
        s3 = 'Duplicate name'
        s4 = 'No matches (duplicate)'
        s5 = 'Matches into an Exclusions pattern'
        s6 = 'No matches'
        s7 = 'Illegal characters in the preset line (duplicate)'
        s8 = 'Illegal characters in the preset line'
        s9 = "'Default' not provided"
       s10 = 'Configuring' ; s10_1 = 'Windows Optional Features' ; s10_2 = 'Function'
       s11 = 'Enter numbers'
       s12 = 'Wrong choice!'
       s13 = 'Selected numbers'
       s14 = 'Skipped'
       s15 = 'Already Enabled'
       s16 = 'Already Disabled'
       s17 = 'Enabling'
       s18 = 'Disabling'
       s19 = 'Parameters not specified in preset file'
    }

    'Manage-Capabilities' = @{

        s1 = 'Saving' ; s1_1 = 'a List of All Possible Capabilities (Except Exclusions)' ; s1_2 = 'File'
        s2 = 'Exclusion Patterns'
        s3 = 'Duplicate name'
        s4 = 'No matches (duplicate)'
        s5 = 'Matches into an Exclusions pattern'
        s6 = 'No matches'
        s7 = 'Illegal characters in the preset line (duplicate)'
        s8 = 'Illegal characters in the preset line'
        s9 = "'Default' not provided"
       s10 = 'Configuring' ; s10_1 = 'Windows Capabilities' ; s10_2 = 'Function'
       s11 = 'Enter numbers'
       s12 = 'Wrong choice!'
       s13 = 'Selected numbers'
       s14 = 'Skipped'
       s15 = 'Already Installed'
       s16 = 'Already Removed'
       s17 = 'Installing'
       s18 = 'Removing'
       s19 = 'Parameters not specified in preset file'
       s20 = 'No internet access for PS'
    }

    'Highlight-Problem-Symbols' = @{

        s1 = 'Problem symbols in the path!'
        s2 = 'The Path is too long!'
    }

    'Write-Warning-Log' = @{

        s1 = 'This warning was written to the folder' ; s1_1 = 'since the file was not assigned'
    }

    'Save-Error' = @{

        s1 = 'This error was recorded in' ; s1_1 = 'since the file was not assigned'
        s2 = 'since there is no write access to the script folder'
    }

    'Check-State-Driver' = @{

        s1 = 'Error      '
        s2 = 'Missing    '
        s3 = 'Not Driver '
        s4 = 'Exist      '

        s5 = 'Stopped '
        s6 = 'Running '

        s7 = 'Boot       '
        s8 = 'System     '
        s9 = 'Automatic  '
       s10 = 'Manual     '
       s11 = 'Disabled   '
    }

    'Check-State-Registry' = @{

        s1 = "The registry key name is incorrect!`n   Key"
        s2 = 'Zero-length binary value'
        s3 = '(Default)'
        s4 = 'Right  '
        s5 = 'Wrong  '
        s6 = 'No access'
    }

    'Check-State-Service' = @{

        s1 = 'Error      '
        s2 = 'Missing    '
        s3 = 'Not service'
        s4 = 'Exist      '

        s5 = 'Stopped '
        s6 = 'Running '

        s7 = 'DelayedAuto'
        s8 = 'Automatic  '
        s9 = 'Manual     '
       s10 = 'Disabled   '
    }

    'Check-State-Task' = @{

        s1 = 'Task name not specified or incorrectly specified'

        s2 = 'Error      '
        s3 = 'Exist      '
        s4 = 'Missing    '

        s5 = '(SDDL not received)'
        s6 = '(Blocked)'
        s7 = '(Not blocked)'

        s8 = 'Enabled    '
        s9 = 'Disabled   '
    }

    'CleanUp-Files-Folders' = @{

        s1 = '   Exclusions'
        s2 = '     Cleaning'
        s3 = '     Deleting'
        s4 = '  Not deleted'
        s5 = '      Blocked'
        s6 = '      Closing'
        s7 = '      Deleted'
        s8 = '        Empty'
        s9 = '   Total size'
    }

    'RegHive-LoadUnload' = @{

        s1 = 'Wrong Prefix'
        s2 = "Must match the pattern: '^[\d\w-]+$' (Letters, numbers, symbols: '-', '_')"
        s3 = 'Registry hive file not found' ; s3_1 = 'Registry hive file not specified'
        s4 = 'Loading the registry hive' ; s4_1 = 'from'
        s5 = 'Skipped, the registry hive is already loaded on this path!'
        s6 = 'Error when loading the registry hive'
        s7 = 'Unloading the registry hive'
        s8 = 'Retrying to unload the hive'
        s9 = 'Something is blocking the hive, close all other applications!'
       s10 = 'Registry hive is not loaded'
    }

    'ReStart-Explorer' = @{

        s1 = "There will be no correct restart of the Explorer!`n Utility not found"
        s2 = 'It was not possible to complete the explorer process!'
    }

    'Save-HtmlLog' = @{

        s1 = 'Saving Console' ; s1_1 = 'Wait ...'
        s2 = 'The console output has been saved to'
    }

    'Set-DComPermission' = @{

        s1 = 'AppID not found'
        s2 = 'Skipping, incorrect specified access parameters' ; s2_1 = 'For type'

        s3 = '      Wrong'
        s4 = '      Right'

        s5 = 'Name' ; s5_1 = 'Type'
        s6 = 'SID does not convert to NTAccount'
    }

    'Set-Drv' = @{

        s1 = 'Error in Begin'
        s2 = 'Driver'
        s3 = 'Error in Process'
        s4 = 'Error in End'
        s5 = 'Not Driver'

        s6 = 'Boot'
        s7 = 'System'
        s8 = 'Automatic'
        s9 = 'Manual'
       s10 = 'Disabled'
    }

    'Set-LGP' = @{

        s1 = 'Error in Begin' ; s1_1 = 'Error in Process'
        s2 = 'Not specified or not found utility LGPO.exe'
        s3 = 'Applying Group Policy settings' ; s3_1 = 'Function'
        s4 = 'Close all windows of MMC snap-ins'
        s5 = "Error applying Group Policy settings.`n   File with erroneous GP parameters was saved to"
        s6 = 'Group Policies configured'
        s7 = 'There are no Group Policies in the system, parameters are configured in the registry'
        s8 = "There are no prepared parameters in `$Global:SettingsGP for setting Group Policies via 'LGPO.exe'"

        s9 = 'GP'
       s10 = "The registry key is not for Group Policy!`n   Key"
       s11 = "The registry key is wrong!`n   Key"
       s12 = "Parent section exclusion cannot be used for Group Policy!`n   Key"
       s13 = 'Zero-length binary value'
       s14 = 'Not a complete command for Group Policy!'
       s15 = 'Error in End'

       s16 = 'Done'
       s17 = 'Right'
       s18 = 'Wrong'
    }

    'Set-Reg' = @{

        s1 = 'Error in Begin'
        s2 = 'Registry'
        s3 = 'You cannot specify the same name when renaming!'
        s4 = "The registry key is invalid!`n   Key"
        s5 = 'Zero-length binary value'
        s6 = 'Error in Process'
        s7 = 'Error in End'

        s8 = 'Done'
        s9 = 'Right'
       s10 = 'No access'
       s11 = 'Wrong'
    }

    'Set-OwnerAndAccess' = @{

        s1 = 'Error in Begin'
        s2 = 'Error. String' ; s2_1 = 'Not converted into'
        s3 = 'Error in Process'
        s4 = "The registry key is invalid!`n   Key"
        s5 = "The registry key does not exist!`nKey" ; s5_1 = "Registry key is locked!`nKey"
        s6 = "You cannot exclude the parent registry key, `n   since you need to access it!`n   Key"
        s7 = 'File specified' ; s7_1 = 'Parent object will not be skipped!'
        s8 = "Skipped objects from recursion through Get-ChildItem, no access!`n   To unlock them, you need to specify them personally"
        s9 = 'Object'
       s10 = 'No Access to the object'
    }

    'Set-SettingsPageVisibility' = @{

        s1 = "Use of 'showonly:' not provided"
        s2 = 'Returning hidden sections from settings' ; s2_1 = 'Function'
        s3 = 'Returning'
        s4 = 'Hiding sections from settings' ; s4_1 = 'Function'
        s5 = 'Hiding'
        s6 = 'Settings'

        s7 = 'Unhidden '
        s8 = 'Hidden   '

        s9 = 'Unhidden'
       s10 = 'Hidden'
    }

    'Set-Svc' = @{

        s1 = 'Error in Begin'
        s2 = 'Service'
        s3 = 'Error in Process'
        s4 = 'Error in End'
        s5 = 'Blocked, run from'

        s6 = 'DelayedAuto'
        s7 = 'Automatic'
        s8 = 'Manual'
        s9 = 'Disabled'
    }

    'Set-TaskAccess' = @{

        s1 = 'Error'
        s2 = 'Task name not specified or incorrectly specified'

        s3 = 'Blocking '
    }

    'Set-Tsk' = @{

        s1 = 'Error in Begin'
        s2 = 'Task name not specified or incorrectly specified'
        s3 = 'Task'
        s4 = 'Error in Process'
        s5 = 'Unknown issue. Task'
        s6 = 'The problem with the removal. Task'
        s7 = 'Error in End'

        s8 = 'Enabled'
        s9 = 'Disabled'
       s10 = 'Error'
       s11 = 'No Task'
       s12 = 'Removed'
    }

    'Show-Result' = @{

        s1 = 'Not found'
    }

    'Start-ParentProcess' = @{

        s1 = "Setting startup type of the TrustedInstaller service to 'Manual' (Default)"
        s2 = 'Path does not exist'
        s3 = 'Process' ; s3_1 = "is not running, the problem is `$CmdLine or no access"
    }

    'Token-Impersonate' = @{

        s1 = 'Error in Begin'
        s2 = 'Error, the current shell is already with Impersonation!'
        s3 = 'Error, Impersonation is not reset!'
        s4 = 'Error getting token from SYSTEM (winlogon)!'
        s5 = 'Error creating identification with token from SYSTEM (winlogon)!'
        s6 = 'Error, token from SYSTEM (winlogon) was not received!'
        s7 = 'Impersonation Error for SYSTEM!'
        s8 = 'Error getting token from TrustedInstaller!'
        s9 = 'Error creating identification with token from TrustedInstaller!'
       s10 = 'Error, token from TrustedInstaller was not received!'
       s11 = 'Error in Process'
       s12 = 'Error. Impersonation for SYSTEM is NOT done!'
       s13 = 'Impersonation Error for TrustedInstaller!'
       s14 = 'Error. Impersonation for TrustedInstaller is NOT done!'
    }

    'Show-Info' = @{

        s1 = 'Configuring'
        s2 = 'Checking'
        s3 = 'Default'
        s4 = 'Component Removed'
    }

    # Below are the translations for Subgroups within the functions of Set-Configs -...

    'Set-Configs-ForRemoved' = @{

        s0 = 'Skipping configure. The script is only for version Windows 10 1809 (17763)'

        s1 = 'Component not removed'
        s2 = 'Need to reboot!'

        s3 = 'Defender'
        s4 = 'Hide the Settings Page: Settings -> Update & Security -> Windows Security'

        s5 = 'MRT'
        s6 = 'SmartScreen'

        s7 = 'Cortana'
        s8 = 'Hide the Settings Page: Settings -> Search'

        s9 = 'Content Delivery Manager | Windows spotlight on lock screen'
       s10 = 'Hide the Settings Page: Settings -> Phone'

       s11 = 'Unifed Telemetry Client'
       s12 = 'Hide the settings window from the settings: Settings -> Privacy -> Diagnostics & Feedback'

       s13 = 'Windows Error Reporting'

       s14 = 'Xbox'
       s15 = 'Hide the Settings Page: Settings -> Games'

       s16 = 'People Experience Host'

       s17 = 'Maps'
       s18 = 'Hide the Settings Page: Settings -> Apps -> Maps'

       s19 = 'Restore file'
       s20 = 'The original utcutil.dll file in WinSxS was not found or corrupted'
       s21 = 'Restore original from archive'
       s22 = 'Archive with original file not found'
       s23 = 'Restored'
       s24 = 'Not restored'
    }

    'Other-RetailDemo' = @{

        s1 = 'Disable "Retail Demo" service (hidden mode for retail)'
    }

    'Other-DMWapPushService' = @{

        s1 = 'Disable WAP Push message Routing Service'

        s2 = 'WAP Push Message Routing Service (needed for Unified Write Filter)'
    }

    'Other-WMPNetworkSvc' = @{

        s1 = 'Disable Windows Media Player Network Sharing Service'
    }

    'Other-WMPTaskUpdateLib' = @{

        s1 = 'Disable Task "Updating new files in the multimedia library"'
    }

    'Other-WMDRM' = @{

        s1 = 'Disable Access to the online audio protection service - Windows Media Digital Rights Management (DRM)'
    }

    'Other-Task1' = @{

        s1 = 'Disable Task "Cleaning the system drive during idle time"'
    }

    'Other-Task2' = @{

        s1 = 'Disable Task "Estimating the volume of the disk usage"'
    }

    'Other-Task3' = @{

        s1 = 'Disable Task "Moving Modern Apps to another drive as needed"'
    }

    'Other-Task4' = @{

        s1 = 'Disable Task "Checking volumes for fault tolerance"'
    }

    'Other-Task5' = @{

        s1 = 'Disable Task "Checking volumes for fault tolerance"'
    }

    'Other-Task6' = @{

        s1 = 'Disable Task "Measuring the speed and capabilities of the system"'
    }

    'Other-Task7' = @{

        s1 = 'Disable Task "Maintaining memory during idle time and error"'
    }

    'Other-Task8' = @{

        s1 = 'Disable Task "Maintaining memory during idle time and error"'
    }

    'Other-Task9' = @{

        s1 = 'Disable Task "Analyzing the energy consumption of the system"'
    }

    'Other-Task10' = @{

        s1 = 'Disable Task "Cleaning Retail Demo content"'
    }

    'Other-Task11' = @{

        s1 = 'Disable Task "Notifications of your location"'
    }

    'Other-Task12' = @{

        s1 = 'Disable Task "Notifications of your location"'
    }

    'Other-Task13' = @{

        s1 = 'Disable Task "Cleaning language parameters"'
    }
    
    'Other-Task14' = @{

        s1 = 'Disable Task "Maintenance drive spaces (analogue RAID, virtual disks)"'
    }

    'Other-Task15' = @{

        s1 = 'Disable Task "Maintenance drive spaces (analogue RAID, virtual disks)"'
    }

    'Other-Task16' = @{

        s1 = 'Disable Task "Loading voice models"'
    }

    'Other-Task17' = @{

        s1 = 'Disable Task "Active Directory"'
    }

    'Other-Task18' = @{

        s1 = 'Disable Task "Active Directory"'
    }

    'Other-Provisioning' = @{

        s1 = 'Disable ProvTool.exe tasks (for SYSPREP and change Windows edition)'

        s2 = "Tasks to reconcile packages during SYSPREP and others via 'ProvTool.exe':"
    }

    'Other-Displays' = @{

        s1 = 'Disable Pairing with Wi-Fi and device displays Bluetooth'
    }

    'Other-WiFi-Settings' = @{

        s1 = 'Disable auto-connect to unknown WiFi'

        s2 = 'Disable password auto-transfer to your WiFi to Microsoft server (WiFiSense):'
        s3 = 'Deny auto-connect to WiFi without password and from my contacts:'
        s4 = 'Prevent auto-connect to WiFi without passwords for all users found in this key:'
        s5 = '828 = All disabled;  829 = only auto connect to WiFi without password'
        s6 = '893 = All enabled;   892 = only auto connect to WiFi from your contacts'
        s7 = 'No keys for WiFi'
        s8 = 'Service for Windows Connect Now, configures access point or WiFi settings:'
        s9 = 'Tasks for background interaction via WiFi:'
       s10 = 'Synchronization and Discovery Tasks for WiFi and eSIM Profiles:'
    }

    'Other-ProjectionToPC' = @{

        s1 = 'Disable Projection to this computer'
        s2 = 'Disable Projection to this computer from other devices (except manual):'
    }

    'Other-Zone.Identifier' = @{

        s1 = 'Disable Zone.Identifier'

        s2 = 'Disable saving file origin zone information (Zone.Identifier) (will bug):'
        s3 = 'Enable Ignore Zone.Identifier:'
        s4 = 'Enable Ignore Zone.Identifier + hide it from file properties:'
    }

    'Other-Webcam-FrameServer' = @{

        s1 = 'Disable MS Frame Server for webcams'

        s2 = 'Disable MS Frame Server, solves or creates webcam blocking problem'
        s3 = 'Frame Server Allows access to the same camera for several Applications/Users:'
    }

    'Other-SoundRecorder' = @{

        s1 = 'Do not allow Sound Recorder to run'
    }

    'Other-DigitalLocker' = @{

        s1 = 'Disable Windows Marketplace Digital Locker'
        s2 = 'Deny the Digital Locker of the Windows Marketplace:'
    }

    'Other-FileHistory' = @{

        s1 = 'Disable File History (Archiving)'

        s2 = 'File History Service:'
        s3 = 'Disabling archiving:'
        s4 = 'Disabling the archive log:'
        s5 = "Disabling show of the 'Previous Versions' tab in the file properties"
        s6 = "And Remove the 'Restore Previous Version' item from the context menu:"
        s7 = 'Task for using archiving (Works only from Auto Maintenance):'
    }

    'Other-AutoStart' = @{

        s1 = 'Disable Automatic start of applications after a reboot'
    }

    'Set-Configs-Other' = @{

        s1 = 'Need to reboot!'
    }

    'Other2-IE' = @{

        s0 = 'Not Required'
        s1 = 'Configure Internet Explorer'

        s2 = 'Disable the first run wizard:'
        s3 = 'To prevent reuse of the Internet Explorer window:'
        s4 = 'Disable script debugging:'
        s5 = 'Turn off autocomplete forms:'
        s6 = 'Do not suggest Internet Explorer to use by default:'
        s7 = 'Default blank page in Internet Explorer:'
        s8 = 'Disable Integrated Windows Authentication:'
        s9 = 'Disable warning about starting a webpage through a secure connection:'
       s10 = 'Cache for temporary files = 337MB by default:'
       s11 = "Disable the warning 'Information transmitted via the Internet may become available to other users':"
       s12 = 'Disable the message about the possibility of using autocomplete:'
       s13 = 'Do not verify the digital signature of downloaded programs:'
       s14 = 'Turn off the use of recommended sites:'
       s15 = ''
       s16 = 'Open popups in a new tab:'
       s17 = 'When opening a new tab, open the New page:'
       s18 = 'Do not warn about closing tabs at the same time:'
       s19 = 'Always switch to a new tab when creating it:'
       s20 = 'Show status bar:'
       s21 = 'Disable Internet Connection Wizard (when you first start IE):'
       s22 = 'Disable autoscanning of feeds by schedule:'
       s23 = 'Do not automatically mark the feed as viewed:'
    }

    'Other2-IE-NewWindow' = @{

        s0 = 'Not Required'
        s1 = 'Open shortcuts and links from other programs in a new Internet Explorer window'
    }

    'Other2-IE-Yandex' = @{

        s0 = 'Not Required'
        s1 = 'Add Yandex search engine to Internet Explorer (RU)'

        s2 = "Adding Search Engine 'Yandex' to IE:"
        s3 = "Setting the Default Search Engine 'Yandex' in IE:"
        s4 = "Removing a user ID from the Yandex Search Engine in IE:"
        s5 = "Search 'Yandex' in IE not added"
        s6 = "Search 'Yandex' in IE added"
    }

    'Other2-IE-Google' = @{

        s0 = 'Not Required'
        s1 = 'Add Google Search to Internet Explorer'

        s2 = "Adding the 'Google' Search Engine to IE:"
        s3 = "Search 'Google' in IE not added"
        s4 = "Search 'Google' in IE added"
    }

    'Other2-IE-DeleteClose' = @{

        s0 = 'Not Required'
        s1 = 'Delete page cache when closing Internet Explorer'
    }

    'Other2-IE-DeleteAllClose' = @{

        s0 = 'Not Required'
        s1 = 'Delete all data when closing Internet Explorer: History, Pass, Forms, Cookies, Temporary files, etc.'
    }

    'Other2-IE-Cache-General' = @{

        s1 = 'Cleaning the IE cache | Sites only, Explorer (connected devices)'
        s2 = "Profile"
        s3 = "Warn from"
    }

    'Other2-IE-Cache-Cookies' = @{

        s1 = 'Cleaning the IE cache | Cookies (login to sites), Autofill (passwords, forms)'
        s2 = "Profile"
        s3 = "Warn from"
    }

    'Other2-IE-Cache-History' = @{

        s1 = 'Cleaning the IE cache | List of visited pages, History, Subscriptions, etc.'
        s2 = "Profile"
        s3 = "Warn from"
    }

    'Other2-WMP12' = @{

        s1 = 'Configure Windows Media Player 12'

        s2 = 'Accept License Agreement:'
        s3 = 'Do not add video files found in the image library:'
        s4 = 'Disable the automatic addition of music to the library:'
        s5 = 'Do not remove files from the computer when removing from the library:'
        s6 = 'Disallow automatic verification of protected file licenses:'
        s7 = 'The player has already started:'
        s8 = 'Do not save ratings in multimedia files:'
        s9 = 'Do not update library contents on first run:'
       s10 = 'Do not show media information from the Internet or update files:'
       s11 = 'Disable downloading licenses for the use of multimedia files:'
       s12 = 'Do not set the clock automatically on devices:'
       s13 = 'Do not save history of open files:'
       s14 = 'Do not send player usage data to Microsoft:'
       s15 = 'Disable Windows Media Player identification on Internet sites:'
       s16 = 'Disable Windows Media Player Update:'
       s17 = 'Do not use Windows Media Player in on-line guides:'
       s18 = 'Disable Player by video size at startup:'
       s19 = 'Do not change the license index of audio files:'
    }

    'Other2-WindowsMail' = @{

        s1 = 'Disable Windows Mail'
    }

    'Other2-NumLock' = @{

        s1 = 'Enable NumLock on the keyboard for everyone, including Login Screen'
    }

    'Other2-StickyKeysSHIFT' = @{

        s1 = 'Disable sticky SHIFT keys after 5 keystrokes'
    }

    'Other2-OnlineTipsSettings' = @{

        s1 = 'Disable Online Tips in Settings'
    }

    'Other2-StartupDelay' = @{

        s1 = 'Disable application startup delay'
    }

    'Other2-ShowErrorBSoD' = @{

        s1 = 'Show error number on blue screen BSoD'
    }

    'Other2-SmallCrashDump' = @{

        s1 = 'Enable the creation of a small memory dump upon failure'
    }

    'Other2-NoNewAppAlert' = @{

        s1 = 'Do not show the notification "A new application has been installed" (To be assigned as the default application)'
    }

    'Other2-FirstLogonAnimate' = @{

        s1 = 'Do not show user first sign-in animation'
    }

    'Other2-DefaultPrinter' = @{

        s1 = 'Do not let Windows manage my default printer'
    }

    'Other2-InputSwitch' = @{

        s1 = 'Disable notifications from Keyboard Layout (2004)'
    }

    'Other2-NetplwizPassword' = @{

        s1 = 'Return auto logon checkbox to "netplwiz.exe" settings (2004)'
    }

    'Other2-AcrylicOnLogon' = @{

        s1 = 'Disable Blur Effect on Sign-in Screen (1903)'
    }

    'Other2-AutoPlayDevices' = @{

        s1 = 'Disable AutoPlay for all media and devices'
    }

    'Other2-TaskManager' = @{

        s1 = 'Configure Task Manager'

        s2 = 'Task manager already configured'
    }

    'Other2-ControlPanelBag' = @{

        s1 = 'Remove/restore an Indexing Item in the Control Panel (fix bug)'

        s2 = 'Removing'
        s3 = 'Restoring'
        s4 = 'Fix is not required'
    }

    'Other2-UpdRestartNotify' = @{

        s1 = 'Show notification when your PC requires a restart to finish updating'
    }

    'Other2-PreviewBuilds' = @{

        s1 = 'Disable pre-release versions, insider + hide from the settings'
    }

    'Other2-RegistryMessages' = @{

        s1 = 'Hide messages in settings about the need to remove parameters in the registry, etc.'
    }

    'Other2-AdsInSettings' = @{

        s1 = 'Hide Windows Update Ads from Modern Settings'
    }

    'Other2-LockScreenCamera' = @{

        s1 = 'Disable The ability to use a web camera on the Lock screen'
    }

    'Set-Configs-Other2' = @{

        s1 = 'Need to reboot!'
    }

    'Spec-SleepStudy' = @{

        s1 = "Disable Tracing for SleepStudy (Connected Standby, Modern Sleep) - Semi-Sleep Mode 'S0'"

        s2 = 'Lock Tracing Installed'
        s3 = 'Lock Tracing Not Installed'
        s4 = 'Tracing Lock Not Removed'
        s5 = 'Lock Tracing Removed'
        s6 = 'Skip (S0 mode enabled)'
    }

    'Spec-wfpdiag' = @{

        s1 = 'Disable Firewall IPsec filter trace (wfpdiag.etl, Process Hacker enables this trace)'

        s2 = '       Done'
        s3 = '      Wrong'
        s4 = '      Right'
        s5 = '      Wrong'
    }

    'Spec-MeltdownSpectr' = @{

        s1 = 'Disable Meltdown and Spectr Fixes:'

        s2 = 'Disabling Meltdown and Spectr Fixes:'
    }

    'Spec-TurnOffNetDevice' = @{

        s1 = 'Prevent disabling network adapters to save power'

        s2 = 'Prevent disabling' ; s2_1 = 'Adapter'
        s3 = 'Disabling is already prohibited'
        s4 = 'Configured'
        s5 = 'Completed'
        s6 = 'Allow to turn off'
        s7 = 'Disabling is already allowed'
    }

    'Spec-DolbyDecMFT' = @{

        s1 = 'Restore support for Dolby Digital Decoder (AC3 sound) for LTSC x64/x86 1809'

        s2 = 'Restoring files from'
        s3 = 'Copying dll file x64 to' ; s3_1 = 'Copied' ; s3_2 = 'Not copied' ; s3_3 = 'Copying dll file x86 to'
        s4 = 'Registering dll x64 and x86' ; s4_1 = 'Registering dll x86' ; s4_2 = 'Registered' ; s4_3 = 'Not registered'
        s5 = 'Completed' ; s5_1 = 'Not restored' ; s5_2 = 'Support is already present'
        s6 = 'No archive'
        s7 = 'Removing Dolby Digital Decoder Support'
        s8 = 'Already removed support for Dolby Digital Decoder'
        s9 = 'Skip removing support, is a Windows component'
    }

    'Spec-ReservedStorage' = @{

        s1 = 'Disable and remove reserved storage'

        s2 = 'Completed' ; s2_1 = 'Already Disabled'
        s3 = 'Completed' ; s3_1 = 'Already Enabled'
    }

    'Spec-OfflineFiles' = @{

        s1 = 'Disable Offline Files in Sync Center'
    }

    'Spec-MappedDrivesAccess' = @{

        s1 = 'Turn on access to mapped drives, regardless of privilege mode (User/Admin)'
    }

    'Spec-DisableVbs' = @{

        s1 = 'Disable Windows Script Host (wscript.exe, cscript.exe, .vbs)'
    }

    'Spec-FixDCOM' = @{

        s1 = 'Fix Access settings errors: DistributedCOM 10016'
    }

    'Spec-ASLR' = @{

        s1 = 'Enable ASLR for all program | Address Space Layout Randomization (Exploit protection)'
    }

    'Spec-AppCompat' = @{

        s1 = 'Disable Program Compatibility Assistant'
    }

    'Spec-NotepadTxtFileRestor' = @{

        s1 = 'Restore the format of txt files and Notepad.exe settings'
        s2 = 'Not required'
    }

    'Spec-OneDrive-Remove' = @{

        s1 = 'Remove completely and disable OneDrive x64/x86'
        s2 = 'Disabling OneDrive installation the first time you login to new Accounts'
    }

    'Spec-OneDrive-Install' = @{

        s1 = 'Install OneDrive x64/x86'
        s2 = 'Restore OneDrive installation the first time you log in to new Accounts'
    }

    'Spec-EdgeAutoUpdate' = @{

        s1 = 'Disable and block Edge Chromium update/installation (it needs to be cleaned after Windows update)'
        s2 = 'Policies for installing and updating Edge work only when connected to Microsoft® Active Directory® domain'
    }

    'Spec-EdgePreloading' = @{

        s1 = 'Disable PreLoading Edge Browser and its tabs'
    }

    'Set-Configs-Special' = @{

        s1 = 'Need to reboot!'
    }

    'Apps-Store' = @{

        s1 = 'Disable All applications from Store and Store'
    }

    'Apps-Store-AutoUpdate' = @{

        s1 = 'Disable Auto Updates for Store Apps'
    }

    'Apps-NoOpenWith' = @{

        s1 = 'Disable Access to Windows Store'
    }

    'Apps-DeviceAccess' = @{

        s1 = 'Disable Access to AppStore applications from other devices to this device'

        s2 = 'Transfer between devices (Settings -> System -> General Features):'
    }

    'Apps-Services-PushToInstall' = @{

        s1 = 'Disable "Windows PushToInstall Service" Service'
    }

    'Apps-Services-InstallService' = @{

        s1 = 'Disable "Microsoft Store Install Service" Service'
    }

    'Apps-Services-WalletService' = @{

        s1 = 'Disable "Wallet Service" Service'
    }

    'Apps-Services-lfsvc' = @{

        s1 = 'Disable "Geolocation Service" Service'
    }

    'Apps-Services-WpnService' = @{

        s1 = 'Disable "Windows Push Notifications System Service" Service'
    }

    'Apps-Services-TabletInputService' = @{

        s1 = 'Disable "Touch Keyboard and Handwriting Panel Service" Service'
    }

    'Apps-Services-AarSvc' = @{

        s1 = 'Disable "Agent Activation Runtime" Service'
    }

    'Apps-Services-CaptureService' = @{

        s1 = 'Disable "CaptureService" Service'
    }

    'Apps-Services-AppXSVC' = @{

        s1 = 'Disable "AppX Deployment Service" Service'
    }

    'Apps-Services-ClipSVC' = @{

        s1 = 'Disable "Client License Service" Service'
    }

    'Apps-Services-LicenseManager' = @{

        s1 = 'Disable "Windows License Manager Service" Service'
    }

    'Apps-Services-wlidsvc' = @{

        s1 = 'Disable "Microsoft Account Sign-in Assistant" Service'
    }

    'Apps-Services-TokenBroker' = @{

        s1 = 'Disable "Web Account Manager" Service'
    }

    'Apps-Services-Appinfo' = @{

        s1 = 'Disable "Application Information" Service'
        s2 = 'Skip, UAC is not disabled'
    }

    'Apps-Tasks' = @{

        s1 = 'Disable AppStore Tasks'
    }

    'Apps-PushNotifications' = @{

        s1 = 'Disable Notifications and tile updates in the start menu'
    }

    'Apps-SettingSync' = @{

        s1 = 'Disable Sync'
    }

    'Apps-Tasks-Sync' = @{

        s1 = 'Disable Tasks of registration, access and synchronization with devices'
    }

    'Apps-Services-Sync' = @{

        s1 = 'Disable Sync Services'
    }

    'Apps-PrivacyAccess-ListLanguages' = @{

        s1 = 'Disable Privacy Access to "List of languages"'
    }

    'Apps-PrivacyAccess-VoiceRecogn' = @{

        s1 = 'Disable Privacy Access to "Voice Recognition"'
    }

    'Apps-PrivacyAccess-Input' = @{

        s1 = 'Disable Privacy Access to "Input Personalization"'
    }

    'Apps-PrivacyAccess-DiagData' = @{

        s1 = 'Disable Privacy Access to "Diagnostic data"'
    }

    'Apps-PrivacyAccess-Location' = @{

        s1 = 'Disable Privacy Access to "Location"'
    }

    'Apps-PrivacyAccess-Webcam' = @{

        s1 = 'Disable Privacy Access to "Webcam"'
    }

    'Apps-PrivacyAccess-Microphone' = @{

        s1 = 'Disable Privacy Access to "Microphone"'
    }

    'Apps-PrivacyAccess-Notifications' = @{

        s1 = 'Disable Privacy Access to "Notifications"'
    }

    'Apps-PrivacyAccess-UserAccount' = @{

        s1 = 'Disable Privacy Access to "Account Info"'
    }

    'Apps-PrivacyAccess-Contacts' = @{

        s1 = 'Disable Privacy Access to "Contacts"'
    }

    'Apps-PrivacyAccess-Calendar' = @{

        s1 = 'Disable Privacy Access to "Calendar"'
    }

    'Apps-PrivacyAccess-CallHistory' = @{

        s1 = 'Disable Privacy Access to "CallHistory"'
    }

    'Apps-PrivacyAccess-Email' = @{

        s1 = 'Disable Privacy Access to "Email"'
    }

    'Apps-PrivacyAccess-DataTasks' = @{

        s1 = 'Disable Privacy Access to "Tasks"'
    }

    'Apps-PrivacyAccess-Messaging' = @{

        s1 = 'Disable Privacy Access to "Messaging"'
    }

    'Apps-PrivacyAccess-Radios' = @{

        s1 = 'Disable Privacy Access to "Radios"'
    }

    'Apps-PrivacyAccess-BluetoothDev' = @{

        s1 = 'Disable Privacy Access to "Other devices"'
    }

    'Apps-PrivacyAccess-AppDiag' = @{

        s1 = 'Disable Privacy Access to "App Diagnostics"'
    }

    'Apps-PrivacyAccess-PhoneCall' = @{

        s1 = 'Disable Privacy Access to "Phone Call"'
    }

    'Apps-PrivacyAccess-CellularData' = @{

        s1 = 'Disable Privacy Access to "Cellular Data"'
    }

    'Apps-PrivacyAccess-Documents' = @{

        s1 = 'Disable Privacy Access to "Documents"'
    }

    'Apps-PrivacyAccess-Pictures' = @{

        s1 = 'Disable Privacy Access to "Pictures"'
    }

    'Apps-PrivacyAccess-Videos' = @{

        s1 = 'Disable Privacy Access to "Videos"'
    }

    'Apps-PrivacyAccess-FileSystem' = @{

        s1 = 'Disable Privacy Access to "File System"'
    }

    'Apps-PrivacyAccess-VoiceActivat' = @{

        s1 = 'Disable Privacy Access to "Voice Activation"'
    }

    'Apps-Clipboard' = @{

        s1 = 'Disable Clipboard History'
    }

    'Apps-TextInput' = @{

        s1 = 'Disable "Microsoft Text Input Application" service'
    }

    'Apps-CDPUserSvc' = @{

        s1 = 'Disable "Connected Devices Platform User Service"'
        s2 = 'Removing Cache Timeline'
        s3 = 'Hide the Settings Page: Settings -> Accounts -> Sync your settings'
        s4 = 'Hide the Settings Page: Settings -> Privacy -> Activity history'
    }

    'Apps-CDPSvc' = @{

        s1 = 'Disable "Connected Devices Platform Service"'
    }

    'Apps-NcbService' = @{

        s1 = 'Disable "Network Connection Broker" Service'
    }

    'Apps-Timeline' = @{

        s1 = 'Disable Activity history Timeline'
        s2 = 'Removing Cache Timeline'
    }

    'Apps-Tasks-Update' = @{

        s1 = 'Disable "Updating store apps" Tasks'
    }

    'Apps-Task1' = @{

        s1 = 'Disable task "CloudExperienceHost"'
    }

    'Apps-Task2' = @{

        s1 = 'Disable task "Checking and updating AppStore Maps"'
    }

    'Apps-Task3' = @{

        s1 = 'Disable task "Checking and updating AppStore Maps"'
    }

    'Apps-MapsBroker' = @{

        s1 = 'Disable "Downloaded Maps Broker" Service'
    }

    'Apps-AutoUpdateMapData' = @{

        s1 = 'Disable Auto-download map data and unsolicited traffic'
    }

    'Apps-FingerPrint' = @{

        s1 = 'Disable Windows Hello and Biometrics'

        s2 = 'Windows Biometric Service:'
        s3 = 'Credential Enrollment Manager Service:'
        s4 = 'The use of biometrics:'
        s5 = 'Windows Hello for Business and Using Biometrics:'
    }

    'Apps-DefenderMSAccount' = @{

        s1 = "Dismiss Microsoft Defender offer in the 'Windows Security' settings about signing in Microsoft account"
    }

    'Apps-DefenderSmartScreen' = @{

        s1 = "Dismiss Microsoft Defender offer in the 'Windows Security' about turning on the SmartScreen for Microsoft Edge"
    }

    'Apps-RecentlyAddedApps' = @{

        s1 = 'Disable show recently added apps in Start menu'
    }

    'Apps-PersonalSync' = @{

        s1 = 'Disable Synchronization of personal settings of programs and Windows'
    }

    'Apps-ContentDelivery' = @{

        s1 = 'Disable Content Delivery Manager | Windows spotlight on lock screen'

        s2 = 'Disable all SpotLight features on the lock screen and do not install Appx:'
        s3 = 'Hide the Settings Page: Settings -> Phone'
        s4 = 'Other parameters for Content Delivery Manager:'
    }

    'Apps-LockScreen' = @{

        s1 = 'Disable Ads-Images and Links on Lock Screen'
    }

    'Apps-LocationAndSensors' = @{

        s1 = 'Disable Location determination'
    }

    'Apps-Tablet-Services' = @{

        s1 = 'Disable Sensor Services for Tablets'

        s2 = 'A service for monitoring sensors, display brightness, screen rotation, etc.:'
        s3 = 'Sensor service, display rotation sensors, location, etc .:'
        s4 = 'Sensor Data Service:'
    }

    'Apps-BackgroundAccessAll' = @{

        s1 = 'Prevent launching and working in the Background for All Apps'
    }

    'Apps-BackgroundAccess' = @{

        s1 = 'Prevent launching and working in the Background for Apps (Except exclusions)'
    }

    'Set-Configs-SyncApps' = @{

        s1 = 'Need to reboot!'
    }

    'Tel-Services' = @{

        s1 = 'Disable Telemetry. Service. UnifedTelemetryClient'
    }

    'Tel-Parameters-Global' = @{

        s1 = 'Disable Telemetry. Main parameters. UnifedTelemetryClient'
    }

    'Tel-Tasks' = @{

        s1 = 'Disable Telemetry and Diagnostic Tasks'

        s2 = "Tasks 'CEIP' Software Quality Improvement Programs"
        s3 = 'Tasks of monitoring and implementing family safety'
        s4 = 'Tasks of collecting telemetric data of programs'
        s5 = "Task collects and downloads 'SQM' data for 'CEIP'"
        s6 = 'SIUF (System Initiated User Feedback) Tasks User Feedback'
        s7 = 'Task collector of complete information about computer and network'
        s8 = "Task for 'CEIP'"
        s9 = 'Mobile network metadata analysis task'
       s10 = 'Windows Diagnostics Infrastructure Website Task'
       s11 = 'Tasks of collecting and sending data about devices'
       s12 = 'DUSM task (Data Usage Subscription Management) for the mobile Internet'
       s13 = 'Task of sending error reports'
       s14 = 'Task of sending Diagnostics'
       s15 = 'Windows Update Telemetry Task'
       s16 = 'Task for Search for recommended troubleshooting methods'
    }

    'Tel-SmartScreen' = @{

        s1 = 'Disable SmartScreen'
    }

    'Tel-Parameters-2' = @{

        s1 = 'Disable Additional Telemetry and Diagnostic Parameters'

        s2 = "Receive updates and telemetry for the virus removal tool:"
        s3 = 'Additional telemetry collection:'
        s4 = "Additional data collection and sending of data 'PerfTrack' and 'DiagTrack':"
        s5 = 'Collection of personal data:'
        s6 = 'Disable sending NVIDIA telemetry and Tasks:'
    }

    'Tel-ErrorReporting' = @{

        s1 = 'Disable Windows Error Reporting'
    }

    'Tel-DeleteReports' = @{

        s1 = 'Delete all Windows Reports'
        s2 = 'Warn from'
    }

    'Tel-IE' = @{

        s1 = 'Disable Internet Explorer Telemetry'

        s2 = 'Deny Quality Improvement Program for IE'
        s3 = 'Disable Recommended Sites for IE'
        s4 = 'Disable enhanced search options'
        s5 = 'Prevent loading toolbars in InPrivate mode'
        s6 = "Always send the header 'do not track'"
    }

    'Tel-Reporting' = @{

        s1 = 'Disable Additional reporting'

        s2 = 'Prevent access to Windows Messenger and improvement program'
        s3 = 'Disabling AVS Web Check (Activation Telemetry)'
        s4 = 'Disable filtering data collection in InPrivate'
        s5 = 'Disable the ability to send error reports'
    }

    'Tel-Spellchecking' = @{

        s1 = 'Disable Spelling and correction of misspelled words'

        s2 = 'Spellchecking, error highlighting and prediction:'
    }

    'Tel-Linguistic' = @{

        s1 = 'Disable Improving keyboard input recognition'
    }

    'Tel-Insights' = @{

        s1 = 'Disable Artificial intelligence assistance while typing'
    }

    'Tel-SwiftKey' = @{

        s1 = 'Disable SwiftKey Typing assistance for RU and EN'
    }

    'Tel-AdvertisingInfo' = @{

        s1 = 'Disable Ad ID for user profiles'
    }

    'Tel-Autologgers' = @{

        s1 = 'Disable and Remove Logs: CloudExperienceHostOobe.etl, Cellcore.etl, WinPhoneCritical.etl'
    }

    'Tel-Office2016-2019' = @{

        s1 = 'Disable Microsoft Office 2016/2019 Telemetry'
        s2 = 'Microsoft Office is not installed'
    }

    'Tel-Office2016-2019+' = @{

        s1 = 'Disable Microsoft Office 2016/2019+ Telemetry (Online content, including help, will not work)'
        s2 = 'Microsoft Office is not installed'
    }

    'Tel-Office-Update' = @{

        s1 = 'Disable Microsoft Office update'
        s2 = 'Microsoft Office is not installed'
        s3 = 'Microsoft Office update tasks not found'
    }

    'Set-Configs-Telemetry' = @{

        s1 = 'Need to reboot!'
    }

    'Xbox-XblAuthManager' = @{

        s1 = 'Disable "Xbox Live Authentication Manager Service" Service'
    }

    'Xbox-XboxNetApiSvc' = @{

        s1 = 'Disable "Xbox Live Network Service" Service'
    }

    'Xbox-XblGameSave' = @{

        s1 = 'Disable "Saving Games on Xbox Live" Service'
    }

    'Xbox-XboxGipSvc' = @{

        s1 = 'Disable "Xbox Accessory Management Service" Service (Xbox Gaming Interface Protocol (GIP) over USB)'
    }

    'Xbox-BcastDVRUserService' = @{

        s1 = 'Disable "DVR User Service for Games and Broadcasts" Service'
    }

    'Xbox-Task1' = @{

        s1 = 'Disable task "\Microsoft\XblGameSave\XblGameSaveTask"'
    }

    'Xbox-Task2' = @{

        s1 = 'Disable task "\Microsoft\XblGameSave\XblGameSaveTaskLogon"'
    }

    'Xbox-AllowgameDVR' = @{

        s1 = 'Disable "Recording GAME Bar, WIN+G games and streaming"'
    }

    'Xbox-DownloadGameInfo' = @{

        s1 = 'Disable the download of game information'
    }

    'Xbox-GameUpdateOptions' = @{

        s1 = 'Disable game updates'
    }

    'Xbox-ListRecentlyPlayed' = @{

        s1 = 'Do not track the time of the last game session'
    }

    'Xbox-UseNexusForGameBar' = @{

        s1 = 'Do not open the game menu using the button on the controller'
    }

    'Xbox-ShowStartupPanel' = @{

        s1 = 'Disable Game Bar prompts'
    }

    'Xbox-GameMode' = @{

        s1 = 'Do not use game mode'
    }

    'Xbox-GameDVR_FSEBehavior' = @{

        s1 = 'Do not display the game menu during the game in full screen mode'
    }

    'Xbox-GameDVR' = @{

        s1 = 'Disable recording and broadcasting Windows games (User)'
    }

    'Xbox-AppCapture' = @{

        s1 = 'Disable capture of games and applications'
    }

    'Xbox-AudioCapture' = @{

        s1 = 'Disable audio capture'
    }

    'Xbox-CursorCapture' = @{

        s1 = 'Disable cursor capture'
    }

    'Xbox-PresenceWriter' = @{

        s1 = 'Disable Game Bar - GameBarPresenceWriter.exe'
        s2 = 'Not found'
    }

    'Xbox-GameSettingsPage' = @{

        s1 = 'Hide the Settings Page: Settings -> Gaming'
    }

    'Set-Configs-Xbox' = @{

        s1 = 'Need to reboot!'
    }

    'Expl-HiddenFiles' = @{

        s1 = 'Enable Show hidden files, folders and drives'
    }

    'Expl-FileExtensions' = @{

        s1 = 'Enable Show file name extensions'
    }

    'Expl-Bitlocker' = @{

        s1 = 'Hide Bitlocker options'

        s2 = 'Hide Bitlocker options from RMB menu and Explorer' ; s2_1 = 'It will be possible to control only through the control panel:'
    }

    'Expl-3DPrintEdit' = @{

        s1 = 'Hide 3D Print and 3D Edit items from Context Menu'

        s2 = 'No 3D Print and 3D Edit items in the context menu'
    }

    'Expl-SendToFaxDuplicate' = @{

        s1 = 'Remove from "Send To" Context Menu duplicate Fax recipient items'

        s2 = 'Removing'
        s3 = 'No duplicate'
    }

    'Expl-SendToItems' = @{

        s1 = 'Remove from "Send To" Context Menu items: Mail recipient, Documents, Fax recipient'

        s2 = 'Removing'
        s3 = 'Restoring'
    }

    'Expl-NewItems' = @{

        s1 = 'Remove from "New" Context Menu items: "Bitmap image, Contact, Rich Text format, Compressed (zipped) Folder"'
    }

    'Expl-RecycleBinSeparat' = @{

        s1 = 'Add separator to Recycle Bin context menu'
    }

    'Expl-CastToDevice' = @{

        s1 = 'Hide the "Cast to Device" item from the context menu for media/foto files'
    }

    'Expl-HideFixCompat' = @{

        s1 = 'Hide the "Fix compatibility problems" item from the context menu'
    }

    'Expl-HideEditWithPhotos' = @{

        s1 = 'Hide the "Edit with Photos" item from the context menu'
    }

    'Expl-HideCreateVideo' = @{

        s1 = 'Hide the "Create a new video" item from the context menu'
    }

    'Expl-HidePrintCmd' = @{

        s1 = 'Hide the "Print" item from the .bat and .cmd files context menu'
    }

    'Expl-HideIncludeInLibrary' = @{

        s1 = 'Hide the "Include in Library" item from folders context menu'
    }

    'Expl-HideSendTo' = @{

        s1 = 'Hide the "Send to" item from folders/files context menu'
    }

    'Expl-AddExtractMsi' = @{

        s1 = 'Add "Extract" item to .msi files context menu'
    }

    'Expl-ThisComputerIcon' = @{

        s1 = 'Show the "This Computer" icon on the desktop'
    }

    'Expl-OpenThisComputer' = @{

        s1 = 'Open "This computer" in Explorer'
    }

    'Expl-HidePeopleBar' = @{

        s1 = 'Hide the "People" icon from the taskbar'
    }

    'Expl-HideMeetNow' = @{

        s1 = 'Hide the "Meet Now" icon from the taskbar (2004)'
    }

    'Expl-HideNewsAndInterest' = @{

        s1 = 'Disable and Hide the "News and Interest" icon from the taskbar (21H1)'
        s2 = 'Not required'
    }

    'Expl-TaskbarTaskView' = @{
        
        s1 = 'Hide the "Task View" icon from taskbar'
    }

    'Expl-TaskbarChat' = @{
        
        s0 = 'Not Required'
        s1 = 'Hide the "Chat" icon from taskbar (W11)'
    }

    'Expl-Taskbarwidgets' = @{
        
        s0 = 'Not Required'
        s1 = 'Hide the "Widgets" icon from taskbar (W11)'
    }

    'Expl-UseCompactMode' = @{

        s1 = 'Enable Classic Compact Mode Explorer (21H1)'
        s2 = 'Not Required'
    }

    'Expl-SnapAssistFlyout' = @{
        
        s0 = 'Not Required'
        s1 = "Turn off the Show snap layouts when I hover over a window's maximize button box (W11)"
    }

    'Expl-LeftAlignmentTaskbar' = @{
        
        s0 = 'Not Required'
        s1 = 'Enable left alignment of the taskbar (W11)'
    }

    'Expl-ContextMenuWin10' = @{
        
        s0 = 'Not Required'
        s1 = 'Enable Explorer Context Menu as in Windows 10 (W11)'
    }

    'Expl-WallpaperQuality' = @{

        s1 = 'Using 100% picture quality when setting the desktop wallpaper (default is 85%)'
    }

    'Expl-ControlPanelItems' = @{

        s1 = 'Enable small icons in Control Panel'
    }

    'Expl-WebPublishingWizard' = @{

        s1 = 'Disable Web publication in the list of tasks for files'
    }

    'Expl-ContentFileUpdates' = @{

        s1 = 'Disable Updating Search Assistant Files'
    }

    'Expl-FeedbackRating' = @{

        s1 = 'Disable Feedback Rating'
    }

    'Expl-ActiveHelp' = @{

        s1 = 'Disable Active Help'
    }

    'Expl-HelpPaneF1' = @{

        s1 = 'Disable (helppane.exe) Help page runing by F1 key'
    }

    'Expl-ArrowsShortcuts' = @{

        s1 = 'Hide arrows on shortcuts'
        s2 = 'File found'
        s3 = 'No file'
    }

    'Expl-ColorWindowTitles' = @{

        s1 = 'Show color of elements in window titles'
    }

    'Expl-DarkThemeColor' = @{

        s1 = 'Enable dark theme color'
    }

    'Expl-ThemeTransparency' = @{

        s1 = 'Disable transparency effect'
    }

    'Expl-ThumbnailCache' = @{

        s1 = 'Disable automatic cleaning of file thumbnail cache'
    }

    'Expl-MaxCachedIcons' = @{

        s1 = 'Increase Icon Cache size to 8MB'
    }

    'Expl-FolderType' = @{

        s1 = 'Disable "Automatic Folder Type Discovery" in Explorer'
    }

    'Expl-NoThumbnailCache' = @{

        s1 = 'Disable Image thumbnail caching'
    }

    'Expl-ThumbsDBOnNetwork' = @{

        s1 = 'Disable thumbnails Caching in hidden thumbs.db files in network folders'
    }

    'Expl-DeleteConfirmation' = @{

        s1 = 'Enable Display delete confirmation dialog (for Recycle Bin)'
        s2 = 'Skipped, the parameter is incorrect'
    }

    'Expl-SeparateProcess' = @{

        s1 = 'Enable Launch the Explorer folders windows in a separate processes'
    }

    'Expl-OneDrive-Ads' = @{

        s1 = 'Disable OneDrive ads in Explorer (sync provider notifications)'
    }

    'Expl-PersonalizedTaskbar' = @{

        s1 = 'Disable Personalized Taskbar (2009 19042)'
        s2 = 'Not required'
    }

    'Set-Configs-Explorer' = @{

        s1 = 'Need to reboot!'
    }

    '' = @{

        s1 = '' ; s1_1 = '' ; s1_2 = ''
        s2 = ''
        s3 = ''
        s4 = ''
        s5 = ''
        s6 = ''
        s7 = ''
        s8 = ''
        s9 = ''
       s10 = ''
       s11 = ''
       s12 = ''
       s13 = ''
       s14 = ''
       s15 = ''
       s16 = ''
       s17 = ''
       s18 = ''
       s19 = ''
       s20 = ''
       s21 = ''
       s22 = ''
       s23 = ''
       s24 = ''
       s25 = ''
       s26 = ''
       s27 = ''
       s28 = ''
       s29 = ''
       s30 = ''
       s31 = ''
       s32 = ''
       s33 = ''
       s34 = ''
       s35 = ''
       s36 = ''
       s37 = ''
       s38 = ''
       s39 = ''
       s40 = ''
       s41 = ''
       s42 = ''
       s43 = ''
       s44 = ''
       s45 = ''
       s46 = ''
       s47 = ''
       s48 = ''
       s49 = ''
       s50 = ''
    }
}