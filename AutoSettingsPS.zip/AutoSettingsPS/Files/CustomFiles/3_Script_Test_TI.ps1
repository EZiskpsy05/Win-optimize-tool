﻿

if ( $Ru ) { $text = 'Свои настройки PowerShell | TrustedInstaller' }
else { $text = 'Custom PowerShell Settings | TrustedInstaller' }

Write-Host
Write-Host " ====================================================== " -ForegroundColor DarkGray
Write-Host "      $text" -ForegroundColor Green
Write-Host " ====================================================== " -ForegroundColor DarkGray
Write-Host

if ( $Ru ) { $text = 'Тут может быть ваш код PowerShell, выполняющийся с правами TrustedInstaller' }
else { $text = 'This might be your PowerShell code running under TrustedInstaller rights.' }

Write-Host " $Text"

