﻿
if ( $Ru ) { $text = 'Свои настройки PowerShell' }
else { $text = 'Custom PowerShell Settings' }

Write-Host
Write-Host " ==================================== " -ForegroundColor DarkGray
Write-Host "      $text" -ForegroundColor Green
Write-Host " ==================================== " -ForegroundColor DarkGray
Write-Host

if ( $Ru ) { $text = 'Тут может быть ваш код PowerShell' }
else { $text = 'This may be your PowerShell code.' }

Write-Host " $Text"

